"""Rerun the CQ-02 Velocity/Position probe with read-only PI evidence."""
import importlib.util
import os
from pathlib import Path
import sys

repo, build, output = map(lambda value: Path(value).resolve(), sys.argv[1:])
module_path = Path(__file__).with_name("reproduce-cq02-dynamics.py")
spec = importlib.util.spec_from_file_location("cq02_dynamics", module_path)
cq02 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cq02)
source_name = "src/falconfoc_virtual_motion.c"
source = cq02.axis_source((repo / "simulation" / source_name).read_text(encoding="utf-8"))
source = cq02.replace_once(
    source,
    '            printf(\n                "AXIS_TRACE,',
    '''            const float committed_a = vm.runtime.outer_velocity.integral_a;
            const float proposed_a = vm.runtime.outer_trial_a;
            if (!isfinite(committed_a) || !isfinite(proposed_a) ||
                fabsf(committed_a) > profile.runtime.motion.iq_limit_a ||
                fabsf(proposed_a) > profile.runtime.motion.iq_limit_a) {
                return 1;
            }
            printf("AXIS_PI,%u,%zu,%u,%u,%.9g,%.9g,%u,%u,%.9g,%u,%u\\n",
                   (unsigned)mode, phase, t, vm.virtual_time_us,
                   (double)committed_a, (double)proposed_a,
                   (unsigned)vm.runtime.accepted_outer_seen,
                   (unsigned)vm.runtime.outer_trial_seen,
                   (double)observation.iq_ref_a, observation.accepted_updates,
                   observation.saturated_updates);
            printf(
                "AXIS_TRACE,''',
)
source = cq02.replace_once(
    source,
    '        puts("AXIS_TRACE,mode,',
    '''        puts("AXIS_PI,mode,phase,phase_us,at_us,integral_a,trial_a,accepted_seen,"
             "trial_seen,iq_ref_a,updates,voltage_limited_updates");
        puts("AXIS_TRACE,mode,''',
)
output.mkdir(exist_ok=True, parents=True)
target = output / "cq03-axes.exe"
cq02.build_and_link(repo, build, target, "falconfoc-virtual-motion", source_name, source)
env = dict(os.environ, CQ02_RECOVERY_TRACE="1")
env.pop("CQ02_DAMPING_48", None)
for cutoff in (0, 48):
    cq02.command([target], build, output / f"axes-{cutoff}.csv", env=env)
    env["CQ02_DAMPING_48"] = "1"
assert cq02.digest(output / "axes-0.csv") == cq02.digest(output / "axes-48.csv")
print("Axis traces including PI witnesses are byte-identical at 0/48 Hz.")

