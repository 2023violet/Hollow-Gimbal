"""Re-run isolated CQ-03 policy trials from the frozen project root."""
import argparse
from pathlib import Path
import json
import os
import subprocess
import sys

from analyze import parse_profile

PROFILES = {"GENERIC_RESEARCH_MOTOR": ("2ca90021", ["--cogging"]),
            "CALIBRATION_SALIENT_MOTOR": ("66aded47", [])}

def checked(args, out=None, err=None):
    args = tuple(str(arg) for arg in args)
    print(">", subprocess.list2cmdline(args), flush=True)
    if out:
        with out.open("w", encoding="utf-8", newline="\n") as stream:
            if err:
                with err.open("w", encoding="utf-8", newline="\n") as errors:
                    subprocess.run(args, check=True, stdout=stream, stderr=errors)
            else:
                subprocess.run(args, check=True, stdout=stream, stderr=subprocess.STDOUT)
    else:
        subprocess.run(args, check=True)

def trial(root, frozen, out, compiler, asan, prefix, prototype, build_suffix):
    name = "proj-" + prefix
    project = root / name
    build = root / ("bld-" + prefix + build_suffix)
    python = sys.executable
    switches = ["--trace", "--transition"] if prototype else ["--trace"]
    checked([python, Path(__file__).with_name("project.py"), frozen, project, *switches])
    flags = "-DCQ03_PROTO_C" if prototype else ""
    link_flags = ""
    if asan:
        flags += " -fsanitize=address,undefined -fno-omit-frame-pointer"
        link_flags = "-fsanitize=address,undefined"
        if os.name == "nt":
            resource = subprocess.check_output([compiler, "-print-resource-dir"], text=True).strip()
            os.environ["PATH"] = str(Path(resource) / "lib/windows") + os.pathsep + os.environ["PATH"]
        os.environ["ASAN_OPTIONS"] = "halt_on_error=1"
        os.environ["UBSAN_OPTIONS"] = "halt_on_error=1:print_stacktrace=1"
    checked(["cmake", "-S", project / "simulation", "-B", build, "-G", "Ninja",
             f"-DCMAKE_C_COMPILER={compiler}", f"-DCMAKE_BUILD_TYPE={'Debug' if asan else 'Release'}",
             f"-DCMAKE_C_FLAGS={flags}", f"-DCMAKE_EXE_LINKER_FLAGS={link_flags}"],
            out / f"{prefix}-configure.log")
    checked(["cmake", "--build", build, "--parallel", 6, "--target", "falconfoc-virtual-calibrate"],
            out / f"{prefix}-build.log")
    for profile, (expected_review, switches) in PROFILES.items():
        exe = build / "falconfoc-virtual-calibrate.exe"
        command = [exe, "--profile-id", profile, *switches]
        preview = out / f"{prefix}-{profile}-preview.jsonl"
        checked(command, preview)
        with preview.open(encoding="utf-8") as stream:
            candidates = [json.loads(line) for line in stream]
        review = next(line["review_id"] for line in candidates if line["event"] == "CANDIDATE_PREVIEW")
        assert review == expected_review, (profile, review, expected_review)
        stem = out / f"{prefix}-{profile}"
        checked([*command, "--approve-candidate", review, "--cq-current-csv", stem.with_suffix(".csv")],
                stem.with_suffix(".jsonl"), stem.with_suffix(".err"))
        assert not stem.with_suffix(".err").stat().st_size
    checked([python, Path(__file__).with_name("analyze.py"), out, prefix],
            out / f"{prefix}-summary.txt")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("frozen", type=Path)
    parser.add_argument("out", type=Path, help="New directory for outputs and intermediate storage")
    parser.add_argument("--compiler", default="gcc")
    parser.add_argument("--asan", action="store_true")
    parser.add_argument("--arm", action="store_true")
    args = parser.parse_args()
    args.out.mkdir()
    build_root = args.out / "scratch"
    trial(build_root, args.frozen, args.out, args.compiler, args.asan, "ab", False, "")
    trial(build_root, args.frozen, args.out, args.compiler, args.asan, "abc", True, "")
    for profile in PROFILES:
        parsed = []
        for stage in ("ab", "abc"):
            stem = args.out / f"{stage}-{profile}"
            parsed.append(parse_profile(stem.with_suffix(".csv"), stem.with_suffix(".jsonl")))
        first, second = parsed
        assert all(metrics == second["cases"][name][group]
                   for name, variants in first["cases"].items() for group, metrics in variants.items())
    (args.out / "ab-parity.txt").write_text(
        "A/B per-scenario metrics, configuration and Safety exactly match between projections.\n",
        encoding="utf-8")
    if args.arm:
        checked([sys.executable, Path(__file__).with_name("arm_resource.py"), args.frozen,
                 args.out / "arm"])

if __name__ == "__main__":
    main()
