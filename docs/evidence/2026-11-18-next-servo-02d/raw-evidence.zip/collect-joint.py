from pathlib import Path
import csv,math,subprocess as sp,sys
from collections import defaultdict

root=Path(__file__).parent
data=root/"data"
data.mkdir(exist_ok=True)
build=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/"final-complete/simulation-clang"
for mode in ("characterization","holdout"):
    command=[build/"test-foc-impedance-robustness.exe","--joint-control-"+mode,"--trace"]
    print(sp.list2cmdline(command),flush=True)
    raw=sp.check_output(command)
    (root/f"{mode}-replay.csv").write_bytes(raw)
    result=defaultdict(list)
    for row in csv.reader(raw.decode("ascii").splitlines()):
        result[row[0]].append(row)
    for tag,rows in result.items():
        if rows[0][1] in ("case","kind","session","mode"):
            assert all(len(row)==len(rows[0]) for row in rows),tag
        with (data/f"{mode}-{tag.removeprefix('JOINT_').lower()}.csv").open("w",newline="") as f:
            csv.writer(f).writerows(rows)
        print(mode,tag,len(rows)-1,flush=True)
    summaries={}
    for line in csv.DictReader((data/f"{mode}-result.csv").open()):
        summaries[line["case"],line["variant"]]=line
    for (case,arm),s in summaries.items():
        if arm in "CD":
            assert int(s["ff_model_id"])!=0 and float(s["peak_ff_nm"])>0
        else:
            assert int(s["ff_model_id"])==0 and float(s["peak_ff_nm"])==0
        assert float(s["cutoff_hz"])==(48.0 if arm in "BD" else 0.0)
    # Diagnostic around the mechanical zero crossing; thresholds are for
    # localization only. Compare to the ideal mechanical velocity error to
    # avoid labelling negligible, noise-level differences as a wrong sign.
    near=defaultdict(list)
    for line in csv.DictReader((data/f"{mode}-trace.csv").open()):
        if line["stage"] not in ("4","5") or abs(float(line["model_velocity_rad_s"]))>.05:
            continue
        if int(line["inhibit"]):
            continue
        s=summaries.get((line["case"],line["variant"]))
        if s is None:
            continue
        damping=float(line["d_nm"])
        ideal=float(s["d_nm_s_per_rad"])*float(line["velocity_error_rad_s"])
        near[line["case"],line["variant"]].append((damping,ideal,abs(float(line["iq_request_a"])),
            abs(float(line["model_iq_a"])),abs(float(line["sensor_velocity_rad_s"])-float(line["damping_velocity_rad_s"]))))
    with (data/f"{mode}-zero-crossing.csv").open("w",newline="") as f:
        out=csv.writer(f)
        out.writerow(["case","arm","samples_abs_mechanical_speed_lte_0p05_rad_s","opposed_sign_when_ideal_above_1mNm",
                      "peak_abs_damping_nm","peak_request_a","peak_plant_a","peak_sensor_minus_damping_speed_rad_s"])
        for (case,arm),rows in sorted(near.items()):
            out.writerow([case,arm,len(rows),sum(abs(r[1])>=.001 and r[0]*r[1]<0 for r in rows),
                          max(abs(r[0]) for r in rows),
                          max(r[2] for r in rows),max(r[3] for r in rows),max(r[4] for r in rows)])
