
C:\Users\16429\AppData\Local\Temp\ff05_2_pr4qyh\builds\arm-before\CMakeFiles\falconfoc-board1.dir\C_\Users\16429\AppData\Local\Temp\ff05_2_pr4qyh\before\runtime\src\foc_pipeline.c.obj:     file format elf32-littlearm


Disassembly of section .text.foc_pipeline_require_rearm:

Disassembly of section .text.foc_pipeline_submit:

00000000 <foc_pipeline_submit>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	f891 8000 	ldrb.w	r8, [r1]
   8:	f100 07cc 	add.w	r7, r0, #204	@ 0xcc
   c:	f1b8 0f01 	cmp.w	r8, #1
  10:	4604      	mov	r4, r0
  12:	bf0c      	ite	eq
  14:	f890 e14e 	ldrbeq.w	lr, [r0, #334]	@ 0x14e
  18:	f890 e14f 	ldrbne.w	lr, [r0, #335]	@ 0x14f
  1c:	460d      	mov	r5, r1
  1e:	cf0f      	ldmia	r7!, {r0, r1, r2, r3}
  20:	b086      	sub	sp, #24
  22:	ae01      	add	r6, sp, #4
  24:	c60f      	stmia	r6!, {r0, r1, r2, r3}
  26:	683b      	ldr	r3, [r7, #0]
  28:	6033      	str	r3, [r6, #0]
  2a:	f8d4 3140 	ldr.w	r3, [r4, #320]	@ 0x140
  2e:	462f      	mov	r7, r5
  30:	f103 0c01 	add.w	ip, r3, #1
  34:	cf0f      	ldmia	r7!, {r0, r1, r2, r3}
  36:	f104 06e0 	add.w	r6, r4, #224	@ 0xe0
  3a:	f8c4 c140 	str.w	ip, [r4, #320]	@ 0x140
  3e:	c60f      	stmia	r6!, {r0, r1, r2, r3}
  40:	e897 000f 	ldmia.w	r7, {r0, r1, r2, r3}
  44:	e886 000f 	stmia.w	r6, {r0, r1, r2, r3}
  48:	782b      	ldrb	r3, [r5, #0]
  4a:	f104 07cc 	add.w	r7, r4, #204	@ 0xcc
  4e:	b90b      	cbnz	r3, 54 <foc_pipeline_submit+0x54>
  50:	f8c4 c148 	str.w	ip, [r4, #328]	@ 0x148
  54:	f1be 0f00 	cmp.w	lr, #0
  58:	d020      	beq.n	9c <foc_pipeline_submit+0x9c>
  5a:	2000      	movs	r0, #0
  5c:	f000 0c01 	and.w	ip, r0, #1
  60:	f884 c14c 	strb.w	ip, [r4, #332]	@ 0x14c
  64:	f884 c14d 	strb.w	ip, [r4, #333]	@ 0x14d
  68:	b350      	cbz	r0, c0 <foc_pipeline_submit+0xc0>
  6a:	ae01      	add	r6, sp, #4
  6c:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
  6e:	c70f      	stmia	r7!, {r0, r1, r2, r3}
  70:	f1b8 0f01 	cmp.w	r8, #1
  74:	6833      	ldr	r3, [r6, #0]
  76:	603b      	str	r3, [r7, #0]
  78:	d10c      	bne.n	94 <foc_pipeline_submit+0x94>
  7a:	f8d4 3144 	ldr.w	r3, [r4, #324]	@ 0x144
  7e:	3301      	adds	r3, #1
  80:	f8c4 3144 	str.w	r3, [r4, #324]	@ 0x144
  84:	f504 7480 	add.w	r4, r4, #256	@ 0x100
  88:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
  8a:	c40f      	stmia	r4!, {r0, r1, r2, r3}
  8c:	e895 000f 	ldmia.w	r5, {r0, r1, r2, r3}
  90:	e884 000f 	stmia.w	r4, {r0, r1, r2, r3}
  94:	4660      	mov	r0, ip
  96:	b006      	add	sp, #24
  98:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  9c:	f8d4 2090 	ldr.w	r2, [r4, #144]	@ 0x90
  a0:	4629      	mov	r1, r5
  a2:	a801      	add	r0, sp, #4
  a4:	f7ff fffe 	bl	0 <foc_device_sim_submit>
			a4: R_ARM_THM_CALL	foc_device_sim_submit
  a8:	2800      	cmp	r0, #0
  aa:	d1d6      	bne.n	5a <foc_pipeline_submit+0x5a>
  ac:	f8d4 3150 	ldr.w	r3, [r4, #336]	@ 0x150
  b0:	b123      	cbz	r3, bc <foc_pipeline_submit+0xbc>
  b2:	f8d4 0154 	ldr.w	r0, [r4, #340]	@ 0x154
  b6:	4629      	mov	r1, r5
  b8:	4798      	blx	r3
  ba:	e7cf      	b.n	5c <foc_pipeline_submit+0x5c>
  bc:	2001      	movs	r0, #1
  be:	e7cd      	b.n	5c <foc_pipeline_submit+0x5c>
  c0:	f1b8 0f01 	cmp.w	r8, #1
  c4:	d1e6      	bne.n	94 <foc_pipeline_submit+0x94>
  c6:	f504 7490 	add.w	r4, r4, #288	@ 0x120
  ca:	e7dd      	b.n	88 <foc_pipeline_submit+0x88>

Disassembly of section .text.foc_pipeline_emit_inhibit:

Disassembly of section .text.foc_pipeline_stop:

Disassembly of section .text.foc_pipeline_accept_time:

Disassembly of section .text.foc_pipeline_after_recovery:

Disassembly of section .text.foc_pipeline_input_newer:

Disassembly of section .text.foc_pipeline_ready_inputs:

Disassembly of section .text.foc_pipeline_init:

Disassembly of section .text.foc_pipeline_set_command:

Disassembly of section .text.foc_pipeline_arm:

Disassembly of section .text.foc_pipeline_start:

Disassembly of section .text.foc_pipeline_request_inhibit:

Disassembly of section .text.foc_pipeline_clear_fault:

Disassembly of section .text.foc_pipeline_step_guarded:

Disassembly of section .text.foc_pipeline_step:
