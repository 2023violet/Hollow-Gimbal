import hashlib,json,pathlib,shutil,uuid
from audit import OUT,ROOT,ENV,run,copy_source
dest=OUT/'gates';repo=OUT/'gate-repo'
assert not dest.exists() and not repo.exists()
temp=pathlib.Path('D:/')/('im04-'+uuid.uuid4().hex[:8]);temp.mkdir(exist_ok=False)
env=ENV.copy();env['TEMP']=env['TMP']=str(temp)
run(dest,'clone',['git','clone','--local','--no-hardlinks','--single-branch','--branch','codex/falconfoc-v2-vm01a',ROOT,repo],env=env)
# Git checkout has platform line endings; overlay immutable snapshot without altering it.
for p in (OUT/'snapshot').rglob('*'):
    if p.is_file():
        target=repo/p.relative_to(OUT/'snapshot');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for rel in ['runtime/src/foc_runtime.c','runtime/tests/test_foc_runtime_mailbox.c','runtime/tests/test_foc_motion_runtime.c','simulation/tests/test_foc_periodic_chain.c']:
    shutil.copy2(ROOT/rel,repo/rel)
copies=[]
for preset in ('fw-full-diag-carrier-debug','fw-standard-carrier-minsizerel','fw-tiny-carrier-minsizerel'):
    for suffix in ('elf','map'):
        rel=pathlib.Path('build')/preset/'output'/('falcon-foc-at32.'+suffix)
        before=ROOT/rel;after=repo/rel;assert not after.exists()
        after.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(before,after)
        digest=hashlib.sha256(before.read_bytes()).hexdigest()
        assert digest==hashlib.sha256(after.read_bytes()).hexdigest()
        copies.append({'source':str(before),'sha256':digest,'scope':'historical Legacy artifact; not rebuilt this round'})
(dest/'historical-legacy-artifacts.json').write_text(json.dumps(copies,indent=2))
for name,script,args in [
    ('legacy-host','scripts/flows/host/run_host_tests.ps1',['-CompilerPath','C:/mingw64/bin/gcc.exe']),
    ('source','scripts/gates/check_falconfoc_source_contract.ps1',[]),
    ('formatter','scripts/format_themis.ps1',['-Mode','check','-Scope','all']),
    ('scope-all-strict','scripts/gates/check_themis_quality_gate.ps1',['-Scope','all','-RequireCMakeFormatter','-Summary'])]:
    run(dest,name,['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',repo/script,'-RepoRoot',repo,*args],env=env,cwd=repo)
