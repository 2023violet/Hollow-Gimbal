#include "foc_runtime.h"
#ifdef HOST
#include <stdio.h>
int main(void){
printf("foc_runtime=%zu\n",sizeof(struct foc_runtime));
printf("foc_pipeline=%zu\n",sizeof(struct foc_pipeline));
printf("foc_runtime_config=%zu\n",sizeof(struct foc_runtime_config));
printf("foc_runtime_snapshot=%zu\n",sizeof(struct foc_runtime_snapshot));
printf("foc_runtime_sensor_slot=%zu\n",sizeof(struct foc_runtime_sensor_slot));
printf("foc_runtime_command=%zu\n",sizeof(struct foc_runtime_command));
printf("foc_runtime_lane=%zu\n",sizeof(struct foc_runtime_lane));
printf("foc_runtime_fast_input=%zu\n",sizeof(struct foc_runtime_fast_input));
printf("foc_current_context=%zu\n",sizeof(struct foc_current_context));
printf("foc_runtime_lifecycle_request=%zu\n",sizeof(struct foc_runtime_lifecycle_request));
printf("foc_runtime_lifecycle_result=%zu\n",sizeof(struct foc_runtime_lifecycle_result));
return 0;}
#else
char layout_foc_runtime[sizeof(struct foc_runtime)];
char layout_foc_pipeline[sizeof(struct foc_pipeline)];
char layout_foc_runtime_config[sizeof(struct foc_runtime_config)];
char layout_foc_runtime_snapshot[sizeof(struct foc_runtime_snapshot)];
char layout_foc_runtime_sensor_slot[sizeof(struct foc_runtime_sensor_slot)];
char layout_foc_runtime_command[sizeof(struct foc_runtime_command)];
char layout_foc_runtime_lane[sizeof(struct foc_runtime_lane)];
char layout_foc_runtime_fast_input[sizeof(struct foc_runtime_fast_input)];
char layout_foc_current_context[sizeof(struct foc_current_context)];
char layout_foc_runtime_lifecycle_request[sizeof(struct foc_runtime_lifecycle_request)];
char layout_foc_runtime_lifecycle_result[sizeof(struct foc_runtime_lifecycle_result)];
#endif
