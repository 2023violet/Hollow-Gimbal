from urllib.request import Request, urlopen
from pathlib import Path
from hashlib import sha256
import re, json,sys
root=Path(sys.argv[1]); where=root/"upstream.json"; logs=json.loads(where.read_bytes())
for label,repo,ref in [("VESC","vedderb/bldc","cb79df8960f77fcdf368f3b921d24d5a3ed86345"),
                      ("ODrive","odriverobotics/ODrive","a308314ed2ca613164b81e7bbdfacc53cd1859ff")]:
    try:
        url=f"https://api.github.com/repos/{repo}/git/trees/{ref}?recursive=1"
        with urlopen(Request(url,headers={"User-Agent":"FalconFOC provenance review"}),timeout=15) as response:
            tree=json.load(response)
        matches=[item["path"] for item in tree["tree"] if item["type"]=="blob"
                 and re.fullmatch(r"(?:Firmware/)?(?:LICENSE|COPYING)(?:\.[a-z]+)?",item["path"],re.I)]
        print(label,"top-level and Firmware license matches",matches)
        for path in matches:
            url=f"https://raw.githubusercontent.com/{repo}/{ref}/{path}"
            try:
                with urlopen(Request(url,headers={"User-Agent":"FalconFOC provenance review"}),timeout=15) as response:
                    data=response.read()
                dest=root/"upstream-source"/label/path
                dest.parent.mkdir(parents=True,exist_ok=True)
                dest.write_bytes(data)
                logs.append(dict(project=label,path=path,ref=ref,url=url,
                                 sha256=sha256(data).hexdigest(),bytes=len(data)))
                print(path, data[:150].decode(errors="replace"))
            except OSError as e:
                print(path,e)
    except OSError as e:
        print(label,e)
where.write_text(json.dumps(logs,indent=2)+"\n",encoding="utf8")

