from audit import OUT,run
run(OUT/'observations','mailbox',[OUT/'tests/runtime-final/build/test-foc-runtime-mailbox.exe'])
run(OUT/'observations','periodic-chain',[OUT/'tests/simulation-final/build/test-foc-periodic-chain.exe'])
