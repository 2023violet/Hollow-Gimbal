import shutil,sys
from audit import OUT,ROOT,CC,run,copy_source

dest=OUT/'review-mutation';repo=dest/'source';phase=sys.argv[1]
if phase=='before':
    copy_source(repo)
    source=repo/'runtime/src/foc_runtime.c';text=source.read_text(encoding='utf-8')
    old='!foc_safe_sequence_newer(sample->captured_us, previous->sample.captured_us, true)))) {\n        return FOC_RUNTIME_ERR_ORDER;\n    }'
    new=old.replace('        return FOC_RUNTIME_ERR_ORDER;',
        '        if (index < 2U) runtime->sensor_slots[index].electrical.angle_rad = 1.0f;\n        return FOC_RUNTIME_ERR_ORDER;')
    assert text.count(old)==1
    source.write_text(text.replace(old,new),encoding='utf-8')
    (dest/'mutation.txt').write_text(new,encoding='utf-8')
for rel in ['simulation/tests/test_foc_periodic_chain.c','simulation/tests/foc_system_angle_oracle.h']:
    shutil.copy2(ROOT/rel,repo/rel)
lane=dest/phase
run(lane,'configure',['cmake','-S',repo/'simulation','-B',lane/'build','-G','Ninja',
                     '-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+CC])
run(lane,'build',['cmake','--build',lane/'build','--parallel','4'])
run(lane,'executable',[lane/'build/test-foc-periodic-chain.exe','--system-angle-csv',lane/'data.csv'],
    expected=0 if phase=='before' else 1)
