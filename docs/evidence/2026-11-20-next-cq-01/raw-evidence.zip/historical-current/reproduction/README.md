# Historical Current and low-voltage evidence

Run from `D:/study/Software/Hollow-Gimbal-vm01a`. The original executable was
built before NEXT-CQ-01 edits. The final executable uses the working-tree
fix. Both are standalone Clang Debug simulation builds.

```powershell
$d = 'build/next-cq-01-historical'
cmake -S simulation -B "$d/clang" -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=clang
cmake --build "$d/clang" --target falconfoc-virtual-device test-foc-motor-id-virtual falconfoc-virtual-current --parallel 4
python tools/falconfoc-cli/falconfoc_cli.py --simulator "$d/clang/falconfoc-virtual-device.exe" virtual-demo --virtual-scenario current --advance-us 500 --duration-us 10000 --csv "$d/historical-current.csv" --json "$d/historical-current.json"
python "$d/reproduction/metrics-adapter.py" $d "$d/clang/test-foc-motor-id-virtual.exe"
python "$d/reproduction/wire-current.py" "$d/historical-current.wire" 0.4
python "$d/reproduction/wire-current.py" "$d/holdout-current-reverse.wire" -0.4
```

`after/commands.json` carries the complete signed holdout and 0.12 V test
arguments. The baseline and final runs use the same model and timeline. After
the final source build, `verify-current.py` compares the final CSV and legacy
JSON fields against the baseline before checking each signed 0.12 V run.

```powershell
python "$d/reproduction/verify-current.py" $d "$d/fixed-clang/falconfoc-virtual-device.exe"
python "$d/reproduction/metrics-adapter.py" "$d/after" "$d/fixed-clang/test-foc-motor-id-virtual.exe"
```

The `*.gdb` commands refer to the baseline MinGW GCC 16.2 Debug build
and its original paths. The low-voltage breakpoint is the instruction
returning `FOC_STATUS_ERR_VOLTAGE_LIMIT` in that build. The debugger traces
are local Host software observations.

`performance-summary.json` summarizes three alternating matched Release
Clang invocations per case. Ordinary and saturated path observations come
from the existing `test-foc-baseline --bench`. The captured low-voltage input
returns an error in the baseline and a valid saturated output in the final
build. Their timing measures different work. No Host timing is MCU WCET.

```powershell
cmake -S <source>/core -B <build> -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=clang
cmake --build <build> --target test-foc-baseline --parallel 4
<build>/test-foc-baseline.exe --golden
<build>/test-foc-baseline.exe --bench
clang -std=c11 -O3 -DNDEBUG -I core/include "$d/reproduction/low-voltage-perf.c" <build>/falconfoc-core.lib -o <build>/low-voltage-perf.exe
<build>/low-voltage-perf.exe <expected_status>
arm-none-eabi-gcc -std=c11 -Os -mcpu=cortex-m4 -mthumb -mfloat-abi=soft -Werror -fstack-usage -I <source>/core/include -I <source>/core/src -c <source>/core/src/foc_current.c -o <object>
```
