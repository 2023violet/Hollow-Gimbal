import json,shutil,sys,pathlib
from audit import OUT,ROOT,SRC,CC,ENV,run,before

REPO=OUT/'green-repo'
CHANGES=['simulation/tests/test_foc_periodic_chain.c','simulation/tests/foc_system_angle_oracle.h']

def overlay(repo):
    for rel in CHANGES:
        shutil.copy2(ROOT/rel,repo/rel)

def configure(dest,repo,project,asan=False,compiler=CC):
    args=['cmake','-S',repo/project,'-B',dest/'build','-G','Ninja',
          '-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+compiler]
    if asan:
        args+=['-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer',
               '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    run(dest,'configure',args)
    run(dest,'build',['cmake','--build',dest/'build','--parallel','4'])

phase=sys.argv[1]
if phase=='initial':
    dest=OUT/'initial'
    run(dest,'clone',['git','clone','--local','--no-hardlinks','--single-branch','--branch',
             'codex/falconfoc-v2-vm01a',ROOT,REPO])
    for rel in before:
        shutil.copy2(SRC/rel,REPO/rel)
    overlay(REPO)
    configure(dest,REPO,'simulation')
    run(dest,'system-angles',[dest/'build/test-foc-periodic-chain.exe','--system-angle-csv',
                             dest/'system-angle.csv'],expected=[0,1])
elif phase=='retry':
    dest=OUT/('retry-'+sys.argv[2]);overlay(REPO)
    configure(dest,REPO,'simulation')
    run(dest,'system-angles',[dest/'build/test-foc-periodic-chain.exe','--system-angle-csv',
                             dest/'system-angle.csv'],expected=[0,1])
else: raise SystemExit('unknown phase')
