from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.request import Request, urlopen
from hashlib import sha256
import json,sys
root=Path(sys.argv[1])
raw=root/"upstream-source"
raw.mkdir()
targets={
    "VESC": ("vedderb/bldc","cb79df8960f77fcdf368f3b921d24d5a3ed86345",
             ["motor/foc_math.c","motor/mcpwm_foc.c","COPYING"]),
    "SimpleFOC": ("simplefoc/Arduino-FOC","c72f063f3d2d2e26d49a22a7383310cf8f88134b",
                  ["src/common/foc_utils.cpp","src/BLDCMotor.cpp","LICENSE"]),
    "ODrive": ("odriverobotics/ODrive","a308314ed2ca613164b81e7bbdfacc53cd1859ff",
               ["Firmware/MotorControl/motor.cpp","Firmware/MotorControl/controller.cpp","LICENSE"]),
    "robot_mc": ("cyberbeast0829/robot_mc","2f1fb61ec081eb7a42ab8436ba8f1504fc529da7",
                 ["Core/Src/foc.c","Core/Src/calibration.c","LICENSE"]),
}
def fetch(task):
    label, repo, ref, path = task
    url=f"https://raw.githubusercontent.com/{repo}/{ref}/{path}"
    dest=raw/label/path
    try:
        data=urlopen(Request(url,headers={"User-Agent":"FalconFOC provenance review"}),timeout=15).read()
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
        return {"project":label,"path":path,"ref":ref,"url":url,
                "sha256":sha256(data).hexdigest(),"bytes":len(data)}
    except OSError as exc:
        return {"project":label,"path":path,"ref":ref,"url":url,"error":str(exc)}
tasks=[(label,repo,ref,path) for label,(repo,ref,paths) in targets.items() for path in paths]
with ThreadPoolExecutor(max_workers=8) as executor:
    logs=list(executor.map(fetch,tasks))
(root/"upstream.json").write_text(json.dumps(logs,indent=2)+"\n",encoding="utf8")
for log in logs:
    print(log["project"],log["path"],log.get("sha256",log.get("error")))

