import collections,csv,json,math,pathlib
from audit import OUT

def analyze(path):
    with path.open(newline='',encoding='utf-8') as stream: rows=list(csv.DictReader(stream))
    assert len(rows)==2587 and all(None not in r for r in rows)
    groups=collections.defaultdict(list)
    for r in rows: groups[r['case']].append(r)
    rms=lambda values: math.sqrt(sum(x*x for x in values)/len(values))
    result={}
    for name,items in groups.items():
        worst=max(items,key=lambda r:abs(float(r['phase_error_rad'])))
        entry={'samples':len(items),'worst':worst}
        for field in ['phase_error_rad','id_error_a','iq_error_a','e_quant','e_raw_velocity','e_lpf',
                      'e_time','e_model','e_numeric','duty_delta','bound_rad']:
            values=[float(r[field]) for r in items]
            entry[field]={'max_abs':max(map(abs,values)),'rms':rms(values)}
        entry['max_dq_norm_a']=max(math.hypot(float(r['id_error_a']),float(r['iq_error_a'])) for r in items)
        entry['max_speed_error_e_rad_s']=max(abs(float(r['omega_estimate_e'])-float(r['omega_true_e'])) for r in items)
        entry['max_combined_velocity_contribution_rad']=max(abs(float(r['e_raw_velocity'])+float(r['e_lpf'])) for r in items)
        result[name]=entry
    worst=max(rows,key=lambda r:abs(float(r['phase_error_rad'])))
    d=groups['capture-delay'];unpredicted=[math.remainder(float(r['theta_h1_e'])-float(r['theta_true']),2*math.pi) for r in d]
    assert all(float(a['phase_error_rad'])==float(b['phase_error_rad']) for a,b in zip(d,groups['execution-jitter']))
    return {'sample_count':len(rows),'cases':result,'worst_combined':worst,
        'max_phase_rad':max(abs(float(r['phase_error_rad'])) for r in rows),
        'max_numeric_rad':max(abs(float(r['e_numeric'])) for r in rows),
        'max_quant_rad':max(abs(float(r['e_quant'])) for r in rows),
        'max_id_error_a':max(abs(float(r['id_error_a'])) for r in rows),
        'max_iq_error_a':max(abs(float(r['iq_error_a'])) for r in rows),
        'delay_without_prediction':{'max_abs_rad':max(map(abs,unpredicted)),'rms_rad':rms(unpredicted)},
        'execution_jitter_phase_unchanged':True}

if __name__=='__main__':
    value=analyze(OUT/'verified/simulation/data.csv')
    (OUT/'measurements.json').write_text(json.dumps(value,indent=2),encoding='utf-8')
    for name,entry in value['cases'].items():
        print(name,'n',entry['samples'],'phase max/rms',entry['phase_error_rad'],
              'speed error_e',entry['max_speed_error_e_rad_s'],
              'velocity contribution',entry['max_combined_velocity_contribution_rad'])
    print('worst',value['worst_combined'])
