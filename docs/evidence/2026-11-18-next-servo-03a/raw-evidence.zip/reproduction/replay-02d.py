from pathlib import Path
from zipfile import ZipFile
import subprocess as sp, hashlib, sys
root=Path(__file__).parent
build=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/"final-complete/simulation-clang"
archive=Path("docs/evidence/2026-11-18-next-servo-02d/raw-evidence.zip")
with ZipFile(archive) as z:
    lines=z.read("replay-sha256.txt").decode().splitlines()
ids=[line.split()[0] for line in lines]
for index, mode in enumerate(("characterization","holdout")):
    command=[build/"test-foc-impedance-robustness.exe","--joint-control-"+mode,"--trace"]
    raw=sp.check_output(command)
    current=hashlib.sha256(raw).hexdigest()
    assert current==ids[index],(mode,current,ids[index])
    print(mode,raw.count(b"JOINT_TRACE,")-1,"trace rows, exact 02D raw SHA-256",current,flush=True)
