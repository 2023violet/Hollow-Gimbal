from pathlib import Path
import subprocess as sp
t=Path(__file__).resolve().parent
src=Path.cwd()
out=t/"arm-sizes"
out.mkdir(exist_ok=True)
inc=["control_plane/include","calibration/include","sensors/include","runtime/include","core/include","g3/np/include","g3/safe/include","components/utils/crc"]
flags=["-std=c11","-Os","-mcpu=cortex-m4","-mthumb","-mfloat-abi=soft",
       "-ffunction-sections","-fdata-sections","-fstack-usage","-Wall","-Wextra","-Wpedantic"]
layout=out/"layout.c"
layout.write_text("""#include "foc_calibration_application.h"
char workflow_bytes[sizeof(struct foc_cal_workflow)];
char bundle_bytes[sizeof(struct foc_cal_workflow_bundle)];
char observation_bytes[sizeof(struct foc_cal_workflow_sample)];
char scratch_bytes[sizeof(((struct foc_cal_workflow *)0)->scratch)];
char lut_encoder_bytes[sizeof(struct foc_encoder_context)];
char application_bytes[sizeof(struct foc_cal_application)];
char application_candidate_bytes[sizeof(struct foc_cal_application_candidate)];
char application_sensor_bytes[sizeof(struct foc_cal_application_sensor)];
char rotor_window_bytes[sizeof(((struct foc_calibration_rotor_context *)0)->samples)];
char lut_limit_count[FOC_ENCODER_CAL_MAX_NODES];
""",encoding="utf8")
def command(*args):
    print("$ "+sp.list2cmdline(list(map(str,args))),flush=True)
    return sp.check_output(args,text=True)
def show(*args):
    output=command(*args)
    print(output.strip(),flush=True)
    return output
show("arm-none-eabi-gcc","--version")
for f in ["calibration/src/foc_calibration_workflow.c",
          "control_plane/src/foc_calibration_application.c",
          "calibration/src/foc_calibration.c","calibration/src/foc_motor_id.c",
          "calibration/src/foc_encoder_calibration.c","calibration/src/foc_mechanical_id.c",
          "core/src/foc_impedance_tuning.c", layout]:
    obj=out/(Path(f).stem+".o")
    show("arm-none-eabi-gcc",*flags,*("-I"+p for p in inc),"-c",f,"-o",obj)
    if Path(f).stem=="crc":
        crc=out/"crc32-only.o"
        show("arm-none-eabi-ld","-r","--gc-sections","-u","crc32_ieee",obj,"-o",crc)
        obj=crc
    sizes=show("arm-none-eabi-size","-A",obj)
    sums={"text":0, "rodata":0, "data":0, "bss":0}
    for line in sizes.splitlines():
        if line.startswith("."):
            section,n,*_=line.split()
            stem=section.split(".")[1]
            if stem in sums:
                sums[stem]+=int(n)
    print(Path(f).stem,sums,flush=True)
    show("arm-none-eabi-nm","-u",obj)
    if Path(f).stem=="layout":
        print({name:int(size,16) for _,size,_,name in
            (line.split() for line in command("arm-none-eabi-nm","-S",obj).splitlines())},flush=True)
    else:
        print((out/(Path(f).stem+".su")).read_text().strip(),flush=True)
