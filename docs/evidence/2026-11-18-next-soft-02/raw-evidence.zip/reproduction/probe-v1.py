"""Probe immutable UART V1 layout against the locked Board1 Host simulator."""
from math import isclose
import json
from pathlib import Path
import struct
import sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "legacy-source" / "tools" / "falconfoc-cli"))
import falconfoc_cli as foc

sim = root / "board-host" / "foc-serial-sim.exe"
rows = {
    1: ("u32", 0, True, False, 8, 32, 24),
    2: ("f32", 1, True, False, .05, 2.5, 2.5),
    3: ("f32", 2, True, False, 1, 1000, 100),
    16: ("u32", 0, False, True, 7, 7, 7),
    17: ("f32", 2, False, True, 0, 0, 0),
    18: ("f32", 3, False, False, 12, 12, 12),
}
with foc.SimulatorTransport(str(sim)) as transport:
    client = foc.Client(transport)
    hello = foc.describe(client.hello())
    print("capability", json.dumps(hello, sort_keys=True))
    assert (hello["protocol"], hello["algorithm_modes"],hello["physical_modes"],
            hello["output_locked"]) == (1, 7, 0, True)
    for identifier, row in rows.items():
        frame = client.call("param-read", foc.parameter_read(identifier))
        data = foc.describe(frame)
        assert len(frame.payload) == 18
        actual = tuple(data[k] for k in ("parameter_type", "unit", "writable", "calibration_required"))
        assert data["result"] == "OK" and data["parameter_id"] == identifier
        assert actual == row[:4], data
        assert all(isclose(data[key], expected, abs_tol=1e-7) 
                   for key, expected in zip(("minimum","maximum","value"), row[4:])), data
        print("read", json.dumps(data, sort_keys=True))
    accesses = [
        ("param-write", foc.parameter_write(1, "u32", 16), "APPLIED"),
        ("param-write", foc.parameter_write(2, "f32", 1.5), "APPLIED"),
        ("param-write", foc.parameter_write(3, "f32", 50), "APPLIED"),
        ("param-write", foc.parameter_write(16, "u32", 5), "NOT_SUPPORTED"),
        ("param-write", foc.parameter_write(17, "f32", 1), "NOT_SUPPORTED"),
        ("param-write", foc.parameter_write(18, "f32", 5), "NOT_SUPPORTED"),
        ("param-write", foc.parameter_write(1, "f32", 16), "INVALID_ARGUMENT"),
        ("param-write", foc.parameter_write(1, "u32", 33), "INVALID_ARGUMENT"),
        ("param-write", struct.pack("<HBf", 2, 2, float("nan")), "INVALID_ARGUMENT"),
        ("param-write", struct.pack("<HBf", 3, 2, float("inf")), "INVALID_ARGUMENT"),
        ("param-read", foc.parameter_read(0x1001), "INVALID_ARGUMENT"),
        ("param-read", foc.parameter_read(0x100B), "INVALID_ARGUMENT"),
        ("param-read", foc.parameter_read(0x3011), "INVALID_ARGUMENT"),
        ("setpoint", struct.pack("<Bf", 3, 0), "INVALID_ARGUMENT"),
        ("arm", b"", "OUTPUT_LOCKED"),
        ("start", b"", "OUTPUT_LOCKED"),
        ("save", b"", "NOT_SUPPORTED"),
        ("clear", b"", "BAD_STATE"),
        ("stop", b"", "ACCEPTED"),
        ("telemetry", b"", "OK"),
    ]
    for message, payload, expected in accesses:
        data = foc.describe(client.call(message, payload))
        print(message, payload.hex(), json.dumps(data, sort_keys=True))
        assert data["result"] == expected, (message, expected, data)
    assert not data["physical_applied"] and not data["current_valid"] and not data["sensor_calibrated"]
print("V1 fixed layout, parameters 1/2/3/16/17/18, mode 3 exclusion, action lock and STOP PASS")

