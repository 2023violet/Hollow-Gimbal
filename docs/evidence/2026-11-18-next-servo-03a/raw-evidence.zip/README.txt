servo-03a.patch is the complete SERVO-03A text diff.
workspace-text-from-head.patch also includes preserved 02D text edits and the 02D report.
The raw evidence archive is delivered as a binary artifact outside the patch.
The separately preserved 02D evidence archive is proven byte-identical in protection.log.
