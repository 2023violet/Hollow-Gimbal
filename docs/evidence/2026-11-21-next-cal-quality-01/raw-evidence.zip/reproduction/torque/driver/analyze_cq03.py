"""Independent CQ-03 analysis of exact CQ-02 Host load reruns."""
import csv
import hashlib
import json
import math
import sys
from itertools import groupby
from pathlib import Path
from statistics import mean

from analyze_load import read_study, row_groups

EPOCH_US = 2_000
BAND_RAD = 0.008
MASK_LIMIT_US = 250_000


def digest(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def extrema(rows, key):
    values = [row[key] for row in rows]
    return [min(values), max(values)]


def signed_peak(rows, key, direction):
    return max((row[key] for row in rows), key=lambda value: direction * value)


def sample(rows, predicate):
    return next(row for row in rows if predicate(row))


def intervals(rows, predicate, timestamp, period):
    return [
        (run[0][timestamp], run[-1][timestamp] + period, len(run) * period)
        for active, siblings in groupby(rows, predicate)
        if active and (run := list(siblings))
    ]


def ideal_plateau(h0, h1_intervals, params, on, off, direction, torque_cap):
    """Use exact constant-torque J/B dynamics once requested Iq reaches the cap."""
    overlap = [
        (max(start, on), min(stop, off))
        for start, stop, _ in h1_intervals
        if max(start, on) < min(stop, off)
    ]
    if not overlap:
        return None
    first, stop = max(overlap, key=lambda item: item[1] - item[0])
    first_rows = [
        row for row in h0
        if first <= row["h0_us"] - EPOCH_US < stop
        and abs(row["load_nm"]) == params["load_magnitude_nm"]
        and abs(row["iq_h0_a"]) == params["motion_iq_limit_a"]
    ]
    if not first_rows:
        return None
    first_observed, last_observed = first_rows[0], first_rows[-1]
    initial_pos = first_observed["position_rad"]
    initial_vel = first_observed["velocity_rad_s"]
    tau_s = params["inertia_kg_m2"] / params["damping_nm_s"]
    limiting_speed = (torque_cap - params["load_magnitude_nm"]) / params["damping_nm_s"]

    def predict(t):
        e = math.exp(-t / tau_s)
        equilibrium = direction * limiting_speed
        return (
            initial_pos + equilibrium * t + (initial_vel - equilibrium) * tau_s * (1.0 - e),
            equilibrium + (initial_vel - equilibrium) * e,
        )

    progress = [
        (point, (point["h0_us"] - first_observed["h0_us"]) / 1e6)
        for point in first_rows
    ]
    errors = [
        (pred_pos - point["position_rad"], pred_speed - point["velocity_rad_s"])
        for point, t in progress
        for pred_pos, pred_speed in [predict(t)]
    ]
    t_max = progress[-1][1]
    result = {
        "first_h0_us": first_observed["h0_us"],
        "last_h0_us": last_observed["h0_us"],
        "tau_s": tau_s,
        "initial_velocity_rad_s": initial_vel,
        "steady_signed_velocity_rad_s": direction * limiting_speed,
        "max_abs_position_model_error_rad": max(abs(x) for x, _ in errors),
        "max_abs_velocity_model_error_rad_s": max(abs(v) for _, v in errors),
        "end_position_rad": last_observed["position_rad"],
        "end_velocity_rad_s": last_observed["velocity_rad_s"],
        "ideal_end_position_rad": predict(t_max)[0],
        "ideal_end_velocity_rad_s": predict(t_max)[1],
    }
    if limiting_speed > 0 and initial_vel * direction < 0:
        result["ideal_zero_velocity_after_first_h0_us"] = (
            1e6 * tau_s * math.log1p(-initial_vel * direction / limiting_speed)
        )
    return result


def summarize_case(meta, h0, h1):
    params = meta["config"]
    period = int(params["h1_us"])
    direction = params["direction"]
    load = params["load_magnitude_nm"]
    on = params["load_on_us"]
    interrupted = "quality" not in meta
    off = 1_400_000 if interrupted else params["load_off_us"]
    iq_cap = params["motion_iq_limit_a"]
    kt = 1.5 * params["pole_pairs"] * params["flux_wb"]
    torque_cap = kt * iq_cap
    ranges = intervals(h1, lambda r: r["limited"] == 1.0, "relative_us", period)
    run_start, run_end, longest = max(ranges, key=lambda item: item[2])
    loaded_h1 = [r for r in h1 if on <= r["relative_us"] < off]
    loaded_h0 = [r for r in h0 if r["state"] == 3 and abs(r["load_nm"]) == load]
    tail_h0 = [r for r in loaded_h0 if EPOCH_US + off - 100_000 <= r["h0_us"] < EPOCH_US + off]
    tail_h1 = [r for r in loaded_h1 if r["relative_us"] >= off - 100_000]
    anchor = loaded_h1[0]["position_plant_rad"]
    across_load = h1
    if not interrupted:
        across_load = [*loaded_h1, sample(h1, lambda r: r["relative_us"] == off)]
    peak_slip = min(
        (r["position_plant_rad"] - anchor for r in across_load if r["relative_us"] >= on),
        key=lambda slip: direction * slip,
    )
    stiff = params["kp_nm_per_rad"]
    damp = params["kd_nm_s_per_rad"]
    h1_index = 0
    h0_compared = 0
    for row in h0:
        if not (row["state"] == 3 and h1[0]["h1_us"] <= row["h0_us"] <= h1[-1]["h1_us"]):
            continue
        while h1_index + 1 < len(h1) and h1[h1_index + 1]["h1_us"] <= row["h0_us"]:
            h1_index += 1
        assert row["iq_h0_a"] == h1[h1_index]["iq_request_a"]
        h0_compared += 1
    spring_damp_error = max(
        abs(r["requested_torque_nm"] - (
            stiff * (r["reference_rad"] - r["position_measured_rad"])
            - damp * r["damping_feedback_rad_s"]
        ))
        for r in h1
    )
    assert spring_damp_error < 2e-7
    termination = meta["termination"]
    last_active = max(row["h0_us"] for row in h0 if row["state"] == 3)
    inhibited = [row for row in h0 if row["h0_us"] > last_active]
    assert len(inhibited) >= 4
    assert termination["updates_before"] == termination["updates_after"]
    assert all(r["enable_request"] == 0 and r["action"] == 0 for r in inhibited)
    assert all(r["updates"] == inhibited[0]["updates"] for r in inhibited)
    assert all(r["integral_d_v"] == inhibited[0]["integral_d_v"] and
               r["integral_q_v"] == inhibited[0]["integral_q_v"] for r in inhibited)
    assert all(r["saturated_updates"] == 0 for r in h0)

    result = {
        "frozen_parameters": params,
        "static_iq_required_a": direction * load / kt,
        "static_current_torque_cap_nm": torque_cap,
        "static_torque_margin_nm": torque_cap - load,
        "static_compliant_offset_rad": direction * load / stiff,
        "active_h0_latest_h1_target_verified_samples": h0_compared,
        "max_abs_h1_p_plus_d_reconstruction_error_nm": spring_damp_error,
        "longest_limit_us": longest,
        "longest_limit_start_relative_us": run_start,
        "longest_limit_end_exclusive_relative_us": run_end,
        "all_limit_duration_us": sum(duration for _, _, duration in ranges),
        "loaded_limit_duration_us": sum(
            max(0, min(end, off) - max(start, on)) for start, end, _ in ranges
        ),
        "first_load_limit_relative_us": min(
            (max(start, on) for start, end, _ in ranges if end > on and start < off), default=None
        ),
        "peak_loaded_slip_rad": peak_slip,
        "last_loaded_500us_slip_rad": loaded_h1[-1]["position_plant_rad"] - anchor,
        "loaded_rms_position_error_rad": math.sqrt(
            mean((r["reference_rad"] - r["position_plant_rad"]) ** 2 for r in loaded_h1)
        ),
        "loaded_tail_signed_pos_error_mean_rad": mean(
            r["reference_rad"] - r["position_plant_rad"] for r in tail_h1
        ),
        "loaded_tail_speed_mean_rad_s": mean(r["velocity_rad_s"] for r in tail_h0),
        "loaded_tail_electromagnetic_torque_mean_nm": mean(r["electromagnetic_nm"] for r in tail_h0),
        "loaded_tail_viscous_term_mean_nm": mean(r["viscous_nm"] for r in tail_h0),
        "loaded_tail_net_torque_mean_nm": mean(r["residual_nm"] for r in tail_h0),
        "loaded_peak_iq_target_a": signed_peak(loaded_h0, "iq_h0_a", direction),
        "loaded_peak_iq_plant_a": signed_peak(loaded_h0, "iq_plant_a", direction),
        "loaded_peak_torque_plant_nm": signed_peak(loaded_h0, "electromagnetic_nm", direction),
        "loaded_peak_requested_torque_nm": signed_peak(loaded_h1, "requested_torque_nm", direction),
        "loaded_peak_voltage_v": max(r["accepted_voltage_v"] for r in loaded_h0),
        "loaded_peak_abs_back_emf_v": max(abs(r["back_emf_v"]) for r in loaded_h0),
        "loaded_pi_d_min_max_v": extrema(loaded_h0, "integral_d_v"),
        "loaded_pi_q_min_max_v": extrema(loaded_h0, "integral_q_v"),
        "loaded_tail_pi_q_mean_v": mean(r["integral_q_v"] for r in tail_h0),
        "loaded_tail_steady_q_voltage_mean_v": mean(
            params["rs_ohm"] * r["iq_plant_a"] + r["back_emf_v"] for r in tail_h0
        ),
        "h0_voltage_limited_updates": int(h0[-1]["saturated_updates"]),
        "termination": {
            **termination,
            "last_active_update_us": last_active,
            "first_confirmed_inhibit_us": inhibited[0]["h0_us"],
            "post_action_h0_inhibited_samples": len(inhibited),
        },
        "ideal_current_clamp": ideal_plateau(h0, ranges, params, on, off, direction, torque_cap),
    }
    if not interrupted:
        release = across_load[-1]
        before_release = max((r for r in h0 if r["h0_us"] <= EPOCH_US + off),
                             key=lambda r: r["h0_us"])
        after_release = [r for r in h1 if r["relative_us"] >= off]
        last_outside = max(
            (r["relative_us"] for r in after_release
             if abs(r["reference_rad"] - r["position_plant_rad"]) > BAND_RAD),
            default=off-period,
        )
        recovery = last_outside - off + period
        assert recovery == meta["quality"]["recovery_us"]
        assert longest == meta["quality"]["longest_limit_us"]
        expected_mask = 16 if longest > MASK_LIMIT_US else 0
        assert meta["quality"]["mask"] == expected_mask
        first_unclamped = sample(after_release, lambda r: r["limited"] == 0)
        in_recovery = sample(after_release, lambda r: r["relative_us"] == off + recovery)
        one_h0_later = sample(h0, lambda r: r["h0_us"] >= in_recovery["relative_us"] + EPOCH_US)
        result.update({
            "historical_mask": int(meta["quality"]["mask"]),
            "release_slip_rad": release["position_plant_rad"] - anchor,
            "release_speed_rad_s": release["velocity_plant_rad_s"],
            "release_pi_q_v": before_release["integral_q_v"],
            "recovery_pi_q_v": one_h0_later["integral_q_v"],
            "unload_to_first_unclamped_h1_us": first_unclamped["relative_us"] - off,
            "unload_to_band_and_remains_us": recovery,
            "end_300ms_peak_position_error_rad": meta["quality"]["tail_peak_error_rad"],
        })
    traces = []
    for elapsed in (on, on + 100_000, on + 250_000, on + 500_000, off - 500):
        if elapsed >= off:
            continue
        h1_row = sample(h1, lambda r: r["relative_us"] == elapsed)
        h0_row = sample(h0, lambda r: r["h0_us"] >= EPOCH_US + elapsed)
        traces.append({
            "t_from_load_us": elapsed - on,
            "p_nm": stiff * (h1_row["reference_rad"] - h1_row["position_measured_rad"]),
            "d_nm": -damp * h1_row["damping_feedback_rad_s"],
            "pd_nm": h1_row["requested_torque_nm"],
            "bounded_nm": h1_row["capped_torque_nm"],
            "electromagnetic_nm": h0_row["electromagnetic_nm"],
            "viscous_term_nm": h0_row["viscous_nm"],
            "net_torque_nm": h0_row["residual_nm"],
            "speed_rad_s": h1_row["velocity_plant_rad_s"],
            "position_rad": h1_row["position_plant_rad"],
            "integral_q_v": h0_row["integral_q_v"],
        })
    result["landmarks"] = traces
    return result


def main():
    replay, archive, out = map(Path, sys.argv[1:])
    parity = {}
    for name in ("baseline-h0.csv", "baseline-h1.csv", "candidate-h0.csv", "candidate-h1.csv"):
        replayed_name = name.replace("baseline-", "disabled-")
        old, new = digest(archive / name), digest(replay / replayed_name)
        assert old == new, name
        parity[name] = new
    runs = {}
    for cutoff, name in ((0, "disabled"), (48, "candidate")):
        records = read_study(replay, name)
        both = zip(
            row_groups(replay / f"{name}-h0.csv"),
            row_groups(replay / f"{name}-h1.csv"),
            strict=True,
        )
        cases = {}
        for (h0_case, h0), (h1_case, h1) in both:
            assert h0_case == h1_case
            cases[h0_case] = summarize_case(records[h0_case], h0, h1)
        runs[cutoff] = cases
    report = {"identical_cq02_raw_trace_sha256": parity, "cases": runs}
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    for cutoff, cases in runs.items():
        for case, record in cases.items():
            print(f"{cutoff:2} Hz {case:24} mask={record.get('historical_mask', '-'):>2} "
                  f"limit_ms={record['longest_limit_us'] / 1000:7.1f} "
                  f"recover_ms={record.get('unload_to_band_and_remains_us', 0) / 1000:6.1f} "
                  f"slip_rad={record['peak_loaded_slip_rad']:+.6f} "
                  f"plant_iq={record['loaded_peak_iq_plant_a']:+.8f} A "
                  f"plant_torque={record['loaded_peak_torque_plant_nm']:+.8f} Nm "
                  f"applied_v={record['loaded_peak_voltage_v']:.6f} V")


if __name__ == "__main__":
    main()

