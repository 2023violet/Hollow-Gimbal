from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import subprocess
import zipfile
from pathlib import Path


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command, *, cwd, stdout=None, env=None):
    subprocess.run([str(value) for value in command], cwd=cwd, stdout=stdout, env=env, check=True)


def build_derived(repo, build, target, generated, original_name, original_c):
    commands = subprocess.check_output(
        ["ninja", "-C", str(build), "-t", "commands", original_name],
        text=True,
    )
    def words(line):
        return [word.strip('"') for word in re.findall(r'"[^"]*"|\S+', line)]
    original_object = f"CMakeFiles/{original_name}.dir/{original_c}.obj"
    original_target = original_name + ".exe"
    compile_line = next(line for line in commands.splitlines() if "-c " in line and original_object in line)
    compile_flags = words(compile_line.split(" -MD -MT ", 1)[0])
    link_line = next(line for line in commands.splitlines() if "-o " + original_target in line)
    link_line = link_line.split("cd . && ", 1)[1]
    link_flags = words(link_line.split(" && cd .", 1)[0])
    experiment_object = target.with_suffix(".obj")
    run(compile_flags + ["-I" + str(repo / "simulation/tests"), "-o", experiment_object, "-c", generated], cwd=build)
    link_flags = [
        str(experiment_object) if token == original_object else
        str(target) if token == original_target else
        token.replace(original_name + ".", target.stem + ".")
        if token.startswith(("/implib:", "/pdb:")) else token
        for token in link_flags
    ]
    run(link_flags, cwd=build)


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError(f"Expected one occurrence of {old!r}, got {text.count(old)}")
    return text.replace(old, new, 1)


def historical_study(source):
    seam = r"""
struct cq_servo_probe {
    const char *name;
    float damping_scale;
    float raw_sensor_cutoff;
    float damping_cutoff;
    float current_scale;
    double load_nm;
    float slew_rad_s;
    bool ideal_phase;
    bool load_feedforward;
    bool invert;
};

static const struct cq_servo_probe baseline_probe = {
    "baseline", 1.0f, 80.0f, 0.0f, 1.0f, 0.039, 0.0f, false, false, false
};
static const struct cq_servo_probe *active_probe = &baseline_probe;
"""
    source = replace_once(source, "static int run_case(", seam + "\nstatic int run_case(")
    first, tail = source.split("static int run_case(", 1)
    body, remainder = tail.split("/* SERVO-02B Host Damping Study", 1)
    body = replace_once(
        body, "    profile.motor.inertia_kg_m2 *= test->inertia_scale;",
        """    profile.motor.inertia_kg_m2 *= test->inertia_scale;
    profile.encoder.speed_lpf_cutoff_hz = active_probe->raw_sensor_cutoff;
    profile.current.kp_v_per_a.d *= active_probe->current_scale;
    profile.current.kp_v_per_a.q *= active_probe->current_scale;
    profile.current.ki_v_per_a_s.d *= active_probe->current_scale;
    profile.current.ki_v_per_a_s.q *= active_probe->current_scale;""",
    )
    body = replace_once(body, "    printf(\n        \"DESIGN,",
        """    gains.damping_nm_s_per_rad *= active_probe->damping_scale;
    struct damping_noise_filter damping_filter = {0};
    if (active_probe != &baseline_probe) {
        profile.runtime.motion.impedance.max_feedforward_nm = 0.315f;
    }
    printf("PROBE,%s,%s,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%u,%u,%u\\n",
        test->name, active_probe->name, profile.encoder.speed_lpf_cutoff_hz,
        active_probe->damping_cutoff, profile.current.kp_v_per_a.d,
        profile.current.kp_v_per_a.q, profile.current.ki_v_per_a_s.q,
        active_probe->load_nm, active_probe->slew_rad_s, (unsigned)active_probe->ideal_phase,
        (unsigned)active_probe->load_feedforward, (unsigned)active_probe->invert);
    printf(
        "DESIGN,""",
    )
    body = replace_once(
        body, "        const float speed = test->stimulus == CRAWL ? 0.05f : 0.0f;",
        """        const double true_position = vm.motor.state.mechanical_position_rad;
        const float true_speed = (float)vm.motor.state.mechanical_velocity_rad_s;
        double theta_true = fmod(profile.motor.electrical_offset_rad +
            profile.motor.pole_pairs * true_position, two_pi);
        if (theta_true < 0.0) {
            theta_true += two_pi;
        }
        if (active_probe->ideal_phase) {
            sample.theta_elec_rad = (float)theta_true;
        }
        float speed = test->stimulus == CRAWL ? 0.05f : 0.0f;""",
    )
    body = replace_once(
        body, "        const float reference = test->stimulus == CRAWL ? speed * (float)t * 1.0e-6f\n"
        "            : t >= reversal                             ? -0.20f\n"
        "                                                        : test->target_rad;",
        """        float reference = test->stimulus == CRAWL ? speed * (float)t * 1.0e-6f
            : t >= reversal                             ? -0.20f
                                                        : test->target_rad;
        if (active_probe->slew_rad_s > 0.0f && test->stimulus == LOAD) {
            const float position = (float)t * 1.0e-6f * active_probe->slew_rad_s;
            if (position < reference) {
                reference = position;
                speed = active_probe->slew_rad_s;
            }
        }
        const float direction = active_probe->invert ? -1.0f : 1.0f;
        reference *= direction;
        speed *= direction;
        float damping_speed = sample.mechanical_rad_s;
        if (active_probe->damping_cutoff > 0.0f) {
            CHECK(damping_noise_filter_step(
                &damping_filter, sample.mechanical_rad_s, active_probe->damping_cutoff, period_us));
            damping_speed = damping_filter.velocity_rad_s;
        }
        const float physical_ff = active_probe->load_feedforward && t >= load_on && t < load_off
            ? direction * active_probe->load_nm : 0.0f;
        const float published_ff = physical_ff +
            gains.damping_nm_s_per_rad * (sample.mechanical_rad_s - damping_speed);""",
    )
    body = replace_once(body, "publish(&vm, &gains, reference, speed, 0.0f)", "publish(&vm, &gains, reference, speed, published_ff)")
    body = replace_once(
        body, "t == load_on ? 0.039 : 0.0",
        "t == load_on ? (active_probe == &baseline_probe ? 0.039 : direction * active_probe->load_nm) : 0.0",
    )
    body = replace_once(
        body, "            .measured_velocity_rad_s = sample.mechanical_rad_s,",
        """            .measured_velocity_rad_s = sample.mechanical_rad_s,
            .torque_feedforward_nm = published_ff,""",
    )
    body = replace_once(
        body, "        if (trace) {\n            printf(",
        """        if (trace && active_probe != &baseline_probe &&
            (test->sensor == NOISY || strstr(test->name, "clean-code") != NULL ||
             strcmp(test->name, "hold-load-beyond-025") == 0)) {
            printf(
                "CQ_TRACE,%s,%u,%u,%u,%u,%u,%u,%u,%u,%u,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,"
                "%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%u\\n",
                test->name, t, capture, delivery, output.last_submitted_us, output.last_applied_us,
                sample.seq, session, vm.output.accepted_updates, vm.runtime.angle_prediction_us,
                (double)raw, reference, true_position, true_speed, sample.mechanical_rad,
                sample.mechanical_rad_s, damping_speed, theta_true, sample.theta_elec_rad,
                slot->electrical.velocity_rad_s, gains.stiffness_nm_per_rad * input.position_error_rad,
                gains.damping_nm_s_per_rad * (speed - damping_speed), physical_ff,
                torque.requested_torque_nm, torque.iq_ref_a, plant->iq_a, plant->id_a,
                vm.motor.load_torque_nm, (unsigned)torque.limited
            );
        }
        if (trace && active_probe == &baseline_probe) {
            printf(""",
    )
    body = replace_once(
        body, "    if (test->cap_a < 1.0f) {",
        """    if (test->cap_a < 1.0f && active_probe == &baseline_probe) {""",
    )
    source = first + "static int run_case(" + body + "/* SERVO-02B Host Damping Study" + remainder
    old = """    if (argc > 1 && strcmp(argv[1], "--mechanical-id-fit") == 0) {"""
    new = r"""    if (argc > 1 && strcmp(argv[1], "--cq01-servo-probes") == 0) {
        static const struct cq_servo_probe probes[] = {
            {"fresh-baseline", 1.0f, 80.0f, 0.0f, 1.0f, 0.039, 0.0f, false, false, false},
            {"D-only-48Hz", 1.0f, 80.0f, 48.0f, 1.0f, 0.039, 0.0f, false, false, false},
            {"D-scaled-0.65", 0.65f, 80.0f, 0.0f, 1.0f, 0.039, 0.0f, false, false, false},
            {"common-sensor-30Hz", 1.0f, 30.0f, 0.0f, 1.0f, 0.039, 0.0f, false, false, false},
            {"oracle-phase-only", 1.0f, 80.0f, 0.0f, 1.0f, 0.039, 0.0f, true, false, false},
            {"inner-36Hz-model", 1.0f, 80.0f, 0.0f, 0.251327412f, 0.039, 0.0f, false, false, false},
            {"inner-2x", 1.0f, 80.0f, 0.0f, 2.0f, 0.039, 0.0f, false, false, false},
            {"oracle-load-039", 1.0f, 80.0f, 0.0f, 1.0f, 0.039, 0.0f, false, true, false},
            {"zero-load", 1.0f, 80.0f, 0.0f, 1.0f, 0.0, 0.0f, false, false, false},
            {"feasible-load-030", 1.0f, 80.0f, 0.0f, 1.0f, 0.03, 0.0f, false, false, false},
            {"oracle-load-030", 1.0f, 80.0f, 0.0f, 1.0f, 0.03, 0.0f, false, true, false},
            {"slew-1.2", 1.0f, 80.0f, 0.0f, 1.0f, 0.039, 1.2f, false, false, false},
            {"negative-mirror", 1.0f, 80.0f, 0.0f, 1.0f, 0.039, 0.0f, false, false, true},
        };
        for (size_t row = 0U; row < sizeof probes / sizeof probes[0]; ++row) {
            active_probe = &probes[row];
            const size_t prior_cases = sizeof holdout / sizeof holdout[0];
            for (size_t i = 0U; i < prior_cases; ++i) {
                if (row >= 7U && i != prior_cases - 1U) {
                    continue;
                }
                CHECK(run_case(&holdout[i], NULL, true) == 0);
            }
            if (row == 0U) {
                struct study_case clean = holdout[1];
                clean.sensor = QUANTIZED;
                clean.name = "same-hold-nominal-clean-code";
                CHECK(run_case(&clean, NULL, true) == 0);
                clean = holdout[2];
                clean.sensor = QUANTIZED;
                clean.name = "same-hold-high-clean-code";
                CHECK(run_case(&clean, NULL, true) == 0);
            }
        }
        return 0;
    }
    if (argc > 1 && strcmp(argv[1], "--mechanical-id-fit") == 0) {"""
    return replace_once(source, old, new)


def phase_consistent_study(source):
    first, body = source.split("static int run_motion_case(", 1)
    body = replace_once(
        body,
        """            CHECK(noise_trial_offer(&filter, &vm, &sample, session, 48.0f) == 0 && filter.pending);
            damping_speed = filter.proposed.velocity_rad_s;""",
        """            struct foc_runtime_sensor damping_error = sample;
            damping_error.mechanical_rad_s -= ref.velocity_rad_s;
            CHECK(noise_trial_offer(&filter, &vm, &damping_error, session, 48.0f) == 0 && filter.pending);
            damping_speed = ref.velocity_rad_s + filter.proposed.velocity_rad_s;""",
    )
    return first + "static int run_motion_case(" + body


def motion_sensor_study(source):
    return replace_once(
        source,
        """    const struct foc_virtual_current_profile profile = foc_virtual_current_default_profile();
    struct motion_result result;""",
        """    struct foc_virtual_current_profile profile = foc_virtual_current_default_profile();
    const bool shared_lpf = getenv("CQ01_MOTION_SENSOR_30HZ") != NULL;
    const bool outer_cal = getenv("CQ01_MOTION_CAL_OUTER") != NULL;
    if (shared_lpf) {
        profile.encoder.speed_lpf_cutoff_hz = 30.0f;
    }
    if (outer_cal) {
        profile.runtime.motion.velocity.kp_a_per_rad_s = 0.365252f;
        profile.runtime.motion.velocity.ki_a_per_rad = 4.812311f;
        profile.runtime.motion.position.kp_per_s = 3.6f;
    }
    struct motion_result result;""",
    ).replace("#include <stdio.h>", "#include <stdio.h>" + chr(10) + "#include <stdlib.h>")


def baseline_metrics(repo, build):
    original = repo / "docs/evidence/2026-11-19-next-cal-integ-01/raw-evidence.zip"
    prior_servo = repo / "docs/evidence/2026-11-18-next-servo-01c/raw-evidence.zip"
    log = build / "historical-servo-holdout.log"
    with zipfile.ZipFile(original) as prior:
        old = prior.read("historical-servo-holdout.log").decode("utf-8-sig")
    with zipfile.ZipFile(prior_servo) as prior:
        frozen = prior.read("inputs/holdout-frozen.txt")
        (build / "original-holdout-frozen.txt").write_bytes(frozen)
    rows = list(csv.reader(log.read_text().splitlines()))
    trace = list(csv.reader((build / "historical-servo-holdout-trace.log").read_text().splitlines()))
    out = {
        "git_head": subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip(),
        "started": (build / "started.txt").read_text(encoding="utf-8-sig").strip(),
        "ended": (build / "ended.txt").read_text(encoding="utf-8-sig").strip(),
        "hashes": {
            "prior_cal_integ_zip": sha256(original),
            "original_holdout_frozen": hashlib.sha256(frozen).hexdigest(),
            "source": sha256(repo / "simulation/tests/test_foc_impedance_robustness.c"),
            "exe": sha256(build / "test-foc-impedance-robustness.exe"),
            "holdout_log": sha256(log),
            "holdout_trace": sha256(build / "historical-servo-holdout-trace.log"),
        },
        "cal_integ_historical_log_normalized_lines_equal": log.read_text().splitlines() == old.splitlines(),
        "cases": {},
    }
    for case in ("hold-noise-nominal", "hold-noise-high", "hold-load-beyond-025"):
        result = next(row for row in rows if row[:2] == ["RESULT", case])
        samples = [row for row in trace if row[:2] == ["TRACE", case]]
        tail_start = (int(result[2]) - 600) * 500
        tail = [row for row in samples if int(row[2]) >= tail_start]
        runs = []
        for row in samples:
            t = int(row[2])
            if row[12] != "1":
                continue
            if runs and t == runs[-1][1] + 500:
                runs[-1][1] = t
            else:
                runs.append([t, t])
        longest = max(runs, key=lambda run: run[1] - run[0], default=None)
        out["cases"][case] = {
            "last_300ms_relative_us": [int(tail[0][2]), int(tail[-1][2])],
            "last_300ms_capture_us": [int(tail[0][3]), int(tail[-1][3])],
            "last_300ms_delivery_us": [int(tail[0][4]), int(tail[-1][4])],
            "longest_limit_relative_us_inclusive": longest,
            "longest_limit_absolute_us_inclusive": [value + 2000 for value in longest] if longest else None,
            "limited_us": int(result[12]),
            "longest_limit_us": int(result[13]),
            "ripple_request_a": float(result[18]),
            "ripple_plant_a": float(result[19]),
            "load_tail_mean_position_error_rad": float(result[14]),
            "post_load_recovery_us": int(result[8]),
            "velocity_sensor_rms_rad_s": float(result[16]),
            "tail_peak_position_error_rad": float(result[15]),
            "fail_mask": int(result[25]),
        }
    (build / "baseline.json").write_text(json.dumps(out, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    parser.add_argument("build", type=Path)
    parser.add_argument("--baseline-only", action="store_true")
    args = parser.parse_args()
    repo, build = args.repo.resolve(), args.build.resolve()
    baseline_metrics(repo, build)
    if args.baseline_only:
        return
    original_source = (repo / "simulation/tests/test_foc_impedance_robustness.c").read_text()
    for stem, transform, calls in (
        ("historical-servo-probes", historical_study, [
            ("historical-servo-probes.log", "--cq01-servo-probes"),
        ]),
        ("servo02d-phase-consistency", phase_consistent_study, [
            ("servo02d-phase-consistency-characterization.log", "--joint-control-characterization", "--trace"),
            ("servo02d-phase-consistency-holdout.log", "--joint-control-holdout", "--trace"),
        ]),
    ):
        generated = build / (stem + ".c")
        generated.write_text(transform(original_source))
        target = build / (stem + ".exe")
        build_derived(
            repo, build, target, generated, "test-foc-impedance-robustness",
            "tests/test_foc_impedance_robustness.c",
        )
        for name, *flags in calls:
            with (build / name).open("wb") as stdout:
                run([target, *flags], cwd=build, stdout=stdout)

    original_motion = repo / "simulation/src/falconfoc_virtual_motion.c"
    generated_motion = build / "servo-motion-modes.c"
    generated_motion.write_text(motion_sensor_study(original_motion.read_text()))
    target_motion = build / "servo-motion-modes.exe"
    build_derived(
        repo, build, target_motion, generated_motion, "falconfoc-virtual-motion",
        "src/falconfoc_virtual_motion.c",
    )
    for label, sensor, outer in (("baseline", False, False),
                                 ("sensor-30Hz", True, False),
                                 ("outer-cal-only", False, True)):
        env = os.environ.copy()
        env.pop("CQ01_MOTION_SENSOR_30HZ", None)
        env.pop("CQ01_MOTION_CAL_OUTER", None)
        if sensor:
            env["CQ01_MOTION_SENSOR_30HZ"] = "1"
        if outer:
            env["CQ01_MOTION_CAL_OUTER"] = "1"
        with (build / ("servo-motion-modes-" + label + ".log")).open("wb") as stdout:
            run([target_motion, "--csv", build / ("servo-motion-modes-" + label + ".csv")],
                cwd=build, stdout=stdout, env=env)


if __name__ == "__main__":
    main()




