import sys,shutil
from audit import OUT,ROOT,CC,run,copy_source
phase=sys.argv[1]; dest=OUT/phase
source=copy_source(dest/'source')
shutil.copy2(ROOT/'runtime/tests/test_foc_runtime_mailbox.c',source/'runtime/tests/test_foc_runtime_mailbox.c')
if not phase.startswith('red'):shutil.copy2(ROOT/'runtime/src/foc_runtime.c',source/'runtime/src/foc_runtime.c')
run(dest,'configure',['cmake','-S',source/'runtime','-B',dest/'build','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+CC])
run(dest,'build',['cmake','--build',dest/'build','--parallel','4'])
run(dest,'ctest',['ctest','--test-dir',dest/'build','--output-on-failure','-R','^test-foc-runtime-mailbox$'],expected=8 if phase.startswith('red') else 0)
