from pathlib import Path
from collections import defaultdict
import csv,hashlib,subprocess as sp,sys
from zipfile import ZipFile

root=Path(__file__).parent
data=root/"data"
data.mkdir(exist_ok=True)
build=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/"sim-smoke"
def run(label,test,*args):
    cmd=[build/(test+".exe"),*args]
    print(sp.list2cmdline(cmd),flush=True)
    raw=sp.check_output(cmd)
    (root/(label+".log")).write_bytes(raw)
    grouped=defaultdict(list)
    for row in csv.reader(raw.decode().splitlines()):
        grouped[row[0]].append(row)
    return grouped
def dump(path,header,rows):
    with path.open("w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(header.split())
        for r in rows:
            assert len(r)==len(header.split()),r
            writer.writerow(r)
id_test="test-foc-mechanical-id-virtual"
imp_test="test-foc-impedance-robustness"
identity=run("identification",id_test,"--trace")
headers={
 "FIT":"record scenario status failure endpoints windows J_truth B_truth J_fit B_fit J_error_pct B_error_pct residual_upper_nm gram_condition accel_rms_rad_s2 speed_rms_rad_s peak_abs_id_a peak_abs_speed_rad_s accel_windows decel_windows usable accepted_quality",
 "OBS":"record scenario sequence aperture_us speed_rad_s measured_id_a measured_iq_a torque_nm opposing_load_nm accepted_vm_updates_at_processing",
 "COUNTERFACTUAL":"record scenario J_unqualified B_unqualified residual_nm",
 "REFUSAL":"record scenario status failure accepted_endpoints",
 "ACQUISITION":"record scenario max_abs_measured_minus_requested_iq_a updates_before_stop updates_after_stop",
 "PREDICT":"record scenario frozen_J frozen_B prediction_rms_nm windows quality_pass"
}
for name,rows in identity.items():
    dump(data/f"identification-{name.lower()}.csv",headers[name],rows)
models=identity["FIT"][:5]
assert [row[1] for row in models]==["nominal","half","double","quad","known-load"]
assert all(row[2:6]==["0","0","16001","40"] and row[-2:]==["1","1"] for row in models)
assert all(float(row[10])<=3.0 and float(row[11])<=8.0 for row in models)
frozen=root/"frozen-models.csv"
previous=frozen.read_bytes() if frozen.exists() else None
dump(frozen,"scenario capture_id setup_id torque_model_id Kt_nm_per_a J_kg_m2 B_nm_s_per_rad",
     [[r[1],100+i,77,91,"0.15",*r[8:10]] for i,r in enumerate(models)])
if previous is not None:
    assert frozen.read_bytes()==previous, "frozen model changed"
digest=hashlib.sha256(frozen.read_bytes()).hexdigest()
code_hashes="\n".join(f"{hashlib.sha256(Path(p).read_bytes()).hexdigest()}  {p}" for p in (
"calibration/src/foc_mechanical_id.c","simulation/tests/test_foc_mechanical_id_virtual.c","simulation/tests/test_foc_impedance_robustness.c"))
(root/"holdout-frozen.txt").write_text(f"""Frozen after measured training and before invoking either independent verification.
Baseline f9af51be41aa21ad11cb66444d6e7664ae93213d.
frozen-models.csv SHA256 {digest}
This second manifest retains the original freeze and extends the first comparison:
same seed and stimulus for additional noise/cap A and B; the prior 01C age rejection
topology is applied to C. Identified coefficients, target design, gates and cases of
the first comparison were held fixed. See first-holdout-frozen.txt.
Training 0.32*sin(2*pi*.9*t) + .12*sin(2*pi*1.7*t+.4).
Independent observed prediction 0.28*sin(2*pi*.64*t+.3) + .13*sin(2*pi*1.31*t-.6).
No fitting on independent captures 200-204. Model parameters are transferred as published Float32 values.
ID recovery bounds: J <=3%, B <=8%, normalized excitation >=.20, fit RMS upper <=.0012Nm.
Held-out measured net-torque prediction RMS <=.0012Nm.
Formal Runtime comparison 1x/4x at the same reference and load conditions.
A fixed legacy K=.65, D=.048. B oracle reference J/B. C measured J/B above.
Common tuning target 18rad/s zeta=.75 for B and C. Stress comparison preserves 01C masks.
C/B agreement bounds: position RMS and overshoot differences <=.01rad, settle/reversal/recovery
each <=50ms and measured peak q current difference <=.05A. Apply to nominal, 4x, 4x delayed.
Source SHA256:
{code_hashes}
""")
print("Frozen before holdout",digest,flush=True)
prediction=run("prediction",id_test,"--predict",*[v for r in models for v in r[8:10]],"--trace")
assert len(prediction["PREDICT"])==5
for name,rows in prediction.items():
    dump(data/f"prediction-{name.lower()}.csv",headers[name],rows)
print("prediction",prediction["PREDICT"],flush=True)
comparison=run("comparison",imp_test,"--mechanical-id-fit",*models[0][8:10],*models[3][8:10],"--trace")
with ZipFile("docs/evidence/2026-11-18-next-servo-01c/raw-evidence.zip") as z:
    for group,args in [("training",["--train","--trace"]),("holdout",["--trace"])]:
        replay=run("01c-"+group,imp_test,*args)
        for name, rows in replay.items():
            expected=list(csv.reader(z.read(f"data/{group}-{name.lower()}.csv").decode().splitlines()))
            assert rows==expected[1:], (group,name,len(rows))
            if group=="holdout" and name in ("QUALITY","GATE"):
                dump(data/f"01c-{name.lower()}.csv"," ".join(expected[0]),rows)
            header=expected[0]
            if name in comparison:
                dump(data/f"comparison-{name.lower()}.csv"," ".join(header),comparison[name])
            print("01C identical",group,name,len(rows),flush=True)
with ZipFile("docs/evidence/2026-11-18-next-servo-01b/raw-evidence.zip") as z:
    replay=run("01b-boundary","test-foc-runtime-impedance-virtual","--trace")
    for name in ("TRACE","SUMMARY","BOUNDARY","RECOVERY","QUALITY"):
        expected=list(csv.reader(z.read(f"data/{name.lower()}.csv").decode().splitlines()))
        assert replay[name]==expected[1:],name
        print("01B identical",name,len(replay[name]),flush=True)
by_name={row[1]:row for row in comparison["RESULT"]}
assert len(by_name)==15 and len(comparison["STOP"])==15
assert len(comparison["DESIGN"])==16 and len(comparison["QUALITY"])==15
gate=comparison["GATE"]
assert len(gate)==1 and gate[0][1]=="jb-invalid-age-C"
assert gate[0][3]=="-5" and gate[0][4]==gate[0][5] and int(gate[0][7])!=0
assert all(row[-1]=="1" for row in prediction["PREDICT"])
for row in comparison["STOP"]:
    assert row[3]==row[4] and row[5]!=row[6]
agreement=[]
for case in ("jb-nominal","jb-quad","jb-delay"):
    b,c=[by_name[case+"-"+method] for method in ("B","C")]
    diffs=[abs(float(c[i])-float(b[i])) for i in (3,5,6,7,8,11)]
    passed=all(d<=limit for d,limit in zip(diffs,(.01,.01,50000,50000,50000,.05)))
    agreement.append([case,*diffs,int(passed)])
dump(data/"comparison-agreement.csv","scenario delta_rms_rad delta_overshoot_rad delta_settle_us delta_reversal_us delta_recovery_us delta_peak_plant_iq_a pass",agreement)
for row in comparison["RESULT"]:
    print(row[1],row[3:9],row[10:14],row[17:19],row[-1])
print("C/B",agreement)
