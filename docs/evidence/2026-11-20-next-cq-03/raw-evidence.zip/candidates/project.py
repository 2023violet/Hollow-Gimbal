"""Project the frozen source outside the working tree for the A/B/C trials."""
import argparse
from pathlib import Path
import shutil

def edit(project, file, old, new):
    path = project / file
    contents = path.read_text(encoding="utf-8")
    found = contents.count(old)
    if found != 1:
        raise ValueError(f"{file}: anchor count {found}: {old[:130]}")
    path.write_text(contents.replace(old, new), encoding="utf-8")

def project_source(frozen, project):
    dirs = ("simulation", "runtime", "core", "g3", "sensors", "protocol", "calibration",
            "control_plane", "firmware", "cmake", "include", "components")
    for name in dirs:
        shutil.copytree(frozen / name, project / name, dirs_exist_ok=True)

def trace_projection(project):
    shutil.copyfile(Path(__file__).with_name("study.inc"), project / "simulation/src/cq03_study.inc")
    path = "simulation/src/falconfoc_virtual_calibrate.c"
    edit(project, path, r'               "%.9g,%.9g,%.9g,%.9g,%.9g,%.9g\n",' + '\n'
                        '               trace->scenario,',
                        r'               "%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%u,%u,%u,%d,%.9g,%.9g\n",' + '\n'
                        '               trace->scenario,')
    edit(project, path, '               (double)cfg->current_limit_a\n',
                        '               (double)cfg->current_limit_a,\n'
                        '               (unsigned)view.output_confirmed,\n'
                        '               (unsigned)driver->output.mode,\n'
                        '               active ? (unsigned)pipeline->cq03_core_saturated : 0U,\n'
                        '               (int)pipeline->last_reason,\n'
                        '#ifdef CQ03_PROTO_C\n'
                        '               (double)pipeline->current.transition_target_a.d,\n'
                        '               (double)pipeline->current.transition_target_a.q\n'
                        '#else\n'
                        '               0.0, 0.0\n'
                        '#endif\n')
    edit(project, path, 'static int run_control(\n', '#include "cq03_study.inc"\n\nstatic int run_control(\n')
    edit(project, path, 'const int status = current_study(trace, profile, init, session);',
                        'const int status = current_study_path[0] != 0\n'
                        '            ? cq03_study(trace, profile, init, session)\n'
                        '            : current_study(trace, profile, init, session);')
    edit(project, "runtime/include/foc_pipeline.h", "    uint32_t feedforward_max_age_us;\n",
         "    uint32_t feedforward_max_age_us;\n    uint8_t cq03_core_saturated;\n")
    edit(project, "runtime/src/foc_pipeline.c", "    pipeline->measured_dq_a = result.measured_dq_a;\n",
         "    pipeline->measured_dq_a = result.measured_dq_a;\n"
         "    pipeline->cq03_core_saturated = result.svpwm.saturated;\n")

def transition_projection(project):
    from transition import apply_transition
    apply_transition(project, edit)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("frozen", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--trace", action="store_true")
    parser.add_argument("--transition", action="store_true")
    args = parser.parse_args()
    project_source(args.frozen, args.project)
    if args.trace:
        trace_projection(args.project)
    if args.transition:
        transition_projection(args.project)

if __name__ == "__main__":
    main()
