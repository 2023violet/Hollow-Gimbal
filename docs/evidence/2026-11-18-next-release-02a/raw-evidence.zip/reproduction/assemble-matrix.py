"""Assemble path-by-path records from the pinned archive and reviewed work notes."""

from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import csv, json, re, sys

out = Path(sys.argv[1])
root = Path("docs/release/2026-11-18-sdk-0.1.0-rc.1")
root.mkdir(parents=True,exist_ok=True)
records = json.loads((out/"history.json").read_bytes())
comp = json.loads((out/"comparison.json").read_bytes())
compare = {item["path"]: item for item in comp["records"]}
early = {
"core/include/foc_core.h": ("G2", "核心公开类型、状态、Clarke/Park/SVPWM API。Legacy 与该头部有通用三相字段和 C++ 链接封装。", "早期类型/API 设计记录与 Legacy 继承范围。", "Core 的接口以及 Current、Motion、Device 的头文件依赖。"),
"core/src/foc_core.c": ("G2", "变换、限幅与调制。G2 明示沿用 Legacy 符号约定，经独立测试向量验证。有限文本筛查未识别实现片段的直接转移。", "原始变换、调制实现草稿及 Legacy 权利链。", "Core 静态库显式编译目标，供 Current 和 Host 使用。"),
"core/include/foc_current.h": ("FOC-01", "独立 dq Current PI 实例、初始化和输出契约。Legacy 电流环的行为是历史背景。", "PI 接口从设计到首轮编写的记录及作者许可。", "Core Current 公开头，由 Pipeline 接入。"),
"core/src/foc_current.c": ("FOC-01", "dq PI、最终占空比还原、抗饱和、事务保护。同期报告描述先写测试再实现的过程。", "抗饱和实现原稿与输入来源。", "Core 静态库显式编译目标，Pipeline 需要其 PI 路径。"),
"core/include/foc_motion.h": ("FOC-02", "转子映射、速度 PI、位置 P 和预测接口。连续机械坐标由调用者建立。", "运动接口设计原稿、参考来源与贡献授权。", "Core 公开运动头，被 Runtime 和 Virtual Motor 使用。"),
"core/src/foc_motion.c": ("FOC-02", "转子电角换算和两个外环数值实现。标准控制关系本身没有给出文件级权利证明。", "外环及预测实现原稿、外部参考边界。", "Core 静态库显式编译目标，Runtime 依赖。"),
"g3/np/include/foc_device.h": ("G3-NP", "ADC 采样/相序、PWM Compare 和输出动作接口。Board1 参数与排序是报告中确认的设计输入。", "接口设计草案与 Board1 继承材料说明。", "Pipeline、Device Sim、Safety 等包含该公开头。"),
"g3/np/src/foc_device.c": ("G3-NP", "原始 ADC 转换、ABC/ACB 与 PWM Compare。原报告逐项标明参考的 Board1 事实；构建闭包无供应商驱动。", "Board1 参考事实与实现表达的边界、实际作者权利依据。", "通过 Host Pipeline 静态库直接编译。"),
"g3/np/include/foc_device_sim.h": ("G3-NP", "仿真寄存器和闭门状态契约。没有供应商寄存器头依赖。", "仿真接口原始设计和独立开发记录。", "Pipeline 公共头和 Demo 直接包含该头。"),
"g3/np/src/foc_device_sim.c": ("G3-NP", "无功率仿真器与受控输出适配器。报告记录始终关闭的 bridge gate。", "Host 模拟器原稿及其测试演化记录。", "Host Pipeline 静态库直接编译，示例调用模拟提交。"),
"g3/safe/include/foc_safe.h": ("G3-SAFE", "软件状态、故障、时间新鲜度、心跳和许可数据结构。", "Safety 契约的原创技术记录和签署人。", "Pipeline 公开契约依赖该头。"),
"g3/safe/src/foc_safe.c": ("G3-SAFE", "软件故障优先级、序号回绕、输出拒绝和清除契约。报告把看门狗许可与实际硬件实现区分。", "状态机设计稿、实现作者确认和贡献授权。", "Host Pipeline 静态库直接编译，运行闭环依赖。"),
"runtime/include/foc_pipeline.h": ("SW01A", "把 Device、Core 与 Safety 显式组合为单执行者 Pipeline 接口。同期测试先暴露缺少该头。", "早期 Pipeline 接口的实际创作记录和授权。", "Runtime 公开头包含该接口。"),
"runtime/src/foc_pipeline.c": ("SW01A", "候选 PI、最终 Safety Gate、Mock 接纳后提交积分。与 Legacy 直接 ISR 的组织不同。", "事务门禁原稿、已知贡献者及新增改动的权利归属。", "Host Pipeline 静态库直接编译，Runtime 调用。"),
"runtime/include/foc_runtime.h": ("SW01B", "H0/H1/Foreground、命令与 Sensor 源身份、生命周期及原子快照接口。", "邮箱和所有权 API 的开发记录及后续贡献授权。", "Host 示例和 Virtual Motor 直接包含该头。"),
"runtime/src/foc_runtime.c": ("SW01B", "调度、原子发布、STOP 和恢复。后续按周期角、生命周期与 IMPEDANCE 扩展。", "初版原子邮箱/调度开发证据，逐段识别后续改动与授权。", "Host Runtime 的直接编译单元，Servo 软件输出契约依赖。"),
}
evidence = {
    "G2": "docs/evidence/2026-11-09-g2-core-validation.md",
    "FOC-01": "docs/evidence/2026-11-10-next-foc-01-current-validation.md",
    "FOC-02": "docs/evidence/2026-11-10-next-foc-02-motion-validation.md",
    "G3-NP": "docs/evidence/2026-11-09-g3-np-validation.md",
    "G3-SAFE": "docs/evidence/2026-11-09-g3-safe-validation.md",
    "SW01A": "docs/evidence/2026-11-10-next-sw01a-pipeline-validation.md",
    "SW01B": "docs/evidence/2026-11-10-next-sw01b-runtime-validation.md",
}
for path in evidence.values():
    assert Path(path).exists(), path

later = {
    "278c691": ("RC0 工作树与新增测试的项目记录；Trajectory、内部数值辅助、Encoder 与基础 Calibration。新增文件依赖既有项目接口。", 
                "docs/code-wiki/AI-handoff-2026-11-15.md"),
    "02425e0": ("VM-01A 项目虚拟 PMSM/Host 周期应用记录；使用公开数学模型和既有 Runtime。", 
                "docs/evidence/2026-11-15-next-vm-01a.md"),
    "af8631b": ("Motor-ID 01A 记录以 robot_mc / ODrive 工程思路为参考，窗积分、回归、API 与连续 PI 输出为项目独立实现。", 
                "docs/evidence/2026-11-17-next-motor-id-01a.md"),
    "e6bd7f4": ("Encoder 01A/01B 记录参考 robot_mc 的周期 LUT 思路。格式、准入、插值、校准与独立质量测试由项目实现。", 
                "docs/evidence/2026-11-27-next-encoder-linear-01a.md; docs/evidence/2026-11-27-next-encoder-linear-01b.md"),
    "a07d7db": ("Servo 项目实现与回归记录。公开力矩方程、力矩可达性、J/B 拟合、K/D 和显式前馈由具体任务与测试跟踪。", 
                "docs/evidence/2026-11-18-next-servo-01a.md; docs/evidence/2026-11-18-next-servo-02a.md; docs/evidence/2026-11-18-next-servo-02c.md"),
}

def later_evidence(row, starter):
    path=row["path"]
    if not starter:
        if row["source"].startswith("scripts/sdk/package/"):
            return ("03B 本地 SDK 入口/文档，由现有公开 Target 和文件闭包组装；保存于原 ZIP 与入包增量。",
                    "docs/evidence/2026-11-18-next-servo-03b.md; SDK-SOURCE-CHANGES.patch")
        return ("03A 本地公开 API 集成示例/文档；03A 证据和 03B 入包补丁记录实际快照。",
                "docs/evidence/2026-11-18-next-servo-03a.md; SDK-SOURCE-CHANGES.patch")
    description, local = later[starter["commit"][:7]]
    if starter["commit"].startswith("278c691") and path.startswith("sensors/"):
        description = "Sensor-01 Encoder source-time decoder and measured velocity work; later alpha-beta and cyclic LUT have separate review records."
        local = "docs/evidence/2026-11-13-next-sensor-01-validation.md; docs/evidence/2026-11-27-next-encoder-linear-01a.md; docs/evidence/2026-11-18-next-sensor-est-02.md"
    return description,local

rows=[]
investigations=[]
for item in records:
    path=item["path"]
    histories=item.get("head_history",[])
    initial=histories[-1] if histories else None
    initial_id=initial["commit"] if initial else "UNTRACKED_IN_BASE_COMMIT"
    date=initial["date"] if initial else "2026-11-18 (snapshot witness)"
    if initial:
        authors=", ".join(sorted(set(record["author"] for record in histories) | set(item["blame_head_authors"])))
        followers=[f"{record['commit'][:7]} {record['subject']}" for record in reversed(histories[:-1])]
        changes="; ".join(followers) or "无后续可达 HEAD 改动"
    else:
        authors="包对应本地开发工作树；无可核查 Git 作者记录"
        changes="快照内容已核对；无可达仓库引入及改动记录"
    if path in early:
        key, relation, missing, dependent=early[path]
        trace=evidence[key]
        origin="UNRESOLVED"
        level="E1"
        possible=relation
        rights="首次入库已确定；入库前完整来源与可再许可权不足"
        notice="UNKNOWN_UPSTREAM_TERMS"
        missing += " 需创作者/共同作者及适用合同、上游条款与书面授权。"
        action="原提交者联系实际权利人并交底；当前保留内部。必要时按审批后的独立规格重写并重验。"
        depends=compare[path]
        for source in (depends["first_blob_in_parent"],):
            assert not source,path
        check=" / ".join(f"{g['group']} {g['max_contiguous_lines']}" for g in depends["comparisons"])
        first = item["original_blob"]
        investigators=[
            f"### `{path}`", "",
            f"- 首版 Git blob `{first['git_blob']}`，SHA-256 `{first['sha256']}`。"
            f"候选 SHA-256 `{item['sha256']}`。",
            f"- 设计与来源线索。{relation} [仓库记录](../../../{trace})",
            f"- 后续历史。{changes}。首版对候选的净行变更为 "
            f"`{item['numstat_since_introduction'].split(chr(9))[0] + '/' + item['numstat_since_introduction'].split(chr(9))[1] if item['numstat_since_introduction'] else '字节相同'}`。",
            f"- 比对摘要。父树无相同 blob；连续规范化行最长值（按比较组）为 {check}。"
            "首版和候选均无外部版权或许可标记。",
            f"- 发布判断。**UNRESOLVED / E1**。{dependent} {missing} 优先补取授权。若确认有上游段落，先界定段落及适用条款。",
            "",
        ]
        investigations.extend(investigators)
    else:
        possible, trace=later_evidence(item, initial)
        origin="PROJECT_ORIGINAL"
        level="E2"
        rights="工程记录支持项目实现或项目集成材料；法律权属待核实"
        notice="PENDING_SCOPE_REVIEW"
        missing="实际版权持有人、共同贡献/雇佣/合同及适用工具或参考材料的可再许可条款；所选许可与批准记录。"
        action="项目维护者确认分组权利链；由有权许可的所有者批准具体范围。"
        relation=possible
    rows.append({
        "package_path":path,
        "sha256":item["sha256"],
        "module":item["module"],
        "repo_path":item["source"],
        "file_type":item["kind"],
        "snapshot_git_state":item["source_state"],
        "introduction_or_witness_date":date,
        "first_commit":initial_id,
        "first_blob_sha256":item.get("original_blob",{}).get("sha256","N/A"),
        "major_changes":changes,
        "known_git_authors_or_snapshot_attribution":authors,
        "origin_class_engineering":origin,
        "evidence_grade":level,
        "possible_upstream_or_dependency":possible,
        "original_copyright_notice":"当前文件无已发现的版权声明" if path != "NOTICE-REVIEW.md" else "仅审查草案，无实际权利声明",
        "applicable_upstream_license":"未定位到适用于本路径的上游许可文本",
        "provenance_and_license_evidence":trace + "; " + ("逐项历史/首次 blob/固定上游筛查" if path in early else "逐项 Git 或快照身份") + "; 未发现已批准项目许可",
        "adaptation_status":relation,
        "rights_finding":rights,
        "public_redistribution_status":"NOT_AUTHORIZED_ON_CURRENT_EVIDENCE",
        "notice_obligation":notice,
        "missing_evidence":missing,
        "next_action_and_responsible_party":action,
    })
assert {r["package_path"] for r in rows if r["origin_class_engineering"]=="UNRESOLVED"}==set(early)
with (root/"source-provenance.tsv").open("w",encoding="utf8",newline="") as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter="\t",lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
assert len(rows)==52 and len({row["package_path"] for row in rows})==52

early_path = root / "early-files.md"
header = early_path.read_text(encoding="utf8").split("\n### ", 1)[0].rstrip()
early_path.write_text(header + "\n\n" + "\n".join(investigations), encoding="utf8", newline="\n")

with ZipFile("docs/evidence/2026-11-18-next-servo-03b/raw-evidence.zip") as archive:
    gate = json.loads(archive.read("sdk-gate/sdk-gate.json"))
    assert gate["archive_sha256"]=="4293dcd599859226ea52248d23262c134cffbf7d74fd09bd2a258aad8b8c5694"
    assert gate["manifest_sha256"]=="34f3cfe5e54bf6daab9d182fac01b2a1fae594bba33d77a3ab852bfc5ca5f0c4"
    assert gate["TECHNICAL_GATE"]=="PASS"
    assert gate["release_status"]=="RELEASE_BLOCKED"
    for lane in ["clang","gcc","clang-asan-ubsan"]:
        log=archive.read(f"sdk-gate/{lane}.log").decode("utf8","replace")
        for marker in ("100% tests passed out of 4","external servo PASS",
                       "Core-only IMPEDANCE PASS","fault checks PASS","test-sdk-mechanical-id"):
            assert marker in log,(lane,marker)
    (out/"03b-existing-technical-gate.json").write_text(json.dumps(gate,indent=2)+"\n",encoding="utf8")
print("52 matrix rows, 16 individual records; 03B technical logs verified against exact package identity")

