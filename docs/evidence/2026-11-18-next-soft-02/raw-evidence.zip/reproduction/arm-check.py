from pathlib import Path
import hashlib, shutil, subprocess as sp, tarfile
root=Path(__file__).resolve().parent
src=Path.cwd()
baseline=root/"arm-baseline"
baseline.mkdir(exist_ok=True)
arc=root/"arm-baseline.tar"
sp.run(["git","archive","--format=tar","--output",arc,"HEAD","core","runtime","g3"],check=True)
with tarfile.open(arc) as t:
    t.extractall(baseline,filter="data")
shutil.copytree(root/"protected/control_plane",baseline/"control_plane",dirs_exist_ok=True)
probe=root/"layout.c"
probe.write_text('''#include "foc_parameter.h"
char runtime_bytes[sizeof(struct foc_runtime)];
char policy_bytes[sizeof(struct foc_runtime_config)];
char snapshot_bytes[sizeof(struct foc_runtime_snapshot)];
char sensor_slot_bytes[sizeof(struct foc_runtime_sensor_slot)];
char descriptor_bytes[sizeof(struct foc_parameter_descriptor)];
''')
flags=["-std=c11","-Os","-mcpu=cortex-m4","-mthumb","-mfloat-abi=soft","-ffunction-sections",
       "-fdata-sections","-fstack-usage","-Wall","-Wextra","-Wpedantic"]
headers=["core/include","runtime/include","control_plane/include","g3/np/include","g3/safe/include"]
comp=sp.check_output(["arm-none-eabi-gcc","--version"],text=True)
print(comp.strip(),flush=True)
print("Flags:",*flags,flush=True)
for label,tree in (("SOFT-01",baseline),("SOFT-02",src)):
    out=root/label
    out.mkdir(exist_ok=True)
    units=[tree/"runtime/src/foc_runtime.c",tree/"control_plane/src/foc_parameter.c",probe]
    if label=="SOFT-02":
        units += [tree/"core/src/foc_motion_limits.c",tree/"core/src/foc_following_error.c"]
    for unit in units:
        obj=out/(unit.stem+".o")
        sp.run(["arm-none-eabi-gcc",*flags,*("-I"+str(tree/i) for i in headers),"-c",unit,"-o",obj],check=True)
        def output(tool,*opts):
            return sp.check_output(["arm-none-eabi-"+tool,*opts,obj],text=True)
        print(label,unit.name,output("size").strip(),sep="\n",flush=True)
        if unit==probe:
            for line in output("nm","-S").splitlines():
                _,size,_,name=line.split()
                print(name,int(size,16))
        if unit.stem=="foc_parameter":
            for line in output("nm","-S").splitlines():
                if line.endswith(" catalog"):
                    print("parameter_catalog_bytes",int(line.split()[1],16))
        if unit.stem in ("foc_motion_limits","foc_following_error","foc_runtime"):
            print("undefined imports:\n"+output("nm","-u").strip())
        if unit!=probe:
            print("stack usage:\n"+(obj.with_suffix(".su").read_text().strip()))
for label,out in (("SOFT-01",root.parent/"servo03a_1795019208235"/"final-complete"/"locked-arm"),
                  ("SOFT-02",root/"final-complete"/"locked-arm")):
    elf=next(out.glob("*.elf"))
    binary=next(out.glob("*.bin"))
    print(label,"locked firmware",binary.stat().st_size,hashlib.sha256(binary.read_bytes()).hexdigest())
    syms=sp.check_output(["arm-none-eabi-nm","-S",elf],text=True)
    for s in ("foc_parameter_prepare_initial","foc_impedance_feedforward_evaluate","servo_demo"):
        assert s not in syms,s
    print(sp.check_output(["arm-none-eabi-size",elf],text=True).strip())
