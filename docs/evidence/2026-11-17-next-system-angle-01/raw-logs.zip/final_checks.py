import json,pathlib,shutil,uuid
from audit import OUT,ROOT,SRC,CC,ENV,run

repo=OUT/'green-repo'
for rel in ['simulation/tests/test_foc_periodic_chain.c','simulation/tests/foc_system_angle_oracle.h']:
    shutil.copy2(ROOT/rel,repo/rel)

for lane,project,cc,asan in [('core','core',CC,False),('runtime','runtime',CC,False),
    ('simulation','simulation',CC,False),('simulation-gcc','simulation','C:/mingw64/bin/gcc.exe',False),
    ('core-asan','core',CC,True),('simulation-asan','simulation',CC,True)]:
    dest=OUT/'final'/lane
    args=['cmake','-S',repo/project,'-B',dest/'build','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug',
          '-DCMAKE_C_COMPILER='+cc]
    if asan:
        args+=['-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer',
               '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    run(dest,'configure',args)
    run(dest,'build',['cmake','--build',dest/'build','--parallel','4'])
    run(dest,'ctest',['ctest','--test-dir',dest/'build','--output-on-failure'])
    if lane.startswith('simulation'):
        run(dest,'data',[dest/'build/test-foc-periodic-chain.exe','--system-angle-csv',dest/'data.csv'])

dest=OUT/'gates';env=ENV.copy()
temp=pathlib.Path('D:/sa01-'+uuid.uuid4().hex[:8]);temp.mkdir(exist_ok=False)
env['TEMP']=env['TMP']=str(temp)
artifacts=[]
for preset in ['fw-tiny-carrier-minsizerel','fw-standard-carrier-minsizerel','fw-full-diag-carrier-debug']:
    for leaf in ['falcon-foc-at32.elf','falcon-foc-at32.map']:
        rel=pathlib.Path('build')/preset/'output'/leaf;target=repo/rel
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,target)
        import hashlib
        digest=hashlib.sha256(target.read_bytes()).hexdigest()
        assert digest==hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
        artifacts.append({'path':str(rel),'sha256':digest,'origin':'historical artifact copy, not a new ARM build'})
(OUT/'gate-isolation.json').write_text(json.dumps({'temp':str(temp),'legacy_artifacts':artifacts},indent=2))
def ps(name,script,*args):
    return run(dest,name,['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',repo/script,
                         '-RepoRoot',repo,*args],env=env,cwd=repo)
ps('seed-gcc','scripts/flows/host/run_host_tests.ps1','-CompilerPath','C:/mingw64/bin/gcc.exe')
ps('source','scripts/gates/check_falconfoc_source_contract.ps1')
ps('format','scripts/format_themis.ps1','-Scope','all','-Mode','check')
p=ps('strict-all','scripts/gates/check_themis_quality_gate.ps1','-Scope','all','-RequireCMakeFormatter','-Summary')
assert '[Total]   PASS' in p.stdout and '45/45' in p.stdout
assert p.stdout.count('[cmake_quality] format-check:')==30
