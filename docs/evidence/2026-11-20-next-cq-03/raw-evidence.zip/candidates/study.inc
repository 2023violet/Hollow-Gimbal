/* Scratch-only CQ-03 observation, included in the reviewed calibration CLI. */
enum cq03_disturbance {
    CQ03_NONE, CQ03_RS_HIGH, CQ03_RS_LOW, CQ03_LOW_CAP, CQ03_SPIN_POS, CQ03_SPIN_NEG,
    CQ03_STOP, CQ03_STALE_COMMAND, CQ03_STALE_H1, CQ03_SENSOR, CQ03_REJECT
};

static int cq03_trial(
    FILE *output, const struct foc_virtual_current_profile *original,
    const struct calibrated_init *measured, const struct foc_encoder_lut *lut,
    const struct foc_virtual_cal_flux_result *flux, const char *scenario,
    int policy, float initial, float second, enum cq03_disturbance disturbance
)
{
    const char *const groups[] = {"A", "B", "C"};
    struct foc_virtual_current_profile profile = *original;
    struct foc_cal_application_candidate variant = *measured->candidate;
    struct calibrated_init init = {.candidate = &variant, .restored_lut = lut};
    struct foc_virtual_current driver = {0};
    const enum foc_runtime_mode mode = FOC_RUNTIME_MODE_CURRENT;
    const bool negative = disturbance >= CQ03_STOP;
    const uint32_t duration_us = negative ? 12000U : 60000U;
    const struct cycle_trace trace = {.output = output, .group = groups[policy], .scenario = scenario};
    if (disturbance == CQ03_RS_HIGH) {
        profile.motor.rs_ohm *= 1.25;
        profile.motor.ld_h *= 0.8;
        profile.motor.lq_h *= 1.25;
    } else if (disturbance == CQ03_RS_LOW) {
        profile.motor.rs_ohm *= 0.75;
        profile.motor.ld_h *= 1.2;
        profile.motor.lq_h *= 0.75;
    } else if (disturbance == CQ03_LOW_CAP) {
        profile.vbus_v = 6.1f;
        variant.pipeline.current.pwm.voltage_limit_v = 0.23f;
    } else if (disturbance == CQ03_SPIN_POS || disturbance == CQ03_SPIN_NEG) {
        profile.initial_state.mechanical_velocity_rad_s = disturbance == CQ03_SPIN_POS ? 2.0 : -2.0;
    }
    if (policy == 1) {
        if (!flux->qualified || flux->capture == 0U ||
            !foc_cal_workflow_identity_matches(&variant.gains.identity, &flux->kt.identity) ||
            !isfinite(variant.gains.model.rs_ohm) || variant.gains.model.rs_ohm <= 0.0f) {
            return -1;
        }
        variant.pipeline.feedforward = (struct foc_pipeline_feedforward_config){
            .enabled = true,
            .model = {
                .ld_h = variant.gains.model.ld_h,
                .lq_h = variant.gains.model.lq_h,
                .psi_f_wb = flux->flux_wb,
            },
            .max_age_us = 500U,
        };
    }
#ifdef CQ03_PROTO_C
    if (policy == 2) {
        if (!isfinite(variant.gains.model.rs_ohm) || variant.gains.model.rs_ohm <= 0.0f ||
            !isfinite(variant.gains.model.ld_h) || variant.gains.model.ld_h <= 0.0f ||
            !isfinite(variant.gains.model.lq_h) || variant.gains.model.lq_h <= 0.0f) {
            return -1;
        }
        variant.pipeline.transition_v_per_a = (struct foc_vector_dq){
            variant.gains.model.ld_h / tuning.current.sample_period_s,
            variant.gains.model.lq_h / tuning.current.sample_period_s,
        };
    }
#endif
    printf("{\"record\":\"scenario\",\"scenario\":\"%s\",\"group\":\"%s\","
           "\"target_a\":%.9g,\"second_a\":%.9g,\"plant_rs_ohm\":%.9g,\"plant_ld_h\":%.9g,"
           "\"plant_lq_h\":%.9g,\"plant_flux_wb\":%.9g,\"plant_initial_speed_rad_s\":%.9g,"
           "\"measured_rs_ohm\":%.9g,\"measured_ld_h\":%.9g,\"measured_lq_h\":%.9g,"
           "\"measured_flux_wb\":%.9g,\"flux_capture\":%" PRIu32 ",\"d_cap\":%" PRIu32 ","
           "\"q_cap\":%" PRIu32 ",\"vbus_v\":%.9g,\"cap_v\":%.9g,\"current_cap_a\":%.9g,"
           "\"command1_us\":700,\"arm_us\":1400,\"start_us\":1800,"
           "\"fresh_command_us\":1800,\"command2_us\":21800}\n",
           scenario, groups[policy], (double)initial, (double)second,
           profile.motor.rs_ohm, profile.motor.ld_h, profile.motor.lq_h, profile.motor.psi_f_wb,
           profile.initial_state.mechanical_velocity_rad_s,
           (double)variant.gains.model.rs_ohm, (double)variant.gains.model.ld_h,
           (double)variant.gains.model.lq_h, (double)flux->flux_wb, flux->capture,
           variant.gains.d_capture, variant.gains.q_capture, (double)profile.vbus_v,
           (double)variant.pipeline.current.pwm.voltage_limit_v,
           (double)variant.pipeline.current.current_limit_a);

    if (foc_virtual_current_init_with(&driver, &profile, calibrated, &init) != 0 ||
        foc_virtual_current_run_until(&driver, 700U) != 0 ||
        foc_virtual_current_publish_iq(&driver, 0.0f, initial) != FOC_RUNTIME_OK ||
        foc_virtual_current_run_until(&driver, 1300U) != 0 ||
        !lifecycle(&driver, FOC_RUNTIME_ACTION_ARM, mode, 1400U) ||
        foc_virtual_current_publish_iq(&driver, 0.0f, initial) != FOC_RUNTIME_OK ||
        foc_virtual_current_run_until(&driver, 1600U) != 0 ||
        !lifecycle(&driver, FOC_RUNTIME_ACTION_START, mode, 1800U) ||
        foc_virtual_current_publish_iq(&driver, 0.0f, initial) != FOC_RUNTIME_OK) {
        return -2;
    }
    if (disturbance == CQ03_REJECT && foc_virtual_current_reject_next_update(&driver) != 0) {
        return -2;
    }
    uint32_t injection_us = 0U;
    uint32_t at_injection = 0U;
    bool injection_seen = false;
    float target = initial;
    for (uint32_t elapsed = 0U; elapsed <= duration_us; elapsed += 200U) {
        if (foc_virtual_current_run_until(&driver, 1800U + elapsed) != 0 ||
            trace_cycle(&trace, &driver, elapsed, &(struct foc_vector_dq){0.0f, target}) != 0) {
            return -3;
        }
        if (negative && elapsed == 5200U && disturbance != CQ03_REJECT &&
            disturbance != CQ03_STALE_COMMAND) {
            injection_us = driver.virtual_time_us;
            at_injection = driver.output.accepted_updates;
            injection_seen = true;
            if (disturbance == CQ03_STOP && foc_virtual_current_request_stop(&driver) != 0) {
                return -4;
            }
            if (disturbance == CQ03_STALE_H1) {
                driver.next_h1_us += 4000U;
            }
            if (disturbance == CQ03_SENSOR &&
                (foc_virtual_current_mark_sensor_fault(&driver, driver.virtual_time_us) != 0 ||
                 foc_virtual_current_fail_next_sensor(&driver) != 0)) {
                return -4;
            }
        }
        if (disturbance == CQ03_SENSOR && injection_seen &&
            foc_virtual_current_fail_next_sensor(&driver) != 0) {
            return -4;
        }
        if (elapsed % 1000U == 0U && elapsed > 0U && elapsed < duration_us &&
            (!negative || ((elapsed <= 5000U || disturbance == CQ03_SENSOR) &&
                           disturbance != CQ03_STALE_COMMAND &&
                           disturbance != CQ03_REJECT))) {
            target = elapsed >= 20000U ? second : initial;
            if (foc_virtual_current_publish_iq(&driver, 0.0f, target) != FOC_RUNTIME_OK) {
                return -4;
            }
        }
    }
    const uint32_t updates = driver.output.accepted_updates;
    if (!negative) {
        struct foc_runtime_snapshot running;
        if (foc_virtual_current_snapshot(&driver, &running) != FOC_RUNTIME_OK ||
            running.state != FOC_SAFE_STATE_RUNNING || !running.output_confirmed ||
            updates != duration_us / 200U || driver.output.rejected_updates != 0U ||
            foc_virtual_current_request_stop(&driver) != 0 ||
            foc_virtual_current_run_until(&driver, driver.virtual_time_us + 1000U) != 0 ||
            trace_cycle(&trace, &driver, duration_us + 1000U, &(struct foc_vector_dq){0}) != 0) {
            return -5;
        }
    }
    struct foc_runtime_snapshot end;
    if (foc_virtual_current_snapshot(&driver, &end) != FOC_RUNTIME_OK) {
        return -6;
    }
    const struct foc_pipeline *pipeline = &driver.runtime.pipeline;
    printf("{\"record\":\"outcome\",\"scenario\":\"%s\",\"group\":\"%s\","
           "\"updates\":%" PRIu32 ",\"rejected\":%" PRIu32 ",\"injection_seen\":%s,"
           "\"injection_us\":%" PRIu32 ",\"updates_at_injection\":%" PRIu32 ","
           "\"last_update_us\":%" PRIu32 ",\"inhibit_accepted_us\":%" PRIu32 ","
           "\"sensor_failure_us\":%" PRIu32 ",\"end_state\":%u,\"end_fault\":%" PRIu32 ","
           "\"end_high_z\":%s,\"end_confirmed\":%s,\"end_updates\":%" PRIu32 ","
           "\"end_integral_d_v\":%.9g,\"end_integral_q_v\":%.9g}\n",
           scenario, groups[policy], updates, driver.output.rejected_updates,
           injection_seen ? "true" : "false", injection_us, at_injection,
           driver.fault_events.last_accepted_update_us, driver.fault_events.inhibit_accepted_us,
           driver.fault_events.sensor_failure_us, (unsigned)end.state, end.faults,
           driver.output.mode == FOC_VIRTUAL_OUTPUT_HIGH_Z ? "true" : "false",
           end.output_confirmed ? "true" : "false", driver.output.accepted_updates,
           (double)pipeline->current.integral_v.d, (double)pipeline->current.integral_v.q);
    return driver.output.mode == FOC_VIRTUAL_OUTPUT_HIGH_Z && end.output_confirmed &&
            driver.output.accepted_updates == updates ? 0 : -7;
}

static int cq03_study(
    FILE *output, const struct foc_virtual_current_profile *profile,
    struct calibrated_init *reviewed, const struct foc_virtual_calibration *session
)
{
    struct foc_encoder_lut lut;
    if (foc_encoder_cal_make_lut(&session->workflow.result.lut, &lut) != FOC_ENCODER_CAL_OK ||
        fputs(
            "scenario,group,elapsed_us,h0_us,sample_us,h1_us,encoder_us,encoder_age_us,"
            "angle_valid,safety_state,action,update_applied,faults,session,near_voltage_cap,"
            "id_ref_a,iq_ref_a,id_measured_a,iq_measured_a,id_plant_a,iq_plant_a,"
            "theta_h0_rad,theta_plant_rad,theta_h1_rad,encoder_rad,encoder_speed_rad_s,"
            "shaft_rad,shaft_speed_rad_s,vd_v,vq_v,duty_a,duty_b,duty_c,id_integral_v,"
            "iq_integral_v,kp_d,kp_q,ki_d,ki_q,vbus_v,voltage_limit_v,load_nm,current_limit_a,"
            "output_confirmed,output_mode,saturated,reason,target_history_d_a,target_history_q_a\n",
            output
        ) < 0) {
        return -1;
    }
    static const struct {
        const char *name;
        float a;
        float b;
        enum cq03_disturbance disturbance;
    } cases[] = {
        {"nominal", 0.45f, -0.45f, CQ03_NONE},
        {"small", 0.15f, -0.15f, CQ03_NONE},
        {"rl_high", 0.45f, -0.45f, CQ03_RS_HIGH},
        {"rl_low", 0.45f, -0.45f, CQ03_RS_LOW},
        {"restricted", 0.45f, -0.15f, CQ03_LOW_CAP},
        {"positive_spin", 0.45f, -0.45f, CQ03_SPIN_POS},
        {"negative_spin", 0.45f, -0.45f, CQ03_SPIN_NEG},
        {"stop", 0.45f, -0.45f, CQ03_STOP},
        {"stale_command", 0.45f, -0.45f, CQ03_STALE_COMMAND},
        {"stale_h1", 0.45f, -0.45f, CQ03_STALE_H1},
        {"sensor_fault", 0.45f, -0.45f, CQ03_SENSOR},
        {"reject_first", 0.45f, -0.45f, CQ03_REJECT},
    };
#ifdef CQ03_PROTO_C
    const int policies = 3;
#else
    const int policies = 2;
#endif
    for (unsigned index = 0U; index < sizeof cases / sizeof cases[0]; ++index) {
        for (int sign = 1; sign >= -1; sign -= 2) {
            char name[48];
            (void)snprintf(name, sizeof name, "%s_%s", cases[index].name, sign == 1 ? "pos" : "neg");
            for (int policy = 0; policy < policies; ++policy) {
                const int status = cq03_trial(output, profile, reviewed, &lut, &session->flux, name,
                                              policy, (float)sign * cases[index].a,
                                              (float)sign * cases[index].b, cases[index].disturbance);
                if (status != 0) {
                    fprintf(stderr, "CQ03 trial %s %d failed %d\n", name, policy, status);
                    return status;
                }
            }
        }
    }
    struct foc_cal_application_candidate invalid = *reviewed->candidate;
    invalid.pipeline.feedforward = (struct foc_pipeline_feedforward_config){
        .enabled = true,
        .model = {.ld_h = NAN, .lq_h = reviewed->candidate->gains.model.lq_h,
                  .psi_f_wb = session->flux.flux_wb},
        .max_age_us = 500U,
    };
    struct calibrated_init invalid_init = {.candidate = &invalid, .restored_lut = &lut};
    struct foc_virtual_current driver = {0};
    const bool b_rejected =
        foc_virtual_current_init_with(&driver, profile, calibrated, &invalid_init) != 0 &&
        !driver.runtime.initialized && driver.output.accepted_updates == 0U;
    printf("{\"record\":\"invalid_admission\",\"group\":\"B\",\"rejected\":%s}\n",
           b_rejected ? "true" : "false");
#ifdef CQ03_PROTO_C
    invalid.pipeline.feedforward.enabled = false;
    invalid.pipeline.transition_v_per_a.q = NAN;
    driver = (struct foc_virtual_current){0};
    invalid_init.sensor = (struct foc_cal_application_sensor){0};
    const bool c_rejected =
        foc_virtual_current_init_with(&driver, profile, calibrated, &invalid_init) != 0 &&
        !driver.runtime.initialized && driver.output.accepted_updates == 0U;
    printf("{\"record\":\"invalid_admission\",\"group\":\"C\",\"rejected\":%s}\n",
           c_rejected ? "true" : "false");
    return b_rejected && c_rejected ? 0 : -2;
#else
    return b_rejected ? 0 : -2;
#endif
}
