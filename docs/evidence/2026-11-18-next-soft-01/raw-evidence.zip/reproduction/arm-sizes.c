#include "foc_parameter.h"
const unsigned char size_candidate[sizeof(struct foc_parameter_candidate)] = {0};
const unsigned char size_receipt[sizeof(struct foc_parameter_receipt)] = {0};
const unsigned char size_descriptor[sizeof(struct foc_parameter_descriptor)] = {0};
const unsigned char size_edit[sizeof(struct foc_parameter_edit)] = {0};

