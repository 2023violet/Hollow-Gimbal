from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os, subprocess as sp, sys

root = Path(__file__).resolve().parent
source = root / "foreign Servo Consumer"
sdk = root / "FalconFOC SDK Source"
assert not (sdk / ".git").exists() and not (source / ".git").exists()

def verify(label, compiler):
    build = root / ("Consumer Verify " + label)
    env = os.environ.copy()
    env["PATH"] = os.pathsep.join([r"C:\mingw64\bin", env["PATH"]])
    with (root / f"minimal-external-{label}.log").open("w", encoding="utf8") as log:
        print(f"SDK .git present: {(sdk / '.git').exists()}", file=log, flush=True)
        commands = [
            [compiler, "--version"],
            ["cmake", "-S", source, "-B", build, "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Debug",
             f"-DCMAKE_C_COMPILER={compiler}", f"-DFALCONFOC_SOURCE_DIR={sdk}"],
            ["cmake", "--build", build, "--target", "external-servo-consumer", "--verbose"],
            [build / "external-servo-consumer.exe"],
            ["ctest", "--test-dir", build, "-R", "^external-servo-consumer$", "--output-on-failure"],
        ]
        for cmd in commands:
            print("$ " + sp.list2cmdline(list(map(str,cmd))), file=log, flush=True)
            status = sp.run(cmd, env=env, stdout=log, stderr=sp.STDOUT).returncode
            print(f"exit={status}", file=log, flush=True)
            if status:
                return status
    print(f"minimal-external-{label} PASS", flush=True)
    return 0

with ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(lambda args: verify(*args),
                            [("clang","clang"), ("gcc","C:/mingw64/bin/gcc.exe")]))
sys.exit(int(any(results)))
