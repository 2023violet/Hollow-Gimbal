# External consumer evidence

The verification root was outside the repository.

```
consumer-final/
  src/isocore/           exact copy of checkout core/ (no sibling G3 or Legacy)
  src/caller/            copy of examples/external-consumer/
  src/modules/core/      copy used by the standard Runtime source target
  src/modules/g3/        copy used by the standard Runtime source target
  src/modules/runtime/   copy used by the standard Runtime source target
  src/modules/sensors/   copy used by the standard Sensor source target
  src/servo/             copy of examples/servo/
  src/calibration/       copy of examples/calibration-workflow/
  raw/                   compiler, commands, logs and hashes
```

To replay, stage the listed source copies from the matching repository in a
fresh workspace, copy `verify.ps1` and `verify-product-examples.ps1` into its
`raw/`, then run the following with PowerShell 7.

```powershell
& "$root/raw/verify.ps1" -Lane clang -EvidenceDir $root
& "$root/raw/verify.ps1" -Lane gcc -EvidenceDir $root
& "$root/raw/verify.ps1" -Lane asan -EvidenceDir $root
& "$root/raw/verify-product-examples.ps1" -Repo $repo -EvidenceDir $root -Compiler clang
& "$root/raw/verify-product-examples.ps1" -Repo $repo -EvidenceDir $root -Compiler gcc
```

Each consumer verification lane builds and installs the copied Core, moves the
installation to a new prefix, and configures the copied caller from that prefix.
The build logs show the exact include and archive paths. The ASan/UBSan lane
adds LLVM's Windows sanitizer DLL directory to the process PATH. The separate
Servo and Calibration builds reuse the checkout's Host source targets, with the
copied example as the out-of-tree CMake entry point.

`source-sha256.txt` hashes the staged source files. Each consumer lane has its
own resolved configuration, installed package and executable hashes. The frozen
Core-only failure trace captures the pre-fix configure error for the same source
layout and BUILD_TESTING=OFF option.
