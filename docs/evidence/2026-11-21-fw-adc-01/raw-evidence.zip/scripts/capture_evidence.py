"""Write persistent FW-ADC-01 evidence: real orchestrator/adapter outputs for key scenarios.

Usage: python -I capture_evidence.py <host build dir> <new output dir>
"""
import hashlib
import json
import struct
import subprocess
import sys
from pathlib import Path

BUILD, OUT = Path(sys.argv[1]), Path(sys.argv[2])
FIXTURE, ADAPTER = BUILD / "foc-board-capture-boot-fixture.exe", BUILD / "foc-board-adc-candidate.exe"
TOOL = Path("tools/falconfoc-calibration-replay")
GAIN = 3.3 / (4095 * 0.5)
CAL = {"profile": "CALIBRATED", "source_direction": -1, "calibration_direction": -1, "runtime_direction": 1,
       "pole_pairs": 11, "coordinate": "RAW_NO_LUT", "supply_id": 0x56464331, "review_id": 0x01210001}
OUT.mkdir(parents=True)
summary = []


def scenario(name, mode, adc, configuration, source="HOST_VIRTUAL", producer="host", witness=True,
             fault=None, host_kind="synthetic"):
    folder = OUT / name
    folder.mkdir()
    image = folder / "capture.bin"
    fixture = subprocess.run([str(FIXTURE), mode, str(image), "--adc", ",".join(map(str, adc)),
                              "--producer", producer], capture_output=True, text=True, check=True)
    (folder / "fixture.txt").write_text(fixture.stdout, encoding="utf-8")
    raw = image.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    capture_id = struct.unpack_from("<I", raw, 20)[0]
    start, end = struct.unpack_from("<2I", raw, 36)
    board = source == "BOARD_RECORDED"
    meta = {"format_version": 1 if configuration is None else 2, "source": source, "capture_id": capture_id,
            "build_tag": 0, "firmware_sha256": "1" * 64 if board else None, "raw_sha256": sha,
            "identity": dict(device_id=11, motor_id=12, encoder_id=13, frame_id=14),
            "origin_note": "FW-ADC-01 Host synthetic rows from the production writer"}
    if configuration is not None:
        meta["configuration"] = configuration
    (folder / "metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    args = [sys.executable, "-B", str(TOOL / "board_adc_candidate.py"), str(image), "--metadata",
            str(folder / "metadata.json"), "--adapter", str(ADAPTER), "--out", str(folder / "out"),
            "--host-kind", host_kind]
    if witness:
        (folder / "witness.json").write_text(json.dumps({
            "format_version": 1, "stage": "ADC_ZERO", "capture_id": capture_id, "raw_sha256": sha,
            "firmware_sha256": meta["firmware_sha256"], "covers_start_us": start, "covers_end_us": end,
            "witness_source": "EXTERNAL_INSTRUMENT" if board else "HOST_VIRTUAL",
            "independent_zero_current": True, "sampling_window_verified": True, "amp_per_count": GAIN,
            "instrument": {"id": "fixture", "model": "deterministic fixture", "calibration": "test"},
            "evidence_reference": "Host fixture declares zero current; not a physical witness."}, indent=2),
            encoding="utf-8")
        args += ["--qualification", str(folder / "witness.json")]
    if fault:
        args += ["--fault", fault]
    process = subprocess.run(args, capture_output=True, text=True)
    (folder / "orchestrator.json").write_text(process.stdout, encoding="utf-8")
    report = json.loads(process.stdout)
    candidate = report.get("candidate") or {}
    summary.append(f"{name:28s} exit {process.returncode} status {report.get('status')} "
                   f"reason {report.get('reason', candidate.get('candidate_failure', '-'))} "
                   f"offsets {candidate.get('offset_a', '-')}/{candidate.get('offset_b', '-')}/"
                   f"{candidate.get('offset_c', '-')} formal_untouched {candidate.get('formal_untouched', '-')}")


T = (2041.25, 2056.75, 2049.5)
scenario("calibrated-host-synthetic", "calibrated", T, CAL)
scenario("nominal-legacy-metadata", "nominal", T, None)
scenario("calibrated-host-virtual", "calibrated", T, CAL, host_kind="virtual")
scenario("no-zero-current-witness", "calibrated", T, CAL, witness=False)
scenario("board-recorded-unverified", "calibrated", T, CAL, source="BOARD_RECORDED", producer="board")
scenario("offset-c-out-of-window", "calibrated", (2041, 2056, 2700), CAL)
scenario("rotor-identity-wrong", "calibrated", T, CAL, fault="rotor-pole-pairs")
scenario("runtime-init-failure", "calibrated", T, CAL, fault="runtime-init")
scenario("adc-identity-gain-wrong", "calibrated", T, CAL, fault="identity-gain")
scenario("swapped-ic-ib-ranks", "calibrated", (T[1], T[0], T[2]), CAL)
(OUT / "summary.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")
print("\n".join(summary))
