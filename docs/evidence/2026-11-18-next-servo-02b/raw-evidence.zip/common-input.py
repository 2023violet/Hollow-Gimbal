from pathlib import Path
import csv, math, sys
from collections import defaultdict
root=Path(__file__).parent
data=root/"data"
trace=Path(sys.argv[1]) if len(sys.argv)>1 else data/"noise-holdout-trace.csv"
rows=defaultdict(list)
with trace.open(newline="") as f:
    for row in csv.DictReader(f):
        if row["variant"]=="A" and row["candidate"].startswith("hold-"):
            rows[row["candidate"]].append(row)
with (data/"noise-common-input.csv").open("w",newline="") as f:
    out=csv.writer(f)
    out.writerow(["case","variant","samples","same_raw_samples","tail_hp_d_nm","tail_hp_iq_a","max_a_reconstruction_delta_a"])
    for name, observed in rows.items():
        d=0.210000008 if name=="hold-4x-matched" else 0.0480000041
        count=0
        lp=[[0.0,0.0] for _ in range(3)]
        sums=[[0.0,0.0] for _ in range(3)]
        last=None
        max_delta=0.0
        for tick in observed:
            timestamp=int(tick["capture_us"])
            ref=float(tick["reference_rad_s"])
            kd=float(tick["d_raw_nm"])
            speed=float(tick["sensor_velocity_rad_s"])
            assert abs(kd-d*(ref-speed))<5e-8
            if last is None:
                filtered=speed
            else:
                w_dt=2*math.pi*48*(timestamp-last)*1e-6
                assert timestamp-last in (464,536)
                filtered+=w_dt/(1+w_dt)*(speed-filtered)
            last=timestamp
            kff=float(tick["k_nm"])+float(tick["ff_nm"])
            damp=[kd,.75*kd,d*(ref-filtered)]
            iq=[max(-.315,min(.315,kff+v))/.15 for v in damp]
            max_delta=max(max_delta,abs(iq[0]-float(tick["request_a"])))
            tail=int(tick["t_us"])>=1300000
            count+=tail
            for i in range(3):
                for j,v in enumerate((damp[i],iq[i])):
                    lp[i][j]+=.2*(v-lp[i][j])
                    if tail:
                        sums[i][j]+=(v-lp[i][j])**2
        assert max_delta<2e-7,(name,max_delta)
        for variant,values in zip("ABC",sums):
            out.writerow([name,variant,count,len(observed),*[f"{math.sqrt(v/count):.10g}" for v in values],f"{max_delta:.10g}"])
assert len(rows)==3
