
from pathlib import Path
import csv, os, sys
from collections import defaultdict
root=Path(__file__).parent
sys.path.insert(0,str(root/"plot-deps"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator

rows=defaultdict(list)
with (root/"data/trace.csv").open(newline="") as f:
    for row in csv.DictReader(f):
        rows[row["scenario"]].append(row)
def curve(ax, scenario, name, label, color, style="-", step=False):
    data=rows[scenario]
    times=[int(r["elapsed_us"])*1e-6 for r in data]
    values=[float(r[name]) for r in data]
    if step:
        ax.step(times,values,where="post",color=color,label=label,linewidth=1.55,linestyle=style)
    else:
        ax.plot(times,values,color=color,label=label,linewidth=1.65,linestyle=style)
fig,ax=plt.subplots(3,1,figsize=(9.3,8.6),layout="constrained")
fig.suptitle("FalconFOC impedance | Frozen virtual motor holdout",fontsize=16)
a,b,c=ax
for axis in ax:
    axis.grid(True,alpha=.24)
    axis.set_xlabel("Time since reference step (s)")
    axis.spines[["right","top"]].set_visible(False)
a.axvspan(.8,1.6,color="#e7c973",alpha=.26,label="0.039 N m opposing load")
curve(a,"load","ref_rad","Reference","#626262","--")
curve(a,"load","plant_rad","Impedance","#076c7e")
curve(a,"cascade-load","plant_rad","Position P + Velocity PI","#a54721")
a.set(title="Load and release",ylabel="Shaft position (rad)",xlim=(0,2.4))
b.axhline(.3,color="#626262",linestyle="--",linewidth=1.4,label="Reference")
curve(b,"hold","plant_rad","Damping 0.048 N m s/rad","#076c7e")
curve(b,"soft-damping","plant_rad","Damping 0.006 N m s/rad","#a54721")
b.set(title="Same spring and reference, two damping gains",ylabel="Shaft position (rad)",xlim=(0,1.6))
curve(c,"limited","target_iq_a","New q request","#076c7e",step=True)
curve(c,"limited","plant_iq_a","Simulated q current","#a54721")
curve(c,"limited","live_cap_a","Live upper bound (shown through derate)","#626262","--",step=True)
c.set(title="Derating changes the request immediately; plant current follows",ylabel="q-axis current (A)",
      xlim=(0,.55),ylim=(-.32,.72))
for axis in ax:
    axis.legend(loc="best",ncols=2,fontsize=8.5,frameon=False)
fig.savefig(root/"holdout-curves.png",dpi=170)

