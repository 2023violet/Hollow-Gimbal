from pathlib import Path
from zipfile import ZipFile
import csv
import hashlib
import json
import math
import subprocess
import sys

repo, runner, frozen, output = (Path(x).resolve() for x in sys.argv[1:])
output.mkdir(parents=True)
report = {}
cli = repo / "tools/falconfoc-cli/falconfoc_cli.py"
with ZipFile(frozen) as archive:
    baseline = json.loads(archive.read("results/summary.json"))
    for name, profile, opts in (
        ("generic", "GENERIC_RESEARCH_MOTOR", ["--cogging"]),
        ("salient", "CALIBRATION_SALIENT_MOTOR", []),
    ):
        def command(tag, flags):
            proc = subprocess.run(
                [sys.executable, "-B", str(cli), "calibrate", "--simulator", str(runner),
                 "--profile-id", profile, *flags],
                capture_output=True, text=True, encoding="utf-8", timeout=55, check=True,
            )
            (output / f"{name}-{tag}.jsonl").write_text(proc.stdout, encoding="utf-8")
            return [json.loads(line) for line in proc.stdout.splitlines()]

        def event(rows, key):
            return next(row for row in rows if row.get("event") == key)

        path = output / f"{name}-intervals.csv"
        preview = command("preview", opts + ["--flux-trace", str(path)])
        fit = event(preview, "FLUX_CANDIDATE")
        legacy = event(preview, "PARAMETERS_IDENTIFIED")
        approval = event(preview, "CANDIDATE_PREVIEW")["review_id"]
        old_review = [json.loads(row) for row in archive.read(f"results/{name}-clean-preview.stdout").decode().splitlines()]
        assert event(old_review, "CANDIDATE_PREVIEW")["review_id"] == approval
        assert event(old_review, "PARAMETERS_IDENTIFIED") == legacy
        with path.open(newline="", encoding="ascii") as data:
            rows = list(csv.DictReader(data))
        old_rows = list(csv.DictReader(archive.read(f"results/{name}-interval.csv").decode().splitlines()))
        assert len(rows) == len(old_rows) == 512
        keys = ("begin_us", "end_us", "id_begin_a", "iq_begin_a", "id_end_a", "iq_end_a",
                "omega_e_rad_s", "mean_vq_v")
        for new, old in zip(rows, old_rows):
            assert all(float(new[k]) == float(old[k]) for k in keys)
            assert new["voltage_begin_us"] == new["speed_begin_us"] == new["begin_us"]
            assert new["voltage_end_us"] == new["speed_end_us"] == new["end_us"]
        assert fit["signed_flux_wb"] == [row["flux_wb"] for row in baseline[name]["direction_fit"]]
        assert fit["signed_residual_rms_v"] == [row["residual_rms_v"] for row in baseline[name]["direction_fit"]]
        assert fit["residual_rms_v"] == baseline[name]["fit"]["residual_rms_v"]
        package = output / f"{name}.fcal"
        applied = command("applied", opts + ["--approve-candidate", approval, "--save-config", str(package)])
        restored = command("restored", ["--load-config", str(package), "--approve-candidate", approval])
        old_restored = [json.loads(row) for row in archive.read(f"results/{name}-clean-reloaded.stdout").decode().splitlines()]
        statuses = {"CONTROL_TRIAL", "CONFIGURATION_APPLIED", "FAULT_RECOVERY_VERIFIED"}
        assert [r for r in applied if r.get("event") in statuses] == \
               [r for r in restored if r.get("event") in statuses] == \
               [r for r in old_restored if r.get("event") in statuses]
        assert package.read_bytes() == archive.read(f"results/{name}-fresh.fcal")
        caps = [r for r in applied if r.get("event") == "CALIBRATED_TORQUE_LIMIT_VERIFIED"]
        assert len(caps) == 2 and caps[0]["iq_ref_a"] < 0.0 < caps[1]["iq_ref_a"]
        assert all(abs(r["iq_ref_a"]) <= r["cap_a"] + 1e-7 and abs(r["load_nm"]) > 0.33
                   and r["stop_confirmed"] and math.isclose(r["kt"], fit["kt_nm_per_peak_q_amp"])
                   for r in caps)
        report[name] = {
            "matched_intervals": len(rows), "matched_closed_loop_trials": 16,
            "fcal_sha256": hashlib.sha256(package.read_bytes()).hexdigest(),
            "torque_limits": caps, "exact_frozen_directional_fit": True,
        }
(output / "summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report))

