/**
 * @file    falconfoc_virtual_calibrate_internal.h
 * @brief   Private foreground seams of the Host calibration executable.
 * @version v0.1.0
 * @date    2026.11.20
 *
 * Design overview
 * ---------------
 * Share the established application, closed-loop verification and FCAL
 * adapters with the interactive reuse owner.
 *
 * Usage example
 * -------------
 * Preview with the draft helper, then verify the reviewed candidate with a
 * fresh initializer and the existing virtual control trials.
 *
 * Ownership / lifecycle / context
 * -------------------------------
 * The Host command loop serializes review and application. The initializer's
 * sensor storage must outlive its initialized Runtime.
 *
 * Failure / recovery
 * ------------------
 * A rejected request never becomes the active reuse history.
 */

#pragma once

/* Includes --------------------------------------------------------------------- */

#include "foc_pmsm_reachability.h"
#include "foc_virtual_calibration.h"
#include "foc_virtual_cogging.h"

/* Public Types ----------------------------------------------------------------- */

struct calibrated_init {
    const struct foc_cal_application *application;
    const struct foc_cal_application_tuning_policy *policy;
    const struct foc_cal_application_candidate *candidate;
    const struct foc_encoder_lut *restored_lut;
    struct foc_cal_application_sensor sensor;
};

/* Public Functions ------------------------------------------------------------- */

extern const struct foc_cal_application_tuning_policy foc_virtual_cal_cli_tuning;

int foc_virtual_cal_cli_error(const char *reason, const char *stage, int native);

int foc_virtual_cal_cli_initialize(void *argument,
                                   struct foc_runtime *runtime,
                                   struct foc_encoder_context *encoder,
                                   const struct foc_pipeline_config *pipeline,
                                   const struct foc_virtual_current_profile *profile);

bool foc_virtual_cal_cli_readback(struct foc_virtual_current *driver,
                                  const struct foc_cal_application_candidate *candidate,
                                  bool emit);

int foc_virtual_cal_cli_verify(struct foc_virtual_current_profile *profile,
                               struct calibrated_init *init,
                               struct foc_virtual_calibration *session,
                               const char *save_config,
                               const char *current_study_path,
                               bool startup_study);

void foc_virtual_cal_cli_preview(const struct foc_cal_application_candidate *candidate,
                                 uint32_t review_id);

bool foc_virtual_cal_cli_review_matches(const char *approved, uint32_t review_id);

int foc_virtual_cal_cli_draft(const struct foc_virtual_calibration *session,
                              const struct foc_cal_application_tuning_policy *policy,
                              struct foc_cal_application_candidate *candidate);

void foc_virtual_cal_cli_cogging_fixture(struct foc_virtual_current_profile *profile);

int foc_virtual_cal_cli_cogging_capture(const struct foc_virtual_current_profile *profile,
                                        struct foc_virtual_calibration *session,
                                        struct foc_virtual_cogging_result *capture);

int foc_virtual_cal_cli_restore(const char *path,
                                struct foc_virtual_current_profile *profile,
                                const struct foc_cal_workflow_identity *identity,
                                const char *approved,
                                const struct foc_pmsm_operating_point *diagnostic);

void foc_virtual_calibration_schedule(struct foc_virtual_calibration *session);

int foc_virtual_cal_cli_reuse_session(const char *name, bool cogging, const char *bootstrap);

int foc_virtual_cal_cli_bootstrap(const char *mode,
                                  const char *scenario,
                                  const char *trace,
                                  struct foc_virtual_current_profile *profile,
                                  struct foc_cal_workflow_request *request,
                                  uint32_t *signature);

struct foc_flux_id_result;

void foc_virtual_cal_cli_flux_preview(const struct foc_flux_id_result *evidence);
uint32_t foc_virtual_cal_cli_flux_signature(const struct foc_flux_id_result *evidence);

/* ---------------------------------------- end of file ----------------------------------------- */
