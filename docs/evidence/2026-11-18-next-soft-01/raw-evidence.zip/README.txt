Contains this stage's complete text-only patch, final optional-library and external
consumer checks, direct ARM static costs, and the independent existing-software regression.
The original internal SDK package and its manifest remain separate and unchanged.
