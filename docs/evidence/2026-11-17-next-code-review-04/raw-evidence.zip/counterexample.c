#define main runtime_original_main
#include "D:/study/Software/FalconFOC-runtime-review-04-20261117/snapshot/runtime/tests/test_foc_runtime.c"
#undef main
static int run_probe(int scenario) {
    struct foc_runtime runtime={0};
    TEST_ASSERT(start_run(&runtime,&runtime_config,0U,0U)==0);
    if(scenario!=0) {
        struct foc_runtime_lifecycle_request request={
            .action=FOC_RUNTIME_ACTION_ARM,
            .request_sequence=1U,
            .source_session=runtime.motion_session,
            .produced_us=scenario==1?302U:UINT32_MAX-1099U,
        };
        TEST_ASSERT(foc_runtime_publish_lifecycle_request(&runtime,&request,302U)==FOC_RUNTIME_OK);
    }
    TEST_ASSERT(publish_angle(&runtime,400U,4U)==FOC_RUNTIME_OK);
    struct foc_runtime_fast_input input=fast_input(400U,4U);
    input.adc.valid_mask=0U;
    int status=foc_runtime_h0_step(&runtime,&input);
    struct foc_runtime_snapshot view;
    TEST_ASSERT(foc_runtime_read_snapshot(&runtime,&view)==FOC_RUNTIME_OK);
    struct foc_runtime_lifecycle_result result;
    TEST_ASSERT(foc_runtime_read_lifecycle_result(&runtime,&result)==FOC_RUNTIME_OK);
    printf("scenario=%d H0=%d state=%d action=%d confirmed=%d invalid_streak=%u last_sample=%u updates=%u lifecycle_result=%d\n",scenario,status,view.state,view.action,view.output_confirmed,runtime.pipeline.safety.invalid_sample_streak,view.sample_us,view.updates,result.result);
    return 0;
}
int main(void){ return run_probe(0)||run_probe(1)||run_probe(2); }
