import json,shutil
from audit import OUT,ROOT,SRC,CC,ENV,run,copy_source

dest=OUT/'attribution';repo=copy_source(dest/'ideal-source')
path=repo/'simulation/src/foc_virtual_current.c'
source=path.read_text(encoding='utf-8')
anchor='    const int status = foc_runtime_h0_step(&context->runtime, &input);'
assert source.count(anchor)==1
injection='''    /* TEST-ONLY COUNTERFACTUAL: perfect ADC-time phase; not full Sensor chain acceptance. */
    const unsigned int phase_slot = atomic_load(&context->runtime.sensor_slot);
    if (phase_slot < 2U && context->runtime.sensor_slots[phase_slot].sample.valid) {
        struct foc_runtime_sensor_slot *slot = &context->runtime.sensor_slots[phase_slot];
        const double truth = (double)context->runtime.config.motion.rotor.pole_pairs *
            context->motor.state.mechanical_position_rad +
            context->runtime.config.motion.rotor.electrical_offset_rad;
        float phase;
        if (foc_angle_normalize((float)truth, &phase) != FOC_STATUS_OK) return -1;
        slot->sample.theta_elec_rad = phase;
        slot->sample.captured_us = input.adc.sample_tick;
        slot->electrical.angle_rad = phase;
    }
'''
path.write_text(source.replace(anchor,injection+anchor),encoding='utf-8')
(dest/'ideal-phase-injection.c.txt').write_text(injection,encoding='utf-8')
run(dest,'configure',['cmake','-S',repo/'simulation','-B',dest/'build','-G','Ninja',
                      '-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+CC])
run(dest,'build',['cmake','--build',dest/'build','--parallel','4'])
for label,exe in [('actual',OUT/'tests/simulation/build/falconfoc-virtual-device.exe'),
                   ('ideal-phase',dest/'build/falconfoc-virtual-device.exe')]:
    run(dest,label,['python',ROOT/'tools/falconfoc-cli/falconfoc_cli.py','--simulator',exe,
        'virtual-demo','--virtual-scenario','current','--advance-us','500','--duration-us','10000',
        '--csv',dest/(label+'.csv'),'--json',dest/(label+'.json')],env=ENV,cwd=repo)
    value=json.loads((dest/(label+'.json')).read_text(encoding='utf-8'))
    print(label,json.dumps(value,ensure_ascii=False),flush=True)
