#include "foc_runtime.h"
const char runtime_bytes[sizeof(struct foc_runtime)] = {0};
const char command_slot_bytes[sizeof(struct foc_runtime_command)] = {0};
const char sample_bytes[sizeof(struct foc_runtime_sensor)] = {0};
const char sensor_slot_bytes[sizeof(struct foc_runtime_sensor_slot)] = {0};
const char config_bytes[sizeof(struct foc_runtime_config)] = {0};
