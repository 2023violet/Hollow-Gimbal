
from pathlib import Path
from collections import defaultdict
import subprocess as sp
import csv
import io
import re
from zipfile import ZipFile

root = Path(__file__).parent
historical = Path(r"C:/Users/16429/AppData/Local/Temp/sensorest_94ba764379474bf6a4ba3a6c66fe6307")
workspace = Path.cwd()
simulation = root/"final/simulation-clang"
def capture(path, exe, *args):
    result = sp.run([exe, *args], capture_output=True, check=True)
    path.write_bytes(result.stdout)
    return result.stdout.decode("ascii").splitlines()
def lines(path):
    data = path.read_bytes()
    return data.decode("utf-16" if data.startswith(b'\xff\xfe') else "utf-8-sig").splitlines()
old = lines(root/"old-speed-trace.log")
new = capture(root/"new-speed-trace.log", simulation/"test-foc-sensor-est.exe", "--trace")
def which(rows, kind):
    return [row for row in rows if row.startswith(kind+',')]
archive = workspace/"docs/evidence/2026-11-27-next-sensor-est-01/raw-evidence.zip"
with ZipFile(archive) as frozen:
    for kind, name in [("INPUT","sensor-input-and-rates"),("SPEED","estimator-summary"),
                       ("CONTROL","control-trace"),("CHAIN","control-summary")]:
        previous = frozen.read(f"data/{name}.csv").decode("ascii").splitlines()[1:]
        assert previous == which(old, kind), (kind,len(previous),len(which(old,kind)))
        print("frozen EST-01 rows reproduced", kind, len(previous))
old_input, new_input = [list(csv.reader(which(rows, "INPUT"))) for rows in (old,new)]
for left,right in zip(old_input,new_input,strict=True):
    assert left[:11] == right[:11] and left[12:] == right[12:], (left,right)
print("INPUT corrected code, count, time, truth, Raw, LPF, PLL identical",len(new_input))
for kind in ("CONTROL","CHAIN"):
    keep = lambda row: row.split(",")[2] != "2"
    before, after = [list(filter(keep,which(rows,kind))) for rows in (old,new)]
    assert before == after
    print(kind,"arms A/B/D identical",len(after))
for kind in ("GATE","DECISION"):
    assert which(old, kind) == which(new, kind)
    print(*which(new, kind),sep="\n")
def speed(rows):
    return {tuple(r[1:4]):r[4:] for r in csv.reader(which(rows, "SPEED"))}
before, after = speed(old), speed(new)
assert before.keys() == after.keys()
max_rms = max_peak = 0.0
with (root/"dynamic-metrics.csv").open("w",newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["study","segment","samples","lpf_rms","lpf_peak","ab_old_rms","ab_new_rms",
                     "ab_old_peak","ab_new_peak","ab_old_t90_us","ab_new_t90_us","pll_rms","pll_peak"])
    for key, n in after.items():
        study, segment, estimator = key
        o = before[key]
        if estimator != "2":
            assert o == n
            continue
        lpf, pll = (after[study, segment, id] for id in ("1","3"))
        writer.writerow([study,segment,n[1],*lpf[2:4],o[2],n[2],o[3],n[3],o[5],n[5],*pll[2:4]])
        if study.startswith("long-") and study != "long-near":
            assert n == after["long-near",segment,"2"]
            continue
        max_rms = max(max_rms, abs(float(o[2])-float(n[2])))
        max_peak = max(max_peak, abs(float(o[3])-float(n[3])))
        assert o[5] == n[5]
assert max_rms <= 1e-3 and max_peak <= 1e-3
print(f"ordinary speed-study deltas max RMS={max_rms:.9g} peak={max_peak:.9g} all T90 identical")
long = defaultdict(list)
for row in new_input:
    if row[1].startswith("long-"):
        long[row[1]].append(row[11])
assert long["long-near"] == long["long-positive"] == long["long-negative"]
print("long-study tracker samples exactly equal per origin (speed trace precision)",len(long["long-near"]))
reference = capture(root/"green-test-trace.log",root/"final/sensors-clang/test-foc-sensor-reference.exe","--trace")
for line in reference:
    if line.startswith(("TRANSLATION,","STATE,")):
        print(line)
prior_simulation = historical/"final/simulation-clang"
for tag, target, args in [
    ("motor-id", "test-foc-motor-id-virtual", ["--trace"]),
    ("motor-id-quality", "test-foc-motor-id-virtual", ["--quality"]),
    ("encoder-linear", "test-foc-periodic-chain", ["--encoder-linearization"]),
    ("encoder-calibration", "test-foc-periodic-chain", ["--encoder-calibration-study"]),
    ("encoder-calibration-dataset", "test-foc-periodic-chain", ["--encoder-calibration-dataset"]),
]:
    path = root/f"{tag}.log"
    new_aux = capture(path, simulation/(target+".exe"), *args)
    original = sp.check_output([prior_simulation/(target+".exe"),*args],text=True).splitlines()
    assert original == new_aux, tag
    print(tag,"old/new identical rows",len(new_aux))
for tag, folder in [("before",prior_simulation),("after",simulation)]:
    path = root/f"system-angle-{tag}.csv"
    capture(root/f"system-angle-{tag}.log",folder/"test-foc-periodic-chain.exe","--system-angle-csv",path)
assert lines(root/"system-angle-before.csv") == lines(root/"system-angle-after.csv")
print("system-angle CSV identical rows",len(lines(root/"system-angle-after.csv")))

