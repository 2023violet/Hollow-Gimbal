param([Parameter(Mandatory)][string]$Repo, [Parameter(Mandatory)][string]$EvidenceDir, [Parameter(Mandatory)][string]$Compiler)
$ErrorActionPreference='Stop'
$Resolved = (Get-Command $Compiler).Source
foreach ($Sample in @('servo','calibration')) {
    $Name = if ($Sample -eq 'servo') { 'falconfoc-servo-demo' } else { 'falconfoc-calibration-workflow-demo' }
    $Source = Join-Path $EvidenceDir "src/$Sample"
    $Build = Join-Path $EvidenceDir "$Compiler-$Sample"
    $Log = Join-Path $EvidenceDir "raw/$Compiler-$Sample.log"
    "cmake -S $Source -B $Build -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=`"$Resolved`" -DFALCONFOC_SOURCE_DIR=$Repo" | Set-Content -Encoding UTF8 $Log
    cmake -S $Source -B $Build -G Ninja -DCMAKE_BUILD_TYPE=Debug "-DCMAKE_C_COMPILER=$Resolved" "-DFALCONFOC_SOURCE_DIR=$Repo" 2>&1 | Tee-Object -Append $Log
    if ($LASTEXITCODE -ne 0) { throw 'configure failed' }
    "cmake --build $Build --target $Name --parallel 4" | Add-Content -Encoding UTF8 $Log
    cmake --build $Build --target $Name --parallel 4 2>&1 | Tee-Object -Append $Log
    if ($LASTEXITCODE -ne 0) { throw 'build failed' }
    "ctest --test-dir $Build -V --output-on-failure -R '^test-$Name|^test-falconfoc-servo-'" | Add-Content -Encoding UTF8 $Log
    ctest --test-dir $Build -V --output-on-failure -R "^test-$Name|^test-falconfoc-servo-" 2>&1 | Tee-Object -Append $Log
    if ($LASTEXITCODE -ne 0) { throw 'tests failed' }
}
