
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import os,shutil,subprocess as sp,sys

root=Path("C:/Users/16429/AppData/Local/Temp/soft01_1795055013460")
src=Path.cwd()
logs=root/"verify-complete"
logs.mkdir(exist_ok=True)
env=os.environ.copy()
env["PATH"]=os.pathsep.join([r"D:\Git\bin",r"C:\mingw64\bin",
  str(Path(sp.check_output(["clang","-print-resource-dir"],text=True).strip())/"lib/windows"),env["PATH"]])
env.update(PYTHONDONTWRITEBYTECODE="1",ASAN_OPTIONS="halt_on_error=1",
           UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")

def run(label, commands, cwd=src):
    logfile=logs/f"{label}.log"
    with logfile.open("w",encoding="utf-8") as f:
        for cmd in commands:
            print("$ "+sp.list2cmdline(list(map(str,cmd))),file=f,flush=True)
            status=sp.run(cmd,cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT).returncode
            if status:
                break
    lines=logfile.read_text(encoding="utf-8",errors="replace").splitlines()
    markers=("tests passed out of","all requested checks passed","[Total]","FLASH:","RAM:",
             "checked C/H files","checked CMake files","checked README files")
    print(f"{label}: {status}",*((lines[-22:] if status else [l for l in lines if any(k in l for k in markers)][-12:])),
          sep="\n",flush=True)
    return status

def host(project, variant):
    label=project+"-"+variant
    out=root/"final-complete"/label
    flags=[]
    compiler="C:/mingw64/bin/gcc.exe" if variant=="gcc" else "clang"
    if variant=="asan":
        flags=["-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
               "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined"]
    return run(label,[["cmake","-S",project,"-B",out,"-G","Ninja","-DCMAKE_BUILD_TYPE=Debug",
                       "-DCMAKE_C_COMPILER="+compiler,*flags],
                      ["cmake","--build",out,"--parallel","6"],
                      ["ctest","--test-dir",out,"--output-on-failure","-j","4"]])

def arm():
    out=root/"final-complete"/"locked-arm"
    resource=root/"final-complete"/"motor-id-arm.o"
    out.parent.mkdir(exist_ok=True)
    return run("arm",[
        ["cmake","-S","firmware/at32f415","-B",out,"-G","Ninja",
         f"-DCMAKE_TOOLCHAIN_FILE={(src/'tools/cmake/arm-gcc-toolchain.cmake').as_posix()}",
         "-DMCU_CPU=cortex-m4","-DMCU_FPU=none","-DMCU_FLOAT=soft"],
        ["cmake","--build",out,"--parallel","6"]])

def gate():
    isolated=root/"quality-complete"
    if not isolated.is_dir():
        sp.run(["git","clone","--shared","--quiet","--no-checkout",src,isolated],check=True)
        sp.run(["git","-C",isolated,"checkout","--quiet","--detach",
                "a07d7db6b3f2d439255724df05e77e343ae6a731"],check=True)
    changed=sp.check_output(["git","status","--porcelain=v1","-z","-uall"],cwd=src).decode()
    overlay=[r[3:] for r in changed.strip("\0").split("\0")
             if r[3:].startswith(("core/","runtime/","simulation/","sensors/","firmware/","calibration/","examples/servo/","docs/servo/","control_plane/","examples/parameters/","scripts/gates/check_falconfoc_source_contract.ps1"))]
    for name in overlay:
        (isolated/name).parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src/name,isolated/name)
    commands=[]
    for preset in ("fw-full-diag-carrier-debug","fw-standard-carrier-minsizerel","fw-tiny-carrier-minsizerel"):
        commands.extend([["cmake","--preset",preset],
                         ["cmake","--build","--preset","build-"+preset,"--parallel","6"]])
    commands.append([r"D:\Git\bin\bash.exe","-lc","./run.sh build"])
    commands.append(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File",
                     "scripts/gates/check_themis_quality_gate.ps1","-RepoRoot",isolated,
                     "-Scope","all","-RequireCMakeFormatter"])
    return run("strict-gate",commands,isolated)

def board():
    out=root/"board-host"
    return run("board-host",[
        ["cmake","-S","firmware/at32f415","-B",out,"-G","Ninja",
         "-DCMAKE_BUILD_TYPE=Debug","-DCMAKE_C_COMPILER=clang"],
        ["cmake","--build",out,"--parallel","6"],
        ["ctest","--test-dir",out,"--output-on-failure","-j","4"]])
def source():
    return run("source-current",[
        ["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File",
         "scripts/gates/check_falconfoc_source_contract.ps1","-RepoRoot",src],
        ["clang-format","--dry-run","--Werror",
         "examples/servo/main.c"]])
def legacy():
    return run("legacy-host",[
        ["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File",
         "scripts/flows/host/run_host_tests.ps1","-RepoRoot",src]])
jobs=[(gate,()),(arm,()),(board,()),(source,()),(legacy,()), *((host, args) for args in [
    ("core","clang"),("core","gcc"),("sensors","clang"),("simulation","clang"),("simulation","gcc"),
    ("runtime","clang"),("runtime","gcc"),("calibration","clang"),("sensors","asan"),("simulation","asan"),("runtime","asan"),("core","asan"),("calibration","asan")])]
if "--common" in sys.argv:
    jobs=[(fn,args) for fn,args in jobs if fn not in (gate,source) and
          (fn!=host or args[0]!="simulation")]
elif "--final" in sys.argv:
    jobs=[(fn,args) for fn,args in jobs if fn in (gate,source) or (fn==host and args[0]=="simulation")]
jobs=[(gate,())]
with ThreadPoolExecutor(max_workers=4) as pool:
    outcomes=[f.result() for f in as_completed([pool.submit(fn,*args) for fn,args in jobs])]
sys.exit(int(any(outcomes)))







