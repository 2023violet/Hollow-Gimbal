"""Repeat the frozen Host Current cases and verify the low-voltage regression."""

import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys


root = Path(sys.argv[1]).resolve()
simulator = Path(sys.argv[2]).resolve()
cli = Path.cwd() / "tools/falconfoc-cli/falconfoc_cli.py"
after = root / "after"
after.mkdir(exist_ok=True)
commands = []


def run(name, options=()):
    command = [sys.executable, str(cli), "--simulator", str(simulator), "virtual-demo",
               "--virtual-scenario", "current", "--advance-us", "500", "--duration-us",
               "10000", "--csv", str(after / f"{name}.csv"), "--json",
               str(after / f"{name}.json"), *options]
    commands.append(command)
    with (after / f"{name}.log").open("wb") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    return json.loads((after / f"{name}.json").read_text(encoding="utf-8"))["metrics"]


def observed_metrics(name, results):
    full, running = (results["measurement_window"][window] for window in ("full", "running"))
    print(name, json.dumps({"quality": results["control_quality"], "full": full,
                           "running": running, "running_tail_rmse": results["running_tail_rmse"],
                           "full_window_rmse": results["full_window_rmse"],
                           "running_window_rmse": results["running_window_rmse"],
                           "final_state": results["final_state"],
                           "settling_time_us": results["settling_time_us"],
                           "accepted_updates": results["update_accepted"],
                           "saturation_duration_us": results["saturation_duration_us"]}))


holdout_options = ("--profile-id", "current-reverse", "--reference", "-0.4",
                   "--current-kp", "1.26", "--current-ki", "630.0", "--velocity-kp", "0.225",
                   "--velocity-ki", "1.75", "--position-kp", "5.0", "--motor-inertia", "0.0024")
for scenario, options in (("historical-current", ()), ("holdout-current-reverse", holdout_options)):
    metrics = run(scenario, options)
    original = json.loads((root / f"{scenario}.json").read_text(encoding="utf-8"))["metrics"]
    observed_metrics(scenario, metrics)
    assert (after / f"{scenario}.csv").read_bytes() == (root / f"{scenario}.csv").read_bytes()
    assert metrics["control_quality"] == "CONTROL_QUALITY_FAIL"
    for window in ("full", "running"):
        metrics["measurement_window"][window].pop("tracking_error")
    assert metrics == original

for label, reference in (("positive", "0.4"), ("negative", "-0.4")):
    name = f"low-voltage-{label}"
    metrics = run(name, ("--voltage-limit-v", "0.12", "--reference", reference))
    observed_metrics(name, metrics)
    assert metrics["control_quality"] == "CONTROL_QUALITY_FAIL"
    assert metrics["update_accepted"] == 52 and metrics["update_rejected"] == 0
    assert metrics["final_state"] == 1 and metrics["final_faults"] == 0
    assert metrics["settling_time_us"] is None and metrics["saturation_count"] == 52
    with (after / f"{name}.csv").open(encoding="utf-8", newline="") as trace:
        rows = list(csv.DictReader(trace))
    assert all(row["state"] == "3" and row["output_action"] == "1" for row in rows[6:27])
    assert all(row["state"] == "1" and row["output_action"] == "0" and
               row["virtual_update_accepted"] == "52" for row in rows[27:])

(after / "commands.json").write_text(json.dumps(commands, indent=2) + "\n", encoding="utf-8")
for path in sorted(list(root.glob("*.wire")) + list(after.glob("*.csv")) + [simulator, cli]):
    print(hashlib.sha256(path.read_bytes()).hexdigest(), path)
