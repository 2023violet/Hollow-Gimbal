"""Independent numerical reduction for PRODUCT-02D3 Virtual Motor CSV."""
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics

PROFILES = ("generic", "salient")
ROOT = Path(__file__).resolve().parent


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            yield {"case": row.pop("case"), **{key: float(value) for key, value in row.items()}}


def demand(model, omega_m, id_a, iq_a):
    angle_rate = model["pp"] * omega_m
    return (
        model["rs"] * id_a - angle_rate * model["lq"] * iq_a,
        model["rs"] * iq_a + angle_rate * (model["ld"] * id_a + model["flux"]),
    )


def iq_interval(model, omega_m, id_a, cap_v, cap_a):
    """Numerical interval via 1-D convex minimization and endpoint bisection."""
    if abs(id_a) > cap_a:
        return None
    edge = math.sqrt(cap_a**2 - id_a**2)
    left, right = -edge, edge

    def magnitude(iq_a):
        return math.hypot(*demand(model, omega_m, id_a, iq_a))

    for _ in range(64):
        first = (2 * left + right) / 3
        second = (left + 2 * right) / 3
        if magnitude(first) < magnitude(second):
            right = second
        else:
            left = first
    minimum = (left + right) / 2
    if magnitude(minimum) > cap_v:
        return None

    def endpoint(outside):
        if magnitude(outside) <= cap_v:
            return outside
        inside = minimum
        for _ in range(64):
            middle = (inside + outside) / 2
            if magnitude(middle) <= cap_v:
                inside = middle
            else:
                outside = middle
        return inside

    return [endpoint(-edge), endpoint(edge)]


def midpoint_voltage(previous, sample):
    dt_s = (sample["elapsed_us"] - previous["elapsed_us"]) * 1e-6
    delta = sample["pp"] * (previous["omega"] + sample["omega"]) * dt_s / 4
    cs, sn = math.cos(delta), math.sin(delta)
    return cs * sample["vd"] - sn * sample["vq"], sn * sample["vd"] + cs * sample["vq"]


def means(group, fields):
    return {field: statistics.mean(row[field] for row in group) for field in fields}


def span(group, field):
    return [min(row[field] for row in group), max(row[field] for row in group)]


def classify(segment, profile, case, sign, phase, initial, stop):
    first, *_, last = segment
    cap_v = min(last["voltage_limit"], last["vbus"] / math.sqrt(3))
    cap_a = last["current_limit"]
    request = last["id_ref"], last["iq_ref"]
    out = {
        "profile": profile,
        "case": case,
        "sign": int(sign),
        "phase": phase,
        "fixture": bool(last["fixture"]),
        "vbus_v": last["vbus"],
        "cap_v": cap_v,
        "cap_a": cap_a,
        "request": request,
        "initial_speed_rad_s": initial["omega"],
        "updates": sum(row["accepted_us"] == row["h0_us"] for row in segment),
        "stop_confirmed": stop["state"] == 1 and stop["confirmed"] == 1 and stop["action"] == 0,
    }
    assert out["stop_confirmed"] and stop["accepted_us"] == last["accepted_us"] or (
        out["stop_confirmed"] and phase == "before_reversal"
    ), out
    if case == "undervoltage":
        assert out["updates"] == 0 and first["pipeline_status"] == -7
        assert all(row["confirmed"] and row["action"] == 0 and row["v_applied"] == 0 for row in segment)
        out.update(verdict="BUS_BELOW_CURRENT_CORE_MINIMUM", first_pipeline_status=int(first["pipeline_status"]))
        return out

    assert all(row["action"] == row["confirmed"] == 1 and row["state"] == 3 and row["faults"] == 0
               and row["h0_us"] == row["adc_us"] == row["accepted_us"] for row in segment)
    assert out["updates"] == len(segment)
    assert max(row["v_applied"] for row in segment) <= cap_v + 2e-6
    assert max(row["v_accepted"] for row in segment) <= cap_v + 2e-6
    out["accepted_after_command_us"] = first["accepted_us"] - first["cmd_us"]
    out["first_applied_interval_end_us"] = int(segment[1]["h0_us"])
    out["first_h0_receipt_us"] = int(first["h0_us"])
    out["encoder_age_max_us"] = int(max(row["h0_us"] - row["enc_us"] for row in segment))
    out["speed_endpoints_rad_s"] = [first["omega"], last["omega"]]
    request_norm = math.hypot(*request)
    target = tuple(value * min(1, cap_a / request_norm) for value in request)
    out["effective_current_target"] = target
    tail = segment[-100:]   # 20 ms at 200 us/tick
    avg = means(tail, ("id", "iq", "omega", "v_applied", "torque"))
    actual = (avg["id"], avg["iq"])
    average_speed = avg["omega"]
    out["observed"] = avg
    out["observed_speed_span"] = span(tail, "omega")
    out["observed_id_span"] = span(tail, "id")
    out["observed_iq_span"] = span(tail, "iq")
    out["predicted_request_v"] = math.hypot(*demand(last, average_speed, *request))
    signed_demands = [math.hypot(*demand(row, row["omega"], *target)) for row in tail]
    out["predicted_effective_target_v_span"] = [min(signed_demands), max(signed_demands)]
    out["predicted_effective_target_v"] = math.hypot(*demand(last, average_speed, *target))
    out["request_id_slice_iq"] = iq_interval(last, average_speed, request[0], cap_v, cap_a)
    out["observed_id_slice_iq"] = iq_interval(last, average_speed, actual[0], cap_v, cap_a)
    out["cap_dwell_us"] = 200 * sum(cap_v - row["v_applied"] <= .002 for row in segment)
    out["tail_cap_dwell_us"] = 200 * sum(cap_v - row["v_applied"] <= .002 for row in tail)
    last_out = max(
        (i for i, row in enumerate(segment) if abs(row["iq"] - target[1]) >
         max(.04, .1 * abs(target[1]))), default=-1)
    out["q_settle_after_first_receipt_us"] = int(
        segment[last_out + 1]["h0_us"] - first["h0_us"]
    ) if len(segment) - last_out - 1 >= 11 else None
    mean_vd = statistics.mean(midpoint_voltage(p, s)[0] for p, s in zip(segment[-101:-1], tail))
    mean_vq = statistics.mean(midpoint_voltage(p, s)[1] for p, s in zip(segment[-101:-1], tail))
    steady = demand(last, average_speed, *actual)
    out["terminal_vdq_v"] = [mean_vd, mean_vq]
    out["predicted_observed_steady_vdq_v"] = steady
    out["steady_vdq_residual_v"] = math.hypot(mean_vd - steady[0], mean_vq - steady[1])
    window_start = segment[-101]
    duration_s = (last["elapsed_us"] - window_start["elapsed_us"]) * 1e-6
    expected_dynamics = [inductance * (end - start) / duration_s for inductance, end, start in (
        (last["ld"], last["id"], window_start["id"]),
        (last["lq"], last["iq"], window_start["iq"]),
    )]
    out["mean_inductive_derivative_vdq_v"] = expected_dynamics
    out["dynamic_vdq_residual_v"] = math.hypot(
        mean_vd - steady[0] - expected_dynamics[0], mean_vq - steady[1] - expected_dynamics[1]
    )
    assert out["dynamic_vdq_residual_v"] < .01, out
    if out["fixture"]:
        assert out["steady_vdq_residual_v"] < .01, out
    out["tracked_offset_a"] = math.hypot(actual[0] - target[0], actual[1] - target[1])
    if min(signed_demands) > cap_v + .01:
        assert out["tracked_offset_a"] > .1 and out["tail_cap_dwell_us"] == 20000, out
        lo, hi = out["observed_id_slice_iq"]
        expected_iq_at_cap = hi if target[1] > actual[1] else lo
        out["boundary_error_a"] = abs(actual[1] - expected_iq_at_cap)
        assert out["boundary_error_a"] < .025, out
        out["verdict"] = "VOLTAGE_LIMITED_CHANGING_SPEED" if not out["fixture"] else "VOLTAGE_LIMITED"
    elif max(signed_demands) < cap_v - .01:
        assert out["tracked_offset_a"] < (.01 if out["fixture"] else .04) and out["tail_cap_dwell_us"] == 0, out
        out["verdict"] = "CURRENT_CORE_VECTOR_CLIPPED" if request_norm > cap_a else (
            "TRACKING" if out["fixture"] else "TRACKING_CHANGING_SPEED")
    else:
        assert not out["fixture"] and min(signed_demands) <= cap_v <= max(signed_demands), out
        assert out["cap_dwell_us"] > 0
        out["verdict"] = "CHANGING_SPEED_CROSSES_LIMIT"
    if case == "plant_mismatch":
        out["plant_rl_flux"] = {key: last[key] for key in ("rs", "ld", "lq", "flux")}
    return out


def historical(outputs):
    quality = json.loads((ROOT / "salient-v1-quality.json").read_text(encoding="utf-8-sig"))
    repro = ROOT / "salient-v1-reproduced.csv"
    frozen = ROOT / "../cq03/startup/startup-salient.csv"
    assert repro.read_bytes() == frozen.read_bytes()
    data = list(csv.DictReader(repro.open(encoding="utf-8-sig")))
    result = {"csv_sha256": hashlib.sha256(repro.read_bytes()).hexdigest(), "cases": {}}
    for direction, sign in (("negative", -1), ("positive", 1)):
        case = quality["cases"][f"cold_large/{direction}"]
        phase = case["phases"][0]
        rows = {int(row["time_us"]): row for row in data if row["scenario"] == "cold_large"
                and row["direction"] == direction}
        start = phase["model_apply_us"]
        def historical_point(tick):
            row = rows[tick]
            return {
                "time_us": tick,
                "speed_rad_s": float(row["shaft_speed_rad_s"]),
                "actual_v": float(row["voltage_v"]),
                "actual_iq_a": float(row["iq_plant_a"]),
                "request_v": math.hypot(*demand(
                    {"rs": .78, "ld": .0017, "lq": .0022, "flux": .032, "pp": 4},
                    float(row["shaft_speed_rad_s"]), 0, float(row["iq_ref_a"])
                )),
            }
        native_result = next(row for row in outputs if row["profile"] == "salient" and
                             row["case"] == "cold_large_free" and row["sign"] == sign)
        held_result = next(row for row in outputs if row["profile"] == "salient" and
                           row["case"] == "cold_large_held" and row["sign"] == sign)
        assert case["updates_after_stop"] == 0 and phase["verdict"] == "CONTROL_QUALITY_FAIL"
        assert phase["publication_to_model_us"] == 200 and phase["settle_after_apply_us"] == 4800
        at_4ms = historical_point(start + 4000)
        assert at_4ms["request_v"] < 2.4 and at_4ms["actual_v"] < 2.4 and abs(at_4ms["actual_iq_a"]) < 1.98
        at_tail = historical_point(61800)
        assert at_tail["request_v"] > 2.4 and at_tail["actual_v"] >= 2.398
        assert abs(at_tail["actual_iq_a"] - native_result["last_iq_a"]) < 1e-7
        result["cases"][direction] = {
            "original_v1": phase,
            "at_4ms": at_4ms,
            "at_tail": at_tail,
            "first_target_voltage_exceeds_cap": next(point for point in map(
                historical_point, range(start, 61801, 200)) if point["request_v"] > 2.4),
            "fixed_zero_speed_same_controller_settle_after_apply_us": held_result["q_settle_after_first_receipt_us"],
            "fixed_zero_speed_same_controller_iq_at_4ms_a": held_result["iq_at_4ms_a"],
            "fixed_zero_speed_tail_iq_a": held_result["last_iq_a"],
        }
    return result


def main():
    outputs = []
    for profile in PROFILES:
        for (case, sign), grouped in itertools.groupby(
            read_csv(ROOT / f"{profile}.csv"), lambda row: (row["case"], row["direction"])
        ):
            start, *active, stop = grouped
            phases = (("before_reversal", active[:500]), ("after_reversal", active[500:])) if (
                case == "high_reverse"
            ) else (("command", active),)
            for phase, segment in phases:
                data = classify(segment, profile, case, sign, phase, start, stop)
                data["last_iq_a"] = segment[-1]["iq"]
                if len(segment) > 20:
                    data["iq_at_4ms_a"] = segment[20]["iq"]
                outputs.append(data)
    assert len(outputs) == 64
    result = {"profiles": list(PROFILES), "segments": outputs, "salient_v1": historical(outputs)}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
