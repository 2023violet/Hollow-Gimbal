"""NEXT-ADC-HW-01A offline Host verification. No hardware access.

Usage: python -I verify_offline.py <firmware host build> <replay build> <new output dir>
Each scenario runs the production fixture/importer/orchestrator/adapter/replay and
records the command, exit code, reason and raw output under <out>/<scenario>/.
"""
import hashlib
import json
import shutil
import struct
import subprocess
import sys
import zlib
from pathlib import Path

FW, REPLAY, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
FIXTURE = FW / "foc-board-capture-boot-fixture.exe"
ADAPTER = FW / "foc-board-adc-candidate.exe"
RUNNER = REPLAY / "falconfoc-calibration-replay-runner.exe"
TOOL = Path("tools/falconfoc-calibration-replay")
GAIN = 3.3 / (4095 * 0.5)
ADC, ENCODER = 128, 128 + 42 * 100
CAL = {"profile": "CALIBRATED", "source_direction": -1, "calibration_direction": -1, "runtime_direction": 1,
       "pole_pairs": 11, "coordinate": "RAW_NO_LUT", "supply_id": 0x56464331, "review_id": 0x01210001}
IDENTITY = dict(device_id=11, motor_id=12, encoder_id=13, frame_id=14)
OUT.mkdir(parents=True)
rows = []


def sh(args):
    process = subprocess.run([str(a) for a in args], capture_output=True, text=True, timeout=120)
    return process.returncode, process.stdout + process.stderr


def patch(path, changes, recompute=True, clear=None):
    raw = bytearray(path.read_bytes())
    for offset, value in changes:
        struct.pack_into("<I", raw, offset, value & 0xFFFFFFFF)
    if clear:
        raw[clear[0]:clear[0] + clear[1]] = bytes(clear[1])
    if recompute:
        struct.pack_into("<I", raw, 124, 0)
        struct.pack_into("<I", raw, 124, zlib.crc32(raw))
    path.write_bytes(raw)


def make(folder, producer="host", adc=(2041.25, 2056.75, 2049.5)):
    folder.mkdir()
    image = folder / "capture.bin"
    code, text = sh([FIXTURE, "calibrated", image, "--adc", ",".join(map(str, adc)), "--producer", producer])
    assert code == 0, text
    return image


def declarations(folder, image, source="HOST_VIRTUAL", witness=True):
    raw = image.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    capture_id = struct.unpack_from("<I", raw, 20)[0]
    start, end = struct.unpack_from("<2I", raw, 36)
    board = source == "BOARD_RECORDED"
    meta = {"format_version": 2, "source": source, "capture_id": capture_id, "build_tag": 0,
            "firmware_sha256": "1" * 64 if board else None, "raw_sha256": sha, "identity": IDENTITY,
            "origin_note": "NEXT-ADC-HW-01A Host synthetic rows; no physical acquisition",
            "configuration": CAL}
    (folder / "metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    witness_path = None
    if witness:
        witness_path = folder / "witness.json"
        witness_path.write_text(json.dumps({
            "format_version": 1, "stage": "ADC_ZERO", "capture_id": capture_id, "raw_sha256": sha,
            "firmware_sha256": meta["firmware_sha256"], "covers_start_us": start, "covers_end_us": end,
            "witness_source": "EXTERNAL_INSTRUMENT" if board else "HOST_VIRTUAL",
            "independent_zero_current": True, "sampling_window_verified": True, "amp_per_count": GAIN,
            "instrument": {"id": "fixture", "model": "declared only", "calibration": "none"},
            "evidence_reference": "Declared by the test; not a physical witness."}, indent=2), encoding="utf-8")
    return folder / "metadata.json", witness_path


def orchestrate(name, image, meta, witness, host_kind="synthetic"):
    folder = image.parent
    args = [sys.executable, "-B", TOOL / "board_adc_candidate.py", image, "--metadata", meta,
            "--adapter", ADAPTER, "--out", folder / "orchestrator", "--host-kind", host_kind]
    if witness:
        args += ["--qualification", witness]
    code, text = sh(args)
    (folder / "orchestrator.txt").write_text(text, encoding="utf-8")
    report = json.loads(text.strip().splitlines()[-1])
    candidate = report.get("candidate") or {}
    rows.append((name, "board_adc_candidate.py", code, report.get("status"),
                 report.get("reason") or candidate.get("candidate_failure") or "-"))
    return code, report


def replay(name, pack, attestation=None):
    args = [sys.executable, "-B", TOOL / "replay.py", "validate", pack, "--runner", RUNNER, "--json"]
    if attestation:
        args += ["--attestation", attestation]
    code, text = sh(args)
    folder = OUT / name
    folder.mkdir(exist_ok=True)
    (folder / "replay.txt").write_text(text, encoding="utf-8")
    report = json.loads(text.strip().splitlines()[-1])
    rows.append((name, "replay.py validate", code, report.get("provenance"), report.get("reason") or "-"))
    return code, report


# Positive: Host Synthetic and Host Virtual produce candidates ----------------------
for name, kind in (("host-synthetic-candidate", "synthetic"), ("host-virtual-candidate", "virtual")):
    image = make(OUT / name)
    orchestrate(name, image, *declarations(OUT / name, image), host_kind=kind)

# Board Recorded: importer + attestation + candidate gate ------------------------------
board = OUT / "board-recorded"
image = make(board, producer="board")
meta, witness = declarations(board, image, source="BOARD_RECORDED")
orchestrate("board-recorded-candidate", image, meta, witness)
pack = board / "orchestrator" / "import" / "trace"
manifest_sha = hashlib.sha256((pack / "manifest.json").read_bytes()).hexdigest()
replay("attestation-missing", pack)
attest_dir = OUT / "attestations"
attest_dir.mkdir()
good = {"manifest_sha256": manifest_sha, "source": "BOARD_RECORDED", "identity": IDENTITY,
        "attested_by": "test caller label only"}
cases = {
    "attestation-bound": good,
    "attestation-sha-mismatch": {**good, "manifest_sha256": "0" * 64},
    "attestation-source-mismatch": {**good, "source": "HOST_VIRTUAL"},
    "attestation-identity-mismatch": {**good, "identity": {**IDENTITY, "motor_id": 99}},
    "attestation-missing-field": {key: value for key, value in good.items() if key != "attested_by"},
}
for name, body in cases.items():
    path = attest_dir / f"{name}.json"
    path.write_text(json.dumps(body, indent=2), encoding="utf-8")
    replay(name, pack, path)
inside = pack / "attestation.json"
inside.write_text(json.dumps(good), encoding="utf-8")
replay("attestation-inside-pack", pack, inside)
inside.unlink()
replay("attestation-file-absent", pack, attest_dir / "does-not-exist.json")
# The candidate path has no attestation input: even with a bound attestation the
# Board Recorded capture above stays PRECONDITION_UNVERIFIED with no candidate.

# Host negatives through the production orchestrator ---------------------------------
def negative(name, changes=(), recompute=True, clear=None, witness=True, source="HOST_VIRTUAL", producer="host"):
    image = make(OUT / name, producer=producer)
    if changes or clear:
        patch(image, list(changes), recompute, clear)
    meta, witness_path = declarations(OUT / name, image, source=source, witness=witness)
    return orchestrate(name, image, meta, witness_path)


negative("no-zero-current-witness", witness=False)
negative("software-inhibit-is-not-zero-current", witness=False)  # every row has OUTPUT_CONFIRMED
negative("crc-error", [(ADC + 132, 2060 << 16 | 1241)], recompute=False)
negative("identity-conflict-recomputed-crc", [(84, 12)])
negative("rank-map-error", [(68, 0x04050601)])
negative("capture-id-mixed", [(ADC + 500, 35)])
negative("adc-sequence-error", [(ADC + 108, 0)])
negative("adc-time-window", [(ADC + 3900 + 12, 0)])  # completion outside the window
negative("row-clock-mismatch", [(ENCODER + 4, 2)])
negative("encoder-record-missing", [(48, 15)], clear=(ENCODER + 15 * 64, 64))
negative("encoder-frame-error", [(ENCODER + 40, 2), (ENCODER + 44, 2), (ENCODER + 48, 1)])
negative("encoder-sequence-gap", [(ENCODER + 15 * 64 + 12, 216)])
negative("encoder-spi-timeout", [(ENCODER + 20, 0), (ENCODER + 32, 0), (ENCODER + 36, 1),
                                  (ENCODER + 40, 1), (ENCODER + 44, 1), (ENCODER + 48, 1)])

# ADC data intact, encoder missing, diagnostic import without witness ----------------
diag = OUT / "adc-valid-encoder-missing-diagnostic"
image = make(diag)
patch(image, [(48, 15)], clear=(ENCODER + 15 * 64, 64))
meta, _ = declarations(diag, image, witness=False)
code, text = sh([sys.executable, "-B", TOOL / "board_capture.py", "import", image, "--metadata", meta,
                 "--out", diag / "archive"])
report = json.loads((diag / "archive" / "diagnostic.json").read_bytes())
(diag / "import.txt").write_text(text, encoding="utf-8")
rows.append(("adc-valid-encoder-missing-diagnostic", "board_capture.py import", code, report["status"],
             f"complete={report['health']['complete']} adc_rows={len(report['adc'])} "
             f"encoder_rows={len(report['encoder'])} ADC_ZERO={report['stage_status']['ADC_ZERO']}"))

lines = [f"{name:40s} {tool:24s} exit {code} {status} {reason}" for name, tool, code, status, reason in rows]
(OUT / "summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))
