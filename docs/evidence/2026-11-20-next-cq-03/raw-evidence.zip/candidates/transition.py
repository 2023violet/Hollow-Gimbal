"""Scratch-only single-accepted-target-change prototype."""
from pathlib import Path

def apply_transition(project, edit):
    header = "core/include/foc_current.h"
    edit(project, header, "    struct foc_vector_dq integral_v;\n",
         "    struct foc_vector_dq integral_v;\n"
         "    struct foc_vector_dq transition_v_per_a;\n"
         "    struct foc_vector_dq transition_target_a;\n")
    current = "core/src/foc_current.c"
    edit(project, current, "    context->integral_v = (struct foc_vector_dq){0};\n",
         "    context->integral_v = (struct foc_vector_dq){0};\n"
         "    context->transition_target_a = (struct foc_vector_dq){0};\n")
    edit(project, current, "        feedforward_enabled = feedforward_output.enabled;\n    }\n",
         """        feedforward_enabled = feedforward_output.enabled;
    }
    const struct foc_vector_dq transition = context->transition_v_per_a;
    const bool track_transition = transition.d != 0.0f || transition.q != 0.0f;
    if (track_transition &&
        (target.d != context->transition_target_a.d || target.q != context->transition_target_a.q)) {
        /* A limited target change contributes on the first accepted H0 only.
         * Pipeline owns commit after the normal Safety and output gates. */
        struct foc_vector_dq pulse = {
            transition.d * (target.d - context->transition_target_a.d),
            transition.q * (target.q - context->transition_target_a.q),
        };
        if (!foc_current_dq_finite(pulse)) {
            return FOC_STATUS_ERR_NONFINITE;
        }
        (void)foc_current_limit_vector(&pulse, 0.40f);
        feedforward_voltage.d += pulse.d;
        feedforward_voltage.q += pulse.q;
        feedforward_enabled = true;
    }
""")
    edit(project, current, "    context->integral_v = integral;\n",
         """    context->integral_v = integral;
    if (track_transition) {
        context->transition_target_a = target;
    }
""")
    edit(project, "runtime/include/foc_pipeline.h", "    struct foc_pipeline_feedforward_config feedforward;\n",
         "    struct foc_pipeline_feedforward_config feedforward;\n"
         "    struct foc_vector_dq transition_v_per_a;\n")
    edit(project, "runtime/src/foc_pipeline.c", "    trial.adc_config = config->adc;\n",
         """    if (!isfinite(config->transition_v_per_a.d) || !isfinite(config->transition_v_per_a.q) ||
        config->transition_v_per_a.d < 0.0f || config->transition_v_per_a.q < 0.0f) {
        return FOC_PIPELINE_ERR_CONFIG;
    }
    trial.current.transition_v_per_a = config->transition_v_per_a;
    trial.adc_config = config->adc;
""")
