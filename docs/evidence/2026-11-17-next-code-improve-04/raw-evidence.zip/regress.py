import sys,shutil
from audit import OUT,ROOT,CC,run,copy_source,ENV
lane=sys.argv[1];dest=OUT/'tests'/lane
assert not dest.exists()
source=copy_source(dest/'source')
for p in ['runtime/src/foc_runtime.c','runtime/tests/test_foc_runtime_mailbox.c','runtime/tests/test_foc_motion_runtime.c','simulation/tests/test_foc_periodic_chain.c']:
    shutil.copy2(ROOT/p,source/p)
project=lane.split('-')[0]
compiler='C:/mingw64/bin/gcc.exe' if lane.endswith('gcc') else CC
args=['cmake','-S',source/project,'-B',dest/'build','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+compiler]
if lane.endswith('asan'):
    args+=['-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
run(dest,'configure',args)
run(dest,'build',['cmake','--build',dest/'build','--parallel','4'])
run(dest,'ctest',['ctest','--test-dir',dest/'build','--output-on-failure'])
run(dest,'entries',['ctest','--test-dir',dest/'build','--show-only=json-v1'])
