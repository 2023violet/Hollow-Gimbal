#include "foc_mechanical_id.h"
const char context_bytes[sizeof(struct foc_mechanical_id_context)] = {0};
const char result_bytes[sizeof(struct foc_mechanical_id_result)] = {0};
const char config_bytes[sizeof(struct foc_mechanical_id_config)] = {0};
const char sample_bytes[sizeof(struct foc_mechanical_id_sample)] = {0};
