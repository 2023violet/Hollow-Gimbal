param(
    [Parameter(Mandatory = $true)][string]$Runner,
    [Parameter(Mandatory = $true)][string]$OutputDirectory,
    [Parameter(Mandatory = $true)][string]$BaselineDirectory
)
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Path $OutputDirectory | Out-Null
foreach ($name in @("generic", "salient")) {
    $options = if ($name -eq "generic") { @("--profile-id", "GENERIC_RESEARCH_MOTOR", "--cogging") }
               else { @("--profile-id", "CALIBRATION_SALIENT_MOTOR") }
    $profileFlag = $options[0..1]
    $preview = & $Runner @options
    if ($LASTEXITCODE -ne 0) { throw "$name preview failed" }
    $preview | Set-Content -Encoding UTF8 "$OutputDirectory/$name-preview.jsonl"
    $reviewId = ($preview | ForEach-Object { ConvertFrom-Json $_ } |
        Where-Object event -eq "CANDIDATE_PREVIEW").review_id
    & $Runner @options --approve-candidate $reviewId --save-config "$OutputDirectory/$name-new.fcal" --cq-current-csv "$OutputDirectory/$name-cycles.csv" |
        Set-Content -Encoding UTF8 "$OutputDirectory/$name-applied.jsonl"
    if ($LASTEXITCODE -ne 0) { throw "$name application failed" }
    & $Runner @profileFlag --load-config "$OutputDirectory/$name-new.fcal" --approve-candidate $reviewId |
        Set-Content -Encoding UTF8 "$OutputDirectory/$name-reloaded.jsonl"
    if ($LASTEXITCODE -ne 0) { throw "$name reload failed" }
    $oldPackage = "$BaselineDirectory/$name-old.fcal"
    $oldPreview = & $Runner @profileFlag --load-config $oldPackage
    if ($LASTEXITCODE -ne 0) { throw "$name legacy preview failed" }
    $oldReview = ($oldPreview | ForEach-Object { ConvertFrom-Json $_ } |
        Where-Object event -eq "CANDIDATE_PREVIEW").review_id
    & $Runner @profileFlag --load-config $oldPackage --approve-candidate $oldReview |
        Set-Content -Encoding UTF8 "$OutputDirectory/$name-legacy-reloaded.jsonl"
    if ($LASTEXITCODE -ne 0) { throw "$name legacy reload failed" }
}

