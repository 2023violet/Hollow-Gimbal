import csv, hashlib, pathlib, re, subprocess, sys, zipfile
root, tmp = pathlib.Path.cwd(), pathlib.Path(sys.argv[1])
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def cmd(*args):
    return subprocess.check_output(args, text=True, encoding="utf-8", errors="replace")
for baseline in csv.DictReader((tmp/"prior-hashes.csv").open(encoding="utf-8-sig")):
    assert sha(pathlib.Path(baseline["Path"])) == baseline["Hash"].lower()
prior = root/"docs/evidence/2026-11-19-next-rt-02"
assert sha(prior/"raw-results.zip") == "2765a2f0731d7f2ec78a4ceda43c50c67a376c68bea31ea0b6b98d34f9888d0d"
with zipfile.ZipFile(prior/"raw-results.zip") as z:
    for line in z.read("independent-review.log").decode("utf-8-sig").splitlines():
        if line.startswith("docs"):
            path, digest = line.rsplit(" ", 1)
            assert sha(root/path) == digest
            print("preserved", path, digest)
    expected = []
    for lane in ("board-clang-off", "board-clang-on"):
        expected.append("["+lane+"]")
        expected.extend(line for line in z.read(lane+"-final.log").decode("utf-8-sig").splitlines()
                        if re.search(r"^2: (legacy-|20/|10/|RT-01|RT-02)|100% tests passed", line))
        expected.append("")
    observed = (prior/"host-timing.txt").read_text(encoding="utf-8-sig").splitlines()
    assert observed == expected
fn = "falconfoc-v2-at32f415"
for mode, digest in [("OFF", "0b6d929c25342c1368ffd2741cd1c88636991903d61bd8cee6d3c18546c6efee"),
                     ("ON", "722c1f8f8f30aa8d0b7892783932fa5a826f7b73d6dcbae38b6574f1ffa69284")]:
    assert sha(tmp/("prior-"+mode)/(fn+".bin")) == digest
    asm = (tmp/("arm-"+mode)/"disassembly.txt").read_text(encoding="utf-8-sig")
    assert "bl" in asm and "<foc_board_spi_on_time>" in asm and "<foc_board_spi_close_result>" in asm
    assert "<foc_at32_trace_hook>" in asm if mode == "ON" else "<foc_at32_trace_hook>" not in asm
    assert len(re.findall(r"\bbl\s+[0-9a-f]+ <adc_preempt_software_trigger_enable>", asm)) == 1
    assert len(re.findall(r"\bbl\s+[0-9a-f]+ <foc_board_adc_complete>", asm)) == 1
    print("RT-03", mode, "BIN", sha(tmp/("arm-"+mode)/(fn+".bin")))
def c_function(source, name):
    start = source.index("{", re.search(r"\b(?:bool|void) "+name+r"\(", source).start())
    nesting = 1
    at = start+1
    while nesting:
        nesting += (source[at] == "{") - (source[at] == "}")
        at += 1
    return source[start:at]
main_path = "firmware/at32f415/src/main.c"
main = (root/main_path).read_text(encoding="utf-8")
assert c_function(main, "foc_at32_lock_output") == c_function(cmd("git","show","HEAD:"+main_path), "foc_at32_lock_output")
assert "adc_preempt_conversion_trigger_set(ADC1, ADC12_PREEMPT_TRIG_SOFTWARE, TRUE);" in main
for irq, level in (("TMR1_CH",0),("ADC1",0),("TMR5_GLOBAL",1),("SPI1",1),("USART1",2)):
    assert f"NVIC_SetPriority({irq}_IRQn, {level}U);" in main
board_path = "firmware/at32f415/src/foc_board.c"
assert c_function((root/board_path).read_text(encoding="utf-8"), "foc_board_output_submit") == c_function(cmd("git","show","HEAD:"+board_path), "foc_board_output_submit")
assert not cmd("git","status","--porcelain","--","core","sensors","platform","protocol","tools","examples","g3","work","control_plane","calibration","simulation").strip()
assert cmd("git","rev-parse","HEAD").strip() == "d824933946a365b8081089c2e396d77b3f661bc8"
assert cmd("git","branch","--show-current").strip() == "codex/falconfoc-v2-vm01a"
assert not cmd("git","diff","--cached","--name-only").strip()
print("RT-02 historical evidence, current software trigger, Board locks, NVIC, protected source scope, HEAD and index verified")

