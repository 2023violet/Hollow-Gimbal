from pathlib import Path
from zipfile import ZipFile
from collections import defaultdict
import csv,subprocess as sp,sys
root=Path(__file__).parent
build=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/"final-complete/simulation-clang"
out=root/"data"
out.mkdir(exist_ok=True)
measured={}
for mode,file in (("train","training-trace.csv"),("holdout","holdout-first-trace.csv"),("legacy","legacy-probe-trace.csv")):
    args=[build/"test-foc-impedance-robustness.exe","--motion-feedforward-"+mode,"--trace"]
    print(sp.list2cmdline(args),flush=True)
    stdout=sp.check_output(args)
    (root/file).write_bytes(stdout)
    groups=defaultdict(list)
    for row in csv.reader(stdout.decode("ascii").splitlines()):
        groups[row[0]].append(row)
    for kind,rows in groups.items():
        assert all(len(row)==len(rows[0]) for row in rows)
        with (out/f"{mode}-{kind.removeprefix('MOTION_').lower()}.csv").open("w",newline="") as f:
            csv.writer(f).writerows(rows)
        print("motion-"+mode,kind,len(rows)-1,flush=True)
    measured[mode]=groups
ref=out/"legacy-input-witness"
ref.mkdir(exist_ok=True)
with ZipFile("docs/evidence/2026-11-18-next-servo-02b/raw-evidence.zip") as z:
    baseline=csv.reader(z.read("data/noise-holdout-trace.csv").decode().splitlines())
    with (ref/"noise-holdout-final-trace.csv").open("w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(next(baseline))
        for row in baseline:
            if row[1:3]==["motion-1p3x","A"]:
                writer.writerow(row)
evaluator=root/"evaluate-motion.py"
with (out/"quality-gates.json").open("w") as f:
    sp.run([sys.executable,evaluator,root,ref],stdout=f,check=True)
print("All C/D quality scopes evaluated. Old zero-FF equivalent to exact 02B original on 6,000 rows.")
