from pathlib import Path
import json
import subprocess
import sys

work=Path(sys.argv[1])
out=work/"historical-quick"
out.mkdir()
exe=work/"integration/falconfoc-virtual-calibrate.exe"
for kind, profile in (("generic","GENERIC_RESEARCH_MOTOR"),("salient","CALIBRATION_SALIENT_MOTOR")):
    package=work/"historical-fcal"/f"old-{kind}.fcal"
    base=[sys.executable,"-B","tools/falconfoc-cli/falconfoc_cli.py","calibrate","--simulator",str(exe),
          "--profile-id",profile,"--calibration-mode","quick","--load-config",str(package)]
    preview=subprocess.run([*base,"--json",str(out/f"{kind}-report.json")],
                           check=True,capture_output=True,text=True)
    rows=[json.loads(r) for r in preview.stdout.splitlines()]
    origin=next(row for row in rows if row.get("event")=="PRODUCT_FCAL_SOURCE")
    assert origin["numerical_config"] and origin["quality"]=="SOURCE_CONFIDENCE_INSUFFICIENT"
    assert all(origin[key] is False for key in ("measurement_sources_restored","dependency_history_restored",
                 "independent_holdout_restored","review_history_restored"))
    assert not any(row.get("event")=="CONFIGURATION_APPLIED" for row in rows)
    before=package.read_bytes()
    token=next(row["review_id"] for row in rows if row.get("event")=="CANDIDATE_PREVIEW")
    approved=subprocess.run([*base,"--approve-candidate",token],check=True,capture_output=True,text=True)
    (out/f"{kind}-approved.jsonl").write_text(approved.stdout,encoding="utf-8")
    rows=[json.loads(r) for r in approved.stdout.splitlines()]
    assert len([r for r in rows if r.get("event")=="CONTROL_TRIAL"])==16
    assert any(r.get("event")=="CONTROL_QUALITY_PASS" for r in rows)
    assert package.read_bytes()==before
    print(profile, token, "old numerical FCAL; source kept absent; verified 16 trials")
