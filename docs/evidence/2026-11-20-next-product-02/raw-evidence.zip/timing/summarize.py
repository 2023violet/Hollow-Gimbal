"""Reduce the Windows QPC runs into median repeat means and observed extrema."""
import csv
from collections import defaultdict
from pathlib import Path
from statistics import median
import sys


def summarize(path):
    lanes = defaultdict(list)
    with path.open(encoding="utf-8-sig", newline="") as source:
        for row in csv.DictReader(source):
            lanes[row["scenario"], row["entry"]].append(row)
    assert len(lanes) == 29
    assert all(len(rows) == 7 for rows in lanes.values())
    print(path.name)
    print("scenario,entry,samples,median_mean_ns,min_mean_ns,max_mean_ns,median_p95_ns,median_p99_ns,max_ns")
    for (scenario, entry), rows in lanes.items():
        means = [float(row["mean_ns"]) for row in rows]
        n = sum(int(row["samples"]) for row in rows)
        p95 = median(float(row["p95_ns"]) for row in rows)
        p99 = median(float(row["p99_ns"]) for row in rows)
        worst = max(float(row["max_ns"]) for row in rows)
        print(f"{scenario},{entry},{n},{median(means):.3f},{min(means):.3f},{max(means):.3f},{p95:.1f},{p99:.1f},{worst:.1f}")
    for label, case, baseline, lane in [
        ("H0 saturated-minus-normal", "current_saturated", "current", "runtime_h0"),
        ("H1 48 Hz-minus-bypass", "impedance48", "impedance0", "runtime_h1"),
    ]:
        deltas = [
            float(candidate["mean_ns"]) - float(reference["mean_ns"])
            for candidate, reference in zip(lanes[case, lane], lanes[baseline, lane], strict=True)
        ]
        print(label, "paired differences (ns):", ", ".join(f"{value:.3f}" for value in deltas),
              f"(median {median(deltas):.3f})")


for argument in sys.argv[1:]:
    summarize(Path(argument))
