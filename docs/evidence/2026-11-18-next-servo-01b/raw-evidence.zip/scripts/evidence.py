
from pathlib import Path
from zipfile import ZipFile
from collections import defaultdict
import subprocess as sp
import csv

root=Path(__file__).parent
prior=Path(r"C:/Users/16429/AppData/Local/Temp/servo01a_1794995524571")
sensor=Path(r"C:/Users/16429/AppData/Local/Temp/sensorest02_de5847f09abe4fa284364f62cb5f055f")
out=root/"data"
out.mkdir(exist_ok=True)
build=root/"final-complete/simulation-clang"
def run(target,*args):
    argv=[build/(target+".exe"),*args]
    print(sp.list2cmdline(argv),flush=True)
    return sp.check_output(argv,stderr=sp.STDOUT).decode("ascii").splitlines()
raw=run("test-foc-runtime-impedance-virtual","--trace")
rows=defaultdict(list)
for row in csv.reader(raw):
    rows[row[0]].append(row)
headers={
    "TRACE":"record scenario elapsed_us capture_us sensor_seq command_seq producer_us session h0_us h1_h0_us updates ref_rad plant_rad plant_rad_s plant_iq_a target_iq_a cap_a load_nm cap_occupied",
    "SUMMARY":"record scenario samples rms_rad max_error_rad overshoot_rad settle_us max_speed_rad_s max_abs_plant_iq_a min_target_iq_a max_target_iq_a pre_max_rad loaded_mean_rad final_max_rad final_rad cap_total_us cap_run_us accepted_updates",
    "QUALITY":"record scenario status",
    "BOUNDARY":"record kind updates_before updates_after rejected_updates old_session new_session fault_bits",
    "RECOVERY":"record kind session updates result",
}
assert set(headers)==set(rows)
for name,fields in headers.items():
    with (out/(name.lower()+".csv")).open("w",newline="") as f:
        wr=csv.writer(f)
        columns=fields.split()
        wr.writerow(columns)
        for row in rows[name]:
            assert len(row)==len(columns),(name,row)
            wr.writerow(row)
def select(path):
    return [x for x in path.read_text(encoding="utf-8-sig").splitlines()
            if x.startswith(("SUMMARY,","QUALITY,"))]
assert select(root/"first-holdout.log")==[x for x in raw if x.startswith(("SUMMARY,","QUALITY,"))]
assert [x[-1] for x in rows["QUALITY"]]==["PASS"]*6
assert len(rows["TRACE"])==20200
new=list(csv.DictReader((out/"trace.csv").open(newline="")))
for r in new:
    t,capture,ss,command,produced,session,h0,age,updates=[int(r[k]) for k in
       ["elapsed_us","capture_us","sensor_seq","command_seq","producer_us","session","h0_us","h1_h0_us","updates"]]
    assert capture==1000+t and ss==1+capture//500 and command==2+t//500 and produced==capture-1
    assert session==1 and h0-capture==age in (0,100) and updates==1+(h0-1000)//200
    assert abs(float(r["target_iq_a"]))<=float(r["cap_a"])
assert all(row[2]==row[3] for row in rows["BOUNDARY"])
assert len(rows["RECOVERY"])==1 and rows["RECOVERY"][0][3]=="15"
print("20,200 identity rows: H1 to H0 0/100 us; producer to H0 1/101 us. Six gates PASS.")
archive=Path("docs/evidence/2026-11-18-next-servo-01a/raw-evidence.zip")
with ZipFile(archive) as frozen:
    old_summary={r["scenario"]:r for r in csv.DictReader(frozen.read("data/summary.csv").decode().splitlines())}
    old_trace=frozen.read("data/trace.csv").decode().splitlines()
    old_rows=[r for r in csv.DictReader(old_trace) if r["scenario"]=="limited" and int(r["elapsed_us"])<40000]
    old_full=prior/"holdout-full.log"
    assert run("test-foc-impedance-virtual","--trace")==old_full.read_text(encoding="ascii").splitlines()
    print("SERVO-01A external Current combination summary and 22,000 sample rows identical.")
new_summary={r["scenario"]:r for r in csv.DictReader((out/"summary.csv").open(newline=""))}
stats=[
    ("error_rms_rad","rms_rad",.004),("max_error_rad","max_error_rad",.004),
    ("overshoot_rad","overshoot_rad",.02),("settling_candidate_us","settle_us",70000),
    ("max_abs_plant_iq_a","max_abs_plant_iq_a",.05),("loaded_signed_mean_error_rad","loaded_mean_rad",.004)
]
with (out/"comparison.csv").open("w",newline="") as f:
    wr=csv.writer(f)
    wr.writerow(["scenario","metric","01a","01b","absolute_difference","frozen_limit","verdict"])
    for case in ("hold","soft-damping","load","reversal"):
        for old_name,new_name,bound in stats:
            a,b=float(old_summary[case][old_name]),float(new_summary[case][new_name])
            err=abs(a-b)
            assert err<=bound,(case,new_name,a,b,bound)
            wr.writerow([case,new_name,a,b,err,bound,"PASS"])
            print(case,new_name,f"{a:.10g}",f"{b:.10g}",f"diff={err:.10g}")
    initial=[r for r in new if r["scenario"]=="limit-045" and int(r["elapsed_us"])<40000]
    deltas=[]
    for a,b in zip(old_rows,initial,strict=True):
        assert a["elapsed_us"]==b["elapsed_us"]
        deltas.append(abs(float(a["plant_iq_a"])-float(b["plant_iq_a"])))
    assert max(deltas)<=.12
    wr.writerow(["limit-045-first-40ms","plant_iq_max_pointwise_delta","","",max(deltas),.12,"PASS"])
    print("0.45A matched current first 40 ms max absolute pointwise delta",max(deltas))
# Re-run exact protected legacy, Motor-ID and Encoder research consumers.
assert run("test-foc-sensor-est","--trace")== (sensor/"new-speed-trace.log").read_text(encoding="ascii").splitlines()
for tag,target,args in [
    ("motor-id","test-foc-motor-id-virtual",["--trace"]),
    ("motor-id-quality","test-foc-motor-id-virtual",["--quality"]),
    ("encoder-linear","test-foc-periodic-chain",["--encoder-linearization"]),
    ("encoder-calibration","test-foc-periodic-chain",["--encoder-calibration-study"]),
    ("encoder-calibration-dataset","test-foc-periodic-chain",["--encoder-calibration-dataset"]),
]:
    assert run(target,*args)== (sensor/(tag+".log")).read_text(encoding="ascii").splitlines()
system=out/"system-angle.csv"
run("test-foc-periodic-chain","--system-angle-csv",system)
assert system.read_bytes()==(sensor/"system-angle-after.csv").read_bytes()
print("SENSOR-EST-02, Encoder Linear 01A/01B, Motor-ID 01A/01B and System Angle unchanged.")

