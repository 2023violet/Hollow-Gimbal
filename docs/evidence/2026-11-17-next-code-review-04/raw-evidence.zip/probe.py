import pathlib,subprocess,json
from audit import OUT,SRC,CC,ENV,run
ARM=pathlib.Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.3 rel1/bin')
incs=[SRC/p for p in ['runtime/include','core/include','g3/np/include','g3/safe/include']]
types=['foc_runtime','foc_pipeline','foc_runtime_config','foc_runtime_snapshot','foc_runtime_sensor_slot','foc_runtime_command','foc_runtime_lane','foc_runtime_fast_input','foc_current_context','foc_runtime_lifecycle_request','foc_runtime_lifecycle_result']
c='#include "foc_runtime.h"\n#ifdef HOST\n#include <stdio.h>\nint main(void){\n'+''.join('printf("'+t+'=%zu\\n",sizeof(struct '+t+'));\n' for t in types)+'return 0;}\n#else\n'+''.join('char layout_'+t+'[sizeof(struct '+t+')];\n' for t in types)+'#endif\n'
(OUT/'layout.c').write_text(c)
run(OUT/'resources','host-build',[CC,'-std=c11','-DHOST',*[a for p in incs for a in ['-I',p]],OUT/'layout.c','-o',OUT/'resources/layout.exe'])
run(OUT/'resources','host-layout',[OUT/'resources/layout.exe'])
flags=['-std=c11','-mcpu=cortex-m4','-mthumb','-mfloat-abi=soft','-Os','-fstack-usage',*[a for p in incs for a in ['-I',p]]]
for name,path in [('runtime',SRC/'runtime/src/foc_runtime.c'),('layout',OUT/'layout.c')]:
    run(OUT/'resources',name+'-arm',[ARM/'arm-none-eabi-gcc.exe',*flags,'-c',path,'-o',OUT/'resources'/(name+'.o')])
    run(OUT/'resources',name+'-symbols',[ARM/'arm-none-eabi-nm.exe','-S','--size-sort',OUT/'resources'/(name+'.o')])
run(OUT/'resources','arm-disassembly',[ARM/'arm-none-eabi-objdump.exe','-dr',OUT/'resources/runtime.o'])
run(OUT/'resources','arm-size',[ARM/'arm-none-eabi-size.exe',OUT/'resources/runtime.o'])
run(OUT/'resources','arm-undefined',[ARM/'arm-none-eabi-nm.exe','-u',OUT/'resources/runtime.o'])
for project in ['runtime','simulation']:
    dest=OUT/project
    run(dest,'configure',['cmake','-S',SRC/project,'-B',dest/'build','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+CC])
    run(dest,'build',['cmake','--build',dest/'build','--parallel','4'])
    run(dest,'ctest',['ctest','--test-dir',dest/'build','--output-on-failure'])
