# CQ-03C 负载诊断复跑

`cq03c-findings.md` 记录固定负载矩阵、带载 STOP/FAULT、闭环限幅及解析对照。完整的四份 H0/H1 轨迹与 CQ-02 的 `load-diagnostics.zip` 中同名 CSV 逐字节一致。此包的 `data/*-selected.csv` 从逐拍输出保留 10 ms 网格和加载、卸载、终止边界，完整逐拍文件继续由 CQ-02 归档提供。源文件及运行数据可用 `manifest.json` 查验。0 Hz 与 48 Hz 的两轴 PI 补充轨迹逐字节一致，包内保留一份完整轨迹及两份哈希。

## 复跑

使用 CQ-03 冻结源码的绝对路径，以及仓库中 CQ-02 的原 `docs/evidence/2026-11-20-next-cq-02/load-diagnostics.zip`。工具为 CMake 3.25+、Ninja、Clang 22.1.8 和 Python 3.11+。命令从本归档解压的目录执行。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run-cq03.ps1 -SourceRepo <CQ03-frozen-source> -Cq02LoadArchive <CQ02-load-diagnostics.zip> -OutputDirectory <new-directory>
```

原复跑用 CQ-02 归档的未改动 `run.ps1` 从冻结 CQ-01 源码和冻结 CQ-03 源码分别构建。附录的单源码复跑使用同一 CQ-03 生产实现配置 0/48 Hz，和随包保存的冻结 CQ-01 用例源码。检查逐字节 SHA-256 时请使用与本包相同的版本、编译器和平台。

```powershell
cmake -S <CQ03-frozen-source>/simulation -B <simulation-build> -G Ninja -DCMAKE_C_COMPILER=clang
cmake --build <simulation-build> --target falconfoc-virtual-motion
python -B .\axes-src\rerun_cq03_axes.py <CQ03-frozen-source> <simulation-build> <new-axis-output>
python -B .\axes-src\analyze_axes.py <new-axis-output>
cmake -S <CQ03-frozen-source>/runtime -B <runtime-build> -G Ninja -DCMAKE_C_COMPILER=clang
cmake --build <runtime-build> --target test-foc-motion-runtime test-foc-runtime-impedance
ctest --test-dir <runtime-build> -R '^(test-foc-motion-runtime|test-foc-runtime-impedance)$' --output-on-failure
```

