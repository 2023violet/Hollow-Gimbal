
from pathlib import Path
import subprocess as sp
import re, hashlib
from collections import Counter

root=Path(__file__).parent
obj=root/"foc_impedance.o"
base=Path(r"C:/Users/16429/AppData/Local/Temp/sensorest02_de5847f09abe4fa284364f62cb5f055f")/"final/locked-arm"
new=root/"final/locked-arm"
def tool(name,*args):
    return sp.check_output(["arm-none-eabi-"+name,*args],text=True,stderr=sp.STDOUT)
flags=["-std=c11","-mcpu=cortex-m4","-mthumb","-mfloat-abi=soft","-Os",
       "-ffunction-sections","-fdata-sections","-fstack-usage","-Wall","-Wextra",
       "-Wpedantic","-Werror"]
print(tool("gcc","--version").splitlines()[0])
print("flags",*flags)
tool("gcc",*flags,"-Icore/include","-c","core/src/foc_impedance.c","-o",obj)
print(tool("size",obj))
print(tool("nm","-S",obj))
print(obj.with_suffix(".su").read_text())
disasm=tool("objdump","-dr",obj)
(root/"foc_impedance-disasm.txt").write_text(disasm)
relocations=Counter(re.findall(r"R_ARM_(?:THM_CALL|THM_JUMP24)\s+(\w+)",disasm))
print("static call sites",dict(relocations))
instr=re.findall(r"^\s*[0-9a-f]+:\s+[0-9a-f]{4}(?: [0-9a-f]{4})?\s+([a-z]\w*)",disasm,re.M)
print("static instruction slots",len(instr))
assert "sqrt" not in disasm and "fmax" not in disasm and "fmin" not in disasm
for label, tree in [("before",base),("after",new)]:
    elf=next(tree.glob("*.elf"))
    binary=next(tree.glob("*.bin"))
    print(label,tool("size",elf),sep="\n")
    assert "foc_impedance" not in tool("nm",elf), label
    print(label,"BIN",binary.stat().st_size,hashlib.sha256(binary.read_bytes()).hexdigest())
    if label=="before":
        prior=binary.read_bytes()
    else:
        assert prior==binary.read_bytes()
        print("locked BIN byte-identical, no impedance symbol")

