# G4 independent review receipt

Reviewer: /root/improve04_review. Read-only review of Runtime source, formal tests,
valid RED log and separately built private probes. No repository/index edits.
Reviewed production SHA256: 4a68022216125138a7af647309ceb76fb513eb66356eb0ee39241d66755b5c6f.

Conclusion: both P1 bypasses removed; action eligibility is captured before Safety
observation, rejected requests cannot be reinterpreted after RUNNING -> DISABLED,
and each ordinary H0 event calls guarded Pipeline once. Invalid ADC reaches existing
invalid-streak/inhibit handling. No new same-level P1, locks, allocation or hardware
dependencies found. Valid disabled SET_MODE cold boundary remains intact.

Supplementary synthetic consume-time session mismatch probe: valid ADC -> one UPDATE;
invalid ADC -> INHIBIT, streak1, no UPDATE. Both terminal REJECTED retain request seq92.
The session is explicitly injected, not claimed as a reproduced interrupt race.

Nonblocking P2: after an UPDATE is already accepted, an AFTER_CONTROL nonfault STOP
inhibits and increments session, but wrong ARM / expired ARM terminal can be REJECTED
rather than CANCELLED. Wrong ARM H0=-5; expired ARM H0=0. Both DISABLED/INHIBIT,
historical updates2. Existing post-admission return/commit ordering was preserved.
Do not reorder general success return to erase an accepted transaction.

Follow-up review of the two directly necessary legacy assertions: APPROVED. Mode
rejection now compares an independently initialized ordinary-cycle Runtime, exact
update count and d/q PI equality; startup transport failure asserts streak1/2/3,
existing threshold3 and SAMPLE_INVALID latch only, no auto-restart. No weakening of
safety assertions found. Full G3/protection checks remain the primary executor's work.
