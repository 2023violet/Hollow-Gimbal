NEXT-SOFT-05 software evidence. All calibration observations in the demo are Host synthetic.
The patch applies to the pre-task snapshot including SOFT-01 through SOFT-04.
It excludes the archive itself. The TDD red-test logs are intentional.
