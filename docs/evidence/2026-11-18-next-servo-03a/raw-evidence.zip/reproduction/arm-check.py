from pathlib import Path
import hashlib, subprocess as sp
root=Path(__file__).parent
previous=Path("C:/Users/16429/AppData/Local/Temp/servo02d_1795018049170/final-complete/locked-arm")
now=root/"final-complete/locked-arm"
bins=[]
for name,p in [("02D",previous),("03A",now)]:
    image=next(p.glob("*.bin"))
    elf=next(p.glob("*.elf"))
    raw=image.read_bytes()
    bins.append(raw)
    syms=sp.check_output(["arm-none-eabi-nm","-S",elf],text=True)
    for unexpected in ("foc_impedance_feedforward_evaluate","damping_noise_filter","servo_demo"):
        assert unexpected not in syms,unexpected
    print(name,len(raw),hashlib.sha256(raw).hexdigest())
    print(sp.check_output(["arm-none-eabi-size",elf],text=True).strip())
assert bins[0]==bins[1]
print("AT32F415 locked binary identical; no example, damping filter, or feedforward calculation symbols.")
