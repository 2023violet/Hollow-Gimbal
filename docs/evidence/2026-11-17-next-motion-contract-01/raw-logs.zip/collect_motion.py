import hashlib, json, pathlib, re, shutil, types, zipfile
from audit import OUT, ROOT, SRC, run

NAME='2026-11-17-next-motion-contract-01'
EVID=ROOT/'docs/evidence'/NAME
BASE=json.loads((OUT/'source-before.json').read_text(encoding='utf-8'))
CHANGED={'core/tests/test_foc_motion.c','core/tests/test_foc_motion_reference.c',
         'core/include/foc_motion.h','core/README.md','docs/governance/Themis_工程维护日志.md'}

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return path.read_text(encoding='utf-8')
def write_json(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def records(folder):
    rows=[json.loads(s) for s in read(folder/'commands.jsonl').splitlines()]
    for r in rows:
        assert r['log_sha256']==sha(folder/(r['name']+'.log'))
    return rows

def ctest(folder,count):
    rows=records(folder); c=next(r for r in rows if r['name']=='ctest')
    assert c['exit']==0 and f'100% tests passed out of {count}' in read(folder/'ctest.log')
    assert all(r['exit']==0 for r in rows)
    return {'count':count,'commands':rows}

def numeric(path):
    # CTest's localized header uses the Windows ACP; numeric markers are ASCII.
    s=path.read_bytes().decode('utf-8',errors='replace')
    nominal=next(s for s in s.splitlines() if s.startswith('prediction_nominal '))
    outside=next(s for s in s.splitlines() if s.startswith('prediction_outside_nominal '))
    count=int(re.search(r'cases=(\d+)',nominal)[1]);error=float(re.search(r'max_error=(\S+)',nominal)[1])
    assert count==74684 and error<=2e-6
    return {'nominal':nominal,'outside_nominal':outside,'count':count,'max_error_rad':error,'budget_rad':2e-6}

results={'baseline':'6b151a1ca745a37b0cd044528058f34b09834919','branch':'codex/falconfoc-v2-vm01a',
         'software_verdict':'PASS','git_delivery':'PENDING_USER_CONFIRMATION',
         'production_motion_sha256':BASE['core/src/foc_motion.c']['sha256'],
         'G1':ctest(OUT/'tests/core',15),'G2':ctest(OUT/'green/core',15),'G3':{},
         'G4':{},'numeric':{},'gate':{},'evidence_root':str(OUT)}
for label in ['commit-trial','commit-negative','commit-finite','time-scale']:
    dest=OUT/'mutations-fresh'/label
    old=ctest(dest/'before-tests',15)
    after=records(dest/'after-tests');byname={r['name']:r for r in after}
    assert byname['configure']['exit']==byname['build']['exit']==0
    assert byname['ctest']['exit']==8 and byname['executable']['exit']==1
    failed=read(dest/'after-tests/executable.log')
    assert 'prediction mismatch' in failed if label=='time-scale' else 'velocity_state_equal' in failed
    results['G3'][label]={'definition':json.loads(read(dest/'mutation.json')),'old_tests':old,
                         'new_tests':after,'failure':failed}

for name,relative,count in [('core-clang','final/core',15),('core-gcc','regression/core-gcc',15),
    ('runtime','final/runtime',11),('simulation','final/simulation',15),
    ('core-asan-ubsan','regression/core-asan',15),('simulation-asan-ubsan','regression/simulation-asan',15)]:
    results['G4'][name]=ctest(OUT/relative,count)
for name,path in [('clang','green-repo/build/motion-contract-01/Testing/Temporary/LastTest.log'),
    ('gcc','regression/core-gcc/build/Testing/Temporary/LastTest.log'),
    ('asan-ubsan','regression/core-asan/build/Testing/Temporary/LastTest.log')]:
    results['numeric'][name]=numeric(OUT/path)
entry=read(OUT/'green/core/entries.log')
assert 'test-foc-motion\n' in entry and 'test-foc-motion-reference\n' in entry and 'Total Tests: 15' in entry
for folder in [OUT/'gates',OUT/'final/gates']:
    assert all(r['exit']==0 for r in records(folder))
    result=read(folder/'strict-all.log')
    assert '[Total]   PASS' in result and result.count('[cmake_quality] format-check:')==30
    assert '45/45' in result and '[quality_gate] all requested checks passed.' in result
results['gate']={'formal':records(OUT/'final/gates'),'preliminary':records(OUT/'gates'),
                 'cmake_format_count':30,'legacy_host_tests':45,
                 'isolation':json.loads(read(OUT/'gate-isolation.json'))}
last_mutation=records(OUT/'mutations-fresh/time-scale/after-tests')[-1]['finished_utc']
assert last_mutation<records(OUT/'final/core')[0]['started_utc']
assert records(OUT/'final/core')[-1]['finished_utc']<records(OUT/'final/runtime')[0]['started_utc']
assert records(OUT/'final/runtime')[-1]['finished_utc']<records(OUT/'final/simulation')[0]['started_utc']
assert records(OUT/'final/simulation')[-1]['finished_utc']<records(OUT/'final/gates')[0]['started_utc']

EVID.mkdir(exist_ok=False)
archive=EVID/'raw-logs.zip'
folders=[OUT/'tests/core',OUT/'green',OUT/'regression',OUT/'mutations',OUT/'mutations-fresh',OUT/'gates',OUT/'final']
files=set()
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file() and p.name in ['commands.jsonl','mutation.json','LastTest.log']:
            files.add(p)
        if p.is_file() and p.suffix=='.log' and (p.parent/'commands.jsonl').is_file():
            files.add(p)
for p in [OUT/'baseline.py',OUT/'audit.py',OUT/'motion_study.py',OUT/'collect_motion.py',
          OUT/'source-before.json',OUT/'artifacts-before.json',OUT/'gate-isolation.json',
          OUT/'git-status-before.txt',OUT/'head.txt',OUT/'branch.txt']:
    files.add(p)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files): z.write(p,p.relative_to(OUT).as_posix())
results['raw_archive']={'sha256':sha(archive),'files':len(files),'bytes':archive.stat().st_size,
    'invalid_initial_attempt':'mutations/commit-trial/after-tests; stale mtime prevented rebuild; excluded from G3'}
write_json(EVID/'results.json',results)
report=read(OUT/'report.template.md').replace('@@MOTION_SHA@@',results['production_motion_sha256'])
assert '@@' not in report
(ROOT/'docs/evidence'/f'{NAME}.md').write_text(report,encoding='utf-8')

log='docs/governance/Themis_工程维护日志.md'
assert (ROOT/log).read_bytes()==(SRC/log).read_bytes()
append='''

## 2026-11-17 FalconFOC V2 NEXT-MOTION-CONTRACT-01 数值合同与错误原子性

- [测试] 既有 Motion CTest 新增正负 Ki trial/P requested 溢出反例：0.25 积分及全部逻辑状态保留、预填输出清零、disabled/非法输入与同实例恢复；旧正常/饱和测试保留。
- [数值] 独立 Double 时间/相位/数学周期 Oracle，名义域有界相位、|omega_e|≤7000 rad/s、0..650 us、Board默认模型设置，74684 样本最大误差1.0674847210623284e-6 rad，小于2e-6预算。高速度域外样本OK但误差0.0015148064769334724 rad，仅作为限制观测。
- [负向] 三类提前提交积分及一类预测时间换算变异均独立成功编译：旧Core15/15通过，新正式测试行为断言失败。首轮复制mtime导致未重编译的无效尝试单独保留排除，有效变异均使用全新构建。
- [回归] Core Clang/GCC各15/15、Runtime11/11、Simulation15/15；Core/Simulation ASan+UBSan各15/15；Source81/9/9、修改C/H格式、严格Scope all含30项CMake格式和Legacy Host45/45通过。原15个Core CTest入口保持。
- [范围] 仅测试、Motion头注释/Core说明、新证据及本日志；生产Motion/参数/Board1/Safety/PWM/UART/整数相位/Golden均未改。区分准入、计算回归与系统总误差；max_error仅约束加速度模型贡献，不称控制品质提升或任意输入精度保证。2427个旧ignored产物保留；Gate使用的6个Legacy ELF/MAP为核对SHA的历史副本，非新ARM重建。
- [交付/边界] 报告docs/evidence/2026-11-17-next-motion-contract-01.md，软件验收PASS，按本轮第7节等待用户确认后才普通commit/push；不自动进入下一轮。G3-SAFE HARDWARE NOT VERIFIED / G3-PWR LOCKED / AT32F415 WCET NOT VERIFIED / MOTOR PHYSICAL OPERATION UNVERIFIED。
'''
with (ROOT/log).open('ab') as f: f.write(append.encode('utf-8'))

module=types.ModuleType('baseline_helpers');module.__file__=str(OUT/'baseline.py')
exec(read(OUT/'baseline.py').split('\nif len(sys.argv) == 1:')[0],module.__dict__)
# Include the protection receipt itself in the final path/count check; no self hash is claimed.
write_json(EVID/'change-verification.json',{})
now=module.manifest();old_artifacts=json.loads(read(OUT/'artifacts-before.json'));artifacts=module.manifest(True)
changed=sorted(p for p in BASE if BASE[p]!=now.get(p));added=sorted(now.keys()-BASE.keys())
assert set(changed)==CHANGED and all(p in now for p in BASE)
assert set(added)=={f'docs/evidence/{NAME}.md',f'docs/evidence/{NAME}/results.json',
                      f'docs/evidence/{NAME}/change-verification.json',f'docs/evidence/{NAME}/raw-logs.zip'}
assert old_artifacts==artifacts
assert all(sha(SRC/p)==info['sha256'] for p,info in BASE.items())
assert (ROOT/log).read_bytes().startswith((SRC/log).read_bytes())
assert module.git('status','--porcelain',root=module.MAIN)==(OUT/'main-status-before.txt').read_bytes()
assert module.git('rev-parse','HEAD')==(OUT/'head.txt').read_bytes()
assert module.git('branch','--show-current')==(OUT/'branch.txt').read_bytes()
remote=module.git('ls-remote','--heads','origin',results['branch']).decode().split()[0]
assert remote==results['baseline']
strip=lambda s: re.sub(r'\s+','',re.sub(r'/\*.*?\*/|//[^\n]*','',s,flags=re.S))
assert strip(read(ROOT/'core/include/foc_motion.h'))==strip(read(SRC/'core/include/foc_motion.h'))
assert sha(ROOT/'core/src/foc_motion.c')==results['production_motion_sha256']
assert all((ROOT/p).read_bytes()==(OUT/'green-repo'/p).read_bytes() for p in CHANGED if p!=log)
protected=[p for p in BASE if p.startswith(('core/','runtime/','simulation/','firmware/','sensors/','g3/','protocol/')) and p not in CHANGED]
assert all(BASE[p]==now[p] for p in protected)
protection={'source_files_before':len(BASE),'source_files_after':len(now),'changed_existing':changed,'added':added,
    'protected_control_files_unchanged':len(protected),'existing_ignored_artifacts_unchanged':len(artifacts),
    'existing_ignored_bytes':sum(v['size'] for v in artifacts.values()),'original_snapshot_unchanged':True,
    'maintenance_prefix_preserved':True,'main_worktree_unchanged':True,'public_header_noncomment_content_unchanged':True,
    'production_motion_sha256':results['production_motion_sha256'],'head':results['baseline'],
    'branch':results['branch'],'remote_head_before_approval':remote,'git_commit_push':'NOT_EXECUTED_PENDING_CONFIRMATION'}
write_json(EVID/'change-verification.json',protection)
write_json(OUT/'change-verification.json',protection)
write_json(OUT/'results.json',results)
run(OUT/'review','diff-check',['git','diff','--check'],cwd=ROOT)
run(OUT/'review','status',['git','status','--short','--untracked-files=all'],cwd=ROOT)
(OUT/'final.patch').write_bytes(module.git('diff','--binary'))
print(json.dumps({'verdict':'PASS','files':changed+added,'archive':results['raw_archive'],
                  'protected_ignored':len(artifacts),'local_remote_head':remote},ensure_ascii=False))
