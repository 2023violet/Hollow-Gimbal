from pathlib import Path
from zipfile import ZipFile
from collections import defaultdict
import csv,math,subprocess as sp,sys
root=Path(__file__).parent
data=root/"data"
data.mkdir(exist_ok=True)
build=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/"baseline"
cmd=[build/"test-foc-impedance-robustness.exe","--damping-noise-holdout","--trace"]
print(sp.list2cmdline(cmd),flush=True)
out=defaultdict(list)
for row in csv.reader(sp.check_output(cmd).decode("ascii").splitlines()):
    out[row[0]].append(row)
with ZipFile("docs/evidence/2026-11-18-next-servo-02b/raw-evidence.zip") as z:
    for tag,stem in [("NOISE_TRACE","trace"),("NOISE_RESULT","result"),("NOISE_BOUNDARY","boundary")]:
        base=list(csv.reader(z.read("data/noise-holdout-"+stem+".csv").decode().splitlines()))
        assert out[tag]==base,(tag,len(out[tag]),len(base))
        print("02B exact",tag,len(base)-1,flush=True)
        if tag!="NOISE_TRACE":
            with (data/f"02b-frozen-{stem}.csv").open("w",newline="") as f:
                csv.writer(f).writerows(base)
trace=out["NOISE_TRACE"]
rows=defaultdict(list)
for row in trace[1:]:
    if row[1]=="motion-1p3x":
        rows[row[2]].append(dict(zip(trace[0],row)))
assert set(rows)=={"A","B","C"}
summaries={r[2]:dict(zip(out["NOISE_RESULT"][0],r)) for r in out["NOISE_RESULT"][1:] if r[1]=="motion-1p3x"}

a0,b0=1120000,1450000
J,B,kt,cap=.0026,.006,.15,.315
travel,duration=-.28,.33
def a_ref(t):
    return 6*travel/duration**2*(1-2*t/duration)
def v_ref(t):
    return 6*travel/duration*(t/duration)*(1-t/duration) if 0<=t<=duration else 0
def rms(values):
    return math.sqrt(sum(x*x for x in values)/len(values))
def peak(values):
    return max(abs(x) for x in values)
def write(name,rows):
    with (data/(name+".csv")).open("w",newline="") as f:
        out=csv.DictWriter(f,fieldnames=list(rows[0]))
        out.writeheader()
        out.writerows(rows)
phases=[
    ("forward-deceleration",630000,840000),
    ("dwell-before-reversal",840000,a0),
    ("reverse-entry",a0,a0+25000),
    ("reverse-acceleration",a0+25000,1285000),
    ("reverse-deceleration",1285000,b0),
    ("post-reversal-settle",b0,1650000),
]
annotated=[]; stats=[]; overall=[]; ideals=[]
for arm,observed in rows.items():
    prev=None
    for row in observed:
        t=int(row["t_us"]); h0=int(row["h0_us"])
        actual_v=float(row["model_rad_s"]); actual_q=float(row["model_iq_a"])
        if prev is None:
            prev=(h0,actual_v,actual_q)
            continue
        dt=(h0-prev[0])*1e-6
        assert dt in (.0004,.0006) or abs(dt-.0006)<1e-12 or abs(dt-.0004)<1e-12
        actual_acc=(actual_v-prev[1])/dt
        torque_balance=J*actual_acc+B*(actual_v+prev[1])/2
        kt_avg_iq=kt*(actual_q+prev[2])/2
        prev=(h0,actual_v,actual_q)
        if not phases[0][1]<=t<phases[-1][2]:
            continue
        phase=next(p for p,lo,hi in phases if lo<=t<hi)
        v=float(row["reference_rad_s"])
        a=(a_ref((t-a0)*1e-6) if a0<=t<b0 else
           -(0.035+5.6*.21)/.21 if t<840000 else 0.0)
        ideal=J*a+B*v
        qreq=float(row["request_a"])
        sensor=float(row["sensor_velocity_rad_s"])
        dq=float(row["d_nm"])
        measured=float(row["model_rad"])
        position=float(row["reference_rad"])
        spring=float(row["k_nm"])
        real_d=float(summaries[arm]["d"])
        arow={
          "arm":arm,"phase":phase,"elapsed_us":t,
          "capture_us":int(row["capture_us"]),"h1_us":2000+t,"producer_us":1999+t,
          "h0_adc_us":h0,"prediction_us":h0-int(row["capture_us"]),"ideal_output_begins_us":h0,
          "recorded_raw_code":int(row["raw_code"]),"clean_code":int(row["clean_code"]),
          "session":int(row["session"]),"sensor_seq":int(row["sample_seq"]),
          "accepted_updates":int(row["updates"]),"output_action":"UPDATE",
          "reference_p_rad":position,"reference_v_rad_s":v,"reference_a_rad_s2":a,
          "plant_p_rad":measured,"plant_v_rad_s":actual_v,"interval_actual_a_rad_s2":actual_acc,
          "position_error_rad":position-measured,"velocity_error_rad_s":v-actual_v,
          "driver_feedback_v_rad_s":v-dq/real_d,"sensor_v_rad_s":sensor,
          "target_torque_nm":ideal,"instant_q_torque_nm":kt*actual_q,
          "interval_torque_balance_nm":torque_balance,"interval_Kt_times_avg_iq_nm":kt_avg_iq,
          "reference_minus_prelimit_nm":ideal-float(row["pre_limit_nm"]),
          "request_minus_instant_KtIq_nm":kt*(qreq-actual_q),
          "K_term_nm":spring,"D_effective_nm":dq,"load_feedforward_nm":float(row["ff_nm"]),
          "host_filter_correction_nm":float(row["host_ff_nm"]),
          "D_with_oracle_capture_velocity_nm":real_d*(v-float(row["true_delta_rad_s"])),
          "prelimit_nm":float(row["pre_limit_nm"]),"postlimit_nm":float(row["post_limit_nm"]),
          "iq_request_a":qreq,"iq_measured_a":actual_q,"limited":int(row["limited"]),
          "source_v_error_rad_s":float(row["lpf_error_rad_s"]),
        }
        annotated.append(arow)
    def results(filter):
        return [r for r in annotated if r["arm"]==arm and filter(r)]
    reverse=results(lambda r:a0<=r["elapsed_us"]<b0)
    frozen=float(summaries[arm]["reverse_error_rad_s"])
    rev_rms=rms([r["velocity_error_rad_s"] for r in reverse])
    assert abs(rev_rms-frozen)<1e-8,(arm,rev_rms,frozen)
    assert not any(r["limited"] for r in reverse)
    applied_start=reverse[0]["h0_adc_us"]
    erp=reverse[0]["position_error_rad"]
    erv=reverse[0]["velocity_error_rad_s"]
    e_p,e_v=erp,erv
    ideal_errors=[]
    # Linear error model with ideal torque tracking, zero Sensor/scheduling delay.
    # This isolates finite K/D as a mechanism, independent of the Virtual Plant.
    if arm!="C":
        K,D=map(float,(summaries[arm]["k"],summaries[arm]["d"]))
        def rate(s,p,v):
            return v,a_ref(s)+B/J*v_ref(s)-(K*p+(B+D)*v)/J
        for row in reverse:
            s=(row["elapsed_us"]-a0)*1e-6
            ideal_errors.append(e_v)
            ideals.append(dict(arm=arm,elapsed_us=row["elapsed_us"],ideal_error_rad=e_p,
                               ideal_velocity_error_rad_s=e_v,actual_velocity_error_rad_s=row["velocity_error_rad_s"]))
            h=.0005
            p1,v1=rate(s,e_p,e_v)
            p2,v2=rate(s+h/2,e_p+p1*h/2,e_v+v1*h/2)
            p3,v3=rate(s+h/2,e_p+p2*h/2,e_v+v2*h/2)
            p4,v4=rate(s+h,e_p+p3*h,e_v+v3*h)
            e_p+=h*(p1+2*p2+2*p3+p4)/6
            e_v+=h*(v1+2*v2+2*v3+v4)/6
    min_lag,shift_rms=min(((lag,rms([v_ref((r["elapsed_us"]-a0-lag)*1e-6)-r["plant_v_rad_s"]
                   for r in reverse])) for lag in range(0,100001,500)),key=lambda pair:pair[1])
    cross=next(r["elapsed_us"]-a0 for r in reverse if r["plant_v_rad_s"]<=-.05)
    overall.append(dict(arm=arm,observed_rms_rad_s=rev_rms,threshold_rad_s=.25,
        reversal_delay_us=cross,rms_no_delay_linear_fb_rad_s=rms(ideal_errors) if ideal_errors else "",
        offline_best_ref_shift_us=min_lag,offline_shifted_rms_rad_s=shift_rms,
        onset_plant_v_rad_s=reverse[0]["plant_v_rad_s"],onset_plant_torque_nm=reverse[0]["instant_q_torque_nm"],
        onset_ref_torque_nm=reverse[0]["target_torque_nm"],
        peak_reference_torque_nm=peak([r["target_torque_nm"] for r in reverse]),
        peak_command_torque_nm=peak([r["prelimit_nm"] for r in reverse]),
        peak_plant_KtIq_nm=peak([r["instant_q_torque_nm"] for r in reverse]),
        rms_feedback_demand_gap_nm=rms([r["reference_minus_prelimit_nm"] for r in reverse]),
        rms_electrical_tracking_gap_nm=rms([r["request_minus_instant_KtIq_nm"] for r in reverse]),
        rms_torque_balance_discrepancy_nm=rms([r["interval_torque_balance_nm"]-r["interval_Kt_times_avg_iq_nm"] for r in reverse]),
        cap_nm=cap,limited_samples=sum(r["limited"] for r in reverse),
        min_h1_wait_us=min(r["h0_adc_us"]-r["h1_us"] for r in reverse),
        max_h1_wait_us=max(r["h0_adc_us"]-r["h1_us"] for r in reverse),
        minimum_source_age_us=min(r["prediction_us"] for r in reverse),
        maximum_source_age_us=max(r["prediction_us"] for r in reverse)))
    rev_sum=sum(r["velocity_error_rad_s"]**2 for r in reverse)
    for phase,lo,hi in phases:
        samples=results(lambda r:r["phase"]==phase)
        mean=lambda field: sum(r[field] for r in samples)/len(samples)
        phase_rms=lambda field: rms([r[field] for r in samples])
        stats.append(dict(arm=arm,phase=phase,start_us=lo,end_us=hi,samples=len(samples),
            vel_rms_rad_s=phase_rms("velocity_error_rad_s"),vel_mean_rad_s=mean("velocity_error_rad_s"),
            pos_rms_rad=phase_rms("position_error_rad"),accel_actual_peak_rad_s2=peak([r["interval_actual_a_rad_s2"] for r in samples]),
            error_energy_fraction_frozen_reverse=(sum(r["velocity_error_rad_s"]**2 for r in samples)/rev_sum
                   if a0<=lo<b0 else ""),ref_torque_mean_nm=mean("target_torque_nm"),
            measured_KtIq_mean_nm=mean("instant_q_torque_nm"),spring_mean_nm=mean("K_term_nm"),
            damping_mean_nm=mean("D_effective_nm"),model_accel_torque_deficit_rms_nm=phase_rms("reference_minus_prelimit_nm"),
            residual_current_torque_error_rms_nm=phase_rms("request_minus_instant_KtIq_nm"),
            sensor_speed_error_rms_rad_s=phase_rms("source_v_error_rad_s")))
write("reversal-trace",annotated)
write("reversal-phase",stats)
write("reversal-summary",overall)
write("reversal-ideal-feedback",ideals)
for row in overall:
    print(row,flush=True)
