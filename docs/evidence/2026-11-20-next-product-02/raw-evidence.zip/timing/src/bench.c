#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "foc_board.h"
#include "foc_serial.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define CHECK(expr)                                                   \
    do {                                                              \
        if (!(expr)) {                                                \
            fprintf(stderr, "%s:%d: %s\n", __FILE__, __LINE__, #expr); \
            return 1;                                                 \
        }                                                             \
    } while (0)

enum { WARM_US = 104000, END_US = 2104000, MAX_SAMPLES = 12000, REPEATS = 7 };

struct samples {
    LONGLONG ticks[MAX_SAMPLES];
    size_t size;
};

static struct samples h0, h1, fg, telemetry, serial_samples, adc_trigger;
static double tick_ns;

static LONGLONG tick(void)
{
    LARGE_INTEGER result;
    QueryPerformanceCounter(&result);
    return result.QuadPart;
}

static void record(struct samples *data, LONGLONG start, LONGLONG end)
{
    if (data->size == MAX_SAMPLES || end < start) {
        abort();
    }
    data->ticks[data->size++] = end - start;
}

static int compare(const void *a, const void *b)
{
    const LONGLONG left = *(const LONGLONG *)a;
    const LONGLONG right = *(const LONGLONG *)b;
    return (left > right) - (left < right);
}

static void print_stats(unsigned repeat, const char *scenario, const char *entry, struct samples *data)
{
    if (data->size == 0U) {
        abort();
    }
    qsort(data->ticks, data->size, sizeof data->ticks[0], compare);
    LONGLONG sum = 0;
    for (size_t i = 0; i < data->size; ++i) {
        sum += data->ticks[i];
    }
    const LONGLONG min = data->ticks[0];
    const LONGLONG p50 = data->ticks[(data->size - 1U) * 50U / 100U];
    const LONGLONG p95 = data->ticks[(data->size - 1U) * 95U / 100U];
    const LONGLONG p99 = data->ticks[(data->size - 1U) * 99U / 100U];
    const LONGLONG max = data->ticks[data->size - 1U];
    printf("%u,%s,%s,%zu,%.3f,%.1f,%.1f,%.1f,%.1f,%.1f\n",
           repeat, scenario, entry, data->size, tick_ns * (double)sum / (double)data->size,
           tick_ns * (double)min, tick_ns * (double)p50, tick_ns * (double)p95,
           tick_ns * (double)p99, tick_ns * (double)max);
    data->size = 0;
}

static struct foc_runtime_sensor sensor_at(uint32_t t, float speed)
{
    return (struct foc_runtime_sensor){
        .theta_elec_rad = 0.37f + (float)(t % 10000U) * 0.0004f,
        .captured_us = t, .seq = t / 500U + 1U, .valid = true,
        .mechanical_rad = 0.75f, .mechanical_rad_s = speed,
        .electrical_phase_valid = true, .mechanical_frame_id = 7U,
    };
}

static struct foc_runtime_fast_input adc_at(uint32_t t)
{
    return (struct foc_runtime_fast_input){
        .adc = {1200U, 2048U, 2048U, 2048U, FOC_DEVICE_SAMPLE_ALL_VALID, t / 200U + 1U, t},
        .now_us = t,
    };
}

static int request(struct foc_runtime *runtime, uint32_t t, enum foc_runtime_action action,
                   enum foc_runtime_mode mode)
{
    struct foc_runtime_snapshot view;
    CHECK(foc_runtime_read_snapshot(runtime, &view) == FOC_RUNTIME_OK);
    const struct foc_runtime_lifecycle_request event = {
        .action = action, .requested_mode = mode, .request_sequence = t / 200U,
        .source_session = view.motion_session, .produced_us = t - 1U,
    };
    CHECK(foc_runtime_publish_lifecycle_request(runtime, &event, t - 1U) == FOC_RUNTIME_OK);
    return 0;
}

static void host_configuration(struct foc_pipeline_config *pipeline, struct foc_runtime_config *policy)
{
    *pipeline = (struct foc_pipeline_config){
        .current = {{1.0f, 2.4f, 0.0f, 1.0f, 0.0006f}, {1.08f, 1.35f}, {540.0f, 540.0f}, 2.5f},
        .adc = {0.01f, 0.002f, 1.0f, 2048.0f, 2048.0f, 2048.0f, FOC_DEVICE_PHASE_ORDER_ABC},
        .pwm = {6000U, FOC_DEVICE_PHASE_ORDER_ABC},
        .safety = {2500U, 500U, 700U, 1000U, 5U},
    };
    *policy = (struct foc_runtime_config){
        .h0 = {200U, 150U, 100U}, .h1 = {500U, 150U, 150U},
        .supervision = {200U, 150U, 100U}, .telemetry = {10000U, 500U, 100U},
        .foreground_budget_us = 150U, .angle_timeout_us = 650U,
        .motion = {
            .enabled = true, .rotor = {4U, 0.37f}, .prediction = {650U, 2000.0f, 0.00065f},
            .velocity = {0.18f, 1.4f, 0.002f}, .position = {4.0f, 12.0f}, .iq_limit_a = 2.5f,
            .impedance = {
                .enabled = true, .mechanical_frame_id = 7U,
                .torque_constant_nm_per_a = 0.25f, .torque_limit_nm = 0.5f,
                .max_stiffness_nm_per_rad = 2.0f, .max_damping_nm_s_per_rad = 0.5f,
                .max_feedforward_nm = 0.4f,
            },
        },
    };
}

static int publish(struct foc_runtime *runtime, uint32_t t, enum foc_runtime_mode mode,
                   bool saturation)
{
    const uint32_t sequence = t / 1000U;
    const float sign = sequence % 2U == 0U ? -1.0f : 1.0f;
    if (mode == FOC_RUNTIME_MODE_CURRENT) {
        const struct foc_pipeline_command cmd = {
            {0.0f, saturation ? 2.5f : sign * 0.15f}, sequence, t - 1U,
        };
        CHECK(foc_runtime_publish_command(runtime, &cmd, t - 1U) == FOC_RUNTIME_OK);
    } else {
        struct foc_runtime_snapshot view;
        CHECK(foc_runtime_read_snapshot(runtime, &view) == FOC_RUNTIME_OK);
        struct foc_runtime_command cmd = {
            .mode = mode, .seq = sequence, .produced_us = t - 1U,
        };
        if (mode == FOC_RUNTIME_MODE_IMPEDANCE) {
            cmd.target.impedance = (struct foc_runtime_impedance_command){
                .position_rad = 0.75f, .velocity_rad_s = 0.0f,
                .stiffness_nm_per_rad = 0.50f, .damping_nm_s_per_rad = 0.25f,
                .mechanical_frame_id = 7U, .source_session = view.motion_session,
            };
            CHECK(foc_runtime_publish_impedance_command(runtime, &cmd, t - 1U) == FOC_RUNTIME_OK);
        } else {
            cmd.target.motion_ref = mode == FOC_RUNTIME_MODE_POSITION ? 0.75f + sign * 0.02f
                                                                     : sign * 0.08f;
            CHECK(foc_runtime_publish_motion_command(runtime, &cmd, t - 1U) == FOC_RUNTIME_OK);
        }
    }
    return 0;
}

static double applied_voltage(const struct foc_device_pwm_request *pwm)
{
    const double a = (double)pwm->duty_a;
    const double b = (double)pwm->duty_b;
    const double c = (double)pwm->duty_c;
    /* Clarke transform of duty times the fixture's 12 V bus. */
    return 8.0 * sqrt(a * a + b * b + c * c - a * b - b * c - c * a);
}

static int active(unsigned repeat, const char *scenario, enum foc_runtime_mode mode,
                  bool saturation, float cutoff)
{
    struct foc_pipeline_config pipeline;
    struct foc_runtime_config policy;
    host_configuration(&pipeline, &policy);
    policy.motion.impedance.damping_filter_hz = cutoff;
    struct foc_runtime runtime;
    CHECK(foc_runtime_init(&runtime, &pipeline, &policy, 0U) == FOC_RUNTIME_OK);
    double voltage_min = 12.0;
    double voltage_max = 0.0;
    uint32_t active_count = 0;
    for (uint32_t t = 0U; t < END_US; t += 100U) {
        if (t == 1000U && mode != FOC_RUNTIME_MODE_CURRENT) {
            CHECK(request(&runtime, t, FOC_RUNTIME_ACTION_SET_MODE, mode) == 0);
        }
        if (t >= 2000U && t % 1000U == 0U) {
            CHECK(publish(&runtime, t, mode, saturation) == 0);
            if (t == 2000U || t == 3000U) {
                CHECK(request(&runtime, t, t == 2000U ? FOC_RUNTIME_ACTION_ARM
                                                     : FOC_RUNTIME_ACTION_START, mode) == 0);
            }
        }
        if (t % 500U == 0U) {
            const float speed = mode == FOC_RUNTIME_MODE_IMPEDANCE
                ? (t % 2000U < 1000U ? 0.05f : -0.05f) : 0.0f;
            const struct foc_runtime_sensor sensor = sensor_at(t, speed);
            const LONGLONG start = tick();
            const int status = foc_runtime_h1_step(&runtime, &sensor, t, 0U);
            const LONGLONG end = tick();
            CHECK(status == FOC_RUNTIME_OK);
            if (t >= WARM_US) {
                record(&h1, start, end);
            }
        }
        if (t % 200U == 0U) {
            const struct foc_runtime_fast_input input = adc_at(t);
            const LONGLONG start = tick();
            const int status = foc_runtime_h0_step(&runtime, &input);
            const LONGLONG end = tick();
            CHECK(status == (t > 3000U ? FOC_RUNTIME_OK : FOC_RUNTIME_IDLE));
            if (t > 3000U) {
                ++active_count;
            }
            if (t >= WARM_US) {
                record(&h0, start, end);
                const double v = applied_voltage(&runtime.pipeline.mock.last_update);
                voltage_min = fmin(voltage_min, v);
                voltage_max = fmax(voltage_max, v);
            }
            struct foc_runtime_foreground_result result;
            const LONGLONG fg_start = tick();
            const int fg_status = foc_runtime_foreground_poll(&runtime, t, 0U, 0U, &result);
            const LONGLONG fg_end = tick();
            CHECK(fg_status == FOC_RUNTIME_OK && result.supervised);
            CHECK(result.telemetry_ready == (t % 10000U == 0U));
            if (t >= WARM_US) {
                record(result.telemetry_ready ? &telemetry : &fg, fg_start, fg_end);
            }
        }
    }
    struct foc_runtime_snapshot final;
    CHECK(foc_runtime_read_snapshot(&runtime, &final) == FOC_RUNTIME_OK);
    CHECK(final.state == FOC_SAFE_STATE_RUNNING && final.mode == mode && final.faults == 0U);
    CHECK(final.output_confirmed && final.updates == active_count);
    CHECK(mode == FOC_RUNTIME_MODE_CURRENT || final.accepted_outer_seen);
    CHECK(cutoff == 0.0f ||
          (runtime.damping_filter_seen && runtime.damping_speed_error_rad_s != 0.0f));
    fprintf(stderr, "%u,%s,updates=%u,voltage_min=%.6f,voltage_max=%.6f,damping_seen=%u\n",
            repeat, scenario, final.updates, voltage_min, voltage_max, (unsigned)runtime.damping_filter_seen);
    CHECK(saturation ? voltage_min > 2.395 && voltage_max <= 2.401 : voltage_max < 2.0);
    print_stats(repeat, scenario, "runtime_h0", &h0);
    print_stats(repeat, scenario, "runtime_h1", &h1);
    print_stats(repeat, scenario, "runtime_fg_supervision", &fg);
    print_stats(repeat, scenario, "runtime_fg_supervision_telemetry", &telemetry);
    return 0;
}

static struct foc_board_adc_event board_event(uint32_t t, bool rollover)
{
    return (struct foc_board_adc_event){
        .now_us = t, .before_us = t,
        .phase_ticks = t % FOC_BOARD_H0_US * (FOC_BOARD_TIMER_HZ / FOC_BOARD_US_HZ),
        .flags = rollover ? FOC_BOARD_SLOT_WRAP : 0U,
        .coherent = true,
    };
}

static int locked(unsigned repeat)
{
    const uint16_t ranks[] = {1241U, 2048U, 2048U, 2048U};
    for (uint32_t round = 0; round < 3000U; ++round) {
        struct foc_runtime runtime;
        struct foc_board_output output = {0};
        struct foc_board_adc adc = {0};
        struct foc_board_encoder encoder = {0};
        CHECK(foc_board_init(&runtime, &output, 0U) == FOC_RUNTIME_OK);
        CHECK(foc_board_adc_init_timing(&adc, 0U, 0U, 0U));
        const struct foc_pipeline_command command = {{0.1f, 0.5f}, 1U, 0U};
        CHECK(foc_runtime_publish_command(&runtime, &command, 0U) == FOC_RUNTIME_OK);
        for (uint32_t i = 0; i < 7U; ++i) {
            const uint32_t t = i * FOC_BOARD_H0_US + 80U;
            if (i == 0U || i == 3U || i == 5U) {
                const uint32_t capture = i == 0U ? 0U : (i == 3U ? 500U : 1000U);
                CHECK(foc_board_encoder_begin(&encoder, capture));
                const LONGLONG start = tick();
                const int encoder_status =
                    foc_board_encoder_complete(&runtime, &encoder, capture + 70U, FOC_BOARD_ENCODER_OK, 100U);
                const LONGLONG end = tick();
                CHECK(encoder_status == (i == 0U ? FOC_RUNTIME_ERR_INPUT : FOC_RUNTIME_OK));
                if (round >= 200U && i == 5U) {
                    record(&h1, start, end);
                }
            }
            if (i == 4U || i == 5U) {
                CHECK(request(&runtime, t, i == 4U ? FOC_RUNTIME_ACTION_ARM : FOC_RUNTIME_ACTION_START,
                              FOC_RUNTIME_MODE_CURRENT) == 0);
            }
            const struct foc_board_adc_event begin = board_event(t, i != 0U);
            const struct foc_board_adc_event complete = board_event(t + 8U, false);
            const LONGLONG start = tick();
            const bool triggered = foc_board_adc_begin(&runtime, &adc, &begin, false);
            foc_board_adc_publish(&adc);
            const LONGLONG triggered_at = tick();
            const int status = foc_board_adc_complete(&runtime, &adc, &output, ranks, 4U, &complete, true);
            foc_board_adc_publish(&adc);
            const LONGLONG end = tick();
            CHECK(triggered);
            if (i == 6U) {
                CHECK(status == FOC_RUNTIME_ERR_CONTROL && adc.live.transaction.update_declined);
                CHECK(!adc.live.transaction.update_accepted && !adc.live.transaction.physical_output_applied);
                if (round >= 200U) {
                    record(&adc_trigger, start, triggered_at);
                    record(&h0, triggered_at, end);
                }
            }
            struct foc_runtime_foreground_result fg_result;
            (void)foc_runtime_foreground_poll(&runtime, t + 9U, 0U, 0U, &fg_result);
        }
        CHECK(output.declined_updates == 1U && output.result == FOC_BOARD_INHIBIT_SOFTWARE);
        CHECK(runtime.pipeline.mock.updates == 0U && runtime.pipeline.current.integral_v.q == 0.0f);
    }
    print_stats(repeat, "locked", "board_adc_begin_publish", &adc_trigger);
    print_stats(repeat, "locked", "board_adc_complete_publish_declined", &h0);
    print_stats(repeat, "locked", "board_encoder_complete_valid", &h1);
    return 0;
}

static uint32_t now_callback(void *argument)
{
    return *(const uint32_t *)argument;
}

static int serial_frame(struct foc_serial *serial, struct foc_uart_buffer *uart, struct foc_runtime *runtime,
                        const struct foc_protocol_frame *request_frame, uint32_t t, bool measure)
{
    uint8_t bytes[FOC_PROTOCOL_WIRE_MAX];
    const size_t n = foc_protocol_encode(request_frame, bytes, sizeof bytes);
    CHECK(n && n <= FOC_SERIAL_RX_DEFAULT);
    for (size_t i = 0; i < n; ++i) {
        foc_uart_rx_push(uart, bytes[i], false);
    }
    const LONGLONG start = tick();
    foc_serial_poll(serial, uart, runtime, now_callback, &t);
    const LONGLONG end = tick();
    if (measure) {
        record(&serial_samples, start, end);
    }
    struct foc_protocol_stream parser = {0};
    struct foc_protocol_frame response;
    uint8_t byte;
    int status = FOC_PROTO_MORE;
    while (foc_uart_tx_pop(uart, &byte)) {
        status = foc_protocol_feed(&parser, byte, &response);
    }
    CHECK(status == FOC_PROTO_OK && response.type == request_frame->type);
    CHECK(response.sequence == request_frame->sequence &&
          (response.flags & FOC_PROTOCOL_RESPONSE) != 0U);
    return 0;
}

static int protocol(unsigned repeat)
{
    struct foc_runtime runtime;
    struct foc_board_output output = {0};
    struct foc_serial serial;
    struct foc_uart_buffer uart = {0};
    CHECK(foc_board_init(&runtime, &output, 0U) == FOC_RUNTIME_OK);
    foc_serial_init(&serial, &runtime);
    struct foc_protocol_frame frame = {
        .flags = FOC_PROTOCOL_REQUEST, .type = FOC_MSG_HELLO, .sequence = 1U,
    };
    CHECK(serial_frame(&serial, &uart, &runtime, &frame, 1U, false) == 0);
    frame.type = FOC_MSG_STATUS_READ;
    frame.session = serial.session;
    for (uint32_t i = 2U; i < 10202U; ++i) {
        frame.sequence = i;
        CHECK(serial_frame(&serial, &uart, &runtime, &frame, i * 1000U, i >= 202U) == 0);
    }
    print_stats(repeat, "locked", "v1_status_poll", &serial_samples);
    return 0;
}

static int limits(void)
{
    for (uint32_t excess = 0U; excess <= 1U; ++excess) {
        struct foc_pipeline_config pipeline;
        struct foc_runtime_config policy;
        struct foc_runtime runtime;
        host_configuration(&pipeline, &policy);
        CHECK(foc_runtime_init(&runtime, &pipeline, &policy, 0U) == FOC_RUNTIME_OK);
        const struct foc_runtime_sensor sample = sensor_at(0U, 0.0f);
        struct foc_runtime_fast_input input = adc_at(0U);
        CHECK(foc_runtime_h1_step(&runtime, &sample, 0U, 0U) == FOC_RUNTIME_OK);
        input.cost_us = 100U + excess;
        const int fast = foc_runtime_h0_step(&runtime, &input);
        CHECK(fast == (excess ? FOC_RUNTIME_ERR_TIMING : FOC_RUNTIME_IDLE));
        CHECK(runtime.h0.budget_count == excess);

        CHECK(foc_runtime_init(&runtime, &pipeline, &policy, 0U) == FOC_RUNTIME_OK);
        const int slow = foc_runtime_h1_step(&runtime, &sample, 0U, 150U + excess);
        CHECK(slow == (excess ? FOC_RUNTIME_ERR_TIMING : FOC_RUNTIME_OK));
        CHECK(runtime.h1.budget_count == excess);

        CHECK(foc_runtime_init(&runtime, &pipeline, &policy, 0U) == FOC_RUNTIME_OK);
        CHECK(foc_runtime_h1_step(&runtime, &sample, 0U, 0U) == FOC_RUNTIME_OK);
        input.cost_us = 0U;
        CHECK(foc_runtime_h0_step(&runtime, &input) == FOC_RUNTIME_IDLE);
        struct foc_runtime_foreground_result result;
        const int fg_status = foc_runtime_foreground_poll(&runtime, 0U, 100U, 50U + excess, &result);
        CHECK(fg_status == FOC_RUNTIME_OK && result.supervised && result.telemetry_ready == !excess);
        fprintf(stderr, "budget h0=%u/status=%d h1=%u/status=%d foreground=%u/telemetry=%u\n",
                100U + excess, fast, 150U + excess, slow, 150U + excess, (unsigned)result.telemetry_ready);

        CHECK(foc_runtime_init(&runtime, &pipeline, &policy, 0U) == FOC_RUNTIME_OK);
        CHECK(foc_runtime_h1_step(&runtime, &sample, 0U, 0U) == FOC_RUNTIME_OK);
        CHECK(foc_runtime_h0_step(&runtime, &input) == FOC_RUNTIME_IDLE);
        CHECK(foc_runtime_foreground_poll(&runtime, 0U, 100U + excess, 0U, &result) ==
              (excess ? FOC_RUNTIME_ERR_TIMING : FOC_RUNTIME_OK));
        CHECK(runtime.supervision.budget_count == excess && result.supervised == !excess);

        CHECK(foc_runtime_init(&runtime, &pipeline, &policy, 0U) == FOC_RUNTIME_OK);
        CHECK(foc_runtime_h1_step(&runtime, &sample, 0U, 0U) == FOC_RUNTIME_OK);
        CHECK(foc_runtime_h0_step(&runtime, &input) == FOC_RUNTIME_IDLE);
        CHECK(foc_runtime_foreground_poll(&runtime, 0U, 0U, 100U + excess, &result) == FOC_RUNTIME_OK);
        CHECK(runtime.telemetry.budget_count == excess && result.telemetry_ready == !excess);

        CHECK(foc_runtime_init(&runtime, &pipeline, &policy, 0U) == FOC_RUNTIME_OK);
        const uint32_t now = 150U + excess;
        const struct foc_runtime_sensor late_sensor = sensor_at(now, 0.0f);
        const int h1_late = foc_runtime_h1_step(&runtime, &late_sensor, now, 0U);
        CHECK(h1_late == (excess ? FOC_RUNTIME_ERR_TIMING : FOC_RUNTIME_OK));
        CHECK(runtime.h1.late_count == excess);

        CHECK(foc_runtime_init(&runtime, &pipeline, &policy, 0U) == FOC_RUNTIME_OK);
        CHECK(foc_runtime_h1_step(&runtime, &sample, 0U, 0U) == FOC_RUNTIME_OK);
        input = adc_at(now);
        const int h0_late = foc_runtime_h0_step(&runtime, &input);
        CHECK(h0_late == (excess ? FOC_RUNTIME_ERR_TIMING : FOC_RUNTIME_IDLE));
        CHECK(runtime.h0.late_count == excess);
        fprintf(stderr, "release_delay=%u/status_h0=%d/status_h1=%d fg_lane_cost=%u/accepted=%u\n",
                now, h0_late, h1_late, 100U + excess, (unsigned)!excess);
    }
    return 0;
}

int main(void)
{
    LARGE_INTEGER frequency;
    CHECK(QueryPerformanceFrequency(&frequency));
    tick_ns = 1.0e9 / (double)frequency.QuadPart;
    fprintf(stderr, "QPC frequency=%lld tick_ns=%.3f\n", frequency.QuadPart, tick_ns);
    CHECK(limits() == 0);
    puts("repeat,scenario,entry,samples,mean_ns,min_ns,p50_ns,p95_ns,p99_ns,max_ns");
    for (unsigned repeat = 0U; repeat < REPEATS; ++repeat) {
        for (unsigned i = 0U; i < 10000U; ++i) {
            const LONGLONG start = tick();
            const LONGLONG end = tick();
            record(&h0, start, end);
        }
        print_stats(repeat, "baseline", "qpc_pair", &h0);
        CHECK(active(repeat, "current", FOC_RUNTIME_MODE_CURRENT, false, 0.0f) == 0);
        CHECK(active(repeat, "current_saturated", FOC_RUNTIME_MODE_CURRENT, true, 0.0f) == 0);
        CHECK(active(repeat, "velocity", FOC_RUNTIME_MODE_VELOCITY, false, 0.0f) == 0);
        CHECK(active(repeat, "position", FOC_RUNTIME_MODE_POSITION, false, 0.0f) == 0);
        for (unsigned pass = 0U; pass < 2U; ++pass) {
            const bool filter = (repeat + pass) % 2U != 0U;
            CHECK(active(repeat, filter ? "impedance48" : "impedance0", FOC_RUNTIME_MODE_IMPEDANCE,
                         false, filter ? 48.0f : 0.0f) == 0);
        }
        CHECK(locked(repeat) == 0);
        CHECK(protocol(repeat) == 0);
    }
    return 0;
}
