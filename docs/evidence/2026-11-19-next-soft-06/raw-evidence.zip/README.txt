SOFT-06 verification. Fixture data and the stdout comparisons are Host only.
The patch applies to the pre-task dirty tree, excluding the zip itself.
For exact fixture bytes on Windows, apply with the bundled attributes file:
git -c core.attributesFile=ABSOLUTE_PATH_TO_EXTRACTED/git/fixture-byte-preservation.gitattributes apply --whitespace=error ABSOLUTE_PATH_TO_EXTRACTED/git/soft-06.patch
The mechanical Kt red test intentionally reproduces the pre-change contract.
