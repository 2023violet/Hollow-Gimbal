"""Instrument a disposable source copy for CQ-02 Current diagnostic observations."""

import shutil
import sys
from pathlib import Path


source, overlay = map(lambda path: Path(path).resolve(), sys.argv[1:])
if overlay.exists() or source in overlay.parents or overlay in source.parents:
    raise SystemExit("Provide a fresh, separate scratch overlay directory")

shutil.copytree(
    source, overlay,
    ignore=shutil.ignore_patterns(".git", "build", "docs", "__pycache__"),
)


def instrument(path, edits):
    path = overlay / path
    source = path.read_text(encoding="utf-8")
    include = source.index("#include")
    source = source[:include] + "#include <stdio.h>\n" + source[include:]
    for before, addition in edits:
        if source.count(before) != 1:
            raise ValueError(f"Unexpected tracing anchor in {path}: {before}")
        source = source.replace(before, addition + "\n" + before)
    path.write_text(source, encoding="utf-8")


instrument("runtime/src/foc_runtime.c", [
    (
        "    const int status =\n        foc_pipeline_step_guarded(pipeline, &step,",
        r'''    fprintf(stderr, "CQ02,INPUT,%u,%u,%u,%u,%u,%u,%u,%u,%u,%.9g,%.9g,%d,%u,%.9g\n",
            now_us, adc->sample_tick, adc->sample_seq, (unsigned)adc->vbus_raw,
            (unsigned)adc->rank2_raw, (unsigned)adc->rank3_raw, (unsigned)adc->rank4_raw,
            sensor.sample.captured_us, sensor.sample.seq, aligned, step.dt_s,
            pipeline->safety.state, pipeline->command.seq, sensor.electrical.angle_rad);'''
    ),
])

instrument("core/src/foc_current.c", [
    (
        "    result.output_enable = 1U;",
        r'''    fprintf(stderr, "CQ02,PI,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,"
            "%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%u,%u,%.9g\n",
            target.d, target.q, result.measured_dq_a.d, result.measured_dq_a.q,
            previous.d, previous.q, integral.d, integral.q, requested.d, requested.q,
            result.voltage_dq_v.d, result.voltage_dq_v.q,
            result.svpwm.saturated, result.target_limited, voltage_limit_v);'''
    ),
])

instrument("simulation/src/foc_virtual_current.c", [
    (
        "    (void)status;\n    return 0;",
        r'''    fprintf(stderr, "CQ02,H1,%u,%u,%u,%u,%.9g,%.9g,%d,%d,%d\n",
            context->virtual_time_us, sample.captured_us, sample.seq, (unsigned)raw_code,
            (double)sample.theta_elec_rad, (double)sample.mechanical_rad_s, status,
            sample.electrical_phase_valid, feedback.speed_valid);'''
    ),
    (
        "    foc_virtual_update_hash(context);",
        r'''    struct foc_runtime_lifecycle_result lifecycle = {0};
    (void)foc_virtual_current_read_lifecycle(context, &lifecycle);
    const struct foc_virtual_current_output *output = &context->output;
    fprintf(stderr, "CQ02,H0,%u,%u,%u,%u,%u,%u,%d,%d,%d,%d,%d,%d,%d,%d,%u,%u,%u,"
        "%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.9g,%.9g,%u,%u,%u,%.9g,%.9g,%.9g,%u\n",
        context->virtual_time_us, snapshot.trigger_us, snapshot.fast_us, snapshot.interval_us,
        snapshot.delay_us, snapshot.missed, status, snapshot.pipeline_status, snapshot.state,
        snapshot.action, snapshot.output_confirmed, snapshot.inhibit_pending,
        lifecycle.action, lifecycle.result, lifecycle.h0_us, output->accepted_updates,
        output->rejected_updates, context->motor.state.id_a, context->motor.state.iq_a,
        context->motor.state.mechanical_position_rad, context->motor.state.mechanical_velocity_rad_s,
        context->motor.params.electrical_offset_rad + (double)context->motor.params.pole_pairs *
            context->motor.state.mechanical_position_rad,
        output->v_alpha_v, output->v_beta_v, context->runtime.pipeline.current.integral_v.d,
        context->runtime.pipeline.current.integral_v.q,
        snapshot.compare[0], snapshot.compare[1], snapshot.compare[2],
        output->request.duty_a, output->request.duty_b, output->request.duty_c,
        snapshot.faults);'''
    ),
    (
        "    context->initialized = true;",
        r'''    fprintf(stderr, "CQ02,CONFIG,%.12g,%.12g,%.12g,%.12g,%u,%.12g,%.12g,%.12g,"
            "%.12g,%.12g,%.12g,%.12g,%.12g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%u,%u,%u,"
            "%.9g,%.9g,%.9g,%.9g,%u,%u,%u,%.9g,%u,%u,%.9g,%.9g,%.9g,%d\n",
        profile->motor.rs_ohm, profile->motor.ld_h, profile->motor.lq_h, profile->motor.psi_f_wb,
        profile->motor.pole_pairs, profile->motor.electrical_offset_rad,
        profile->motor.inertia_kg_m2, profile->motor.damping_nm_s,
        profile->initial_state.id_a, profile->initial_state.iq_a,
        profile->initial_state.mechanical_position_rad, profile->initial_state.mechanical_velocity_rad_s,
        profile->load_torque_nm, profile->vbus_v,
        profile->current.kp_v_per_a.d, profile->current.kp_v_per_a.q,
        profile->current.ki_v_per_a_s.d, profile->current.ki_v_per_a_s.q,
        profile->current.current_limit_a, profile->current.pwm.voltage_limit_v,
        profile->current.pwm.vbus_min_v, profile->runtime.h0.period_us,
        profile->runtime.h1.period_us, profile->runtime.supervision.period_us,
        profile->adc.current_a_per_count, profile->adc.phase_a_offset_count,
        profile->adc.phase_b_offset_count, profile->adc.phase_c_offset_count,
        profile->adc_noise_counts, profile->encoder.counts_per_revolution, profile->pwm.period_counts,
        profile->encoder.speed_lpf_cutoff_hz,
        profile->runtime.motion.prediction.max_prediction_us, profile->runtime.angle_timeout_us,
        profile->runtime.motion.rotor.electrical_offset_rad, profile->current.pwm.max_dt_s,
        profile->runtime.motion.iq_limit_a, context->runtime.pipeline.feedforward.enabled);'''
    ),
])

instrument("simulation/src/falconfoc_virtual_device.c", [
    (
        "        if (!device->load_applied && device->load_on_us != 0U",
        r'''        const struct foc_virtual_motor *motor = &device->current.motor;
        const struct foc_virtual_current_output *output = &device->current.output;
        fprintf(stderr, "CQ02,PLANT,%u,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%d,%u,%u\n",
            next_us, motor->state.id_a, motor->state.iq_a, motor->state.mechanical_position_rad,
            motor->state.mechanical_velocity_rad_s,
            motor->params.electrical_offset_rad + (double)motor->params.pole_pairs *
                motor->state.mechanical_position_rad, output->v_alpha_v, output->v_beta_v,
            output->mode, output->accepted_updates, device->current.fault_events.last_accepted_update_us);'''
    ),
])


