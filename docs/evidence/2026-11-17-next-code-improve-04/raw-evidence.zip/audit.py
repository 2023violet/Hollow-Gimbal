import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys,types

OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('D:/study/Software/Hollow-Gimbal-vm01a')
SRC=OUT/'snapshot'
DEV=pathlib.Path('D:/study/Software/FalconFOC-code-improve-02b-20261116')
CC='C:/Program Files/LLVM/bin/clang.exe'
ARM=pathlib.Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.3 rel1/bin')
ENV=os.environ.copy()
ENV['PYTHONIOENCODING']='utf-8'
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
ENV['PATH']='C:/Program Files/LLVM/lib/clang/22/lib/windows;D:/Git/usr/bin;D:/Git/bin;'+str(ARM)+';'+ENV['PATH']
ENV['PYTHONPYCACHEPREFIX']=str(OUT/'python-cache')
before=json.loads((OUT/'source-before.json').read_text(encoding='utf-8'))

def run(dest,name,args,expected=0,env=None,cwd=None,input_path=None):
    dest.mkdir(parents=True,exist_ok=True)
    log=dest/(name+'.log');assert not log.exists(),str(log)
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with open(input_path,encoding='ascii') if input_path else open(os.devnull) as stream:
        p=subprocess.run([str(a) for a in args],cwd=cwd or dest,env=env or ENV,capture_output=True,
                         text=True,encoding='utf-8',errors='replace',stdin=stream)
    log.write_bytes((p.stdout+p.stderr).encode('utf-8'))
    record={'name':name,'command':[str(a) for a in args],'cwd':str(cwd or dest),'exit':p.returncode,
            'expected_exit':expected,'started_utc':started,
            'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    with (dest/'commands.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(record)+'\n')
    print(name,'exit=',p.returncode,'expected=',expected,flush=True)
    print('\n'.join(line[:350] for line in (p.stdout+p.stderr).splitlines()[-12:]),flush=True)
    assert p.returncode in expected if isinstance(expected,list) else p.returncode==expected,str(log)
    return p

def copy_source(destination):
    for name in before:
        target=destination/name;target.parent.mkdir(parents=True,exist_ok=True)
        assert not target.exists() or target.read_bytes()==(SRC/name).read_bytes(),str(target)
        shutil.copy2(SRC/name,target)
    return destination

def regression(lane):
    dest=OUT/'tests'/lane;assert not dest.exists()
    source=copy_source(dest/'source')
    project=lane.split('-')[0]
    env=ENV.copy()
    if project=='board':
        project='firmware/at32f415'
        (source/'build/vm01a-simulation').mkdir(parents=True,exist_ok=False)
        env['FOC_VIRTUAL_DEVICE']=str(OUT/'tests/simulation/build/falconfoc-virtual-device.exe')
    args=['cmake','-S',source/project,'-B',dest/'build','-G','Ninja',
          '-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+CC]
    if lane.endswith('asan'):
        args+=['-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer',
               '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    run(dest,'configure',args,env=env)
    run(dest,'build',['cmake','--build',dest/'build','--parallel','4'],env=env)
    run(dest,'ctest',['ctest','--test-dir',dest/'build','--output-on-failure'],env=env)

if __name__=='__main__':regression(sys.argv[1])
