from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess as sp
import sys
import tarfile

evidence = Path(__file__).resolve().parent
repo = Path.cwd()
source = evidence / "FalconFOC Source"
consumer = evidence / "External Config Store Consumer"
source.mkdir()
consumer.mkdir()

head = sp.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
archive_path = evidence / "baseline.tar"
sp.run(["git", "archive", "--format=tar", "--output", archive_path, head], check=True)
with tarfile.open(archive_path) as archive:
    archive.extractall(source, filter="data")

manifest = {}
changed = sp.check_output(["git", "status", "--porcelain=v1", "-z", "-uall"]).decode("utf-8")
source_roots = ("core/", "runtime/", "simulation/", "control_plane/", "calibration/", "sensors/",
                "g3/", "components/utils/crc/", "protocol/")
for entry in changed.strip("\0").split("\0"):
    name = entry[3:]
    if name.startswith(source_roots):
        target = source / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / name, target)
        manifest[name] = sha256(target.read_bytes()).hexdigest()

demo_files = ("CMakeLists.txt", "README.md", "config_store.c", "main.c")
for name in demo_files:
    target = consumer / name
    shutil.copyfile(repo / "examples/parameters" / name, target)
    manifest[f"examples/parameters/{name}"] = sha256(target.read_bytes()).hexdigest()

assert not (source / ".git").exists() and not (consumer / ".git").exists()
assert not (source / "examples/parameters").exists()
(evidence / "source-snapshot.json").write_text(json.dumps({"head": head, "overlay_sha256": manifest},
                                                         indent=2, sort_keys=True) + "\n",
                                                encoding="utf-8")

env = os.environ.copy()
clang_resource = Path(sp.check_output(["clang", "-print-resource-dir"], text=True).strip())
env["PATH"] = os.pathsep.join([r"C:\mingw64\bin", str(clang_resource / "lib/windows"), env["PATH"]])
env.update(ASAN_OPTIONS="halt_on_error=1", UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1",
           PYTHONDONTWRITEBYTECODE="1")

target = "falconfoc-config-store-demo"
test = "test-falconfoc-config-store-demo"

def run_variant(variant, compiler):
    build = evidence / f"Build {variant}"
    flags = ["-G", "Ninja", "-DCMAKE_BUILD_TYPE=Debug", f"-DCMAKE_C_COMPILER={compiler}",
             "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON", f"-DFALCONFOC_SOURCE_DIR={source}"]
    if variant == "clang-asan-ubsan":
        flags += ["-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
                  "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined"]
    commands = [
        [compiler, "--version"],
        ["cmake", "-S", consumer, "-B", build, *flags],
        ["cmake", "--build", build, "--target", target, "--parallel", "4", "--verbose"],
        ["ctest", "--test-dir", build, "-R", f"^{test}$", "--no-tests=error", "--output-on-failure"],
        [build / f"{target}.exe"],
    ]
    runtime_log = evidence / f"{variant}-demo.txt"
    with (evidence / f"{variant}.log").open("w", encoding="utf-8") as log:
        print(f"FalconFOC source SHA: {head}\nSource snapshot: {source}\nConsumer: {consumer}", file=log)
        for command in commands:
            print("$ " + sp.list2cmdline(list(map(str, command))), file=log, flush=True)
            if command == commands[-1]:
                completed = sp.run(command, cwd=evidence, env=env, stdout=sp.PIPE, stderr=sp.STDOUT)
                runtime_log.write_bytes(completed.stdout)
                log.write(completed.stdout.decode("ascii"))
                status = completed.returncode
            else:
                status = sp.run(command, cwd=evidence, env=env, stdout=log, stderr=sp.STDOUT).returncode
            print(f"exit={status}", file=log, flush=True)
            if status:
                print(f"{variant}: exit {status}", flush=True)
                return status

        units = json.loads((build / "compile_commands.json").read_text(encoding="utf-8"))
        paths = {Path(unit["file"]).resolve() for unit in units}
        assert all(path.is_relative_to(source) or path.is_relative_to(consumer) for path in paths), paths
        assert (consumer / "config_store.c") in paths
        assert all(source / "control_plane/src" / name in paths for name in
                   ("foc_config_codec.c", "foc_config_store.c", "foc_config_store_host.c"))
        print("Consumer and production compile units resolve to the two isolated directories.", file=log)
        dependency_dump = sp.check_output(["ninja", "-C", build, "-t", "deps"], env=env, text=True)
        headers = {"foc_config_store.h", "foc_config_store_host.h", "foc_parameter.h",
                   "foc_virtual_current.h", "foc_runtime.h"}
        seen = {(build / line.strip()).resolve() for line in dependency_dump.splitlines()
                if line.startswith("    ") and Path(line.strip()).name in headers}
        assert {path.name for path in seen} == headers and all(path.is_relative_to(source) for path in seen), seen
        print("Public header dependency paths resolve inside the isolated source tree.", file=log)
    print(f"{variant}: PASS", flush=True)
    return 0

variants = (("clang", "clang"), ("gcc", "C:/mingw64/bin/gcc.exe"), ("clang-asan-ubsan", "clang"))
with ThreadPoolExecutor(max_workers=3) as pool:
    outcomes = list(pool.map(lambda variant: run_variant(*variant), variants))
if any(outcomes):
    sys.exit(1)
outputs = [(evidence / f"{variant}-demo.txt").read_bytes() for variant, _ in variants]
assert outputs[0] == outputs[1] == outputs[2]
assert all(sha256((repo / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
print(f"All three demo outputs byte-identical, SHA-256 {sha256(outputs[0]).hexdigest()}")
