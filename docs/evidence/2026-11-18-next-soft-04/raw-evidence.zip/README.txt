NEXT-SOFT-04 software evidence. CLI images are Host fixtures.
The patch applies to the pre-task snapshot including SOFT-01/02/03.
It excludes the archive itself.
