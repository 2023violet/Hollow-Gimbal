[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourceRepo,

    [Parameter(Mandatory = $true)]
    [string]$Cq02LoadArchive,

    [Parameter(Mandatory = $true)]
    [string]$OutputDirectory
)

$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path -LiteralPath $SourceRepo).Path
$priorZip = (Resolve-Path -LiteralPath $Cq02LoadArchive).Path
$driver = Join-Path $PSScriptRoot 'driver'
$reference = Join-Path $driver 'frozen-cq01'
$out = (New-Item -ItemType Directory -Path $OutputDirectory -Force).FullName
$prior = Join-Path $out 'prior'
$build = Join-Path $out 'build'

function Invoke-Checked {
    param([string]$Name, [string[]]$Arguments, [string]$Log)
    & $Name @Arguments | Tee-Object -FilePath (Join-Path $out $Log)
    if ($LASTEXITCODE -ne 0) {
        throw "$Name returned $LASTEXITCODE while writing $Log"
    }
}

Expand-Archive -LiteralPath $priorZip -DestinationPath $prior -Force
Invoke-Checked 'cmake' @('-S', $driver, '-B', $build, '-G', 'Ninja',
    '-DCMAKE_C_COMPILER=clang', "-DSOURCE_REPO=$repo", "-DHISTORICAL_REPO=$reference",
    '-DCQ02_FILTER_CONFIG=ON') 'configure.log'
Invoke-Checked 'cmake' @('--build', $build, '--target', 'cq02-load') 'build.log'
$target = Join-Path $build 'cq02-load.exe'
foreach ($item in @(@{Name='disabled'; Hz='0'}, @{Name='candidate'; Hz='48'})) {
    $name = $item.Name
    Invoke-Checked $target @($item.Hz, (Join-Path $out "$name-h0.csv"),
        (Join-Path $out "$name-h1.csv")) "$name-study.log"
}
Invoke-Checked 'python' @('-B', (Join-Path $driver 'analyze_cq03.py'),
    $out, $prior, (Join-Path $out 'independent-load-summary.json')) 'analysis.log'

