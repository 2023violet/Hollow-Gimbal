from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os, subprocess as sp,sys
t=Path(__file__).resolve().parent
env=os.environ.copy()
env["PATH"]=os.pathsep.join([r"C:\mingw64\bin",str(Path(sp.check_output(["clang","-print-resource-dir"],text=True).strip())/"lib/windows"),env["PATH"]])
env.update(ASAN_OPTIONS="halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1",PYTHONDONTWRITEBYTECODE="1")
logs=t/"final-logs"
logs.mkdir(exist_ok=True)
def run(job):
    project,variant=job
    compiler="C:/mingw64/bin/gcc.exe" if variant=="gcc" else "clang"
    out=t/f"final-{project}-{variant}"
    flags=["-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
           "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined"] if variant=="asan" else []
    targets=["test-foc-parameter","test-foc-config-codec","test-foc-config-store",
             "test-foc-config-diagnostics","test-foc-calibration-application"] if project=="control_plane" else []
    selection=["-R",r"^test-foc-(parameter|config-(codec|store|diagnostics)|calibration-application)$"] if targets else []
    commands=[[compiler,"--version"],["cmake","-S",project,"-B",out,"-G","Ninja",
             "-DCMAKE_BUILD_TYPE=Debug","-DCMAKE_C_COMPILER="+compiler,*flags],
             ["cmake","--build",out,"--parallel","4",*(["--target",*targets] if targets else [])],
             ["ctest","--test-dir",out,"--no-tests=error","--output-on-failure",*selection]]
    executable=(out/"test-foc-calibration-application.exe" if targets else out/"test-foc-calibration-workflow.exe")
    commands+=[[executable]]
    path=logs/f"{project}-{variant}.log"
    with path.open("w",encoding="utf8") as f:
        for command in commands:
            print("$ "+sp.list2cmdline(list(map(str,command))),file=f,flush=True)
            rc=sp.run(command,env=env,stdout=f,stderr=sp.STDOUT).returncode
            print(f"exit={rc}",file=f,flush=True)
            if rc:
                break
    results=[s for s in path.read_text(encoding="utf8",errors="replace").splitlines() if "tests passed out of" in s]
    print(project,variant,rc,*results,flush=True)
    return rc
with ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,[(p,v) for p in ("calibration","control_plane") for v in ("clang","gcc","asan")]))
sys.exit(int(any(results)))
