"""Check CQ-03 fixed comparisons and retain full per-case Current metrics."""
import argparse
from collections import defaultdict
import csv
from itertools import groupby
import json
import math
from pathlib import Path

DWELL_US = 2000
BAND_A = 0.04
H0_US = 200
HOLDOUT_US = 200
HOLDOUT_A = 0.02
NEGATIVE = ("stop", "stale_command", "stale_h1", "sensor_fault", "reject_first")

def rows_from(path):
    with path.open(newline="", encoding="utf-8-sig") as source:
        return list(csv.DictReader(source))

def ints(rows, name):
    return [int(row[name]) for row in rows]

def col(row, name):
    return float(row[name])

def metrics(rows, origin):
    elapsed = [int(row["h0_us"]) - origin for row in rows]
    errors = [col(row, "iq_plant_a") - col(row, "iq_ref_a") for row in rows]
    first = next((when for when, error in zip(elapsed, errors) if abs(error) <= BAND_A), None)
    count = DWELL_US // H0_US + 1
    dwell = next((elapsed[i] for i in range(len(rows) - count + 1)
                  if elapsed[i + count - 1] - elapsed[i] == DWELL_US
                  and all(abs(error) <= BAND_A for error in errors[i:i + count])), None)
    longest = current = 0
    for _, grouped in groupby(errors, key=lambda error: abs(error) <= BAND_A):
        items = list(grouped)
        if abs(items[0]) <= BAND_A:
            current = (len(items) - 1) * H0_US
            longest = max(longest, current)
    tail = errors[len(errors) * 3 // 4:]
    direction = math.copysign(1.0, col(rows[0], "iq_ref_a"))
    saturation = ints(rows, "saturated")
    return {
        "first_entry_us": first,
        "dwell_entry_us": dwell,
        "longest_dwell_us": longest,
        "running_rms_a": math.sqrt(math.fsum(e*e for e in errors) / len(errors)),
        "max_abs_error_a": max(map(abs, errors)),
        "overshoot_a": max(0.0, *(direction*error for error in errors)),
        "tail_bias_a": math.fsum(tail) / len(tail),
        "tail_rms_a": math.sqrt(math.fsum(e*e for e in tail) / len(tail)),
        "cycles": len(rows),
        "saturated_h0": sum(saturation),
        "saturated_duration_us": sum(saturation) * H0_US,
        "near_cap_h0": sum(ints(rows, "near_voltage_cap")),
        "first_no_saturation_us": next((t for t, sat in zip(elapsed, saturation) if not sat), None),
        "max_voltage_v": max(math.hypot(col(row, "vd_v"), col(row, "vq_v")) for row in rows),
        "first_vq_v": col(rows[0], "vq_v"),
        "first_integral_v": col(rows[0], "iq_integral_v"),
        "last_integral_v": col(rows[-1], "iq_integral_v"),
        "first_plant_speed_rad_s": col(rows[0], "shaft_speed_rad_s"),
        "first_encoder_speed_rad_s": col(rows[0], "encoder_speed_rad_s"),
    }

def negative_check(name, rows, journal, update_rows):
    stop = next(row for row in rows if int(row["elapsed_us"]) >= 200 and
                int(row["safety_state"]) != 3)
    active_end_us = int(update_rows[-1]["h0_us"]) if update_rows else 0
    clear = (journal["end_high_z"] and journal["end_confirmed"]
             and not any(int(row["update_applied"]) for row in rows[rows.index(stop):]))
    integral, target = col(stop, "iq_integral_v"), col(stop, "target_history_q_a")
    if name.startswith("reject_first"):
        authority = (journal["rejected"] == 1 and not update_rows
                     and integral == 0 and target == 0)
    elif name.startswith("stop"):
        authority = (active_end_us == journal["injection_us"] and journal["end_state"] == 1
                     and journal["end_fault"] == 0)
    elif name.startswith("stale_command"):
        authority = active_end_us < 1800 + 2500 and journal["end_state"] == 4
    elif name.startswith("stale_h1"):
        authority = active_end_us < journal["injection_us"] + 600 and journal["end_state"] != 3
    else:
        authority = (active_end_us < journal["inhibit_accepted_us"]
                     and active_end_us < journal["sensor_failure_us"] + H0_US
                     and journal["end_state"] == 4)
    return {
        "passed": clear and authority,
        "first_disabled_or_fault_us": int(stop["h0_us"]),
        "pipeline_reason": int(stop["reason"]),
        "active_end_us": active_end_us,
        "uncommitted_integral_v": integral,
        "uncommitted_target_a": target,
        **journal,
    }

def parse_profile(csv_path, json_path):
    rows = defaultdict(list)
    for row in rows_from(csv_path):
        rows[row["scenario"], row["group"]].append(row)
    with json_path.open(encoding="utf-8-sig") as source:
        journal = [json.loads(line) for line in source]
    scenario = {(rec["scenario"], rec["group"]): rec for rec in journal
                if rec.get("record") == "scenario"}
    outcome = {(rec["scenario"], rec["group"]): rec for rec in journal
               if rec.get("record") == "outcome"}
    cases = defaultdict(dict)
    assert rows and rows.keys() == scenario.keys() == outcome.keys()
    for (name, group), timeline in rows.items():
        updates = [row for row in timeline if row["update_applied"] == "1"
                   and row["safety_state"] == "3" and row["output_confirmed"] == "1"]
        assert all(row["sample_us"] == row["h0_us"] for row in updates)
        info = {"scenario": scenario[name, group], "outcome": outcome[name, group]}
        first_update = int(updates[0]["h0_us"]) if updates else None
        info["first_update_us"], info["first_sample_used_us"] = first_update, first_update
        if name.startswith(NEGATIVE):
            info["negative_check"] = negative_check(name, timeline, outcome[name, group], updates)
        else:
            assert len(updates) == 300
            assert outcome[name, group]["last_update_us"] == 61800
            assert outcome[name, group]["end_high_z"] and outcome[name, group]["end_confirmed"]
            assert outcome[name, group]["end_state"] == 1 and outcome[name, group]["end_fault"] == 0
            assert outcome[name, group]["end_updates"] == outcome[name, group]["updates"]
            assert all(abs(col(row, "iq_ref_a")) <= col(row, "current_limit_a") for row in updates)
            startup = [row for row in updates if int(row["elapsed_us"]) <= 20000]
            reversal = [row for row in updates if int(row["elapsed_us"]) > 20000]
            info["cold"] = metrics(startup, first_update)
            info["step"] = metrics(reversal, scenario[name, group]["command2_us"])
        cases[name][group] = info
    return {"cases": cases, "invalid_admission": [
        rec for rec in journal if rec.get("record") == "invalid_admission"],
        "review_id": next(rec["review_id"] for rec in journal if rec.get("event") == "CANDIDATE_REVIEWED")}

def compare(number, label, cases):
    failed = []
    for name, variants in cases.items():
        base, candidate = variants["A"], variants[label]
        assert all(base["scenario"][k] == candidate["scenario"][k]
                   for k in base["scenario"] if k != "group")
        lhs, rhs = base["first_update_us"], candidate["first_update_us"]
        if lhs != rhs:
            failed.append((name, "first_update_us", lhs, rhs))
        if "negative_check" in base:
            a, b = base["negative_check"], candidate["negative_check"]
            safety_fields = ("end_fault", "end_state", "active_end_us", "first_disabled_or_fault_us")
            if not a["passed"] or not b["passed"] or any(a[k] != b[k] for k in safety_fields):
                failed.append((name, "negative_check", a, b))
            continue
        for part in ("cold", "step"):
            a, b = base[part], candidate[part]
            metric = "dwell_entry_us"
            if name.startswith("nominal") and part == "cold":
                if a[metric] is None or b[metric] is None or a[metric] - b[metric] < H0_US:
                    failed.append((name, f"{part}.{metric}.required_gain", a[metric], b[metric]))
            for metric in ("first_entry_us", "dwell_entry_us", "first_no_saturation_us"):
                if a[metric] is not None and (b[metric] is None or b[metric] > a[metric] + HOLDOUT_US):
                    failed.append((name, f"{part}.{metric}", a[metric], b[metric]))
            for metric in ("overshoot_a", "running_rms_a"):
                if b[metric] > a[metric] + HOLDOUT_A:
                    failed.append((name, f"{part}.{metric}", a[metric], b[metric]))
            if name.startswith("nominal") and b["saturated_h0"] > a["saturated_h0"]:
                failed.append((name, f"{part}.saturated_h0", a["saturated_h0"], b["saturated_h0"]))
    return failed

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path)
    parser.add_argument("run")
    args = parser.parse_args()
    results = {}
    for profile in ("GENERIC_RESEARCH_MOTOR", "CALIBRATION_SALIENT_MOTOR"):
        stem = args.path / f"{args.run}-{profile}"
        parsed = parse_profile(stem.with_suffix(".csv"), stem.with_suffix(".jsonl"))
        groups = sorted(parsed["cases"]["nominal_pos"])
        parsed["production_gate_failures"] = {
            group: compare(profile, group, parsed["cases"]) for group in groups if group != "A"
        }
        results[profile] = parsed
        print(profile, parsed["review_id"])
        for key in ("nominal_pos", "nominal_neg", "small_pos", "small_neg", "restricted_pos",
                    "positive_spin_pos", "negative_spin_pos"):
            values = parsed["cases"][key]
            for part in ("cold", "step"):
                print(key, part, [
                    [group, m["first_entry_us"], m["dwell_entry_us"], m["saturated_h0"],
                     round(m["running_rms_a"], 5), round(m["overshoot_a"], 5),
                     round(m["first_vq_v"], 5)]
                    for group in groups for m in (values[group][part],)])
        for group in groups:
            print(group, [(name, values[group]["negative_check"]["passed"])
                          for name, values in parsed["cases"].items() if name.startswith(NEGATIVE)])
        for group, failures in parsed["production_gate_failures"].items():
            print(group, "REJECT" if failures else "PASS", failures)
    (args.path / f"{args.run}-metrics.json").write_text(json.dumps(results, indent=2) + "\n",
                                                         encoding="utf-8")

if __name__ == "__main__":
    main()
