NEXT-SOFT-02 software evidence
The patch applies to a pre-task working snapshot, including SOFT-01's existing local files.
The patch excludes the archive itself. Runtime/Host/static evidence only.
