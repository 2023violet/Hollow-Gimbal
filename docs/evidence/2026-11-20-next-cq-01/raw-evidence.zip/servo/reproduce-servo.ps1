param(
    [Parameter(Mandatory = $true)][string]$RepoRoot,
    [string]$BuildPath = (Join-Path $env:TEMP 'falconfoc-cq01-servo-replay'),
    [string]$EvidencePath = (Join-Path $env:TEMP 'falconfoc-cq01-servo-replay-evidence'),
    [string]$ClangPath = 'C:/Program Files/LLVM/bin/clang.exe'
)
$ErrorActionPreference = 'Stop'
$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
New-Item -ItemType Directory -Force -Path $BuildPath | Out-Null
Get-Date -Format o | Set-Content -Encoding UTF8 (Join-Path $BuildPath 'started.txt')

cmake -S (Join-Path $RepoRoot 'simulation') -B $BuildPath -G Ninja "-DCMAKE_C_COMPILER=$ClangPath" '-DCMAKE_BUILD_TYPE=Debug' *> (Join-Path $BuildPath 'configure.log')
if ($LASTEXITCODE -ne 0) { throw 'Servo baseline configuration failed' }
cmake --build $BuildPath --target test-foc-impedance-robustness *> (Join-Path $BuildPath 'build.log')
if ($LASTEXITCODE -ne 0) { throw 'Servo baseline build failed' }

$Exe = Join-Path $BuildPath 'test-foc-impedance-robustness.exe'
& $Exe | Set-Content -Encoding ascii (Join-Path $BuildPath 'historical-servo-holdout.log')
if ($LASTEXITCODE -ne 0) { throw 'Frozen Servo baseline execution failed' }
& $Exe --trace | Set-Content -Encoding ascii (Join-Path $BuildPath 'historical-servo-holdout-trace.log')
if ($LASTEXITCODE -ne 0) { throw 'Frozen Servo baseline trace failed' }
Get-Date -Format o | Set-Content -Encoding UTF8 (Join-Path $BuildPath 'ended.txt')
ctest --test-dir $BuildPath -R '^test-foc-impedance-(robustness|damping-noise|motion-feedforward|motion-reference-probe|joint-characterization|joint-holdout)$' --output-on-failure *> (Join-Path $BuildPath 'servo-ctest.log')
if ($LASTEXITCODE -ne 0) { throw 'Servo CTest regression failed' }
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'reproduce-servo-probes.py') -Destination $BuildPath
python (Join-Path $BuildPath 'reproduce-servo-probes.py') $RepoRoot $BuildPath
if ($LASTEXITCODE -ne 0) { throw 'Servo probe execution failed' }
python (Join-Path $PSScriptRoot 'collect-servo-evidence.py') $RepoRoot $BuildPath $EvidencePath
if ($LASTEXITCODE -ne 0) { throw 'Servo evidence collection failed' }

