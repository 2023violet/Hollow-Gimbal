#include "foc_parameter.h"
char runtime_bytes[sizeof(struct foc_runtime)];
char policy_bytes[sizeof(struct foc_runtime_config)];
char snapshot_bytes[sizeof(struct foc_runtime_snapshot)];
char sensor_slot_bytes[sizeof(struct foc_runtime_sensor_slot)];
char descriptor_bytes[sizeof(struct foc_parameter_descriptor)];
