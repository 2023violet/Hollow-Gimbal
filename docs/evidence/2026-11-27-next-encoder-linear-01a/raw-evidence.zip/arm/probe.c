#include "foc_encoder.h"
const unsigned char encoder_context_size[sizeof(struct foc_encoder_context)] = {0};
const unsigned char encoder_config_size[sizeof(struct foc_encoder_config)] = {0};
const unsigned char encoder_feedback_size[sizeof(struct foc_encoder_feedback)] = {0};
#if WITH_LUT
const unsigned char encoder_lut_size[sizeof(struct foc_encoder_lut)] = {0};
#endif
