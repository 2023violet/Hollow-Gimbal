#include "foc_impedance.h"
int foc_impedance_step(const struct foc_impedance_config *config,
                       const struct foc_impedance_input *input,
                       struct foc_impedance_output *output)
{
    (void)config;
    (void)input;
    *output = (struct foc_impedance_output){0};
    return FOC_STATUS_OK;
}

