#include "foc_damping_noise_filter.h"
#include "foc_impedance_feasibility.h"
#include "foc_runtime.h"
const char filter_bytes[sizeof(struct damping_noise_filter)] = {0};
const char runtime_bytes[sizeof(struct foc_runtime)] = {0};
const char feas_input_bytes[sizeof(struct foc_impedance_feasibility_input)] = {0};
const char feas_result_bytes[sizeof(struct foc_impedance_feasibility_result)] = {0};
bool isolated_trial(struct damping_noise_filter *state, float velocity_rad_s, float cutoff_hz, uint32_t dt_us)
{
    return damping_noise_filter_step(state, velocity_rad_s, cutoff_hz, dt_us);
}
