
from pathlib import Path
from zipfile import ZipFile
from collections import defaultdict
import csv, sys
root=Path(__file__).parent
sys.path.insert(0,str(Path(r"C:/Users/16429/AppData/Local/Temp/servo01a_1794995524571")/"plot-deps"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def group(source):
    buckets=defaultdict(list)
    for row in csv.DictReader(source):
        buckets[row["scenario"]].append(row)
    return buckets
with (root/"data/trace.csv").open(newline="") as f:
    new=group(f)
with ZipFile("docs/evidence/2026-11-18-next-servo-01a/raw-evidence.zip") as archive:
    old=group(archive.read("data/trace.csv").decode().splitlines())
fig, axes=plt.subplots(3,1,figsize=(9.4,8.3),layout="constrained")
fig.suptitle("FalconFOC | Runtime IMPEDANCE holdout",fontsize=17)
for axis in axes:
    axis.grid(True,alpha=.23)
    axis.set_xlabel("Time from reference step (s)")
    axis.spines[["top","right"]].set_visible(False)
def curve(ax,data,key,label,color="#087583",style="-",step=False):
    t=[int(r["elapsed_us"])*1e-6 for r in data]
    y=[float(r[key]) for r in data]
    if step:
        ax.step(t,y,label=label,color=color,linestyle=style,where="post",linewidth=1.5)
    else:
        ax.plot(t,y,label=label,color=color,linestyle=style,linewidth=1.6)
a,b,c=axes
a.axvspan(.8,1.6,color="#ebd184",alpha=.30,label="0.039 N m opposing load")
a.axhline(.3,color="#555555",linestyle=":",label="Reference")
curve(a,new["load"],"plant_rad","01B H1 IMPEDANCE")
curve(a,old["load"],"plant_rad","01A external Current","#bb5e28","--")
a.set(xlim=(0,2.4),ylabel="Position (rad)",title="Matched load profile and recovery")
curve(b,new["hold"],"plant_rad","Damping 0.048 N m s/rad")
curve(b,new["soft-damping"],"plant_rad","Damping 0.006 N m s/rad","#bb5e28")
b.axhline(.3,color="#555555",linestyle=":",label="Reference")
b.set(xlim=(0,1.6),ylabel="Position (rad)",title="Same stiffness, two command damping gains")
curve(c,new["limit-045"],"target_iq_a","01B q request at 0.45 A cap",step=True)
curve(c,new["limit-045"],"plant_iq_a","01B plant q current","#07505a")
curve(c,old["limited"],"plant_iq_a","01A plant q current","#bb5e28","--")
c.set(xlim=(0,.04),ylim=(-.02,.49),ylabel="q-axis current (A)",
      title="Matched first 40 ms of the 0.45 A cap")
for ax in axes:
    ax.legend(loc="best",ncols=2,fontsize=8.6,frameon=False)
fig.savefig(root/"runtime-impedance-curves.png",dpi=165)

