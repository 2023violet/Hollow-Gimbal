from pathlib import Path
import importlib.util
import json
import sys

runner, output = (Path(value).resolve() for value in sys.argv[1:])
output.mkdir(parents=True)
sys.argv = [sys.argv[0], str(runner)]
test_path = Path("simulation/tests/test_virtual_calibration_reuse_cli.py").resolve()
spec = importlib.util.spec_from_file_location("reuse_test", test_path)
test = importlib.util.module_from_spec(spec)
spec.loader.exec_module(test)
with (output / "product-events.jsonl").open("x", encoding="utf-8") as journal:
    original_command = test.ReuseSession.command
    original_calibrate = test.run_calibration
    def record(kind, request, rows):
        print(json.dumps({"kind": kind, "request": request, "rows": rows}), file=journal)
        journal.flush()
        return rows
    def command(self, request, *args, **kwargs):
        return record("reuse", request, original_command(self, request, *args, **kwargs))
    def run(*args, **kwargs):
        return record("calibrate", args, original_calibrate(*args, **kwargs))
    test.ReuseSession.command = command
    test.run_calibration = run
    test.main()
print("Product scenarios passed; JSONL preserves every native command response.")

