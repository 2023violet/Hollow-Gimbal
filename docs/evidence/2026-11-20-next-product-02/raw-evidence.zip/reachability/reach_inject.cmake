# Injected into the existing standalone Simulation project after it is defined.
if(PROJECT_IS_TOP_LEVEL)
  function(add_reach_probe)
    add_executable(reach-probe
      "$ENV{FALCON_REACH_PROBE_SOURCE}"
      "${CMAKE_CURRENT_SOURCE_DIR}/src/foc_virtual_calibration_package.c")
    target_link_libraries(reach-probe PRIVATE falconfoc-virtual-calibration)
    target_include_directories(reach-probe PRIVATE ../components/utils/crc)
    target_compile_features(reach-probe PRIVATE c_std_11)
    if(CMAKE_C_COMPILER_ID MATCHES "GNU|Clang")
      target_compile_options(reach-probe PRIVATE -Wall -Wextra -Wpedantic -Werror)
    endif()
  endfunction()
  cmake_language(DEFER CALL add_reach_probe)
endif()
