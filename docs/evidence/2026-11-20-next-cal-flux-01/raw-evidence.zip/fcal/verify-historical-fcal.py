"""Verify archived v1 package compatibility using the supplied Host build."""

import hashlib
import json
import pathlib
import struct
import subprocess
import sys
from zipfile import ZipFile


def main():
    runner, out = (pathlib.Path(arg).resolve() for arg in sys.argv[1:])
    out.mkdir()
    summary = []

    def run(label, profile, *args, expected=0):
        result = subprocess.run([runner, "--profile-id", profile, *args], text=True,
                                capture_output=True, timeout=45)
        (out / f"{label}.jsonl").write_text(result.stdout, encoding="utf-8")
        assert result.returncode == expected, (label, result.returncode, result.stderr, result.stdout)
        return [json.loads(line) for line in result.stdout.splitlines()]

    def event(rows, name):
        return next(row for row in rows if row.get("event") == name)

    def trials(rows):
        return [row for row in rows if row.get("event") == "CONTROL_TRIAL"]

    for kind, profile in (("generic", "GENERIC_RESEARCH_MOTOR"),
                          ("salient", "CALIBRATION_SALIENT_MOTOR")):
        cases = (
            ("old", "2026-11-19-next-cal-integ-01", f"final-product/{kind}-motor.fcal"),
            ("active", "2026-11-20-next-cq-03", f"startup/active-{kind}.fcal"),
        )
        for prefix, evidence, member in cases:
            label = f"{prefix}-{kind}"
            with ZipFile(pathlib.Path("docs/evidence") / evidence / "raw-evidence.zip") as archive:
                payload = archive.read(member)
                if prefix == "active":
                    archived = [json.loads(line) for line in archive.read(
                        f"startup/reload-{kind}.jsonl").decode("utf-8-sig").splitlines() if line.strip()]
            path = out / f"{label}.fcal"
            path.write_bytes(payload)
            fingerprint, = struct.unpack("<I", payload[-4:])
            review_id = f"{fingerprint:08x}"
            preview = run(f"{label}-preview", profile, "--load-config", path)
            assert event(preview, "CANDIDATE_PREVIEW")["review_id"] == review_id
            assert not any(row.get("event") == "CONFIGURATION_APPLIED" for row in preview)
            wrong = run(f"{label}-reject", profile, "--load-config", path, "--approve-candidate",
                        "badcafe0", expected=2)
            assert wrong[-1]["error"] == "REVIEW_ID_MISMATCH"
            assert not trials(wrong)
            applied = run(f"{label}-applied", profile, "--load-config", path, "--approve-candidate",
                          review_id)
            assert len(trials(applied)) == 16
            assert event(applied, "CONFIGURATION_APPLIED")["lut_nodes"] == 32
            assert event(applied, "CONFIGURATION_APPLIED")["damping_filter_hz"] == 48
            assert event(applied, "FAULT_RECOVERY_VERIFIED")["stop_confirmed"]
            assert path.read_bytes() == payload
            if prefix == "active":
                assert trials(applied) == trials(archived)
                assert event(applied, "CONFIGURATION_APPLIED") == event(archived, "CONFIGURATION_APPLIED")
                switches = ["--cogging"] if kind == "generic" else []
                repeated = out / f"{label}-fresh.fcal"
                fresh = run(f"{label}-fresh", profile, *switches, "--approve-candidate", review_id,
                            "--save-config", repeated)
                assert repeated.read_bytes() == payload
                assert trials(fresh) == trials(applied)
            summary.append({"artifact": path.name, "archive": evidence, "entry": member,
                            "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest(),
                            "review_id": review_id, "verified_trials": len(trials(applied)),
                            "exact_active_archive_and_fresh_parity": True if prefix == "active" else None})

    result = json.dumps(summary, indent=2)
    (out / "summary.json").write_text(result + "\n", encoding="utf-8")
    print(result)


if __name__ == "__main__":
    main()
