#include "foc_impedance_tuning.h"
const char input_bytes[sizeof(struct foc_impedance_tuning_input)] = {0};
const char candidate_bytes[sizeof(struct foc_impedance_tuning_candidate)] = {0};

