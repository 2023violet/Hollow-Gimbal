import pathlib,shutil
from audit import OUT,ROOT,SRC,CC,run
ARM=pathlib.Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.3 rel1/bin')
dest=OUT/'resources';dest.mkdir(exist_ok=False)
old=pathlib.Path('D:/study/Software/FalconFOC-runtime-review-04-20261117/layout.c')
shutil.copy2(old,OUT/'layout.c')
incs=[SRC/p for p in ['runtime/include','core/include','g3/np/include','g3/safe/include']]
flags=['-std=c11','-mcpu=cortex-m4','-mthumb','-mfloat-abi=soft','-Os','-fstack-usage',*[a for p in incs for a in ['-I',p]]]
for name,path in [('before',SRC/'runtime/src/foc_runtime.c'),('after',ROOT/'runtime/src/foc_runtime.c'),('layout',OUT/'layout.c')]:
    run(dest,name+'-compile',[ARM/'arm-none-eabi-gcc.exe',*flags,'-c',path,'-o',dest/(name+'.o')])
    run(dest,name+'-symbols',[ARM/'arm-none-eabi-nm.exe','-S','--size-sort',dest/(name+'.o')])
run(dest,'arm-size',[ARM/'arm-none-eabi-size.exe',dest/'before.o',dest/'after.o'])
run(dest,'after-disassembly',[ARM/'arm-none-eabi-objdump.exe','-dr',dest/'after.o'])
run(dest,'host-build',[CC,'-std=c11','-DHOST',*[a for p in incs for a in ['-I',p]],OUT/'layout.c','-o',dest/'layout.exe'])
run(dest,'host-layout',[dest/'layout.exe'])
