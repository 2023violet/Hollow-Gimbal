param([string]$Destination)
$ErrorActionPreference='Stop'
[IO.Directory]::CreateDirectory($Destination) | Out-Null
$map=Get-Content -Raw -Encoding UTF8 scripts/sdk/source-map.json | ConvertFrom-Json
foreach($entry in $map.files){
  $to=Join-Path $Destination $entry.path
  [IO.Directory]::CreateDirectory((Split-Path -Parent $to)) | Out-Null
  Copy-Item -LiteralPath $entry.source -Destination $to
}
