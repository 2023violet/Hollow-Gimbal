from pathlib import Path
import hashlib,subprocess as sp
root=Path(__file__).parent
def tool(name,*a):
    return sp.check_output(["arm-none-eabi-"+name,*a],text=True,stderr=sp.STDOUT)
print(tool("gcc","--version").splitlines()[0])
flags=["-std=c11","-mcpu=cortex-m4","-mthumb","-mfloat-abi=soft","-Os",
       "-ffunction-sections","-fdata-sections","-fstack-usage","-Wall","-Wextra","-Wpedantic","-Werror"]
print("flags"," ".join(flags))
files=[
 ("feasibility","core/src/foc_impedance_feasibility.c"),
 ("damping-probe",root/"damping-probe.c"),
]
(root/"damping-probe.c").write_text('''#include "foc_damping_noise_filter.h"
#include "foc_impedance_feasibility.h"
#include "foc_runtime.h"
const char filter_bytes[sizeof(struct damping_noise_filter)] = {0};
const char runtime_bytes[sizeof(struct foc_runtime)] = {0};
const char feas_input_bytes[sizeof(struct foc_impedance_feasibility_input)] = {0};
const char feas_result_bytes[sizeof(struct foc_impedance_feasibility_result)] = {0};
bool isolated_trial(struct damping_noise_filter *state, float velocity_rad_s, float cutoff_hz, uint32_t dt_us)
{
    return damping_noise_filter_step(state, velocity_rad_s, cutoff_hz, dt_us);
}
''')
for label,path in files:
    obj=root/(label+".o")
    tool("gcc",*flags,"-Icore/include","-Isimulation/tests","-Iruntime/include",
         "-Ig3/np/include","-Ig3/safe/include","-c",path,"-o",obj)
    print(label,tool("size",obj),tool("nm","-S","-t","d",obj),obj.with_suffix(".su").read_text())
    (root/(label+"-disasm.txt")).write_text(tool("objdump","-dr",obj))
for label,location in (("02A",Path("C:/Users/16429/AppData/Local/Temp/servo02a_1795010163449/final-complete/locked-arm")),("02B",root/"final-complete/locked-arm")):
    elf=next(location.glob("*.elf"))
    bin_data=next(location.glob("*.bin")).read_bytes()
    symbols=tool("nm","-S",elf)
    assert "foc_impedance_feasibility_evaluate" not in symbols
    print(label,tool("size",elf),"BIN",len(bin_data),hashlib.sha256(bin_data).hexdigest())
    if label=="02A":
        baseline=bin_data
    else:
        assert baseline==bin_data
print("Reference locked firmware byte-identical.")

