from pathlib import Path
from collections import defaultdict
import csv,subprocess as sp,sys

root=Path(__file__).parent
data=root/"data"
data.mkdir(exist_ok=True)
build=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/"final-complete/simulation-clang"
for mode in ("train","holdout"):
    exe=build/"test-foc-impedance-robustness.exe"
    cmd=[exe,"--damping-noise-"+mode,"--trace"]
    output=sp.check_output(cmd)
    (root/f"noise-{mode}.log").write_bytes(output)
    collected=defaultdict(list)
    for row in csv.reader(output.decode("ascii").splitlines()):
        collected[row[0]].append(row)
    for tag,items in collected.items():
        with (data/f"noise-{mode}-{tag.removeprefix('NOISE_').lower()}.csv").open("w",newline="") as f:
            if items[0][1] in ("candidate","kind"):
                assert all(len(row)==len(items[0]) for row in items)
            csv.writer(f).writerows(items)
        print(mode,tag,len(items),flush=True)
sp.run([sys.executable,root/"common-input.py"],check=True)
