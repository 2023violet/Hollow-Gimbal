import csv, hashlib, json, re, subprocess, sys
from pathlib import Path
from zipfile import ZipFile
base = Path(sys.argv[1])
repo = Path.cwd()
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
v = {'arm-base':('c8648a7e6ebb92c02c60acf277cdf9f1e9634ac15967965bda7a0d2181d15c5e',29620),
     'arm-dwt':('41fdb961a17af7ddf75b25d479bd8870a594d5eb1529fb5982fc82951dde18b0',29204),
     'arm-capture':('dd02c49d14acdc38432bf262b760b2927a949ef1e4311a6a740df09b70ee5c1e',24108),
     'arm-both':('b1696c1dc1718ead8d0c0baa537275bf4aec71e58948d160834455b88de4c955',23692)}
for mode, (digest, headroom) in v.items():
    folder=base/mode
    assert sha(folder/'falconfoc-v2-at32f415.bin')==digest
    text=(folder/'nm.txt').read_text(encoding='utf-8-sig')
    assert 'foc_board_pwm_' not in text
    assert all(x in text for x in ('ADC1_IRQHandler','TMR1_CH_IRQHandler','SPI1_IRQHandler','USART1_IRQHandler'))
    top=int(re.search(r'^([0-9a-f]+) \w _estack$',text,re.M)[1],16)
    bss=int(re.search(r'^([0-9a-f]+) \w _ebss$',text,re.M)[1],16)
    assert top-bss==headroom
    print(mode,'byte-identical BIN',digest,'stack headroom',headroom)
script=(repo/'tools/falconfoc-calibration-replay/locked_timing_export.gdb').read_text()
assert not re.search(r'^\s*(?:target|monitor|load|restore|program|dump)\b',script,re.M)
assert all(line.strip().startswith('set $fct') for line in script.splitlines() if line.strip().startswith('set '))
print('Timing GDB helper only writes convenience variables.')
paths=['firmware/at32f415/src/main.c','firmware/at32f415/src/foc_board.c','runtime/src/foc_pipeline.c','runtime/src/foc_runtime.c','protocol','platform/at/at32f415','calibration','control_plane']
print('The four matching production ARM images independently verify compiled operation equality.')
with (base/'prior-hashes.csv').open(encoding='utf-8-sig',newline='') as stream:
    prior=list(csv.DictReader(stream))
for row in prior:
    assert sha(Path(row['Path']))==row['Hash'].lower(),row['Path']
print(len(prior),'existing evidence digests unchanged.')
git=lambda *args: subprocess.check_output(['git',*args],cwd=repo)
assert not git('diff','--cached','--name-only')
assert git('rev-parse','HEAD').strip()==b'd824933946a365b8081089c2e396d77b3f661bc8'
before={(line.strip()) for line in (base/'baseline-status.txt').read_text(encoding='utf-8-sig').splitlines()[1:]}
after={line.strip() for line in git('status','--porcelain=v1','-b').decode().splitlines()[1:]}
assert before.issubset(after),sorted(before-after)
print('Starting changed and untracked paths preserved. Index empty.')
snapshot=json.loads((base/'host-gdb-report.json').read_text(encoding='utf-8-sig'))
assert snapshot['source']=='HOST_FIXTURE' and not snapshot['target_wcet_verified'] and not snapshot['physical_inhibit_verified']
assert snapshot['spans']['h0']['cycles']==30 and snapshot['spans']['h1']['cycles']==27
print('Host GDB output imports and stays OBSERVATIONS_ONLY.')
with ZipFile(repo/'docs/evidence/2026-11-19-next-integ-02/raw-results.zip') as z:
    stack=z.read('stack-review.py').decode()
stack=stack.replace('("capoff", "capon", "traceoff", "captrace")','("arm-base", "arm-capture", "arm-dwt", "arm-both")')
(base/'stack-review.py').write_text(stack,encoding='utf-8')
