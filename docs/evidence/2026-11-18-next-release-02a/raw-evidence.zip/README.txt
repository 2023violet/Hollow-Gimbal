Raw evidence for INTERNAL use only. The original 03B candidate remains separate.
Contains the original first in-repository Git bytes of the 16 unresolved files,
tracked history, bounded comparison coordinates and upstream links/hashes.
Public upstream source text is retrieved during comparison and is not copied into this evidence bundle.
G2/G3 and early FOC/Runtime sources are analyzed only under this audit scope.
