import hashlib, json, pathlib, shutil, sys, uuid
from audit import OUT, ROOT, SRC, CC, ENV, run, copy_source

CHANGES = ['core/tests/test_foc_motion.c', 'core/tests/test_foc_motion_reference.c',
           'core/include/foc_motion.h', 'core/README.md']
REPO = OUT / 'green-repo'

def overlay(repo):
    for rel in CHANGES:
        shutil.copy2(ROOT / rel, repo / rel)

def project(dest, source, name, compiler=CC, sanitizer=False, configure=True):
    args = ['cmake', '-S', source / name, '-B', dest / 'build', '-G', 'Ninja',
            '-DCMAKE_BUILD_TYPE=Debug', '-DCMAKE_C_COMPILER=' + compiler]
    if sanitizer:
        args += ['-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer',
                 '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    if configure:
        run(dest, 'configure', args)
    run(dest, 'build', ['cmake', '--build', dest / 'build', '--parallel', '4'])
    run(dest, 'ctest', ['ctest', '--test-dir', dest / 'build', '--output-on-failure'])

def mutations():
    original = (SRC / 'core/src/foc_motion.c').read_text(encoding='utf-8')
    guard = '    if (!isfinite(trial) || !isfinite(requested)) {\n'
    cases = {
        'commit-trial': (guard, guard + '        context->integral_a = trial;\n', 'test-foc-motion'),
        'commit-negative': (guard, guard + '        if (trial < 0.0f) context->integral_a = trial;\n', 'test-foc-motion'),
        'commit-finite': (guard, guard + '        if (isfinite(trial)) context->integral_a = trial;\n', 'test-foc-motion'),
        'time-scale': ('(float)elapsed_us * 1.0e-6f;', '(float)elapsed_us * 1.000001e-6f;', 'test-foc-motion-reference'),
    }
    for label, (old, new, target) in cases.items():
        dest = OUT / 'mutations-fresh' / label
        source = copy_source(dest / 'source')
        assert original.count(old) == 1
        mutated = original.replace(old, new)
        (source / 'core/src/foc_motion.c').write_text(mutated, encoding='utf-8')
        (dest / 'mutation.json').write_text(json.dumps({'label':label, 'old':old, 'new':new,
            'mutant_sha256':hashlib.sha256((source/'core/src/foc_motion.c').read_bytes()).hexdigest()},indent=2))
        project(dest / 'before-tests', source, 'core')
        overlay(source)
        run(dest / 'after-tests', 'configure', ['cmake','-S',source/'core','-B',dest/'after-tests/build',
            '-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+CC])
        run(dest / 'after-tests', 'build', ['cmake', '--build', dest / 'after-tests/build', '--parallel', '4'])
        p = run(dest / 'after-tests', 'ctest', ['ctest', '--test-dir', dest / 'after-tests/build',
                    '--output-on-failure', '-R', '^' + target + '$'], expected=8)
        assert '***Failed' in p.stdout and target + ' (Failed)' in p.stdout
        # A compiled executable must return test failure; a compile error is not a kill.
        run(dest / 'after-tests', 'executable', [dest / 'after-tests/build' / (target + '.exe')], expected=1)

phase = sys.argv[1]
if phase == 'green':
    dest = OUT / 'green'; assert not REPO.exists()
    run(dest, 'clone', ['git', 'clone', '--local', '--no-hardlinks', '--single-branch', '--branch',
                        'codex/falconfoc-v2-vm01a', ROOT, REPO])
    # Restore the captured worktree byte content, independent of checkout eol rules.
    for rel in json.loads((OUT/'source-before.json').read_text(encoding='utf-8')):
        shutil.copy2(SRC / rel, REPO / rel)
    overlay(REPO)
    project(dest / 'core', REPO, 'core')
    run(dest / 'core', 'entries', ['ctest', '--test-dir', dest / 'core/build', '-N'])
    run(dest / 'core', 'prediction-values', [dest / 'core/build/test-foc-motion-reference.exe'])
    run(dest / 'core', 'atomicity-values', [dest / 'core/build/test-foc-motion.exe'])
elif phase == 'mutations':
    mutations()
elif phase == 'regression':
    assert all((REPO/rel).read_bytes()==(ROOT/rel).read_bytes() for rel in CHANGES)
    for name, compiler, asan in [('core-gcc','C:/mingw64/bin/gcc.exe',False),
                                 ('runtime',CC,False), ('simulation',CC,False),
                                 ('core-asan',CC,True), ('simulation-asan',CC,True)]:
        project(OUT/'regression'/name, REPO, name.split('-')[0], compiler, asan)
    project(OUT/'regression/core-final', REPO, 'core')
elif phase == 'gate':
    dest = OUT / 'gates'
    temp = pathlib.Path('D:/mc01-' + uuid.uuid4().hex[:8]); temp.mkdir(exist_ok=False)
    env = ENV.copy(); env['TEMP'] = env['TMP'] = str(temp)
    artifacts = []
    for preset in ['fw-tiny-carrier-minsizerel','fw-standard-carrier-minsizerel','fw-full-diag-carrier-debug']:
        for leaf in ['falcon-foc-at32.elf','falcon-foc-at32.map']:
            rel = pathlib.Path('build') / preset / 'output' / leaf
            target = REPO / rel; target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(ROOT / rel, target)
            digest = hashlib.sha256(target.read_bytes()).hexdigest()
            assert digest == hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
            artifacts.append({'path':str(rel), 'sha256':digest, 'origin':'historical artifact copy; not a fresh ARM build'})
    (OUT/'gate-isolation.json').write_text(json.dumps({'repo':str(REPO),'temp':str(temp),
        'CI':env.get('CI'),'GITHUB_ACTIONS':env.get('GITHUB_ACTIONS'),'legacy_artifacts':artifacts},indent=2))
    def ps(label, relative, *extra):
        return run(dest, label, ['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',
                   REPO/relative,'-RepoRoot',REPO,*extra], env=env, cwd=REPO)
    ps('seed-gcc','scripts/flows/host/run_host_tests.ps1','-CompilerPath','C:/mingw64/bin/gcc.exe')
    ps('source-contract','scripts/gates/check_falconfoc_source_contract.ps1')
    ps('formatter','scripts/format_themis.ps1','-Mode','check','-Scope','all')
    p=ps('strict-all','scripts/gates/check_themis_quality_gate.ps1','-Scope','all','-RequireCMakeFormatter','-Summary')
    assert p.stdout.count('[cmake_quality] format-check:')==30
    assert '[quality_gate] all requested checks passed.' in p.stdout and '45/45' in p.stdout
elif phase == 'final':
    # Formal G4 in the requested order, after all mutation experiments finished.
    dest=OUT/'final'; env=ENV.copy(); env['CC']=CC
    assert (REPO/'core/src/foc_motion.c').read_bytes()==(SRC/'core/src/foc_motion.c').read_bytes()
    run(dest/'core','configure',['cmake','-S','core','-B','build/motion-contract-01','-G','Ninja',
        '-DCMAKE_BUILD_TYPE=Debug'],env=env,cwd=REPO)
    run(dest/'core','build',['cmake','--build','build/motion-contract-01','--parallel','4'],env=env,cwd=REPO)
    run(dest/'core','ctest',['ctest','--test-dir','build/motion-contract-01','--output-on-failure'],env=env,cwd=REPO)
    for name in ['runtime','simulation']:
        project(dest/name,REPO,name)
    env=ENV.copy()
    env['TEMP']=env['TMP']=json.loads((OUT/'gate-isolation.json').read_text())['temp']
    run(dest/'gates','strict-all',['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',
        REPO/'scripts/gates/check_themis_quality_gate.ps1','-RepoRoot',REPO,'-Scope','all',
        '-RequireCMakeFormatter','-Summary'],env=env,cwd=REPO)
else:
    raise SystemExit('unknown phase')
