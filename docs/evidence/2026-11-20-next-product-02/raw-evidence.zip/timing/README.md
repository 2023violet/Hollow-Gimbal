# PRODUCT-02C｜Runtime 时间与锁定 ARM 资源

**SOFTWARE_TIMING_BUDGET_DOCUMENTED** · **ARM_STATIC_RESOURCE_ANALYSIS_PASS**  
**ARM_STATIC_COST_ANALYZED** · **HOST_EXECUTION_MEASURED** · **TARGET_WCET_NOT_VERIFIED**

## 复跑

在 Windows 上使用 Python 3、CMake、Ninja、Clang、MinGW GCC 和 Arm GNU 工具链。从证据包解压目录运行下列命令，输出目录必须是新目录。

~~~powershell
python run.py D:/study/Software/Hollow-Gimbal-vm01a D:/path/to/fresh-timing-evidence
~~~

本次绑定 PRODUCT-02A 冻结的实际源文件，其中 CQ-02 Runtime 的 48 Hz 分支已经进入基线。日志和逐重复 CSV 位于 evidence/。src/bench.c 通过 CMake 链接正式 Board1 Host 库，复用 CQ-02 的公开 Runtime 加 QPC 方法和 RT-01/03 的 Board 输出拒绝构型。stack-review.py 沿用 RT-03 证据包的栈遍历，仅适配本轮构建目录名。arm-calls.py 用已链接 ELF 的反汇编统计直接调用点、可见尾调用和间接边位置。

## 实际路径

| 域 | 锁定镜像中的实际调用链和配置 |
| --- | --- |
| H0 触发 | TMR1 CH4 比较 IRQ → TMR2/TMR1 双读时间夹取与标志确认 → Board ADC token 校验、时间/目标槽归属与重复检查 → 软件触发 ADC 四个抢占通道 → Board 诊断发布。 |
| H0 完成 | ADC1 PCCE IRQ → 读四 rank 并清/查标志 → Board 配对 token、rank 边界与时间 → Runtime H0 调度、源身份、ADC 解码/电流有效性、角度对齐和生命周期 → Pipeline 的 ADC 解码/采样门槛、Safety → Current Core Clarke/Park、PI、逆 Park/SVPWM、电压限幅与抗饱和 → PWM request map、最后 Guard、适配器 → 确认后提交积分和外环 trial 并发布快照。Board 适配器核对映射后拒绝 UPDATE、返回 INHIBIT，拒绝后积分保持安全状态。在 Host mock 中经过同一 guard 的接受分支可以提交。 |
| H1 | TMR5 overflow 拉低 CS，CH1 发起 SPI，SPI1 RX/error IRQ 记录一字并返回。CH2 TMR5 close 检查 RX/hold/窗，释放 CS，然后在此 IRQ 内完成 Board Encoder → 原始计数拆包/连续角、速度差/LPF/跟踪估计、整数相位 → Runtime H1 有效性及控制快照 → 速度环或位置再速度环，或阻抗 K/D、前馈、限幅及目标发布。48 Hz D 滤波由 RUNNING、命令/会话有效及配置启用决定。默认 Board1 的阻抗、D 滤波和轨迹策略禁用，分支仍可见于已链接 Runtime。 |
| Foreground | Board 主循环先 Runtime 监督及到期遥测，然后 V1 COBS/CRC、参数校验/会话/命令发布和状态响应。USART1 单字节 IRQ 移交 RX/TX。原始 RX 队列 256 元素，每 poll 默认 24、参数允许 8–32，V1 原始数据 114 B、含 framing 上限 116 B。Board 当前使用名义配置初始化，ADC 硬件本地校准在启动，完整标定协调/FCAL/CLI 由 Host 产品工作流调用，耗时不计入板端周期监督。 |

H1 在 TMR5 close 中完成。可核对 firmware/at32f415/src/main.c、foc_board.c、foc_serial.c，runtime/src/foc_runtime.c、foc_pipeline.c，core/src/foc_current.c、foc_motion.c、foc_core.c，以及 sensors/src/foc_encoder.c。

## 时间预算

| 阶段 | 现有约束与来源 | 仍需测量 |
| --- | --- | --- |
| TMR1/ADC | 逻辑槽 200 µs，TMR2 每 µs 一 tick，CH4 名义 +40 µs、请求可接受至 +110 µs，PCCE 须同槽且不晚于 token +80 µs。75 MHz APB2 除 6 为 12.5 MHz ADCCLK，4 × (7.5 采样 +12.5 转换时钟)/12.5 MHz 得 6.4 µs 的名义 SOC→末 rank，沿用 RT-02 模型。 | 真实校准后触发同步、rank aperture、PCCE IRQ 响应和有效每相 CSA 窗。 |
| H0、最终输出 | Runtime 周期/迟到/成本入参上限为 200/150/100 µs。150 MHz 下 100 µs 等于 15,000 周期的预算量纲。+40 名义触发和 6.4 µs 转换后，逻辑边界前余 153.6 µs。允许窗口末端 +110 触发后只余 83.6 µs，完整 100 µs 软件成本上限已经放不进此空间，即使忽略 IRQ 及提交开销。以上为软件允许窗口的算术结果，当前允许的完成时间仍须满足 Runtime 入场和后续实际装载约束。 | 等优先级 CH4/PCCE 等待、H0 正常/饱和/保护/拒绝成本和适配器返回、真实负载接受时刻及 setup。当前锁定没有实际写入合同。 |
| SPI/H1 | TMR5 +0/+20/+70 µs 发起/传输/关闭槽，软件动作代理检查 CS ≤+10，TX +20…+30，close +70…+100 µs，且识别 RX 已服务、总线空闲、延后至少 2 个 µs tick。75 MHz APB2 除 16，16 bit 上线名义 3.413 µs。H1 周期/迟到/成本为 500/150/150 µs，150 µs 对应 22,500 周期的预算量纲。源角度和预测年龄上限 650 µs。 | SPI IRQ 驻留、CS 到数据有效和 SPI hold，相对 H0 相位最坏排队，close 到 H1 发布和首个 H0 消耗的跨度。 |
| 抢占/共享 | CH4/PCCE 优先级 0 互相串行，TMR5 与 SPI1 优先级 1 互相串行且可被 0 抢占，USART1 优先级 2。H1 控制快照最多再复制一次。RT-03 Host 复现 SPI 经过 23 µs（4 注入 CPU +19 抢占），排队使 close 到 +105 µs 时拒绝。 | IRQ 进入/退出、Flash/APB 等待、发布/保护冲突、底层原子重试次数和同步窗口。 |
| 前台 | 监督 200/150/100 µs，遥测 10,000/500/100 µs，合计输入限 150 µs，V1 服务另外执行。115200 8N1 名义字节间隔 86.8 µs。仅把独立成本上限当作持续执行量，H0/H1/监督已达 130% CPU，所以不能据各自上限声明调度可行。 | 持续 IRQ 下的监督完成、满速双向与错误帧、空轮询/解析成本和最坏心跳间隔。 |

实时响应核算需要逐发布点使用 R = C + 同级排队 + 屏蔽 + 异常进出 + 窗内高优先级干扰，H0 的触发与 PCCE 是两个发布点，SPI overflow、TX、RX、close 也是不同事件。不能直接将 150 µs Runtime 允许迟到视为输出截止期。软件固定期输入成本与实耗独立。ARM 的 H0/H1 和前台当前均传入零值占位。Host 单独使用正式调度器验证 H0 100/101 µs、H1 150/151 µs、监督及遥测各 100/101 µs、合计 150/151 µs 的边界行为，H0/H1 的 release delay 150 接受、151 拒绝。Board 模型确认一次快照冲突恢复、两次 BUSY 请求 STOP、失配 ADC token 和逾期拒绝。各项均保留日志。

## Host 执行测量

Windows x64 i5-10200H，Clang 22.1.8 / MinGW GCC 16.2.0，Release，QPC 10 MHz，时间差粒度 100 ns。报告为七次运行的平均值中位数，无空计时扣除。每次 10,000 H0/4,000 H1，9,800 单监督/200 监督加遥测，锁定路径每次 2,800，V1 STATUS 10,000 次。Mock 矢量从已接受 duty 和 12 V 反算。常规 Current 实测 0.154–0.267 V，饱和构型保持 2.400 V。每次主动控制通过公开生命周期入场并确认 10,504 次 UPDATE、无故障，以及所需模式和 D 分支实效。

| 生产调用所处的 Host 场景 | Clang ns | GCC ns |
| --- | ---: | ---: |
| H0 Current 常规 / 电压饱和 | 443 / 545 | 455 / 564 |
| H0 Velocity / Position | 476 / 563 | 450 / 454 |
| H1 Velocity / Position | 105 / 134 | 112 / 118 |
| H1 Impedance 0 / 48 Hz | 83 / 103 | 77 / 82 |
| Runtime 单监督 / 监督和遥测，Current | 58 / 92 | 56 / 85 |
| Board ADC token begin+publish / complete+publish，锁定拒绝→INHIBIT | 25 / 493 | 25 / 566 |
| Board 合法 Encoder complete→H1 / V1 STATUS poll | 141 / 654 | 173 / 620 |
| 空 QPC 对 | 13 | 13 |

H0 饱和路径配对均值差中位数约 +69/+113 ns。48 Hz 配对差约 +8/+6 ns，个别重复变号，因此本测量不能稳定量化滤波增量。计时覆盖函数调用，排除测试输入构造、统计、协议包注入和响应取出。锁定 Board Host 不包括真实寄存器访问、ADC 或 SPI 线上等待、硬件 IRQ 和预抢占。V1 STATUS 代表已成帧的诊断调用，最坏协议负载和标定计算未纳入。CSV 保留 OS 尾部及 p50/p95/p99，任何 Host 尾部、均值或硬件时钟比例均不用于 MCU WCET。

## ARM Soft-float 静态数据

Arm GNU 14.3.1 Cortex-M4 Thumb、soft ABI、nofp 库、-Os。Board capture 保持 OFF。编译及默认锁定构建标准与 CQ-03 一致，默认 BIN SHA-256 为 78d055e1135d23a5c2d08f6db17fbf64622333f429381efa2632401eb58cbda2。

| B | CQ-03 默认 | 本次默认 | 本次 DWT trace |
| --- | ---: | ---: | ---: |
| Flash 链接区域 | 44,452 | 44,452 | 45,564 |
| RAM 链接区域 | 4,184 | 4,184 | 4,600 |
| .text / .rodata | 42,540 / 1,444 | 42,540 / 1,444 | 43,652 / 1,444 |
| .data / .bss | 84 / 3,072 | 84 / 3,072 | 84 / 3,488 |
| _estack−_ebss | 29,608 | 29,608 | 29,192 |

- H0/H1 符号体 1,108/1,664 B，直接 .su 帧 168/328 B。Board ADC/Encoder complete 80/64 B，Core Current 内部和调制 184/64 B，Pipeline step 312 B，Encoder update 88 B，Foreground 监督和串口直接帧 240/440 B。反汇编回放把已审计 callback 与库帧计入。默认/trace ADC IRQ 链 1,648/1,664 B、TMR5 链 768/800 B、前台监督/串口 436/844 B。前台→USART→TMR5→ADC/TMR1 按每级额外至多 36 B 硬件异常帧的分析假设，普通嵌套路径为 3,456/3,512 B，低于链接器 4 KiB 最低要求。该模型遍历库归约大参数分支，包含了经常不符合已归一化相位的路径。NMI/fault 特例与实际边界/水位未测。
- H0 确实链接软件浮点加/乘/除/比较及转换，角对齐和调制涉及 fmodf/sinf/cosf、hypotf、sqrtf，限幅和积分判据可再进入调制。H1 直接 Runtime 负责估算外环目标及 D 支路，Board Encoder 还单独触发两次角度归一化，每次缓存 helper 会做 fmodf/sinf/cosf，即使接口只取归一后的角。该现象由实际镜像调用点确认。数学库执行路径随输入和分支变化，链接符号尺寸/调用点数与执行周期无等价关系。
- 产品镜像链接符号中无 malloc/calloc/realloc/free/sbrk，期间没发现 ADC/SPI IRQ 内忙等外设。源代码循环按固定结构长度、最多一次快照重试或 V1 上限界定。反汇编仍显示原子 read-modify-write 的 LDREX/STREX 重试回边，较低优先级可受异常打断，和库数学循环一样须在目标响应分析中明确上界。启动 ADC/时钟等待有固定计数。前台空转为调度结构。
- 判定 KEEP。优先对 H0 角度/限压和 H1 角度归一化分段测量，先用相同输入、镜像和锁定状态数清 IRQ/传输/提交，同步证明最坏相位和外设有效窗口，再判断是否值得优化。现在的最大直接组合风险是 ADC 允许窗口与 H0 入参预算之间缺少下一槽完成保证，以及 H0 抢占 SPI 的短动作窗口。没有真实 AT32F415 超期证据。
