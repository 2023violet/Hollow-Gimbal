from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from hashlib import sha256
import os,subprocess as sp
t=Path(__file__).resolve().parent
env=os.environ.copy()
env["PATH"]=os.pathsep.join([r"C:\mingw64\bin",str(Path(sp.check_output(["clang","-print-resource-dir"],
  text=True).strip())/"lib/windows"),env["PATH"]])
env.update(ASAN_OPTIONS="halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1",PYTHONDONTWRITEBYTECODE="1")
logs=t/"final-logs"
logs.mkdir(exist_ok=True)
tests=["test-foc-parameter","test-foc-config-codec","test-foc-config-store","test-foc-config-diagnostics"]
def run(variant):
    compiler="C:/mingw64/bin/gcc.exe" if variant=="gcc" else "clang"
    out=t/("control-"+variant)
    options=["-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
             "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined"] if variant=="asan" else []
    commands=[[compiler,"--version"],["cmake","-S","control_plane","-B",out,"-G","Ninja",
              "-DCMAKE_BUILD_TYPE=Debug","-DCMAKE_C_COMPILER="+compiler,*options],
              ["cmake","--build",out,"--target",*tests,"--parallel","5"],
              ["ctest","--test-dir",out,"--no-tests=error","--output-on-failure","-R",
               r"^test-foc-(parameter|config-.*)$"]]
    with (logs/(variant+".log")).open("w",encoding="utf8") as f:
        for c in commands:
            print("$ "+sp.list2cmdline(list(map(str,c))),file=f,flush=True)
            sp.run(c,env=env,stdout=f,stderr=sp.STDOUT,check=True)
            print("exit=0",file=f,flush=True)
    for target in tests:
        raw=sp.check_output([out/(target+".exe")],env=env,stderr=sp.STDOUT)
        (logs/(variant+"-"+target+".txt")).write_bytes(raw)
    print(variant,"4/4",flush=True)
with ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(run,["clang","gcc","asan"]))
for target in tests:
    digests={sha256((logs/(variant+"-"+target+".txt")).read_bytes()).hexdigest()
             for variant in ("clang","gcc","asan")}
    assert len(digests)==1
    print(target,"identical output",digests.pop(),flush=True)

prior=t.parent/'falconfoc-soft03-2026-11-18'/'final-logs'
for target in ('test-foc-config-store','test-foc-config-codec'):
    for variant in ('clang','gcc','asan'):
        name=variant+'-'+target+'.txt'
        assert (logs/name).read_bytes() == (prior/name).read_bytes(), name
    print(target, 'byte-identical to SOFT-03 stdout in all variants', flush=True)
