from collections import Counter
from hashlib import sha256
from pathlib import Path
import re
import subprocess as sp
import sys
import zipfile

import os
root = Path(__file__).resolve().parent
src = Path.cwd()
logs = root / "logs"
env = os.environ.copy()

archive_path = src / "docs/evidence/2026-11-18-next-servo-02d/raw-evidence.zip"
def replay():
    with (logs / "replay-02d-verified.log").open("w", encoding="utf-8") as output, zipfile.ZipFile(archive_path) as archive:
        print(f"Reference archive: {archive_path}", file=output)
        source = archive.read("replay-sha256.txt").decode("ascii")
        cases = [("characterization", 24000), ("holdout", 153764)]
        status = 0
        for name, count in cases:
            match = re.search(r"([0-9a-f]{64})\s+.*\b" + re.escape(name) + r"\b", source, re.IGNORECASE)
            command = [root / "test-simulation-clang/test-foc-impedance-robustness.exe", "--joint-control-" + name, "--trace"]
            print("$ " + sp.list2cmdline(list(map(str, command))), file=output, flush=True)
            out = root / f"{name}-verified.csv"
            with out.open("wb") as rows:
                result = sp.run(command, cwd=src, env=env, stdout=rows, stderr=output).returncode
            print(f"Exit code {result}", file=output)
            trace = out.read_bytes()
            trace_count = sum(line.startswith(b"JOINT_TRACE,") for line in trace.splitlines()) - 1
            digest = sha256(trace).hexdigest()
            expected = match[1]
            print(f"{name}: {trace_count} trace rows, SHA-256 {digest}, frozen SHA-256 {expected}", file=output)
            archived_trace = archive.read(f"data/{name}-trace.csv")
            extracted_trace = b"\r\n".join(line for line in trace.splitlines() if line.startswith(b"JOINT_TRACE,")) + b"\r\n"
            trace_equal = extracted_trace.splitlines() == archived_trace.splitlines()
            print(f"Frozen archived trace line equality: {trace_equal}", file=output)
            status |= int(result != 0 or trace_count != count or digest != expected or not trace_equal)
        print(f"Comparison exit code {status}", file=output)
    print((logs / "replay-02d-verified.log").read_text(encoding="utf-8"))
    return status

raise SystemExit(replay())

