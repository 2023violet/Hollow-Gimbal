from pathlib import Path
import hashlib,json,sys
r=Path(sys.argv[1])
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def events(file): return [json.loads(row) for row in file.read_text(encoding='utf-8-sig').splitlines()]
def cfg(rows, kind): return next(row for row in rows if row.get("event")==kind)
def trials(rows):
    return {(x['mode'],x['configuration'],x['reference']):x for x in rows
            if x['event']=='CONTROL_TRIAL' and x['configuration'] in ('before','after')}
result={}
for name in ('generic','salient'):
    prior=r/'calibration/cq01-reference'
    final=r/'calibration/final'
    old,new,reload=(events(path/f'{name}-{kind}.jsonl')
                    for path,kind in ((prior,'applied'),(final,'applied'),(final,'reloaded')))
    old_trials,new_trials=trials(old),trials(new)
    assert tuple(old_trials)==tuple(new_trials) and len(new_trials)==16
    assert new_trials==trials(reload)
    for key in old_trials:
        if key[0]!='impedance':
            assert old_trials[key]==new_trials[key],key
    assert cfg(old,'PARAMETERS_IDENTIFIED')==cfg(new,'PARAMETERS_IDENTIFIED')
    assert cfg(old,'FAULT_RECOVERY_VERIFIED')==cfg(new,'FAULT_RECOVERY_VERIFIED')==cfg(reload,'FAULT_RECOVERY_VERIFIED')
    assert cfg(new,'CONFIGURATION_APPLIED')==cfg(reload,'CONFIGURATION_APPLIED')
    assert cfg(new,'CONFIGURATION_APPLIED')['damping_filter_hz']==48
    frozen_hash=digest(prior/f'{name}-new.fcal')
    assert frozen_hash==digest(final/f'{name}-new.fcal')
    assert cfg(old,'CANDIDATE_PREVIEW')['review_id']==cfg(new,'CANDIDATE_PREVIEW')['review_id']
    assert cfg(events(final/f'{name}-legacy-reloaded.jsonl'),'CONFIGURATION_APPLIED')['damping_filter_hz']==48
    result[name]={"unchanged_modes": ["current","velocity","position"],"package_sha256":frozen_hash,
                  "impedance_rows":[{"case":k,"prior":old_trials[k],"applied":new_trials[k]} for k in old_trials if k[0]=='impedance']}
baseline=(r/'baseline/baseline-servo.csv').read_text()
assert baseline==(r/'impedance/live-servo-unfiltered.csv').read_text()
result["servo_0_hz_equal_rows"]=len(baseline.splitlines())
phase=r/'dynamics/phase-consistent'
for fname in ('axes','axes-recovery'):
    assert digest(phase/f'{fname}-off.csv')==digest(phase/f'{fname}-48hz.csv')
for lane,expect in [('phase-consistent',(0,0,0)),('measured-only',(0,15,0))]:
    d=json.loads((r/'dynamics'/lane/'frozen-evaluation.json').read_text())
    count=tuple(len(d[x]) for x in ('noise_failures','dynamic_failures','saturation_failures'))
    assert count==expect,(lane,count)
    result[lane]={"failure_counts":[*count],"gates":d["gates"]}
(r/'cq02-parity-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print("Servo bypass, calibration archives, dual-profile ordinary modes, joint evaluator and cross-mode traces match expected invariants.")
