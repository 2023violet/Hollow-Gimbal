[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$FrozenRepo,

    [Parameter(Mandatory = $true)]
    [string]$CandidateRepo,

    [Parameter(Mandatory = $true)]
    [string]$OutputDirectory
)

$ErrorActionPreference = 'Stop'
$FrozenRepo = (Resolve-Path -LiteralPath $FrozenRepo).Path
$CandidateRepo = (Resolve-Path -LiteralPath $CandidateRepo).Path
$output = (New-Item -ItemType Directory -Force -Path $OutputDirectory).FullName
$frozenBuild = Join-Path $output 'frozen-build'
$candidateBuild = Join-Path $output 'candidate-build'

function Invoke-Checked {
    param([string]$Name, [string[]]$Arguments, [string]$Log)
    & $Name @Arguments | Tee-Object -FilePath (Join-Path $output $Log)
    if ($LASTEXITCODE -ne 0) {
        throw "$Name returned $LASTEXITCODE while writing $Log"
    }
}

Invoke-Checked 'cmake' @('-S', $PSScriptRoot, '-B', $frozenBuild, '-G', 'Ninja',
    '-DCMAKE_C_COMPILER=clang', "-DSOURCE_REPO=$FrozenRepo",
    "-DHISTORICAL_REPO=$FrozenRepo", '-DCQ02_FILTER_CONFIG=OFF') 'frozen-configure.log'
Invoke-Checked 'cmake' @('--build', $frozenBuild, '--target', 'cq02-load', 'test-foc-impedance-robustness') 'frozen-build.log'
Invoke-Checked 'cmake' @('-S', $PSScriptRoot, '-B', $candidateBuild, '-G', 'Ninja',
    '-DCMAKE_C_COMPILER=clang', "-DSOURCE_REPO=$CandidateRepo",
    "-DHISTORICAL_REPO=$FrozenRepo", '-DCQ02_FILTER_CONFIG=ON') 'candidate-configure.log'
Invoke-Checked 'cmake' @('--build', $candidateBuild, '--target', 'cq02-load') 'candidate-build.log'

$original = Join-Path $frozenBuild 'simulation/test-foc-impedance-robustness.exe'
& $original --trace > (Join-Path $output 'original-holdouts.log')
if ($LASTEXITCODE -ne 0) {
    throw "Historical executable failed with $LASTEXITCODE"
}

$runs = @(
    @{ Name = 'baseline'; Build = $frozenBuild; Cutoff = '0' },
    @{ Name = 'disabled'; Build = $candidateBuild; Cutoff = '0' },
    @{ Name = 'candidate'; Build = $candidateBuild; Cutoff = '48' }
)
foreach ($run in $runs) {
    $name = $run.Name
    Invoke-Checked (Join-Path $run.Build 'cq02-load.exe') @($run.Cutoff,
        (Join-Path $output "$name-h0.csv"), (Join-Path $output "$name-h1.csv")) "$name-study.log"
}

Invoke-Checked 'python' @('-B', (Join-Path $PSScriptRoot 'analyze_load.py'), $output) 'analysis.log'
