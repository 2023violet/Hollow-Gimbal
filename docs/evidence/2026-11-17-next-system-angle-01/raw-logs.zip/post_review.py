import json,shutil
from audit import OUT,ROOT,CC,ENV,run

repo=OUT/'green-repo'
for rel in ['simulation/README.md','simulation/tests/test_foc_periodic_chain.c',
            'simulation/tests/foc_system_angle_oracle.h']:
    shutil.copy2(ROOT/rel,repo/rel)
for label,cc,asan in [('simulation',CC,False),('simulation-gcc','C:/mingw64/bin/gcc.exe',False),
                     ('simulation-asan',CC,True)]:
    dest=OUT/'verified'/label
    args=['cmake','-S',repo/'simulation','-B',dest/'build','-G','Ninja',
          '-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+cc]
    if asan:
        args+=['-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer',
               '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    run(dest,'configure',args)
    run(dest,'build',['cmake','--build',dest/'build','--parallel','4'])
    run(dest,'ctest',['ctest','--test-dir',dest/'build','--output-on-failure'])
    run(dest,'data',[dest/'build/test-foc-periodic-chain.exe','--system-angle-csv',dest/'data.csv'])
env=ENV.copy();env['TEMP']=env['TMP']=json.loads((OUT/'gate-isolation.json').read_text())['temp']
dest=OUT/'verified/gates'
for label,script,extra in [('source','scripts/gates/check_falconfoc_source_contract.ps1',[]),
    ('format','scripts/format_themis.ps1',['-Scope','all','-Mode','check']),
    ('strict-all','scripts/gates/check_themis_quality_gate.ps1',
       ['-Scope','all','-RequireCMakeFormatter','-Summary'])]:
    p=run(dest,label,['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',repo/script,
                     '-RepoRoot',repo,*extra],env=env,cwd=repo)
    if label=='strict-all':
        assert '[Total]   PASS' in p.stdout and '45/45' in p.stdout
        assert p.stdout.count('[cmake_quality] format-check:')==30
