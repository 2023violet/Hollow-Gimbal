#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#define main impedance_fixture_main
#include FOC_BENCH_FIXTURE
#undef main

int main(void)
{
    LARGE_INTEGER frequency;
    CHECK(QueryPerformanceFrequency(&frequency));
    struct foc_runtime_config policy = config;
    for (unsigned int repeat = 0; repeat < RUNS; ++repeat) {
#if HAS_DAMPING_POLICY
        policy.motion.impedance.damping_filter_hz = repeat % 2 == 0 ? 0.0f : 48.0f;
        const double cutoff = policy.motion.impedance.damping_filter_hz;
#else
        const double cutoff = 0.0;
#endif
        struct foc_runtime runtime;
        CHECK(select_impedance(&runtime, &policy, &pipeline_config) == 0);
        const struct foc_runtime_command initial = command_at(&runtime, 1U, 101U);
        CHECK(foc_runtime_publish_impedance_command(&runtime, &initial, 101U) == FOC_RUNTIME_OK);
        CHECK(arm_start(&runtime, 200U) == 0);
        LONGLONG ticks = 0;
        for (uint32_t cycle_number = 4; cycle_number < 62004U; ++cycle_number) {
            const uint32_t now = cycle_number * 100U;
            const struct foc_runtime_command command = command_at(&runtime, cycle_number, now - 1U);
            CHECK(foc_runtime_publish_impedance_command(&runtime, &command, now - 1U) == FOC_RUNTIME_OK);
            const float speed = cycle_number % 2 == 0 ? 0.15f : 0.35f;
            LARGE_INTEGER before, after;
            QueryPerformanceCounter(&before);
            const int status = sense(&runtime, now, 0.75f, speed, 7U);
            QueryPerformanceCounter(&after);
            if (cycle_number >= 2004U) ticks += after.QuadPart - before.QuadPart;
            CHECK(status == FOC_RUNTIME_OK);
            CHECK(cycle(&runtime, now, FOC_RUNTIME_OK) == 0);
        }
        CHECK(runtime.pipeline.mock.updates == 62000U);
        const double ns = (double)ticks * 1.0e9 / (frequency.QuadPart * 60000.0);
        printf("%u,%.0f,%.6f,%zu,%zu,%zu,%lld\n", repeat, cutoff, ns, sizeof runtime,
               sizeof policy, sizeof runtime.sensor_slots[0], frequency.QuadPart);
    }
    return 0;
}

