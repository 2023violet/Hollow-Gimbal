"""Cross-check the production ARM binaries, capture ABI, and source isolation."""

import csv
import hashlib
from pathlib import Path
import re
import subprocess
import sys


base = Path(sys.argv[1])
repo = Path(sys.argv[2])
image = "falconfoc-v2-at32f415"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def symbols(mode):
    rows = (base / mode / "nm.txt").read_text(encoding="utf-8-sig").splitlines()
    result = {}
    for row in rows:
        match = re.fullmatch(r"([0-9a-f]+)(?: ([0-9a-f]+))? [a-zA-Z] (\S+)", row)
        if match:
            result[match[3]] = int(match[1], 16), int(match[2], 16) if match[2] else 0
    return result


for mode, baseline in (("capoff", "baseline-OFF"), ("traceoff", "baseline-ON")):
    actual = digest(base / mode / (image + ".bin"))
    previous = digest(base / baseline / (image + ".bin"))
    assert actual == previous
    assert not any(name.startswith(("falconfoc_capture_", "foc_board_capture_")) for name in symbols(mode))
    print(mode, "is byte-identical to the starting Board1 image", actual)

for mode in ("capon", "captrace"):
    syms = symbols(mode)
    address, size = syms["falconfoc_capture_ram"]
    state = address + 5480
    request, req_size = syms["falconfoc_capture_request"]
    cancel, cancel_size = syms["falconfoc_capture_cancel"]
    assert size == 5492 and req_size == cancel_size == 4
    assert len({request, cancel, address}) == 3 and max(request, cancel) < address
    assert all(0x20000000 <= point < 0x20008000 for point in (address, state, request, cancel))
    assert syms["_estack"][0] - syms["_ebss"][0] >= 4096
    print(mode, "BIN", digest(base / mode / (image + ".bin")))
    print(f"  image=[{address:#x},{state:#x}); request={request:#x}; cancel={cancel:#x}; stack headroom="
          f"{syms['_estack'][0] - syms['_ebss'][0]}")
    for name in ("ADC1_IRQHandler", "TMR5_GLOBAL_IRQHandler", "SPI1_IRQHandler", "foc_at32_spi_finish"):
        print(" ", name, "linked symbol bytes", syms[name][1])

gdb = (repo / "tools/falconfoc-calibration-replay/board_capture_export.gdb").read_text()
writes = re.findall(r"^\s+set \*.*&(falconfoc_capture_\w+)\s*=", gdb, flags=re.M)
assert sorted(writes) == ["falconfoc_capture_cancel", "falconfoc_capture_request"]
assert "if $capture_state == 3" in gdb and "dump binary memory board1.bin" in gdb
assert not re.search(r"^\s*(?:load|program|monitor|target)\b", gdb, flags=re.M)
assert (base / "gdb-witness/board1.bin").read_bytes() == (base / "gdb-witness/host-virtual.bin").read_bytes()
print("GDB export guard, two SRAM mailbox writers, and Host fixture equality verified")

roots = ["calibration", "control_plane", "core", "g3", "protocol", "sensors", "simulation", "platform",
         "firmware/at32f415/src/foc_serial.c", "firmware/at32f415/src/foc_uart_buffer.c",
         "tools/falconfoc-calibration-replay/replay.py"]
changes = subprocess.check_output(["git", "status", "--porcelain", "--", *roots], cwd=repo)
assert not changes, changes
assert not subprocess.check_output(["git", "diff", "--cached", "--name-only"], cwd=repo)
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo).strip() == b"d824933946a365b8081089c2e396d77b3f661bc8"
print("Owning Trace/Replay, control, UART V1, sensor, vendor and Core sources are unchanged; index empty")

with (base / "prior-hashes.csv").open(encoding="utf-8-sig", newline="") as stream:
    old = list(csv.DictReader(stream))
for entry in old:
    entry = {key.lower(): value for key, value in entry.items()}
    assert digest(Path(entry["path"])) == entry["hash"].lower(), entry["path"]
print(f"Prior evidence SHA-256 unchanged for {len(old)} files")