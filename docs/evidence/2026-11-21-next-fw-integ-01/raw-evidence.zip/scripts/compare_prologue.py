"""Compare the locked main() prologue (up to the clock init) of two ELF disassemblies.

Usage: python -I compare_prologue.py <baseline main.dis> <candidate main.dis>
Literal-pool offsets and stack-frame offsets are normalized; instruction
mnemonics, immediates and called functions must match.
"""
import re
import sys


def prologue(path):
    lines = []
    for raw in open(path, encoding="utf-8"):
        match = re.match(r"\s*[0-9a-f]+:\s*(.*)", raw)
        if not match:
            continue
        text = match.group(1)
        text = re.sub(r"[0-9a-f]{7,8} (<[^>]+>)", r"\1", text)
        text = re.sub(r"<main\+0x[0-9a-f]+>", "<main+X>", text)
        text = re.sub(r"@ \([0-9a-f]+ <main\+X>\)", "@ (LIT)", text)
        text = re.sub(r"\[pc, #\d+\]", "[pc, #N]", text)
        text = re.sub(r"sp, #\d+.*", "sp, #S", text)
        text = re.sub(r"\[sp, #S", "[sp", text)
        text = re.sub(r"(add\s+r\d+, )sp, #S", r"\1sp", text)
        lines.append(text.strip())
        if "system_core_clock_update" in text:
            break
    return lines


base = prologue(sys.argv[1])
cand = prologue(sys.argv[2])
print(f"baseline {len(base)} instructions, candidate {len(cand)} instructions")
diffs = [(i, b, c) for i, (b, c) in enumerate(zip(base, cand)) if b != c]
for index, left, right in diffs:
    print(f"{index}: {left!r} != {right!r}")
if len(base) != len(cand):
    print("LENGTH DIFFERS")
    sys.exit(1)
print("PROLOGUE IDENTICAL (normalized)" if not diffs else "PROLOGUE DIFFERS")
sys.exit(1 if diffs else 0)
