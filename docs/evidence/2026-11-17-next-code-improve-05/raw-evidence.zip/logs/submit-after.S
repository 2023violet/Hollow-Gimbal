
C:\Users\16429\AppData\Local\Temp\ff05_2_pr4qyh\builds\arm-after\CMakeFiles\falconfoc-board1.dir\C_\Users\16429\AppData\Local\Temp\ff05_2_pr4qyh\after\runtime\src\foc_pipeline.c.obj:     file format elf32-littlearm


Disassembly of section .text.foc_pipeline_require_rearm:

Disassembly of section .text.foc_pipeline_submit:

00000000 <foc_pipeline_submit>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	f8d0 3140 	ldr.w	r3, [r0, #320]	@ 0x140
   8:	f891 8000 	ldrb.w	r8, [r1]
   c:	f103 0c01 	add.w	ip, r3, #1
  10:	f1b8 0f01 	cmp.w	r8, #1
  14:	460f      	mov	r7, r1
  16:	bf0c      	ite	eq
  18:	f890 e14e 	ldrbeq.w	lr, [r0, #334]	@ 0x14e
  1c:	f890 e14f 	ldrbne.w	lr, [r0, #335]	@ 0x14f
  20:	b086      	sub	sp, #24
  22:	460d      	mov	r5, r1
  24:	f8c0 c140 	str.w	ip, [r0, #320]	@ 0x140
  28:	f100 06e0 	add.w	r6, r0, #224	@ 0xe0
  2c:	4604      	mov	r4, r0
  2e:	cf0f      	ldmia	r7!, {r0, r1, r2, r3}
  30:	c60f      	stmia	r6!, {r0, r1, r2, r3}
  32:	e897 000f 	ldmia.w	r7, {r0, r1, r2, r3}
  36:	e886 000f 	stmia.w	r6, {r0, r1, r2, r3}
  3a:	782b      	ldrb	r3, [r5, #0]
  3c:	b90b      	cbnz	r3, 42 <foc_pipeline_submit+0x42>
  3e:	f8c4 c148 	str.w	ip, [r4, #328]	@ 0x148
  42:	f1be 0f00 	cmp.w	lr, #0
  46:	d022      	beq.n	8e <foc_pipeline_submit+0x8e>
  48:	2000      	movs	r0, #0
  4a:	f000 0c01 	and.w	ip, r0, #1
  4e:	f884 c14c 	strb.w	ip, [r4, #332]	@ 0x14c
  52:	f884 c14d 	strb.w	ip, [r4, #333]	@ 0x14d
  56:	b360      	cbz	r0, b2 <foc_pipeline_submit+0xb2>
  58:	af01      	add	r7, sp, #4
  5a:	cf0f      	ldmia	r7!, {r0, r1, r2, r3}
  5c:	f104 06cc 	add.w	r6, r4, #204	@ 0xcc
  60:	c60f      	stmia	r6!, {r0, r1, r2, r3}
  62:	f1b8 0f01 	cmp.w	r8, #1
  66:	683b      	ldr	r3, [r7, #0]
  68:	6033      	str	r3, [r6, #0]
  6a:	d10c      	bne.n	86 <foc_pipeline_submit+0x86>
  6c:	f8d4 3144 	ldr.w	r3, [r4, #324]	@ 0x144
  70:	3301      	adds	r3, #1
  72:	f8c4 3144 	str.w	r3, [r4, #324]	@ 0x144
  76:	f504 7480 	add.w	r4, r4, #256	@ 0x100
  7a:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
  7c:	c40f      	stmia	r4!, {r0, r1, r2, r3}
  7e:	e895 000f 	ldmia.w	r5, {r0, r1, r2, r3}
  82:	e884 000f 	stmia.w	r4, {r0, r1, r2, r3}
  86:	4660      	mov	r0, ip
  88:	b006      	add	sp, #24
  8a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  8e:	f8d4 2090 	ldr.w	r2, [r4, #144]	@ 0x90
  92:	4629      	mov	r1, r5
  94:	a801      	add	r0, sp, #4
  96:	f7ff fffe 	bl	0 <foc_device_sim_submit>
			96: R_ARM_THM_CALL	foc_device_sim_submit
  9a:	2800      	cmp	r0, #0
  9c:	d1d4      	bne.n	48 <foc_pipeline_submit+0x48>
  9e:	f8d4 3150 	ldr.w	r3, [r4, #336]	@ 0x150
  a2:	b123      	cbz	r3, ae <foc_pipeline_submit+0xae>
  a4:	f8d4 0154 	ldr.w	r0, [r4, #340]	@ 0x154
  a8:	4629      	mov	r1, r5
  aa:	4798      	blx	r3
  ac:	e7cd      	b.n	4a <foc_pipeline_submit+0x4a>
  ae:	2001      	movs	r0, #1
  b0:	e7cb      	b.n	4a <foc_pipeline_submit+0x4a>
  b2:	f1b8 0f01 	cmp.w	r8, #1
  b6:	d1e6      	bne.n	86 <foc_pipeline_submit+0x86>
  b8:	f504 7490 	add.w	r4, r4, #288	@ 0x120
  bc:	e7dd      	b.n	7a <foc_pipeline_submit+0x7a>

Disassembly of section .text.foc_pipeline_emit_inhibit:

Disassembly of section .text.foc_pipeline_stop:

Disassembly of section .text.foc_pipeline_accept_time:

Disassembly of section .text.foc_pipeline_after_recovery:

Disassembly of section .text.foc_pipeline_input_newer:

Disassembly of section .text.foc_pipeline_ready_inputs:

Disassembly of section .text.foc_pipeline_init:

Disassembly of section .text.foc_pipeline_set_command:

Disassembly of section .text.foc_pipeline_arm:

Disassembly of section .text.foc_pipeline_start:

Disassembly of section .text.foc_pipeline_request_inhibit:

Disassembly of section .text.foc_pipeline_clear_fault:

Disassembly of section .text.foc_pipeline_step_guarded:

Disassembly of section .text.foc_pipeline_step:
