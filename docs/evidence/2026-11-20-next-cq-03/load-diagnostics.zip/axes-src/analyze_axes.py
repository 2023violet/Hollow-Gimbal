import csv
import json
from itertools import groupby
from pathlib import Path
from sys import argv

folder=Path(argv[1])
with (folder/'axes-48.csv').open(encoding='ascii', newline='') as f:
    lines=list(f)
pi=list(csv.DictReader(line for line in lines if line.startswith('AXIS_PI,')))
record=[]
for (mode,phase),group in groupby(pi, key=lambda row:(row['mode'], row['phase'])):
    rows=list(group)
    record.append({
        'mode': int(mode), 'phase': int(phase),
        'samples': len(rows),
        'int_first_a':float(rows[0]['integral_a']),
        'int_last_a':float(rows[-1]['integral_a']),
        'int_abs_peak_a':max(abs(float(r['integral_a'])) for r in rows),
        'trial_abs_peak_a':max(abs(float(r['trial_a'])) for r in rows),
        'iq_ref_at_limit_1ms_samples':sum(abs(float(r['iq_ref_a'])) >= 0.25-1e-6 for r in rows),
        'voltage_limited_updates_count_end':int(rows[-1]['voltage_limited_updates']),
    })
fault=list(csv.DictReader(line for line in lines if line.startswith('AXIS_FAULT,')))
performance=list(csv.DictReader(line for line in lines if line.startswith('AXIS_RESULT,')))
summary={'pi':record, 'fault':fault,'performance':performance}
(folder/'axes-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for row in record:
 print(row)
for row in fault:
 print(row)
