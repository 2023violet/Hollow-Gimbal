from pathlib import Path
import importlib
import json
import sys
from zipfile import ZipFile, ZipInfo

root = Path(__file__).resolve().parent
repo = Path.cwd()
dist = Path(sys.argv[1])
sys.path.insert(0, str(repo / "scripts/sdk"))
pack = importlib.import_module("build_sdk_package")
gate = importlib.import_module("check_sdk_package")
archive = dist / "falconfoc-servo-sdk-0.1.0-rc.1.zip"
mapping = pack.MAP.read_bytes()

def rejected(label, callback, expected):
    try:
        callback()
    except ValueError as error:
        assert expected in str(error), (label, str(error))
        print(f"{label}: rejected ({error})", flush=True)
    else:
        raise AssertionError(label)

def fixture(label, transform):
    directory=root / ("negative " + label)
    directory.mkdir()
    for name in (pack.MANIFEST_NAME, pack.METADATA_NAME, gate.PATCH_NAME):
        (directory/name).write_bytes((dist/name).read_bytes())
    copied=directory/archive.name
    with ZipFile(archive) as old, ZipFile(copied, "x") as new:
        payload=[(m,old.read(m)) for m in old.infolist()]
        for entry,data in transform(payload,directory):
            new.writestr(entry,data)
    copied.with_name(copied.name + ".sha256").write_bytes(
        f"{pack.sha256(copied.read_bytes())}  {copied.name}\n".encode())
    return copied

rejected("source path traversal", lambda: pack.safe_parts("../not-sdk.c"), "Unsafe path")
rejected("source path with drive", lambda: pack.safe_parts("C:/not-sdk.c"), "Unsafe path")
rejected("DOS special file alias", lambda: pack.safe_parts("core/CON.h"), "Unsafe path")
rejected("environment file", lambda: pack.safe_parts("code/.env"), "Unsafe path")
spec = json.loads(mapping)
spec["files"][0]["path"] = "build/sdk/CMakeLists.txt"
rejected("generated tree mapped", lambda: pack.load_map(pack.json_bytes(spec)), "Generated tree")

bad_file=fixture("content hash", lambda payload, _: [
    (member, data+b"changed") if member.filename.endswith("/core/src/foc_core.c") else (member,data)
    for member,data in payload])
rejected("payload changed with outer checksum updated",
         lambda: gate.read_sdk(bad_file,mapping,root/"unwritten content"), "Payload hash mismatch")
extra=fixture("unlisted", lambda payload, _: payload + [
    (ZipInfo(f"{archive.stem}/NOT-ON-MANIFEST.md"), b"")])
rejected("unlisted file", lambda: gate.read_sdk(extra,mapping,root/"unwritten extra"), "Unlisted or duplicate")
missing=fixture("missing", lambda payload, _: [
    (member,data) for member,data in payload if not member.filename.endswith("/core/src/foc_core.c")])
rejected("missing file", lambda: gate.read_sdk(missing,mapping,root/"unwritten missing"), "Files are missing")
duplicate=fixture("duplicate", lambda payload, _: payload+payload[:1])
rejected("duplicate member", lambda: gate.read_sdk(duplicate,mapping,root/"unwritten duplicate"), "Unlisted or duplicate")
bad_name=fixture("path member", lambda payload,_: payload + [
    (ZipInfo(f"{archive.stem}/../elsewhere"), b"")])
rejected("outside extraction path", lambda: gate.read_sdk(bad_name,mapping,root/"unwritten path"), "Unsafe path")

def change_blob_sha(payload, destination):
    rows = json.loads((dist/pack.MANIFEST_NAME).read_bytes())
    next(row for row in rows["files"] if row["source_state"]=="tracked")["git_blob_sha256"]="f"*64
    manifest = pack.json_bytes(rows)
    metadata = json.loads((dist/pack.METADATA_NAME).read_bytes())
    metadata["manifest_sha256"] = pack.sha256(manifest)
    metadata = pack.json_bytes(metadata)
    replace={pack.MANIFEST_NAME:manifest,pack.METADATA_NAME:metadata}
    for name, content in replace.items():
        (destination/name).write_bytes(content)
    return [(m,replace.get(m.filename.split("/")[-1],d)) for m,d in payload]

bad_git=fixture("git blob",change_blob_sha)
rejected("tracked Git byte mismatch with updated manifest and archive hashes",
         lambda: gate.read_sdk(bad_git,mapping,root/"unwritten git"), "Unchanged source disagrees with Git blob")
assert not any(root.glob("unwritten *"))
print("No invalid archive extracted.")

