NEXT-SOFT-03 software evidence
The patch applies to the pre-task working snapshot, including locally delivered SOFT-01/02.
The patch excludes the archive itself. The power cuts are Host model evidence.
