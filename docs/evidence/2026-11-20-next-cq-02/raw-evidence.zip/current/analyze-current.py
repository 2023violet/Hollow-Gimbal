"""Derive sample-level attribution from the unchanged CQ-01 Current wire replay."""

import csv
import hashlib
import json
import math
import sys
from pathlib import Path


SCHEMAS = {
    "CONFIG": (
        "rs_ohm ld_h lq_h psi_f_wb pole_pairs motor_offset_rad inertia_kg_m2 damping_nm_s "
        "initial_id_a initial_iq_a initial_position_rad initial_velocity_rad_s load_nm vbus_v "
        "kp_d kp_q ki_d ki_q current_limit_a voltage_limit_v vbus_min_v h0_period_us h1_period_us "
        "foreground_period_us adc_a_per_count offset_a offset_b offset_c adc_noise_counts "
        "encoder_cpr pwm_period_counts encoder_lpf_hz max_prediction_us angle_timeout_us "
        "controller_offset_rad pi_max_dt_s motion_iq_limit_a feedforward_enabled"
    ),
    "INPUT": (
        "time_us adc_us adc_seq raw_vbus raw_rank2 raw_rank3 raw_rank4 encoder_us encoder_seq "
        "aligned_theta_rad dt_s prior_state command_seq source_theta_rad"
    ),
    "PI": (
        "target_d_a target_q_a adc_id_a adc_iq_a prev_id_i_v prev_iq_i_v next_id_i_v next_iq_i_v "
        "request_vd_v request_vq_v core_voltage_d_v core_voltage_q_v saturated current_limited cap_v"
    ),
    "H1": "time_us sensor_us sensor_seq encoder_code source_theta_rad shaft_velocity_rad_s status phase_valid speed_valid",
    "H0": (
        "time_us trigger_us last_heartbeat_us dt_us delay_us missed status pipeline_status state "
        "action confirmed inhibit_pending lifecycle_action lifecycle_result lifecycle_us "
        "updates rejected motor_id_a motor_iq_a motor_position_rad motor_speed_rad_s "
        "motor_theta_rad alpha_v beta_v integral_d_v integral_q_v compare1 compare2 compare3 "
        "duty_a duty_b duty_c faults"
    ),
    "PLANT": (
        "time_us id_a iq_a position_rad speed_rad_s theta_rad alpha_v beta_v mode updates "
        "last_update_us"
    ),
}


def number(value):
    try:
        return int(value)
    except ValueError:
        return float(value)


def trace(path):
    rows = {tag: [] for tag in SCHEMAS}
    h0_input_us = None
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.startswith("CQ02,"):
            continue
        _, tag, *fields = line.split(",")
        record = dict(zip(SCHEMAS[tag].split(), map(number, fields), strict=True))
        if tag == "INPUT":
            h0_input_us = record["time_us"]
        elif tag == "PI":
            assert h0_input_us is not None
            record = {"time_us": h0_input_us, **record}
        rows[tag].append(record)
    return rows


def rc_step(iq, voltage, dt_s, rs, lq):
    decay = math.exp(-dt_s * rs / lq)
    return decay * iq + (1.0 - decay) * voltage / rs


def ideal_pi(start_us, kp, ki, config, final_us):
    """Analytic zero-order hold at fixed angle with exact, unquantized current feedback."""
    dt_us = config["h0_period_us"]
    rs, lq = config["rs_ohm"], config["lq_h"]
    observed = {}
    iq = integral = voltage = 0.0
    for timestamp_us in range(start_us, final_us + 1, 100):
        if timestamp_us != start_us:
            iq = rc_step(iq, voltage, 100e-6, rs, lq)
        observed[timestamp_us] = iq
        if (timestamp_us - start_us) % dt_us == 0:
            error = 0.4 - iq
            integral += ki * dt_us * 1e-6 * error
            voltage = kp * error + integral
            assert abs(voltage) < config["voltage_limit_v"]
    return observed


def dq(alpha, beta, angle):
    sine, cosine = math.sin(angle), math.cos(angle)
    return [alpha * cosine + beta * sine, -alpha * sine + beta * cosine]


def pmsm_step(state, vd, vq, duration_us, config):
    """Integrate held stationary voltage from a fixed initial rotor reference."""
    nsteps = max(1, math.ceil(duration_us / 2))
    step_s = (duration_us / nsteps) * 1e-6
    rs, ld, lq, flux = (config[f] for f in ("rs_ohm", "ld_h", "lq_h", "psi_f_wb"))
    pairs, inertia, damp = (config[f] for f in ("pole_pairs", "inertia_kg_m2", "damping_nm_s"))
    initial_position = state[2]

    def derivative(value):
        id_a, iq_a, position_rad, velocity = value
        angle = pairs * (position_rad - initial_position)
        voltage_d, voltage_q = dq(vd, vq, angle)
        electrical_speed = pairs * velocity
        torque = 1.5 * pairs * (flux + (ld - lq) * id_a) * iq_a
        return (
            (voltage_d - rs * id_a + electrical_speed * lq * iq_a) / ld,
            (voltage_q - rs * iq_a - electrical_speed * (ld * id_a + flux)) / lq,
            velocity,
            (torque - damp * velocity - config["load_nm"]) / inertia,
        )

    def add(value, derivative, duration_s):
        return tuple(x + duration_s * dx for x, dx in zip(value, derivative, strict=True))

    for _ in range(nsteps):
        a = derivative(state)
        b = derivative(add(state, a, step_s / 2.0))
        c = derivative(add(state, b, step_s / 2.0))
        d = derivative(add(state, c, step_s))
        average = tuple((w + 2.0*x + 2.0*y + z) / 6.0 for w, x, y, z in zip(a, b, c, d))
        state = add(state, average, step_s)
    return state


def rms(values):
    return math.sqrt(sum(x * x for x in values) / len(values))


def main(output):
    raw = trace(output / "trace-wire.stderr")
    [config] = raw["CONFIG"]
    data = {
        tag: {row["time_us"]: row for row in rows}
        for tag, rows in raw.items() if tag != "CONFIG"
    }
    for tag, rows in raw.items():
        with (output / f"current-{tag.lower()}.csv").open("w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    historical = json.loads((output / "historical-current.json").read_text(encoding="utf-8"))
    metrics = historical["metrics"]
    assert metrics["control_quality"] == "CONTROL_QUALITY_FAIL"
    historical_bytes = (output / "historical-current.csv").read_bytes()
    assert historical_bytes == (output / "trace-current.csv").read_bytes()
    sha = hashlib.sha256(historical_bytes).hexdigest()
    with (output / "historical-current.csv").open(encoding="utf-8", newline="") as trace_file:
        historical_records = list(csv.DictReader(trace_file))
    actual_records = [r for r in historical_records if r["state"] == "3" and r["output_action"] == "1"]
    outside = [
        int(r["virtual_time_us"]) for r in actual_records
        if abs(float(r["iq_target_a"]) - float(r["iq_actual_a"])) > metrics["tolerance"]
    ]
    assert outside == [3000, 3500, 4000]
    stop_us = next(t for t, h in data["H0"].items() if t > 13000 and h["action"] == 0)
    first_us = min(data["PI"])
    start_us = data["H0"][first_us]["lifecycle_us"]
    assert (start_us, first_us, stop_us) == (2600, 2800, 13200)
    assert data["H0"][start_us]["state"] == 3 and data["H0"][start_us]["action"] == 0
    assert data["H0"][first_us]["updates"] == 1
    assert all(
        h["confirmed"] and h["state"] == 1 and h["action"] == 0 and h["faults"] == 0
        and not h["inhibit_pending"] and h["updates"] == 52
        for now, h in data["H0"].items() if now >= stop_us
    )
    for record in historical_records[1:]:
        plant = data["PLANT"][int(record["virtual_time_us"])]
        assert abs(plant["iq_a"] - float(record["iq_actual_a"])) <= 3e-8
        assert abs(plant["id_a"] - float(record["id_actual_a"])) <= 3e-8
        assert plant["updates"] == int(record["virtual_update_accepted"])

    first_window = [t for t in data["PI"] if first_us <= t <= max(outside)]
    reconstruction_delta = []
    angle_delta = []
    adc_delta = []
    dq_quantization_errors = []
    for now, pi in data["PI"].items():
        h0, inp = data["H0"][now], data["INPUT"][now]
        assert h0["updates"] == (now - first_us) // config["h0_period_us"] + 1
        assert h0["action"] == 1 and h0["confirmed"] and h0["rejected"] == 0
        assert (h0["delay_us"], h0["missed"], h0["dt_us"]) == (0, 0, 200)
        assert inp["adc_us"] == now and now - inp["encoder_us"] <= config["max_prediction_us"]
        assert not pi["saturated"] and not pi["current_limited"]
        assert h0["integral_q_v"] == pi["next_iq_i_v"] and h0["integral_d_v"] == pi["next_id_i_v"]
        assert abs(pi["next_iq_i_v"] - pi["prev_iq_i_v"]
                   - config["ki_q"] * inp["dt_s"] * (pi["target_q_a"] - pi["adc_iq_a"])) < 4e-8
        if now > first_us:
            assert pi["prev_iq_i_v"] == data["H0"][now - 200]["integral_q_v"]
        observed_vd, observed_vq = dq(h0["alpha_v"], h0["beta_v"], inp["aligned_theta_rad"])
        reconstruction_delta.append(math.hypot(observed_vd - pi["request_vd_v"],
                                              observed_vq - pi["request_vq_v"]))
        if now in first_window:
            angle_delta.append(abs(inp["aligned_theta_rad"] - h0["motor_theta_rad"]))
            adc_delta.append(abs(pi["adc_iq_a"] - h0["motor_iq_a"]))
            dq_quantization_errors.append(math.hypot(
                pi["adc_id_a"] - h0["motor_id_a"], pi["adc_iq_a"] - h0["motor_iq_a"]))

    rs, lq = config["rs_ohm"], config["lq_h"]
    dt_us = config["h0_period_us"]
    cap = config["voltage_limit_v"]
    omega_130 = math.tau * 130.0
    historical_omega = config["kp_q"] / lq
    # The accepted CQ-01 timing envelope has a 360 us worst sample period.
    # Also show the more permissive bound for this exact 200 us Host fixture.
    omega_200_limit = 0.3 / (dt_us * 1e-6)
    omega_360_limit = 0.3 / (360e-6)
    ideal = {
        "ideal_legacy": ideal_pi(first_us, config["kp_q"], config["ki_q"], config, 4500),
        "ideal_no_lifecycle_h0": ideal_pi(start_us, config["kp_q"], config["ki_q"], config, 4500),
        "ideal_130hz": ideal_pi(first_us, lq * omega_130, rs * omega_130, config, 4500),
        "ideal_200us_bandwidth_bound": ideal_pi(
            first_us, lq * omega_200_limit, rs * omega_200_limit, config, 4500),
        "ideal_360us_bandwidth_bound": ideal_pi(
            first_us, lq * omega_360_limit, rs * omega_360_limit, config, 4500),
    }
    points = []
    for timestamp in outside + [4500]:
        hold = data["PLANT"][timestamp]
        prior_hold = data["PLANT"][timestamp - 100]
        serviced_us = hold["last_update_us"]
        inp, pi, h0 = (data[tag][serviced_us] for tag in ("INPUT", "PI", "H0"))
        latest_encoder = data["H1"][(timestamp // config["h1_period_us"]) * config["h1_period_us"]]
        points.append({
            "observation_us": timestamp,
            "elapsed_since_start_us": timestamp - start_us,
            "elapsed_since_first_energized_us": timestamp - first_us,
            "plant": hold,
            "absolute_q_error_a": abs(pi["target_q_a"] - hold["iq_a"]),
            "h0_used": h0,
            "h0_input": inp,
            "adc_age_at_h0_us": serviced_us - inp["adc_us"],
            "adc_age_at_observation_us": timestamp - inp["adc_us"],
            "encoder_age_at_h0_us": serviced_us - inp["encoder_us"],
            "encoder_used_at_h0": data["H1"][inp["encoder_us"]],
            "encoder_latest_at_observation": latest_encoder,
            "newly_held_voltage_dq_at_observation_angle": dq(
                hold["alpha_v"], hold["beta_v"], hold["theta_rad"]),
            "preceding_interval_voltage_dq_at_observation_angle": dq(
                prior_hold["alpha_v"], prior_hold["beta_v"], hold["theta_rad"]),
            "preceding_interval_update_us": prior_hold["last_update_us"],
            "pi": pi,
            "model_q_a": {label: values[timestamp] for label, values in ideal.items()},
        })

    first_elapsed_s = (outside[0] - first_us) * 1e-6
    min_iq = 0.4 - metrics["tolerance"]
    min_v = min_iq * rs / -math.expm1(-first_elapsed_s * rs / lq)
    cap_min_time_s = -lq / rs * math.log1p(-min_iq * rs / cap)
    stop_sample_us = [13200, 13300, 13500, 14000, 14500]
    stop_compare = [{
        "time_us": t,
        "actual_iq_a": data["PLANT"][t]["iq_a"],
        "rl_zero_voltage_iq_a": rc_step(
            data["PLANT"][stop_us]["iq_a"], 0.0, (t - stop_us) * 1e-6, rs, lq),
        "actual_voltage_v": math.hypot(data["PLANT"][t]["alpha_v"], data["PLANT"][t]["beta_v"]),
        "accepted_updates": data["PLANT"][t]["updates"],
    } for t in stop_sample_us]
    stopped_state = data["PLANT"][stop_us]
    stop_initial = tuple(stopped_state[f] for f in ("id_a", "iq_a", "position_rad", "speed_rad_s"))
    for row in stop_compare:
        row["pmsm_zero_voltage_iq_a"] = pmsm_step(
            stop_initial, 0.0, 0.0, row["time_us"] - stop_us, config)[1]
        assert abs(row["actual_iq_a"] - row["pmsm_zero_voltage_iq_a"]) < 1e-7

    # An optimistic plant-only bound/counterexample. This is not a controller
    # proposal or a change to the historical input, gain, voltage, or verdict.
    max_initial_state = pmsm_step((0.0, 0.0, 0.0, 0.0), 0.0, cap, outside[0] - first_us, config)
    cap_then_hold = {
        t: pmsm_step(max_initial_state, 0.0, rs * 0.4, t - outside[0], config)[1]
        for t in outside
    }
    assert all(min_iq <= iq <= 0.4 + metrics["tolerance"] for iq in cap_then_hold.values())

    report = {
        "historical_csv_sha256": sha,
        "historical_verdict": metrics["control_quality"],
        "historical_tolerance_a": metrics["tolerance"],
        "full_rmse_a": metrics["full_window_rmse"],
        "full_peak_a": metrics["peak_error"],
        "full_final_a": metrics["final_error"],
        "running_rmse_a": metrics["running_window_rmse"],
        "running_peak_a": metrics["transient_peak_error"],
        "running_tail_rmse_a": metrics["running_tail_rmse"],
        "h0_window_includes_first_update": {
            "start_us": first_us, "end_us": max(data["PI"]),
            "rmse_a": rms([data["PI"][t]["target_q_a"] - data["H0"][t]["motor_iq_a"]
                          for t in data["PI"]]),
            "peak_error_a": max(abs(data["PI"][t]["target_q_a"] - data["H0"][t]["motor_iq_a"])
                                for t in data["PI"]),
        },
        "start_h0_us": start_us,
        "first_update_us": first_us,
        "last_update_us": max(data["PI"]),
        "stop_inhibit_confirmed_us": stop_us,
        "saturated_updates": sum(pi["saturated"] for pi in data["PI"].values()),
        "saturated_duration_us": 0,
        "peak_h0_requested_voltage_v": max(
            math.hypot(pi["request_vd_v"], pi["request_vq_v"]) for pi in data["PI"].values()),
        "accepted_updates": len(data["PI"]),
        "rejected_updates": data["H0"][stop_us]["rejected"],
        "accepted_updates_after_stop": 0,
        "stop_decay": stop_compare,
        "diagnostic_maxima": {
            "plant_vs_ideal_legacy_q_a": max(
                abs(point["plant"]["iq_a"] - point["model_q_a"]["ideal_legacy"]) for point in points),
            "adc_minus_plant_q_a_at_h0_through_4000us": max(adc_delta),
            "adc_minus_plant_dq_norm_a_at_h0_through_4000us": max(dq_quantization_errors),
            "electrical_angle_error_rad_at_h0_through_4000us": max(angle_delta),
            "core_request_vs_applied_alpha_beta_v": max(reconstruction_delta),
        },
        "rl_feasibility": {
            "full_pmsm_plant_only_cap_then_hold_iq_a": cap_then_hold,
            "frozen_pi_equivalent_hz": historical_omega / math.tau,
            "electrical_time_constant_s": lq / rs,
            "required_first_sample_iq_a": min_iq,
            "constant_vq_needed_to_hit_floor_at_first_sample_v": min_v,
            "max_constant_vq_ideal_iq_at_first_sample_a": rc_step(0.0, cap, first_elapsed_s, rs, lq),
            "earliest_ideal_at_cap_to_hit_floor_s": cap_min_time_s,
            "first_cycle_actual_request_v": data["PI"][first_us]["request_vq_v"],
            "first_cycle_vq_bound_timing_design_200us_v": (
                0.4 * omega_200_limit * (lq + rs * dt_us * 1e-6)),
            "first_cycle_vq_bound_timing_design_360us_v": (
                0.4 * omega_360_limit * (lq + rs * dt_us * 1e-6)),
            "first_cycle_vq_bound_timing_design_200us_hz": omega_200_limit / math.tau,
            "first_cycle_vq_bound_timing_design_360us_hz": omega_360_limit / math.tau,
        },
        "samples": points,
        "config": config,
    }
    (output / "current-attribution.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    for key in ("historical_verdict", "historical_csv_sha256", "full_rmse_a", "running_rmse_a",
                "running_peak_a", "start_h0_us", "first_update_us", "stop_inhibit_confirmed_us",
                "accepted_updates", "diagnostic_maxima", "rl_feasibility"):
        print(key, report[key])
    for point in points:
        print(point["observation_us"], point["plant"]["iq_a"], point["absolute_q_error_a"],
              point["model_q_a"])


if __name__ == "__main__":
    main(Path(sys.argv[1]))


