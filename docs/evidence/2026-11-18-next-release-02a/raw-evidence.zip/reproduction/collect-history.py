"""Inventory committed history, package bytes, notice markers, and include closure."""

import collections
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
from hashlib import sha256
from zipfile import ZipFile

dist = Path(sys.argv[1])
out = Path(sys.argv[2])
repo = Path.cwd()
archive = dist / "falconfoc-servo-sdk-0.1.0-rc.1.zip"
manifest = json.loads((dist / "SDK-SOURCE-MANIFEST.json").read_bytes())
metadata = json.loads((dist / "SDK-METADATA.json").read_bytes())
head = metadata["source_git_commit"]
format_string = "--format=%H%x09%aI%x09%an%x09%s"


def git(*args):
    return subprocess.check_output(["git", "-c", "core.quotePath=false", *args], cwd=repo)


def text(*args):
    return git(*args).decode("utf8", "replace").strip()


def entries(data):
    result = []
    for line in data.splitlines():
        commit, author_date, author, subject = line.split("\t", 3)
        result.append(dict(commit=commit, date=author_date, author=author, subject=subject))
    return result


def markers(data):
    pattern = re.compile(r"copyright|spdx|(?:all rights reserved)|(?:licen[cs]ed under)|"
                         r"(?:derived from)|(?:adapted from)|(?:ported from)|GNU General Public License", re.I)
    return [dict(line=n, text=line.strip()) for n, line in enumerate(data.splitlines(), 1)
            if pattern.search(line)]


def content_id(data):
    return {"bytes": len(data), "sha256": sha256(data).hexdigest()}


root = archive.stem
with ZipFile(archive) as zip_file:
    payload = {row["path"]: zip_file.read(f"{root}/{row['path']}") for row in manifest["files"]}
assert len(payload) == 52
headers = {PurePosixPath(name).name: name for name in payload if name.endswith(".h")}
assert len(headers) == sum(name.endswith(".h") for name in payload)

records = []
for row in manifest["files"]:
    path = row["path"]
    source = row["source"]
    body = payload[path].decode("utf8")
    result = {**row, "notice_markers": markers(body)}
    result["includes"] = [
        {"kind": "project" if delim == '"' else "system",
         "name": name, "resolved": headers.get(name) if delim == '"' else None}
        for delim, name in re.findall(r'^\s*#\s*include\s*(["<])([^">]+)[">]', body, re.M)
        if path.endswith((".c", ".h"))
    ]
    assert all(inc["resolved"] for inc in result["includes"] if inc["kind"] == "project"), path
    if row["source_state"] == "tracked":
        assert git("show", f"{head}:{source}") == payload[path], path
        history = entries(text("log", "--follow", format_string, head, "--", source))
        result["head_history"] = history
        result["reachable_path_adds"] = entries(text(
            "log", "--all", "--full-history", "--diff-filter=A", format_string, "--", source
        ))
        result["blame_head_authors"] = dict(collections.Counter(
            line[7:] for line in text("blame", "-w", "--line-porcelain", head, "--", source).splitlines()
            if line.startswith("author ")
        ))
        start = history[-1]
        assert start["commit"] == row["git_first_add"], path
        start_content = git("show", f"{start['commit']}:{source}")
        result["original_blob"] = {
            **content_id(start_content),
            "git_blob": text("rev-parse", f"{start['commit']}:{source}"),
            "markers": markers(start_content.decode("utf8")),
        }
        result["first_add_parents"] = text("show", "-s", "--format=%P", start["commit"]).split()
        result["numstat_since_introduction"] = text("diff", "--numstat", start["commit"], head, "--", source)
        if row["origin"] == "origin_unresolved":
            original = out / "first-introduction" / source
            original.parent.mkdir(parents=True, exist_ok=True)
            original.write_bytes(start_content)
            result["exact_blob_history_all_refs"] = entries(text(
                "log", "--all", f"--find-object={result['original_blob']['git_blob']}", format_string
            ))
            for parent in result["first_add_parents"]:
                assert not git("ls-tree", "-r", parent, "--", source), source
    else:
        assert row["source_state"] == "untracked", path
        assert not git("ls-tree", "-r", head, "--", source), path
        assert Path(source).read_bytes() == payload[path], path
        result["reachable_path_adds"] = entries(text(
            "log", "--all", "--full-history", "--diff-filter=A", format_string, "--", source
        ))
        result["source_record"] = "03B dirty snapshot, exact archived bytes"
    records.append(result)

scope = dict(
    git_shallow=text("rev-parse", "--is-shallow-repository"),
    git_head=text("rev-parse", "HEAD"),
    refs=text("for-each-ref", "--format=%(refname) %(objectname)", "refs/heads", "refs/remotes", "refs/tags"),
    root_license_history=text("log", "--all", format_string, "--", ":(top,glob)LICENSE*",
                              ":(top,glob)COPYING*", ":(top,glob)NOTICE*"),
    head_root_files=text("ls-tree", "--name-only", head),
    identity_counts=dict(collections.Counter(row["source_state"] for row in records)),
    first_add_counts=dict(collections.Counter(
        row["head_history"][-1]["commit"][:7] for row in records if "head_history" in row
    )),
    include_counts=dict(collections.Counter(inc["kind"] for row in records for inc in row["includes"])),
    unknown_paths=[row["path"] for row in records if row["origin"]=="origin_unresolved"],
    paylod_marker_files=[row["path"] for row in records if row["notice_markers"]],
)
(out / "history.json").write_text(json.dumps(records, indent=2, ensure_ascii=False) + "\n", encoding="utf8")
(out / "scope.json").write_text(json.dumps(scope, indent=2, ensure_ascii=False) + "\n", encoding="utf8")
print(json.dumps({k:scope[k] for k in ("identity_counts", "first_add_counts", "include_counts",
                                      "paylod_marker_files")},ensure_ascii=False,indent=2))

