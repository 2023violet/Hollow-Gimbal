
from pathlib import Path
from collections import Counter
import subprocess as sp
import re
import hashlib

root = Path(__file__).parent
baseline = root / "protected"
work = Path.cwd()
past = Path(r"C:/Users/16429/AppData/Local/Temp/sensorest_94ba764379474bf6a4ba3a6c66fe6307")
out = root / "arm-compare"
out.mkdir(exist_ok=True)
probe = out / "probe.c"
probe.write_text('#include "foc_encoder.h"\n'
                 'const unsigned char encoder_context_bytes[sizeof(struct foc_encoder_context)] = {0};\n'
                 'const unsigned char encoder_feedback_bytes[sizeof(struct foc_encoder_feedback)] = {0};\n')
flags = ["-std=c11", "-mcpu=cortex-m4", "-mthumb", "-mfloat-abi=soft", "-Os",
         "-ffunction-sections", "-fdata-sections", "-fstack-usage", "-Wall", "-Wextra",
         "-Wpedantic", "-Werror"]
def capture(*cmd):
    return sp.check_output(cmd, text=True, stderr=sp.STDOUT)
print(capture("arm-none-eabi-gcc", "--version").splitlines()[0])
print("FLAGS", " ".join(flags))
for label, tree, firmware in [("before", baseline, past/"final/locked-arm"),
                              ("after", work, root/"final/locked-arm")]:
    lane = out / label
    lane.mkdir(exist_ok=True)
    inc = tree / "sensors/include"
    obj = lane / "encoder.o"
    sizes = lane / "probe.o"
    for src, dest in [(tree/"sensors/src/foc_encoder.c", obj), (probe, sizes)]:
        cmd = ("arm-none-eabi-gcc", *flags, "-I", str(inc), "-c", str(src), "-o", str(dest))
        print(sp.list2cmdline(cmd))
        capture(*cmd)
    symbols = capture("arm-none-eabi-nm", "-S", "--size-sort", obj)
    undefined = capture("arm-none-eabi-nm", "-u", obj)
    disasm = capture("arm-none-eabi-objdump", "-dr", obj)
    probe_symbols = capture("arm-none-eabi-nm", "-S", "--radix=d", sizes)
    size = capture("arm-none-eabi-size", obj)
    (lane/"encoder-disasm.txt").write_text(disasm)
    (lane/"encoder-symbols.txt").write_text(symbols + "\n" + undefined)
    (lane/"probe-size.txt").write_text(probe_symbols)
    update = disasm.split("<foc_encoder_update>:", 1)[1].split("Disassembly of section")[0]
    callsites = Counter(re.findall(r"R_ARM_(?:THM_CALL|THM_JUMP24)\s+(__aeabi_\w+)", update))
    instructions = []
    for line in update.splitlines():
        match = re.match(r"\s*[0-9a-f]+:\s+[0-9a-f]{4}(?: [0-9a-f]{4})?\s+([a-z][\w.]*)", line)
        if match:
            instructions.append(match.group(1).split(".")[0])
    print(label, size, probe_symbols, sep="\n")
    print(next(l for l in symbols.splitlines() if l.endswith(" T foc_encoder_update")))
    print(next(l for l in obj.with_suffix(".su").read_text().splitlines() if "foc_encoder_update" in l))
    print("static_update_instructions", len(instructions))
    print("static_update_aeabi_calls", dict(sorted(callsites.items())))
    print("static_update_instruction_counts", dict(sorted(Counter(instructions).items())))
    print("object_undefined_symbols", " ".join(undefined.split()))
    elf = next(firmware.glob("*.elf"))
    binary = next(firmware.glob("*.bin"))
    print(capture("arm-none-eabi-size", elf))
    print("LOCKED_BIN", binary.stat().st_size, hashlib.sha256(binary.read_bytes()).hexdigest())

