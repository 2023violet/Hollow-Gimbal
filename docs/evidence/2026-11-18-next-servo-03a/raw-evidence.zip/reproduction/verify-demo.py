from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os, shutil, subprocess as sp, sys

root = Path(__file__).resolve().parent
repo = Path.cwd()
demo = root / "foreign Servo Demo"
demo.mkdir(exist_ok=True)
for source in (repo / "examples/servo").iterdir():
    shutil.copy2(source, demo / source.name)

sdk = root / "FalconFOC SDK Source"
assert not (sdk / ".git").exists()
assert not (demo / ".git").exists()
env = os.environ.copy()
resource = sp.check_output(["clang", "-print-resource-dir"], text=True).strip()
env["PATH"] = os.pathsep.join([r"C:\mingw64\bin", str(Path(resource) / "lib/windows"), env["PATH"]])
env["ASAN_OPTIONS"] = "halt_on_error=1"
env["UBSAN_OPTIONS"] = "halt_on_error=1:print_stacktrace=1"

def verify(label, source, out, compiler, extra=()):
    exe = out / "falconfoc-servo-demo.exe"
    with (root / (label + ".log")).open("w", encoding="utf8") as log:
        commands = [
            [compiler, "--version"],
            ["cmake", "-S", source, "-B", out, "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Debug",
             "-DCMAKE_C_COMPILER=" + compiler, *extra],
            ["cmake", "--build", out, "--target", "falconfoc-servo-demo", "--parallel", "6", "--verbose"],
            ["ninja", "-C", out, "-t", "commands", "falconfoc-servo-demo"],
            [exe], [exe, "--faults"],
            ["ctest", "--test-dir", out, "-R", "^test-falconfoc-servo-", "--output-on-failure"],
        ]
        for cmd in commands:
            print("$ " + sp.list2cmdline(list(map(str, cmd))),file=log,flush=True)
            status = sp.run(cmd, env=env, stdout=log, stderr=sp.STDOUT).returncode
            print(f"exit={status}", file=log, flush=True)
            if status:
                print(f"{label} FAIL {status}",flush=True)
                return status
    print(f"{label} PASS", flush=True)
    return 0

params = [
    ("demo-quickstart", repo / "examples/servo", repo / "build/servo-demo", "clang"),
    ("demo-external-clang", demo, root / "foreign Demo Clang", "clang", (f"-DFALCONFOC_SOURCE_DIR={sdk}",)),
    ("demo-external-gcc", demo, root / "foreign Demo GCC", "C:/mingw64/bin/gcc.exe", (f"-DFALCONFOC_SOURCE_DIR={sdk}",)),
    ("demo-asan", demo, root / "foreign Demo ASan", "clang", (f"-DFALCONFOC_SOURCE_DIR={sdk}",
        "-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
        "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined")),
]
with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(lambda args: verify(*args), params))
sys.exit(int(any(results)))

