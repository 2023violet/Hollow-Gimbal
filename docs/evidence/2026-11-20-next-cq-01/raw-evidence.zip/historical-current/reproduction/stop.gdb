set pagination off
break foc_virtual_current.c:61 if context->virtual_time_us > 13000 && request->action == 0
commands
silent
printf "regular STOP INHIBIT submission\n"
p context->virtual_time_us
p context->output.accepted_updates
p context->runtime.pipeline.safety.state
bt 5
quit
end
run < build/next-cq-01-historical/historical-current.wire > build/next-cq-01-historical/stop-gdb-wire.out
