from pathlib import Path
import csv, math, struct
from zipfile import ZipFile

root=Path(__file__).parent
out=root/"data"
out.mkdir(exist_ok=True)
archive=Path("docs/evidence/2026-11-18-next-servo-02c/raw-evidence.zip")
def f32(x): return struct.unpack("<f",struct.pack("<f",x))[0]
def lpf(state,value,dt_us):
    value=f32(value)
    if state is None:
        return value
    u=f32(f32(6.283185307179586*1e-6)*48*dt_us)
    return f32(state+f32(f32(u/f32(1+u))*f32(value-state)))
def rms(xs):
    return math.sqrt(sum(x*x for x in xs)/len(xs))
rows=[]
summary=[]
with ZipFile(archive) as z:
    for dataset in ("legacy","holdout"):
        with z.open(f"data/{dataset}-trace.csv") as raw:
            import io
            prev={}
            batches={}
            for r in csv.DictReader(io.TextIOWrapper(raw,encoding="utf-8")):
                name=r["case"]
                if r["variant"]!="C" or (dataset=="holdout" and name!="hold-1p3x"):
                    continue
                t=int(r["t_us"])
                capture=int(r["capture_us"])
                vref=float(r["ref_velocity_rad_s"])
                meas=float(r["sensor_velocity_rad_s"])
                before,ref_f,meas_f,err_f=prev.get(name,(capture,None,None,None))
                dt=capture-before
                ref_f=lpf(ref_f,vref,dt)
                meas_f=lpf(meas_f,meas,dt)
                err_f=lpf(err_f,vref-meas,dt)
                prev[name]=(capture,ref_f,meas_f,err_f)
                # Independent, same-input arithmetic using the actual archived
                # reference and Sensor raw LPF history, not a new control run.
                if t<1120000 or t>=1450000:
                    continue
                d=.0480000041
                raw=d*(vref-meas)
                feedback_only=d*(vref-meas_f)
                error_filtered=d*err_f
                phase_offset=d*(vref-ref_f)
                assert abs((feedback_only-error_filtered)-phase_offset)<1.5e-8
                sample=dict(dataset=dataset,case=name,t_us=t,capture_us=capture,dt_us=dt,
                    velocity_reference=vref,velocity_sensor=meas,velocity_feedback_lpf=meas_f,
                    reference_lpf=ref_f,model_motion_ff_nm=float(r["feedforward_nm"]),
                    torque_d_unfiltered_nm=raw,torque_d_feedback_only_nm=feedback_only,
                    torque_d_error_lpf_nm=error_filtered,time_misalignment_torque_nm=phase_offset,
                    feedback_filter_delta_nm=feedback_only-raw)
                rows.append(sample)
                batches.setdefault(name,[]).append(sample)
            for name,group in batches.items():
                assert len(group)==660
                vals=lambda k: [r[k] for r in group]
                summary.append(dict(dataset=dataset,case=name,samples=len(group),
                    tau_s=1/(2*math.pi*48),equivalent_added_j_kg_m2=.048/(2*math.pi*48),
                    phase_bias_rms_nm=rms(vals("time_misalignment_torque_nm")),
                    phase_bias_peak_nm=max(abs(x) for x in vals("time_misalignment_torque_nm")),
                    damping_delta_rms_nm=rms(vals("feedback_filter_delta_nm")),
                    motion_ff_rms_nm=rms(vals("model_motion_ff_nm"))))
for name,records in (("same-input-phase-trace",rows),("same-input-phase",summary)):
    with (out/(name+".csv")).open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
for x in summary:
    print(x)
