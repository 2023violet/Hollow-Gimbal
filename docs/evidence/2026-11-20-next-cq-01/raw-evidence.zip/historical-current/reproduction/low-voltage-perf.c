/* Host timing of the same captured input in two libraries with different outcomes. */
#include "foc_current.h"

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main(int argc, char **argv)
{
    if (argc != 2) {
        return 2;
    }
    const int expected_status = atoi(argv[1]);
    const struct foc_current_config config = {
        .pwm = {6.0f, 0.12f, 0.0f, 1.0f, 0.0006f},
        .kp_v_per_a = {1.08f, 1.35f},
        .ki_v_per_a_s = {540.0f, 540.0f},
        .current_limit_a = 2.5f,
    };
    const struct foc_current_input input = {
        .phase_current_a = {-0.0240000002f, 0.0659999996f, -0.0420000032f},
        .theta_elec_rad = 0.37f,
        .target_a = {0.0f, 0.4f},
        .vbus_v = 12.0f,
        .dt_s = 0.0002f,
    };
    struct foc_current_context initial;
    LARGE_INTEGER frequency;
    const unsigned int repetitions = 200000U;

    if (foc_current_init(&initial, &config) != FOC_STATUS_OK ||
        !QueryPerformanceFrequency(&frequency)) {
        return 1;
    }
    puts("outcome_status,batch,iterations,ns_per_step,checksum");
    for (unsigned int batch = 0; batch < 16U; ++batch) {
        float checksum = 0.0f;
        LARGE_INTEGER start, end;
        QueryPerformanceCounter(&start);
        for (unsigned int i = 0; i < repetitions; ++i) {
            struct foc_current_context context = initial;
            struct foc_current_output output;
            const int status = foc_current_step(&context, &input, &output);
            if (status != expected_status) {
                fprintf(stderr, "expected %d, observed %d\n", expected_status, status);
                return 1;
            }
            checksum += output.svpwm.duty_a + output.voltage_dq_v.q + context.integral_v.q;
        }
        QueryPerformanceCounter(&end);
        if (batch > 0U) {
            const double ns_per_step = (double)(end.QuadPart - start.QuadPart) * 1.0e9 /
                ((double)frequency.QuadPart * repetitions);
            printf("%d,%u,%u,%.6f,%.9g\n", expected_status, batch, repetitions, ns_per_step, checksum);
        }
    }
    return 0;
}
