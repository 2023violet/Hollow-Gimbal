
static int run_axis_recovery(const struct foc_virtual_current_profile *original,
                             enum foc_runtime_mode mode)
{
    static const uint32_t phase_us[] = {
        900000U, 550000U, 300000U, 650000U, 1100000U
    };
    const bool position = mode == FOC_RUNTIME_MODE_POSITION;
    const float amplitude = position ? 0.50f : 1.5f;
    const float hold = position ? amplitude : 0.0f;
    const float ref[] = {amplitude, hold, hold, hold, -amplitude};
    const double load_nm[] = {0.0, 0.0, 0.025, 0.0, 0.0};
    const double tolerance = position ? 0.05 : 0.5;
    struct foc_virtual_current_profile profile = *original;
    profile.runtime.motion.iq_limit_a = 0.25f;
    struct foc_virtual_current vm;
    if (foc_virtual_current_init(&vm, &profile) != 0 ||
        !vm.runtime.config.motion.impedance.enabled ||
        vm.runtime.config.motion.impedance.damping_filter_hz !=
            original->runtime.motion.impedance.damping_filter_hz ||
        start_motion(&vm, mode, ref[0]) != 0) {
        return 1;
    }
    const uint32_t session = vm.runtime.motion_session;
    for (size_t phase = 0; phase < sizeof phase_us / sizeof phase_us[0]; ++phase) {
        if (foc_virtual_motor_set_load(&vm.motor, load_nm[phase]) != 0) {
            return 1;
        }
        unsigned saturation = 0U;
        double sum_sq = 0.0;
        double tail_sq = 0.0;
        double ending_error = 0.0;
        for (uint32_t t = 1000U; t <= phase_us[phase]; t += 1000U) {
            struct foc_virtual_current_observation observation;
            if (foc_virtual_current_publish_motion(&vm, mode, ref[phase]) != FOC_RUNTIME_OK ||
                foc_virtual_current_run_until(&vm, vm.virtual_time_us + 1000U) != 0 ||
                foc_virtual_current_observe(&vm, &observation) != 0 ||
                observation.safety_state != FOC_SAFE_STATE_RUNNING ||
                observation.motion_session != session || observation.faults != 0U ||
                observation.rejected_updates != 0U || vm.runtime.damping_filter_seen ||
                fabsf(observation.iq_ref_a) > profile.runtime.motion.iq_limit_a) {
                return 1;
            }
            const double actual = position ? observation.mechanical_position_rad
                                           : observation.mechanical_velocity_rad_s;
            ending_error = ref[phase] - actual;
            sum_sq += ending_error * ending_error;
            if (t > phase_us[phase] - 50000U) {
                tail_sq += ending_error * ending_error;
            }
            saturation += fabsf(observation.iq_ref_a) >= profile.runtime.motion.iq_limit_a - 1e-6f;
            printf(
                "AXIS_TRACE,%u,%u,%u,%u,%.9g,%.9g,%.12g,%.12g,%.9g,%.9g,%u,%u,%u,%u,%u\n",
                (unsigned)mode, (unsigned)phase, t, observation.virtual_time_us,
                (double)ref[phase], load_nm[phase], observation.mechanical_position_rad,
                observation.mechanical_velocity_rad_s, (double)observation.iq_ref_a,
                (double)observation.iq_a, observation.accepted_updates, (unsigned)observation.safety_state,
                observation.faults, observation.motion_session, foc_virtual_current_hash(&vm)
            );
        }
        printf("AXIS_RESULT,%u,%u,%.9g,%.9g,%.9g,%u\n", (unsigned)mode,
               (unsigned)phase, sqrt(sum_sq * 1000.0 / phase_us[phase]),
               sqrt(tail_sq / 50.0), ending_error, saturation);
        if (check(phase == 2U || fabs(ending_error) <= tolerance, "motion phase tail") ||
            check(phase != 0U || saturation > 0, "initial current saturation") ||
            check(phase != 3U || saturation == 0, "unloaded current saturation")) {
            return 1;
        }
    }
    const uint32_t injection = vm.next_h1_us;
    struct foc_virtual_current_observation fault;
    struct foc_virtual_fault_events events;
    if (foc_virtual_current_mark_sensor_fault(&vm, injection) != 0 ||
        foc_virtual_current_fail_next_sensor(&vm) != 0 ||
        foc_virtual_current_run_until(&vm, injection + 1000U) != 0 ||
        foc_virtual_current_observe(&vm, &fault) != 0 ||
        foc_virtual_current_read_fault_events(&vm, &events) != 0 ||
        fault.safety_state != FOC_SAFE_STATE_FAULT_LATCHED ||
        (fault.faults & FOC_SAFE_FAULT_SAMPLE_INVALID) == 0U ||
        !events.h1_invalid_seen || !events.inhibit_accepted_seen || !events.fault_latched_seen ||
        fault.accepted_updates != events.updates_at_h1_invalid ||
        vm.output.request.action != FOC_DEVICE_OUTPUT_INHIBIT ||
        fault.motion_session == session) {
        return 1;
    }
    printf("AXIS_FAULT,%u,%u,%u,%u,%u,%u,%u,%u,%u\n",
        (unsigned)mode, injection, events.h1_invalid_us, events.inhibit_accepted_us,
        events.fault_latched_us, events.updates_at_h1_invalid, fault.accepted_updates,
        fault.faults, fault.motion_session);
    return 0;
}

