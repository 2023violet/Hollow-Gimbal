from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import json, os, shutil, subprocess as sp, sys, tarfile

root=Path(__file__).resolve().parent
repo=Path.cwd()
sdk=root/"FalconFOC Source"
consumer=root/"External Parameter Consumer"
sdk.mkdir()
shutil.copytree(repo/"examples/parameters", consumer)
head=sp.check_output(["git","rev-parse","HEAD"],text=True).strip()
arch=root/"base.tar"
sp.run(["git","archive","--format=tar","--output",arch,head],check=True)
with tarfile.open(arch) as archive:
    archive.extractall(sdk,filter="data")
shutil.copytree(repo/"control_plane",sdk/"control_plane")
assert not (sdk/".git").exists() and not (consumer/".git").exists()
assert not (sdk/"examples/parameters").exists()
env=os.environ.copy()
env["PATH"]=os.pathsep.join([r"C:\mingw64\bin",
    str(Path(sp.check_output(["clang","-print-resource-dir"],text=True).strip())/"lib/windows"),env["PATH"]])
env.update(ASAN_OPTIONS="halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")

def verify(label, source, build, compiler, name, test, sdk_flags=(), sanitizer=False):
    exe=build/(name+".exe")
    flags=["-G","Ninja","-DCMAKE_BUILD_TYPE=Debug",f"-DCMAKE_C_COMPILER={compiler}",
           "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON",*sdk_flags]
    if sanitizer:
        flags+=["-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
                "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined"]
    commands=[
        [compiler,"--version"], ["cmake","-S",source,"-B",build,*flags],
        ["cmake","--build",build,"--target",name,"--parallel","4","--verbose"],
        ["ctest","--test-dir",build,"-R",f"^{test}$","--no-tests=error","--output-on-failure"],
        [exe],
    ]
    with (root/(label+".log")).open("w",encoding="utf8") as log:
        print(f"identity {head} actual examples from {consumer}; clean SDK {sdk}",file=log,flush=True)
        for cmd in commands:
            print("$ "+sp.list2cmdline(list(map(str,cmd))),file=log,flush=True)
            status=sp.run(cmd,cwd=root,env=env,stdout=log,stderr=sp.STDOUT).returncode
            print(f"exit={status}",file=log,flush=True)
            if status:
                print(f"{label}: FAIL {status}",flush=True)
                return status
        units=json.loads((build/"compile_commands.json").read_text(encoding="utf8"))
        if source==consumer:
            for unit in units:
                unit_path=Path(unit["file"]).resolve()
                assert unit_path.is_relative_to(sdk) or unit_path.is_relative_to(consumer),unit_path
            print("All generated compile units map to the external consumer or no-Git source tree.",file=log)
            deps=sp.check_output(["ninja","-C",build,"-t","deps"],env=env,text=True,errors="replace")
            headers = {path.name for path in (sdk/"control_plane/include").glob("*.h")}
            seen=[(build/Path(line.strip())).resolve() for line in deps.splitlines()
                  if line.startswith("    ") and Path(line.strip()).name in headers]
            assert seen and all(path.is_relative_to(sdk) for path in seen)
            print("Parameter public header dependency resolves inside the no-Git tree.",file=log)
    print(f"{label}: PASS",flush=True)
    return 0

jobs=[]
for compiler, variant in (("clang","clang"),("C:/mingw64/bin/gcc.exe","gcc"),("clang","asan")):
    jobs.append((f"unit-{variant}",repo/"control_plane",root/f"unit {variant}",
                 compiler,"test-foc-parameter","test-foc-parameter",(),variant=="asan"))
    jobs.append((f"external-{variant}",consumer,root/f"external {variant}",
                 compiler,"falconfoc-parameter-demo","test-falconfoc-parameters-example",
                 (f"-DFALCONFOC_SOURCE_DIR={sdk}",),variant=="asan"))
jobs.append(("in-tree-demo",repo/"examples/parameters",root/"in-tree demo",
             "clang","falconfoc-parameter-demo","test-falconfoc-parameters-example"))
with ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(lambda job:verify(*job),jobs))
sys.exit(int(any(results)))

