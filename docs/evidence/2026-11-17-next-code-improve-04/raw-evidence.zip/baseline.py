import hashlib
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path('D:/study/Software/Hollow-Gimbal-vm01a')
MAIN = pathlib.Path('D:/study/Software/Hollow-Gimbal')
OUT = pathlib.Path(__file__).resolve().parent
assert OUT != ROOT and ROOT not in OUT.parents

def git(*args, root=ROOT):
    return subprocess.run(['git', '-c', 'core.quotepath=false', *args], cwd=root,
                          capture_output=True, check=True).stdout

def manifest(ignored=False):
    args = ['ls-files', '-z', '--others', '--exclude-standard']
    args += ['--ignored'] if ignored else ['--cached']
    names = sorted(set(p.decode('utf-8') for p in git(*args).split(b'\0') if p))
    result = {}
    for name in names:
        path = ROOT / name
        if path.is_file():
            with path.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            result[name] = {'sha256': digest, 'size': path.stat().st_size}
    return result

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')

if len(sys.argv) == 1:
    assert not (OUT / 'source-before.json').exists(), 'Do not overwrite a baseline'
    source = manifest()
    dump('source-before.json', source)
    for name, data in [('git-status-before.txt', git('status', '--short', '--untracked-files=all')),
                       ('diff-before.patch', git('diff', '--binary')),
                       ('head.txt', git('rev-parse', 'HEAD')),
                       ('branch.txt', git('branch', '--show-current')),
                       ('main-status-before.txt', git('status', '--porcelain', root=MAIN))]:
        (OUT / name).write_bytes(data)
    for name in source:
        dest = OUT / 'snapshot' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, dest)
    ignored = manifest(True)
    dump('artifacts-before.json', ignored)
    print(json.dumps({'source_files': len(source), 'existing_ignored_files': len(ignored),
                      'ignored_bytes': sum(v['size'] for v in ignored.values())}), flush=True)
else:
    source = json.loads((OUT / 'source-before.json').read_text(encoding='utf-8'))
    artifacts = json.loads((OUT / 'artifacts-before.json').read_text(encoding='utf-8'))
    now_source, now_artifacts = manifest(), manifest(True)
    delta = lambda a, b: sorted(p for p in a.keys() | b.keys() if a.get(p) != b.get(p))
    snapshot_changed = []
    for name, before in source.items():
        with (OUT / 'snapshot' / name).open('rb') as stream:
            if hashlib.file_digest(stream, 'sha256').hexdigest() != before['sha256']:
                snapshot_changed.append(name)
    result = {'source_files_before': len(source), 'source_files_after': len(now_source),
              'source_changed': delta(source, now_source),
              'ignored_files_before': len(artifacts), 'ignored_files_after': len(now_artifacts),
              'artifacts_changed': delta(artifacts, now_artifacts), 'snapshot_changed': snapshot_changed,
              'git_status_unchanged': git('status', '--short', '--untracked-files=all') == (OUT / 'git-status-before.txt').read_bytes(),
              'diff_unchanged': git('diff', '--binary') == (OUT / 'diff-before.patch').read_bytes(),
              'head_unchanged': git('rev-parse', 'HEAD') == (OUT / 'head.txt').read_bytes(),
              'branch_unchanged': git('branch', '--show-current') == (OUT / 'branch.txt').read_bytes(),
              'main_status_unchanged': git('status', '--porcelain', root=MAIN) == (OUT / 'main-status-before.txt').read_bytes()}
    dump('readonly-verification.json', result)
    print(json.dumps(result))
    assert not any(result[k] for k in ('source_changed', 'artifacts_changed', 'snapshot_changed'))
    assert all(result[k] for k in ('git_status_unchanged', 'diff_unchanged', 'head_unchanged', 'branch_unchanged', 'main_status_unchanged'))
