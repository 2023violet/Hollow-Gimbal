
"""Evaluate the fixed SERVO-02C Host gates and compare the original diagnostic replay."""
import csv
import json
from pathlib import Path
from sys import argv

root = Path(argv[1])
noise_root = Path(argv[2])

def records(filename, name):
    with filename.open(encoding="ascii", newline="") as stream:
        yield from csv.DictReader(line for line in stream if line.startswith(name + ","))

held = root / "holdout-first-trace.csv"
old_probe = root / "legacy-probe-trace.csv"
results = {(r["case"], r["variant"]): r for r in records(held, "MOTION_RESULT")}
assert len(results) == 15
gates = list(records(held, "MOTION_GATE"))
assert len(gates) == 3
boundary = list(records(held, "MOTION_BOUNDARY"))
assert len(boundary) == 3

report = {"result": {}, "age_gate": gates, "boundary": boundary}
for (case, variant), row in results.items():
    baseline = results[case, "B"]
    f = lambda key: float(row[key])
    b = lambda key: float(baseline[key])
    fail = {}

    def require(key, limit):
        if f(key) > limit:
            fail[key] = {"value": f(key), "bound": limit}

    for phase in ("forward_accel", "forward_decel", "reverse_accel", "reverse_decel", "crawl"):
        key = f"{phase}_rms_rad_s"
        cap = 0.030 if phase == "crawl" else 0.25
        if variant != "B":
            cap = min(cap, 1.10 * b(key) + 0.005)
        require(key, cap)
    require("reversal_rms_rad_s", 0.25 if variant == "B" else min(0.25, 0.80 * b("reversal_rms_rad_s")))
    require("crossed_us", 150_000)
    for key in ("settle_us", "recover_us"):
        require(key, 650_000 if variant == "B" else min(650_000, b(key) + 25_000))
    require("tail_peak_position_error_rad", 0.008)
    require("peak_limit_run_us", 250_000)
    for key in ("tail_request_hp_a", "tail_model_hp_a"):
        require(key, 0.035 if variant == "B" else min(0.035, b(key) + 0.005))
    if variant != "B":
        require("peak_model_a", 1.25 * b("peak_model_a") + 0.02)

    case_result = report["result"].setdefault(case, {})
    reference_feasible = f("over_budget_us") == 0
    output_limited = f("limited_us") > 0
    if not reference_feasible:
        assert case == "hold-lowcap-1p3x" and output_limited
    case_result[variant] = {
        "model": "MODEL_UNUSED" if variant == "B" else "MODEL_VALID",
        "feedforward": "FEEDFORWARD_DISABLED" if variant == "B" else "FEEDFORWARD_VALID",
        "actuator": "ACTUATOR_LIMITED" if output_limited else "ACTUATOR_UNLIMITED",
        "reference": "REFERENCE_INFEASIBLE" if not reference_feasible else "WITHIN_MODELED_TORQUE_BUDGET",
        "quality": "HOST_QUALITY_FAIL" if fail else "HOST_QUALITY_PASS",
        "failed_gates": fail,
        "reversal_rms_rad_s": f("reversal_rms_rad_s"),
        "position_rms_rad": f("position_rms_rad"),
        "peak_model_iq_a": f("peak_model_a"),
        "tail_requested_iq_hp_a": f("tail_request_hp_a"),
        "tail_model_iq_hp_a": f("tail_model_hp_a"),
        "max_source_age_us": f("max_accepted_source_age_us"),
    }

for gate in gates:
    assert int(gate["reason"]) == -5
    assert gate["updates_before"] == gate["updates_after"]
    assert gate["old_session"] != gate["new_session"]
    if gate["variant"] != "B":
        assert float(gate["peak_ff_nm"]) > 0.01

for row in boundary:
    assert row["updates_before"] == row["updates_after"]
    assert row["old_session"] != row["new_session"]
    assert float(row["feedforward_nm"]) < -0.01
    assert int(row["rejected"]) == (int(row["kind"]) == 1)
    assert int(row["faults"]) == (4 if int(row["kind"]) == 2 else 0)

legacy_baseline = [
    row for row in records(noise_root / "noise-holdout-final-trace.csv", "NOISE_TRACE")
    if row["candidate"] == "motion-1p3x" and row["variant"] == "A"
]
legacy_replay = [row for row in records(old_probe, "MOTION_TRACE") if row["variant"] == "B"]
assert len(legacy_baseline) == len(legacy_replay) == 6000
for baseline, replay in zip(legacy_baseline, legacy_replay):
    same = {
        "t_us": "t_us", "capture_us": "capture_us", "h0_us": "h0_us",
        "session": "session", "sample_seq": "sample_seq", "updates": "updates",
        "raw_code": "encoder_raw", "reference_rad": "ref_position_rad",
        "reference_rad_s": "ref_velocity_rad_s", "request_a": "iq_request_a",
    }
    for original_key, current_key in same.items():
        assert baseline[original_key] == replay[current_key], (original_key, current_key)
    floats = {"model_rad": "model_position_rad", "model_rad_s": "model_velocity_rad_s", "model_iq_a": "model_iq_a"}
    for old, new in floats.items():
        assert abs(float(baseline[old]) - float(replay[new])) <= 5e-9, (old, new)

report["legacy_probe"] = {
    "same_raw_reference_request_time_rows": len(legacy_replay),
    "results": list(records(old_probe, "MOTION_RESULT")),
}
print(json.dumps(report, indent=2))

