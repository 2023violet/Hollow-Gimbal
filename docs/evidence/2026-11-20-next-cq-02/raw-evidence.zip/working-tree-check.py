from pathlib import Path
import sys, subprocess,json,hashlib
base=Path(sys.argv[1])
repo=Path.cwd()
frozen=json.loads((base/'baseline-manifest.json').read_text(encoding='utf-8'))['files']
def git(*args): return subprocess.check_output(['git',*args]).decode('utf-8')
paths=set(git('ls-files','-c','-o','--exclude-standard','-z').strip('\0').split('\0'))|frozen.keys()
changed={}
for name in sorted(paths):
 if name.startswith(('work/','docs/evidence/2026-11-20-next-cq-02')):continue
 p=repo/name; before=frozen.get(name); after=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
 if before!=after:changed[name]={"before":before,"after":after}
assert set(changed)=={
'control_plane/src/foc_parameter.c','docs/governance/Themis_工程维护日志.md',
'examples/servo/README.md','examples/servo/main.c','runtime/README.md','runtime/include/foc_runtime.h',
'runtime/src/foc_runtime.c','runtime/tests/test_foc_runtime_impedance.c','simulation/CMakeLists.txt',
'simulation/README.md','simulation/src/falconfoc_virtual_calibrate.c',
'simulation/tests/test_foc_impedance_robustness.c','simulation/tests/test_virtual_calibration_cli.py'
},list(changed)
state={'head':git('rev-parse','HEAD').strip(),'branch':git('branch','--show-current').strip(),'staged':git('diff','--cached','--name-only'),'status':git('-c','core.quotepath=false','status','--short','--branch'),'files':changed}
assert not state['staged']
assert state['branch']=='codex/falconfoc-v2-vm01a'
(base/'cq02-working-tree-delta.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
print(state['head'],len(changed),'expected changed paths')

