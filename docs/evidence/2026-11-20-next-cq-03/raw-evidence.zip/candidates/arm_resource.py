"""Build and compare uninjected Cortex-M4 Soft-float Core/Pipeline/Runtime objects."""
import argparse
from pathlib import Path
import subprocess
import sys

def run(args, log):
    args = [str(item) for item in args]
    result = subprocess.run(args, check=True, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    print(">", subprocess.list2cmdline(args), file=log)
    print(result.stdout, end="", file=log)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("frozen", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(exist_ok=True)
    prototype = args.out / "prototype"
    run([sys.executable, Path(__file__).with_name("project.py"), args.frozen, prototype,
         "--transition"], sys.stdout)
    footprint = args.out / "footprint.c"
    footprint.write_text(
        '#include "foc_runtime.h"\n'
        'unsigned char arm_sizeof_foc_current_context[sizeof(struct foc_current_context)];\n'
        'unsigned char arm_sizeof_foc_pipeline[sizeof(struct foc_pipeline)];\n'
        'unsigned char arm_sizeof_foc_pipeline_config[sizeof(struct foc_pipeline_config)];\n'
        'unsigned char arm_sizeof_foc_runtime[sizeof(struct foc_runtime)];\n',
        encoding="utf-8")
    common = ["-mcpu=cortex-m4", "-mthumb", "-mfloat-abi=soft", "-std=c11", "-Os",
              "-g0", "-ffunction-sections", "-fdata-sections", "-fstack-usage",
              "-Wall", "-Wextra", "-Wpedantic"]
    with (args.out / "arm-resource.log").open("w", encoding="utf-8") as log:
        run(["arm-none-eabi-gcc", "--version"], log)
        for group, source in (("AB", args.frozen), ("C", prototype)):
            print(f"=== {group} (compile only, trace instrumentation excluded) ===", file=log)
            includes = [f"-I{source / name / 'include'}"
                        for name in ("core", "runtime", "g3/np", "g3/safe")]
            units = [source / name for name in ("core/src/foc_current.c",
                                                "runtime/src/foc_pipeline.c",
                                                "runtime/src/foc_runtime.c")] + [footprint]
            objects = []
            for unit in units:
                target = args.out / f"{group}-{unit.stem}.o"
                run(["arm-none-eabi-gcc", *common, *includes, "-c", unit, "-o", target], log)
                objects.append(target)
            run(["arm-none-eabi-size", *objects[:-1]], log)
            run(["arm-none-eabi-nm", "-S", "-t", "d", objects[-1]], log)
            for target in objects[:-1]:
                stack = target.with_suffix(".su").read_text(encoding="utf-8")
                for line in stack.splitlines():
                    if any(fn in line for fn in ("foc_current_step", "foc_current_feedforward_compute",
                                                 "foc_pipeline_step", "foc_pipeline_init",
                                                 "foc_runtime_h0_step", "foc_runtime_h1_step")):
                        print(line, file=log)

if __name__ == "__main__":
    main()
