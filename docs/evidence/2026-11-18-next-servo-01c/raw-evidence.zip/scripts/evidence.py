
from pathlib import Path
from zipfile import ZipFile
from collections import defaultdict
import subprocess as sp
import csv

root=Path(__file__).parent
previous=Path(r"C:/Users/16429/AppData/Local/Temp/servo01b_1795001461062")
out=root/"data"
out.mkdir(exist_ok=True)
def lines(path):
    data=path.read_bytes()
    return data.decode("utf-16" if data.startswith(b"\xff\xfe") else "utf-8-sig").splitlines()
def run(project,target,*args):
    cmd=[root/"final-complete"/project/(target+".exe"),*args]
    print(sp.list2cmdline(cmd),flush=True)
    return sp.check_output(cmd).decode("ascii").splitlines()
def groups(records):
    result=defaultdict(list)
    for row in csv.reader(records):
        result[row[0]].append(row)
    return result
baseline=lines(root/"baseline-01b.log")
assert baseline==run("simulation-clang","test-foc-runtime-impedance-virtual","--trace")
baseline_rows=groups(baseline)
with ZipFile("docs/evidence/2026-11-18-next-servo-01b/raw-evidence.zip") as z:
    for label in ("TRACE","SUMMARY","BOUNDARY","RECOVERY","QUALITY"):
        expected=list(csv.reader(z.read(f"data/{label.lower()}.csv").decode().splitlines()))[1:]
        assert baseline_rows[label]==expected,label
        print("01B immutable comparison identical",label,len(expected))
assert run("simulation-clang","test-foc-impedance-virtual","--trace")==lines(Path(r"C:/Users/16429/AppData/Local/Temp/servo01a_1794995524571")/"holdout-full.log")
print("01A composition replay identical (22,000 samples)")
columns={
 "DESIGN":"record scenario design model_id J_actual B_actual J_model B_model K D omega_ideal zeta_ideal model_valid",
 "RESULT":"record scenario samples rms_error_rad peak_error_rad overshoot_rad settle_us reverse_settle_us recover_us peak_speed_rad_s peak_request_a peak_plant_iq_a limited_us longest_limit_us loaded_mean_error_rad tail_peak_error_rad tail_speed_rms_rad_s tail_request_rms_a tail_request_hf_rms_a tail_plant_hf_rms_a tail_torque_rms_nm tail_damping_rms_nm repeated_codes max_accepted_source_age_us updates quality_mask",
 "TRACE":"record scenario elapsed_us capture_us h1_us h0_submit_us plant_apply_us command_seq sensor_seq session updates raw_code limited ref_rad plant_rad plant_rad_s sensor_rad_s target_iq_a plant_iq_a torque_nm load_nm output_action",
 "STOP":"record scenario cancelled_pending updates_before updates_after old_session new_session",
 "GATE":"record scenario inhibit_us pipeline_reason updates_before updates_after max_admitted_age_us fault_bits session",
 "QUALITY":"record scenario verdict mask"
}
for group,args in [("training",["--train","--trace"]),("holdout",["--trace"])]:
    result=run("simulation-clang","test-foc-impedance-robustness",*args)
    parsed=groups(result)
    if group=="holdout":
        assert [r for r in result if not r.startswith("TRACE,")]==lines(root/"first-holdout.log")
    else:
        assert parsed["RESULT"]==groups(lines(root/"training.log"))["RESULT"]
    for name,rows in parsed.items():
        header=columns[name].split()
        with (out/f"{group}-{name.lower()}.csv").open("w",newline="") as f:
            writer=csv.writer(f)
            writer.writerow(header)
            for row in rows:
                assert len(row)==len(header),(name,len(row),len(header))
                writer.writerow(row)
    counts=defaultdict(int)
    for row in parsed["QUALITY"]:
        counts[row[2]]+=1
    print(group,"trace",len(parsed["TRACE"]),dict(counts),"expected gates",len(parsed["GATE"]))
    print("quality failures", [r[1:] for r in parsed["QUALITY"] if r[2]=="HOST_QUALITY_FAIL"])
    for row in parsed["STOP"]:
        assert row[3]==row[4] and row[5]!=row[6]
    if group=="holdout":
        gates=parsed["GATE"]
        assert len(gates)==1 and gates[0][1:6]==["hold-delay-reject","2400","-5","7","7"]
    source_age={}
    for r in csv.DictReader((out/f"{group}-trace.csv").open(newline="")):
        capture,h1,submit,apply=map(int,(r["capture_us"],r["h1_us"],r["h0_submit_us"],r["plant_apply_us"]))
        assert 0<capture<h1 and submit<=h1 and apply<=h1
        assert int(r["session"])==1 and int(r["sensor_seq"])==int(r["command_seq"])+3
        source_age.setdefault(r["scenario"],set()).add(h1-capture)
    print(group,"capture-to-H1 ages",source_age)


