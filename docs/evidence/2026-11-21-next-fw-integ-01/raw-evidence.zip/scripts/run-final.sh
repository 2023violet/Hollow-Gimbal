#!/usr/bin/env bash
# NEXT-FW-INTEG-01 final software reproduction. Run from the repository root:
#   bash build/fwinteg/run-final.sh build/fwinteg/final
# Every step records its own exit code; the script never hides a failure.
set -u
OUT="${1:?output directory}"
ROOT="$(pwd -W 2>/dev/null || pwd)"
mkdir -p "$OUT"
STATUS="$OUT/exit-codes.txt"
: > "$STATUS"

record() { echo "$1 exit $2" | tee -a "$STATUS"; }

for toolchain in clang gcc sanitizer; do
  pwsh -NoProfile -File build/fwinteg/run-test-matrix.ps1 -OutputRoot "$ROOT/$OUT/matrix" \
    -Toolchain "$toolchain" > "$OUT/matrix-$toolchain.txt" 2>&1
  record "matrix-$toolchain" $?
done

# Witness output of the two startup tests from each lane's own build, sanitizer runtime on PATH.
for toolchain in clang gcc sanitizer; do
  for test in test-foc-board-boot test-foc-board-boot-default; do
    pwsh -NoProfile -Command "\$env:Path=\"\$(clang --print-resource-dir)\\lib\\windows;\$env:Path\"; \
      \$env:ASAN_OPTIONS='halt_on_error=1'; \$env:UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'; \
      & '$OUT/matrix/$toolchain-firmware-at32f415/$test.exe'; exit \$LASTEXITCODE" \
      > "$OUT/witness-$toolchain-$test.txt" 2>&1
    record "witness-$toolchain-$test" $?
  done
done

# Every CTest result line must say Passed: count anything else explicitly.
total=$(cat "$OUT"/matrix/*.log | grep -cE "Test +#[0-9]+: ")
passed=$(cat "$OUT"/matrix/*.log | grep -E "Test +#[0-9]+: " | grep -c " Passed ")
bad=$(cat "$OUT"/matrix/*.log | grep -cE "Not Run|Skipped|\*\*\*Failed|\*\*\*Exception|\*\*\*Timeout")
echo "ctest result lines $total, passed $passed, not-run/skipped/failed $bad" | tee "$OUT/skip-check.txt"
[ "$total" -gt 0 ] && [ "$total" -eq "$passed" ] && [ "$bad" -eq 0 ]
record skip-check $?

arm() {
  local name="$1"; shift
  local dir="$OUT/arm-$name"
  cmake -S firmware/at32f415 -B "$dir" -G Ninja \
    "-DCMAKE_TOOLCHAIN_FILE=$ROOT/tools/cmake/arm-gcc-toolchain.cmake" \
    -DMCU_CPU=cortex-m4 -DMCU_FLOAT=soft -DMCU_FPU=none "$@" > "$dir.configure.log" 2>&1
  record "arm-$name-configure" $?
  cmake --build "$dir" > "$dir.build.log" 2>&1
  record "arm-$name-build" $?
}
arm default -DFALCONFOC_BOARD_CALIBRATION_SUPPLY=NONE
arm verification -DFALCONFOC_BOARD_CALIBRATION_SUPPLY=VERIFICATION
arm default-capture -DFALCONFOC_BOARD_CAPTURE=ON -DFALCONFOC_BOARD_CAPTURE_BUILD_TAG=7
arm default-trace -DFALCONFOC_RT02_TIMING_TRACE=ON

# Static evidence and UART readback from THIS run's ARM images and Host simulators.
python -I build/fwinteg/arm_static.py build/fwinteg/evidence/baseline "$OUT" > "$OUT/arm-static.txt" 2>&1
record arm-static $?
python -I build/fwinteg/uart_check.py build/fwinteg/evidence/baseline/uart-demo.jsonl \
  "$OUT/matrix/clang-firmware-at32f415" "$OUT/uart" > "$OUT/uart-check.txt" 2>&1
record uart-check $?

for preset in fw-full-diag-carrier-debug fw-standard-carrier-minsizerel fw-tiny-carrier-minsizerel; do
  { cmake --preset "$preset" && cmake --build --preset "build-$preset"; } > "$OUT/preset-$preset.log" 2>&1
  record "preset-$preset" $?
done

pwsh -NoProfile -ExecutionPolicy Bypass -File scripts/gates/check_themis_quality_gate.ps1 \
  -RepoRoot "$ROOT" -Scope all -RequireCMakeFormatter -Summary > "$OUT/quality-gate.log" 2>&1
record quality-gate $?

sha256sum "$OUT"/arm-*/*.bin > "$OUT/bin-sha256.txt"
cat "$STATUS"
