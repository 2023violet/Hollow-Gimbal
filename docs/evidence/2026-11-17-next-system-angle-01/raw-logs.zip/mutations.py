import json,shutil
from audit import OUT,ROOT,SRC,CC,run,copy_source

old=(SRC/'runtime/src/foc_runtime.c').read_text(encoding='utf-8')
changes={
 'missing-poles': ('(float)runtime->config.motion.rotor.pole_pairs * sample->mechanical_rad_s;',
                    'sample->mechanical_rad_s;'),
 'publication-time': ('struct foc_runtime_sensor_slot candidate = {.sample = *sample};',
                    'struct foc_runtime_sensor_slot candidate = {.sample = *sample};\n    candidate.sample.captured_us = now_us;'),
}
for label,(find,replace) in changes.items():
    dest=OUT/'mutations'/label;repo=copy_source(dest/'source')
    assert old.count(find)==1
    (repo/'runtime/src/foc_runtime.c').write_text(old.replace(find,replace),encoding='utf-8')
    (dest/'mutation.json').write_text(json.dumps({'find':find,'replace':replace},indent=2))
    for state in ['old-tests','new-tests']:
        lane=dest/state
        if state=='new-tests':
            for rel in ['simulation/tests/test_foc_periodic_chain.c','simulation/tests/foc_system_angle_oracle.h']:
                shutil.copy2(ROOT/rel,repo/rel)
        run(lane,'configure',['cmake','-S',repo/'simulation','-B',lane/'build','-G','Ninja',
                             '-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+CC])
        run(lane,'build',['cmake','--build',lane/'build','--parallel','4'])
        if state=='old-tests':
            run(lane,'ctest',['ctest','--test-dir',lane/'build','--output-on-failure',
                              '-R','^test-foc-periodic-chain$'])
        else:
            run(lane,'executable',[lane/'build/test-foc-periodic-chain.exe','--system-angle-csv',
                                  lane/'data.csv'],expected=1)
