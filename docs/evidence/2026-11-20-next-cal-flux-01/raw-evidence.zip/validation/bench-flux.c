#include "foc_flux_id.h"

#include <stdio.h>
#include <time.h>

int main(void)
{
    const struct foc_flux_id_config policy = {
        .identity = {1, 10, 201, 1, 1, 1, 1, 1, 1, 1, 0, 4},
        .rl = {.rs_ohm = .6f, .ld_h = .0012f, .lq_h = .0015f},
        .rl_qualified = true,
        .source = FOC_MOTOR_ID_VIRTUAL,
        .voltage_source = FOC_MOTOR_ID_VOLTAGE_VIRTUAL_TERMINAL,
        .interval_us = 50, .intervals_per_window = 32, .min_windows_per_direction = 8,
        .max_abs_current_a = 2.5, .max_abs_vq_v = 6.84, .max_abs_speed_rad_s = 100,
        .min_abs_window_speed_rad_s = 1, .min_speed_span_rad_s = 1, .min_speed_rms_rad_s = 5,
        .min_flux_wb = .001, .max_flux_wb = .2,
        .max_residual_rms_v = .02, .max_direction_difference_relative = .05,
    };
    struct foc_flux_id_interval raw[512];
    const double omega[] = {10, -10, 20, -20};
    for (unsigned int i = 0; i < 512; ++i) {
        const double speed = omega[i / 128];
        raw[i] = (struct foc_flux_id_interval){
            .identity = policy.identity, .source = policy.source, .voltage_source = policy.voltage_source,
            .sequence = i, .begin_us = 50 * i, .end_us = 50 * (i + 1),
            .voltage_begin_us = 50 * i, .voltage_end_us = 50 * (i + 1),
            .speed_begin_us = 50 * i, .speed_end_us = 50 * (i + 1),
            .id_begin_a = .1, .id_end_a = .1, .iq_begin_a = .12, .iq_end_a = .12,
            .mean_omega_e_rad_s = speed, .mean_vq_v = policy.rl.rs_ohm * .12 +
                speed * (policy.rl.ld_h * .1 + .025),
            .current_valid = true, .voltage_valid = true, .speed_valid = true,
            .frame_confirmed = true, .output_confirmed = true, .terminal_voltage_witnessed = true,
        };
    }
    printf("sizeof context=%zu result=%zu interval=%zu CLOCKS_PER_SEC=%ld\n",
           sizeof(struct foc_flux_id), sizeof(struct foc_flux_id_result),
           sizeof(struct foc_flux_id_interval), (long)CLOCKS_PER_SEC);
    double checksum = 0;
    for (unsigned int rep = 0; rep < 5; ++rep) {
        const clock_t start = clock();
        for (unsigned int capture = 0; capture < 4000; ++capture) {
            struct foc_flux_id context;
            struct foc_flux_id_result result;
            if (foc_flux_id_init(&context, &policy) != FOC_CALIBRATION_FAILURE_NONE) {
                return 1;
            }
            for (unsigned int i = 0; i < 512; ++i) {
                if (foc_flux_id_push(&context, &raw[i]) != FOC_CALIBRATION_FAILURE_NONE) {
                    return 2;
                }
            }
            if (foc_flux_id_finish(&context, &result) != FOC_CALIBRATION_FAILURE_NONE) {
                return 3;
            }
            checksum += result.flux_wb;
        }
        const clock_t elapsed = clock() - start;
        printf("rep=%u captures=4000 intervals/capture=512 us/capture=%.3f\n",
               rep, (double)elapsed / CLOCKS_PER_SEC * 1e6 / 4000.0);
    }
    printf("accepted flux checksum=%.10g\n", checksum);
    return 0;
}

