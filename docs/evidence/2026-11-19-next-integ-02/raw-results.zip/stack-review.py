import functools, pathlib, re, subprocess, sys
base = pathlib.Path(sys.argv[1])
flex = {
    "foc_board_adc_complete": ("foc_at32_trace_cycles",),
    "foc_board_encoder_complete": ("foc_at32_trace_cycles",),
    "foc_board_trace_submit": ("foc_at32_trace_cycles",),
    "foc_serial_poll": ("foc_at32_serial_now",),
    "foc_runtime_hook": ("foc_at32_trace_hook",),
    "foc_pipeline_submit": ("foc_board_trace_submit", "foc_board_output_submit"),
    "foc_pipeline_step_guarded": ("foc_runtime_admit_update",),
}
roots = ["TMR1_CH_IRQHandler", "ADC1_IRQHandler", "TMR5_GLOBAL_IRQHandler",
         "SPI1_IRQHandler", "USART1_IRQHandler", "foc_runtime_foreground_poll", "foc_serial_poll"]
for mode in ("capoff", "capon", "traceoff", "captrace"):
    build = base / mode
    rows, own = {}, {}
    for file in build.rglob("*.su"):
        for row in file.read_text(encoding="utf-8", errors="replace").splitlines():
            sig, size, kind = row.split("\t")
            name = sig.rsplit(":", 1)[-1]
            own[name] = (int(size), kind)
    name = ""
    for line in (build/"disassembly.txt").read_text(encoding="utf-8-sig").splitlines():
        match = re.match(r"^([0-9a-f]+) <([^>]+)>:", line)
        if match:
            name = match[2]
            rows[name] = []
            continue
        match = re.match(r"^\s*[0-9a-f]+:\s+(?:[0-9a-f]{4}\s+)+([a-z][a-z0-9.]+)\s*(.*?)\s*$", line)
        if match and name:
            rows[name].append((match[1], re.split(r"[;@]", match[2], maxsplit=1)[0].strip()))
    unresolved, dynamic, cycles = set(), set(), set()
    def library_frame(name):
        size = 0
        for op, arg in rows[name]:
            op = op.split(".")[0]
            if op == "push" or (op == "stmdb" and arg.startswith("sp!")):
                regs = re.search(r"\{([^}]+)\}", arg)
                if not regs:
                    dynamic.add((name, op, arg))
                else:
                    for reg in regs[1].split(","):
                        span = re.fullmatch(r"r(\d+)-r(\d+)", reg.strip())
                        size += 4 * (1 + int(span[2])-int(span[1]) if span else 1)
            elif op == "sub" and arg.startswith("sp,"):
                dec = re.fullmatch(r"sp,\s*(?:sp,\s*)?#(\d+)", arg)
                if dec:
                    size += int(dec[1])
                else:
                    dynamic.add((name, op, arg))
            elif op.startswith("str") and re.search(r"\[sp, #-(\d+)\]!", arg):
                size += int(re.search(r"\[sp, #-(\d+)\]!", arg)[1])
            elif op in ("vpush", "mov", "bic") and (op == "vpush" or arg.startswith("sp,")):
                dynamic.add((name, op, arg))
        return size
    def children(name):
        result = set()
        for op, arg in rows[name]:
            op = op.split(".")[0]
            if op in ("bl", "blx", "b", "beq", "bne", "bhi", "bls", "bgt", "blt", "bge", "ble", "bcc", "bcs", "bpl", "bmi", "bvc", "bvs"):
                if re.fullmatch(r"r\d+|ip", arg):
                    if name in flex:
                        result.update(child for child in flex[name] if child in rows)
                    else:
                        unresolved.add((name, op, arg))
                else:
                    target = re.search(r" <([^>]+)>", arg)
                    if target and "+" not in target[1] and target[1] != name:
                        if target[1] in rows:
                            result.add(target[1])
                        else:
                            unresolved.add((name, op, target[1]))
            if op == "bx" and arg not in ("lr", "r14"):
                if name in flex:
                    result.update(child for child in flex[name] if child in rows)
                else:
                    unresolved.add((name, op, arg))
        return result
    @functools.lru_cache(None)
    def path(name, ancestors=()):
        if name in ancestors:
            cycles.add(ancestors[ancestors.index(name):]+(name,))
            return 0, ()
        frame, kind = own.get(name, (0, "library"))
        if kind == "library":
            frame = library_frame(name)
        elif kind != "static":
            dynamic.add((name, kind, str(frame)))
        below = max((path(child, ancestors+(name,)) for child in children(name)), default=(0, ()))
        return frame+below[0], ((name, frame),)+below[1]
    print("\n"+mode)
    values = {}
    for root in roots:
        size, chain = path(root)
        values[root] = size
        print(root, "own", own.get(root), "chain bytes", size, " -> ".join(f"{f}:{n}" for f,n in chain))
    for capture in ("foc_board_capture_adc", "foc_board_capture_encoder", "foc_board_capture_poll", "foc_board_capture_start"):
        if capture in rows:
            count, chain = path(capture)
            print(capture, "own", own.get(capture), "chain", count, "symbol instructions", len(rows[capture]),
                  " -> ".join(f"{f}:{n}" for f, n in chain))
    print("main direct frame", own["main"])
    print("unresolved", sorted(unresolved))
    print("dynamic", sorted(dynamic))
    print("recursive", sorted(cycles))
    print("nested envelope bytes incl 3*36 exception frames",
          own["main"][0] + max(values[roots[5]], values[roots[6]]) + values[roots[4]]
          + max(values[roots[2]], values[roots[3]]) + max(values[roots[0]], values[roots[1]]) + 108)
    for key in ("foc_at32_trace_enter", "foc_at32_trace_exit", "foc_at32_trace_hook",
                "foc_runtime_copy_snapshot", "foc_runtime_h0_step", "foc_runtime_h1_step", "sinf", "cosf", "fmodf", "sqrtf", "hypotf"):
        actual = next((name for name in rows if name == key or name.startswith(key+".")), None)
        if actual:
            print(actual, "static instructions visible in symbol", len(rows[actual]))

