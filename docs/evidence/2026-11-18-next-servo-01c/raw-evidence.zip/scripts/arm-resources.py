
from pathlib import Path
import subprocess as sp, hashlib

root=Path(__file__).parent
old=Path(r"C:/Users/16429/AppData/Local/Temp/servo01b_1795001461062")/"final-complete/locked-arm"
current=root/"final-complete/locked-arm"
obj=root/"foc_impedance_tuning.o"
def tool(name,*args):
    return sp.check_output(["arm-none-eabi-"+name,*args],text=True,stderr=sp.STDOUT)
print(tool("gcc","--version").splitlines()[0])
flags=["-std=c11","-mcpu=cortex-m4","-mthumb","-mfloat-abi=soft","-Os",
       "-ffunction-sections","-fdata-sections","-fstack-usage","-Wall","-Wextra","-Wpedantic","-Werror"]
print("flags"," ".join(flags))
tool("gcc",*flags,"-Icore/include","-c","core/src/foc_impedance_tuning.c","-o",obj)
print(tool("size",obj))
print(tool("nm","-S",obj))
print(obj.with_suffix(".su").read_text())
(root/"foc_impedance_tuning-disasm.txt").write_text(tool("objdump","-dr",obj))
for name,d in [("01B",old),("01C",current)]:
    elf=next(d.glob("*.elf"))
    binfile=next(d.glob("*.bin"))
    assert "foc_impedance_tuning_design" not in tool("nm","-S",elf)
    print(name,tool("size",elf))
    print(name,"BIN",binfile.stat().st_size,hashlib.sha256(binfile.read_bytes()).hexdigest())
    if name=="01B":
        baseline=binfile.read_bytes()
    else:
        assert binfile.read_bytes()==baseline
        print("locked BIN identical; tuning symbol absent in both")

