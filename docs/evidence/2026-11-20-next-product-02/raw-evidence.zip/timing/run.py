"""Reproduce PRODUCT-02C on Windows without touching the source tree.

Usage: python run.py D:/path/to/source D:/path/to/new/output
Requires Python 3, CMake, Ninja, Clang, MinGW GCC, and Arm GNU on PATH.
"""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import platform
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
IMAGE = "falconfoc-v2-at32f415"
CQ03_BIN_SHA256 = "78d055e1135d23a5c2d08f6db17fbf64622333f429381efa2632401eb58cbda2"


def command(argv, output, errors=None):
    argv = [str(value) for value in argv]
    print(subprocess.list2cmdline(argv), flush=True)
    with output.open("wb") as stdout:
        if errors is None:
            subprocess.run(argv, check=True, stdout=stdout, stderr=subprocess.STDOUT)
        else:
            with errors.open("wb") as stderr:
                subprocess.run(argv, check=True, stdout=stdout, stderr=stderr)


def benchmark(repo, out, compiler):
    build = out / f"host-{compiler}"
    command(["cmake", "-S", HERE / "src", "-B", build, "-G", "Ninja", f"-DREPO={repo}",
             "-DCMAKE_BUILD_TYPE=Release", f"-DCMAKE_C_COMPILER={compiler}"],
            out / f"host-{compiler}-configure.txt")
    command(["cmake", "--build", build, "--target", "product02-timing", "test-foc-timing"],
            out / f"host-{compiler}-build.txt")
    command([build / "product02-timing.exe"], out / f"host-{compiler}-timing.csv",
            out / f"host-{compiler}-checks.txt")
    command([build / "board" / "test-foc-timing.exe"], out / f"board-{compiler}-witness.txt")


def arm_image(repo, out, mode):
    build = out / f"arm-{mode}"
    trace = "ON" if mode == "trace" else "OFF"
    command(["cmake", "-S", repo / "firmware" / "at32f415", "-B", build, "-G", "Ninja",
             f"-DCMAKE_TOOLCHAIN_FILE={repo}/tools/cmake/arm-gcc-toolchain.cmake",
             "-DMCU_CPU=cortex-m4", "-DMCU_FLOAT=soft", "-DMCU_FPU=none",
             f"-DFALCONFOC_RT02_TIMING_TRACE={trace}", "-DFALCONFOC_BOARD_CAPTURE=OFF",
             "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON"], out / f"arm-{mode}-configure.txt")
    command(["cmake", "--build", build], out / f"arm-{mode}-build.txt")
    elf = build / f"{IMAGE}.elf"
    command(["arm-none-eabi-objdump", "-d", elf], build / "disassembly.txt")
    command(["arm-none-eabi-nm", "-a", "-S", "--size-sort", "--radix=d", elf],
            out / f"arm-{mode}-symbols.txt")
    command(["arm-none-eabi-size", "-A", elf], out / f"arm-{mode}-sections.txt")
    command(["arm-none-eabi-readelf", "-A", elf], out / f"arm-{mode}-attributes.txt")
    for file, label in [(build / "disassembly.txt", "disassembly.txt"),
                        (build / "compile_commands.json", "compile-commands.json"),
                        (build / f"{IMAGE}.map", "link.map")]:
        shutil.copyfile(file, out / f"arm-{mode}-{label}")
    with (out / f"arm-{mode}-stack-usage.txt").open("w", encoding="utf-8") as stack:
        for source in sorted(build.rglob("*.su")):
            stack.write(source.read_text(encoding="utf-8"))
    binary = build / f"{IMAGE}.bin"
    return binary.stat().st_size, sha256(binary.read_bytes()).hexdigest()


def main():
    if sys.platform != "win32" or len(sys.argv) != 3:
        raise SystemExit(__doc__)
    repo = Path(sys.argv[1]).resolve(strict=True)
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=False)
    with (out / "environment.txt").open("w", encoding="utf-8") as environment:
        print(datetime.now(timezone.utc).isoformat(), platform.platform(),
              platform.processor(), file=environment)
        for executable in ("cmake", "ninja", "clang", "gcc", "arm-none-eabi-gcc"):
            print(subprocess.check_output([executable, "--version"], text=True), file=environment)
    for compiler in ("clang", "gcc"):
        benchmark(repo, out, compiler)
    command([sys.executable, HERE / "summarize.py", out / "host-clang-timing.csv",
             out / "host-gcc-timing.csv"], out / "host-summary.txt")
    default_size, default_sha = arm_image(repo, out, "default")
    trace_size, trace_sha = arm_image(repo, out, "trace")
    (out / "arm-bin-identity.txt").write_text(
        f"default BIN {default_size} B SHA-256 {default_sha}\n"
        f"trace BIN {trace_size} B SHA-256 {trace_sha}\n"
        f"CQ-03 default BIN identical: {default_sha == CQ03_BIN_SHA256}\n",
        encoding="utf-8")
    command([sys.executable, HERE / "stack-review.py", out], out / "arm-stack-review.txt")
    command([sys.executable, HERE / "arm-calls.py", out / "arm-default-disassembly.txt",
             out / "arm-trace-disassembly.txt"], out / "arm-call-sites.txt")


if __name__ == "__main__":
    main()
