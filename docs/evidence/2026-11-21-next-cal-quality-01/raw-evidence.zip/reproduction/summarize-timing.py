"""Summarize actual native stage events without mixing the three clocks."""
import csv
import json
from pathlib import Path
import sys


ACQUISITION = {"BOOTSTRAP_ADC", "BOOTSTRAP_SCAN", "ADC_ZERO", "ENCODER_LUT", "ROTOR",
               "ELECTRICAL_OFFSET", "ELECTRICAL_D", "ELECTRICAL_Q", "FLUX", "MECHANICAL",
               "LIVE_ADC_CHECK", "LIVE_ENCODER_CHECK"}


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def summary(data):
    stages = [r for r in data["events"] if r.get("event") == "CAL_STAGE" and r["status"] != "RUNNING"]
    return {
        "subprocess_round_trip_ms": data["host_wall_elapsed_ns"] / 1e6,
        "exit_status": data["exit_status"],
        "calibration_simulated_us": sum((r["simulated_motor_us"] or 0) for r in stages
                                        if r["stage"] in ACQUISITION and r["status"] in ("COMPLETED", "FAILED")),
        "control_holdout_simulated_us": sum((r["simulated_motor_us"] or 0) for r in stages
                                            if r["stage"] == "CONTROL_HOLDOUT"),
        "native_wall_us_sum": sum((r["host_wall_us"] or 0) for r in stages),
        "process_cpu_us_sum": sum((r["host_compute_us"] or 0) for r in stages),
        "elapsed_stages": stages,
    }


def summarize(root, out):
    report = {}
    all_stages = []
    for profile in sorted(root.iterdir()):
        if not profile.is_dir():
            continue
        results = {}
        report[profile.name] = results
        for kind in ("full-preview", "full-reviewed", "full-cancelled", "quick-preview",
                     "quick-reviewed", "quick-encoder-rejection", "quick-wrong-review"):
            results[kind] = summary(read(profile / (kind + ".json")))
        plan = None
        for path in sorted(profile.glob("selective-*.json")):
            data = read(path)
            command = data["command"][-1].split(" ", 1)
            if command[0] == "plan" and data["exit_status"] == 0:
                plan = command[1]
            if command[0] == "capture":
                plan = None
                results["selective-initial-capture"] = summary(data)
            if command[0] == "measure" and f"selective-measure-{plan}" not in results:
                results[f"selective-measure-{plan}"] = summary(data)
            if command[0] == "approve" and f"selective-approve-{plan or 'initial'}" not in results:
                results[f"selective-approve-{plan or 'initial'}"] = summary(data)
        for operation, row in results.items():
            print(profile.name, operation, row["calibration_simulated_us"], row["native_wall_us_sum"],
                  row["process_cpu_us_sum"], round(row["subprocess_round_trip_ms"], 3))
            for stage in row["elapsed_stages"]:
                all_stages.append({**stage, "profile": profile.name, "operation": operation})
    out.mkdir()
    (out / "timing-summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    with (out / "timing-stages.csv").open("w", encoding="utf-8", newline="") as stream:
        fields = ("profile", "operation", "mode", "stage", "status", "simulated_motor_us",
                  "host_wall_us", "host_compute_us", "user_interaction_us", "eta_us")
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_stages)


if __name__ == "__main__":
    summarize(*(Path(arg) for arg in sys.argv[1:]))
