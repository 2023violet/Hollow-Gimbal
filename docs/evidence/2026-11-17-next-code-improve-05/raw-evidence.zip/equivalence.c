
#include "runtime/src/foc_pipeline.c"
#define main existing_pipeline_main
#include "runtime/tests/test_foc_pipeline.c"
#undef main

struct adapter_trace {
    struct foc_pipeline *pipeline;
    struct foc_device_sim_registers entry[4];
    enum foc_device_output_action actions[4];
    unsigned calls;
    bool reject_update;
    bool reject_inhibit;
};

static bool same_registers(struct foc_device_sim_registers a, struct foc_device_sim_registers b)
{
    return a.bridge_gate_closed == b.bridge_gate_closed && a.bridge_enabled == b.bridge_enabled &&
        a.channel1_compare == b.channel1_compare && a.channel2_compare == b.channel2_compare &&
        a.channel3_compare == b.channel3_compare;
}

static bool same_request(struct foc_device_pwm_request a, struct foc_device_pwm_request b)
{
    return a.action == b.action && a.output_enable_request == b.output_enable_request &&
        a.duty_a == b.duty_a && a.duty_b == b.duty_b && a.duty_c == b.duty_c &&
        a.channel1_compare == b.channel1_compare && a.channel2_compare == b.channel2_compare &&
        a.channel3_compare == b.channel3_compare;
}

static bool observe_submit(void *argument, const struct foc_device_pwm_request *request)
{
    struct adapter_trace *trace = argument;
    if (trace->calls >= sizeof trace->actions / sizeof trace->actions[0]) {
        return false;
    }
    trace->entry[trace->calls] = trace->pipeline->mock.registers;
    trace->actions[trace->calls++] = request->action;
    return request->action == FOC_DEVICE_OUTPUT_UPDATE ? !trace->reject_update
                                                       : !trace->reject_inhibit;
}

static void report(const char *name, int status, const struct foc_pipeline *p,
                   const struct adapter_trace *trace)
{
    const struct foc_pipeline_mock *m = &p->mock;
    printf("%s status=%d reason=%d state=%d faults=%u attempts=%u updates=%u "
           "inhibit_attempt=%u ask=%d ack=%d confirmed=%d regs=%u,%u,%u,%u,%u "
           "pi=%a,%a calls=%u",
           name, status, p->last_reason, p->safety.state, (unsigned)p->safety.latched_faults,
           (unsigned)m->attempts, (unsigned)m->updates, (unsigned)m->last_inhibit_attempt,
           m->last_request.action, m->last_accepted, m->output_confirmed,
           m->registers.bridge_gate_closed, m->registers.bridge_enabled,
           (unsigned)m->registers.channel1_compare, (unsigned)m->registers.channel2_compare,
           (unsigned)m->registers.channel3_compare,
           p->current.integral_v.d, p->current.integral_v.q, trace->calls);
    for (unsigned i = 0; i < trace->calls; i++) {
        printf(" %d", trace->actions[i]);
    }
    putchar('\n');
}

static int direct_cases(void)
{
    const struct foc_device_sim_registers seed = {7U, 9U, 11U, 22U, 33U};
    const struct foc_device_sim_registers expected = {1U, 0U, 100U, 200U, 300U};
    const struct foc_device_pwm_request update = {
        .action = FOC_DEVICE_OUTPUT_UPDATE,
        .output_enable_request = 1U,
        .duty_a = 0.25f, .duty_b = 0.5f, .duty_c = 0.75f,
        .channel1_compare = 100U, .channel2_compare = 200U, .channel3_compare = 300U,
    };
    struct foc_pipeline p = {.pwm_config = test_config.pwm, .output_submit = observe_submit};
    struct adapter_trace trace = {.pipeline = &p};
    p.output_arg = &trace;
    p.mock.registers = seed;
    TEST_ASSERT(foc_pipeline_submit(&p, &update));
    TEST_ASSERT(same_registers(p.mock.registers, expected) && same_registers(trace.entry[0], seed));
    TEST_ASSERT(p.mock.attempts == 1U && p.mock.updates == 1U && trace.calls == 1U);
    TEST_ASSERT(p.mock.output_confirmed && p.mock.last_accepted &&
                same_request(p.mock.last_update, update) && same_request(p.mock.last_request, update));
    report("normal-update", 0, &p, &trace);

    struct foc_device_pwm_request other = update;
    other.channel1_compare = 123U;
    trace.calls = 0U;
    p.mock.reject_update = true;
    TEST_ASSERT(!foc_pipeline_submit(&p, &other));
    TEST_ASSERT(same_registers(p.mock.registers, expected) && trace.calls == 0U);
    TEST_ASSERT(p.mock.attempts == 2U && p.mock.updates == 1U);
    TEST_ASSERT(!p.mock.output_confirmed && !p.mock.last_accepted &&
                same_request(p.mock.last_update, update) &&
                same_request(p.mock.last_rejected_update, other) &&
                same_request(p.mock.last_request, other));
    report("forced-update-reject", -1, &p, &trace);

    p.mock.reject_update = false;
    other.channel1_compare = test_config.pwm.period_counts + 1U;
    TEST_ASSERT(!foc_pipeline_submit(&p, &other));
    TEST_ASSERT(same_registers(p.mock.registers, expected) && trace.calls == 0U);
    TEST_ASSERT(p.mock.attempts == 3U && p.mock.updates == 1U);
    TEST_ASSERT(!p.mock.output_confirmed && !p.mock.last_accepted &&
                same_request(p.mock.last_update, update) &&
                same_request(p.mock.last_rejected_update, other) &&
                same_request(p.mock.last_request, other));
    report("invalid-device-request", -1, &p, &trace);

    struct foc_device_pwm_request stop;
    TEST_ASSERT(foc_device_output_inhibit(&p.pwm_config, &stop) == FOC_DEVICE_STATUS_OK);
    p.mock.reject_inhibit = true;
    TEST_ASSERT(!foc_pipeline_submit(&p, &stop));
    TEST_ASSERT(same_registers(p.mock.registers, expected) && trace.calls == 0U);
    TEST_ASSERT(!p.mock.output_confirmed && !p.mock.last_accepted &&
                p.mock.attempts == 4U && p.mock.last_inhibit_attempt == 4U && p.mock.updates == 1U);
    TEST_ASSERT(same_request(p.mock.last_request, stop) && same_request(p.mock.last_update, update) &&
                same_request(p.mock.last_rejected_update, other));
    report("forced-inhibit-reject", -1, &p, &trace);

    p.mock.reject_inhibit = false;
    TEST_ASSERT(foc_pipeline_submit(&p, &stop));
    TEST_ASSERT(inhibited(&p) && same_registers(trace.entry[0], expected));
    TEST_ASSERT(p.mock.attempts == 5U && p.mock.last_inhibit_attempt == 5U &&
                p.mock.updates == 1U && trace.calls == 1U && trace.actions[0] == FOC_DEVICE_OUTPUT_INHIBIT);
    TEST_ASSERT(same_request(p.mock.last_request, stop) && same_request(p.mock.last_update, update) &&
                same_request(p.mock.last_rejected_update, other));
    report("normal-inhibit", 0, &p, &trace);
    return 0;
}

static int callback_cases(bool reject_inhibit)
{
    struct foc_pipeline p = {0};
    struct adapter_trace trace = {.pipeline = &p};
    struct foc_pipeline_config config = test_config;
    config.output_submit = observe_submit;
    config.output_arg = &trace;
    struct foc_pipeline_input input = sample(0U, 0U);
    TEST_ASSERT(begin_run(&p, &config, &input, (struct foc_vector_dq){0.1f, 1.0f}) == 0);
    trace.calls = 0U;
    input = sample(100U, 1U);
    TEST_ASSERT(foc_pipeline_step(&p, &input) == FOC_PIPELINE_OK);
    const struct foc_device_sim_registers committed = p.mock.registers;
    const struct foc_device_pwm_request previous = p.mock.last_update;
    const struct foc_vector_dq integral = p.current.integral_v;
    const uint32_t attempts = p.mock.attempts;
    trace.calls = 0U;
    trace.reject_update = true;
    trace.reject_inhibit = reject_inhibit;
    input = sample(200U, 2U);
    const int status = foc_pipeline_step(&p, &input);
    TEST_ASSERT(status == (reject_inhibit ? FOC_PIPELINE_ERR_INHIBIT : FOC_PIPELINE_ERR_UPDATE));
    TEST_ASSERT(p.last_reason == FOC_PIPELINE_ERR_UPDATE && p.safety.state == FOC_SAFE_STATE_DISABLED);
    TEST_ASSERT(trace.calls == 2U && trace.actions[0] == FOC_DEVICE_OUTPUT_UPDATE &&
                trace.actions[1] == FOC_DEVICE_OUTPUT_INHIBIT);
    TEST_ASSERT(same_registers(trace.entry[0], committed) && same_registers(trace.entry[1], committed));
    TEST_ASSERT(p.current.integral_v.d == integral.d && p.current.integral_v.q == integral.q);
    TEST_ASSERT(p.mock.attempts == attempts + 2U && p.mock.updates == 1U &&
                p.mock.last_request.action == FOC_DEVICE_OUTPUT_INHIBIT &&
                p.mock.last_rejected_update.action == FOC_DEVICE_OUTPUT_UPDATE &&
                same_request(p.mock.last_update, previous));
    TEST_ASSERT(reject_inhibit ? (!p.mock.output_confirmed && !p.mock.last_accepted &&
                                  same_registers(p.mock.registers, committed)) : inhibited(&p));
    report(reject_inhibit ? "adapter-double-reject" : "adapter-update-reject", status, &p, &trace);
    return 0;
}

static int stop_recovery(bool fault)
{
    struct foc_pipeline p = {0};
    struct adapter_trace trace = {.pipeline = &p};
    struct foc_pipeline_config config = test_config;
    config.output_submit = observe_submit;
    config.output_arg = &trace;
    struct foc_pipeline_input input = sample(0U, 0U);
    TEST_ASSERT(begin_run(&p, &config, &input, (struct foc_vector_dq){0.1f, 1.0f}) == 0);
    trace.calls = 0U;
    input = sample(100U, 1U);
    TEST_ASSERT(foc_pipeline_step(&p, &input) == FOC_PIPELINE_OK);
    const struct foc_vector_dq integral = p.current.integral_v;
    const struct foc_device_sim_registers committed = p.mock.registers;
    trace.calls = 0U;
    input = sample(200U, 2U);
    input.before_gate.inhibit = true;
    input.before_gate.fault_bits = fault ? FOC_SAFE_FAULT_COMMAND_TIMEOUT : FOC_SAFE_FAULT_NONE;
    const int status = foc_pipeline_step(&p, &input);
    TEST_ASSERT(status == FOC_PIPELINE_ERR_STOP && inhibited(&p) && p.mock.updates == 1U);
    TEST_ASSERT(trace.calls == 1U && trace.actions[0] == FOC_DEVICE_OUTPUT_INHIBIT &&
                same_registers(trace.entry[0], committed));
    TEST_ASSERT(p.current.integral_v.d == integral.d && p.current.integral_v.q == integral.q &&
                p.safety.latched_faults == input.before_gate.fault_bits &&
                p.safety.state == (fault ? FOC_SAFE_STATE_FAULT_LATCHED : FOC_SAFE_STATE_DISABLED));
    report(fault ? "stop-plus-fault" : "stop", status, &p, &trace);
    if (fault) {
        TEST_ASSERT(foc_pipeline_clear_fault(&p, 200U) == FOC_PIPELINE_OK);
    }
    trace.calls = 0U;
    TEST_ASSERT(publish_command(&p, 300U, 1U) == FOC_PIPELINE_OK);
    TEST_ASSERT(publish_heartbeats(&p, 300U) == 0);
    input = sample(300U, 3U);
    TEST_ASSERT(foc_pipeline_step(&p, &input) == FOC_PIPELINE_ERR_STATE);
    TEST_ASSERT(foc_pipeline_arm(&p, 300U) == FOC_PIPELINE_OK);
    TEST_ASSERT(foc_pipeline_start(&p, 300U) == FOC_PIPELINE_OK);
    TEST_ASSERT(p.current.integral_v.d == 0.0f && p.current.integral_v.q == 0.0f);
    input = sample(400U, 4U);
    TEST_ASSERT(foc_pipeline_step(&p, &input) == FOC_PIPELINE_OK);
    TEST_ASSERT(p.mock.updates == 2U && p.mock.output_confirmed &&
                p.mock.last_request.action == FOC_DEVICE_OUTPUT_UPDATE && p.current.integral_v.q > 0.0f);
    TEST_ASSERT(trace.calls == 2U && trace.actions[0] == FOC_DEVICE_OUTPUT_INHIBIT &&
                trace.actions[1] == FOC_DEVICE_OUTPUT_UPDATE);
    report(fault ? "fault-recovery-update" : "stop-recovery-update", 0, &p, &trace);
    return 0;
}

int main(void)
{
    return direct_cases() || callback_cases(false) || callback_cases(true) ||
        stop_recovery(false) || stop_recovery(true);
}

