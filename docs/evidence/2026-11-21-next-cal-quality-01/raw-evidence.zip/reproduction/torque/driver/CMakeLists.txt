cmake_minimum_required(VERSION 3.25)
project(falconfoc_cq02_load LANGUAGES C)
set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS OFF)

set(SOURCE_REPO "" CACHE PATH "Repository providing production libraries")
set(HISTORICAL_REPO "${SOURCE_REPO}" CACHE PATH "Frozen CQ-01 repository")
option(CQ02_FILTER_CONFIG "Use the CQ-02 damping setting" OFF)
add_subdirectory("${SOURCE_REPO}/simulation" simulation EXCLUDE_FROM_ALL)

add_executable(cq02-load cq02_load.c
    "${SOURCE_REPO}/core/src/foc_impedance_tuning.c"
    "${SOURCE_REPO}/core/src/foc_impedance_feedforward.c"
)
target_include_directories(cq02-load PRIVATE "${HISTORICAL_REPO}/simulation/tests")
target_link_libraries(cq02-load PRIVATE falconfoc-virtual-motor)
if(CQ02_FILTER_CONFIG)
    target_compile_definitions(cq02-load PRIVATE CQ02_FILTER_CONFIG=1)
endif()
if(CMAKE_C_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(cq02-load PRIVATE -Wall -Wextra -Wpedantic -Werror)
endif()
