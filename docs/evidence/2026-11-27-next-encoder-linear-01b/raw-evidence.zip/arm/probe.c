#include "foc_encoder_calibration.h"
const unsigned char fit_context_bytes[sizeof(struct foc_encoder_cal_context)] = {0};
const unsigned char fit_config_bytes[sizeof(struct foc_encoder_cal_config)] = {0};
const unsigned char fit_result_bytes[sizeof(struct foc_encoder_cal_result)] = {0};
const unsigned char fit_sample_bytes[sizeof(struct foc_encoder_cal_sample)] = {0};
const unsigned char fit_offset_bytes[sizeof(((struct foc_encoder_cal_result *)0)->offsets)] = {0};
const unsigned char sensor_context_bytes[sizeof(struct foc_encoder_context)] = {0};
