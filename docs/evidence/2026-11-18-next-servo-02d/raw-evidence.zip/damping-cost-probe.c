#include "foc_damping_noise_filter.h"
#include "foc_runtime.h"
const char filter_state_bytes[sizeof(struct damping_noise_filter)] = {0};
const char runtime_state_bytes[sizeof(struct foc_runtime)] = {0};
bool host_filter_step(struct damping_noise_filter *state, float speed, float cutoff, uint32_t dt_us)
{
    return damping_noise_filter_step(state, speed, cutoff, dt_us);
}
