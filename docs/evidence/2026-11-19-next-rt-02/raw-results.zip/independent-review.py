import hashlib, pathlib, re, subprocess, sys
root = pathlib.Path.cwd()
tmp = pathlib.Path(sys.argv[1])
firmware = "falconfoc-v2-at32f415"
arms = [tmp / flavor for flavor in ("arm-before", "arm-OFF", "arm-ON")]
for extension in ("bin", "hex"):
    before, off, on = ((folder / f"{firmware}.{extension}").read_bytes() for folder in arms)
    assert before == off and before != on
    print(extension, "RT-01 = RT-02 default byte for byte", hashlib.sha256(off).hexdigest())
    print(extension, "RT-02 instrumentation only", hashlib.sha256(on).hexdigest())
assert hashlib.sha256((arms[0] / (firmware + ".bin")).read_bytes()).hexdigest() == (
    "0b6d929c25342c1368ffd2741cd1c88636991903d61bd8cee6d3c18546c6efee"
)
def command(*args):
    return subprocess.check_output(args, text=True, encoding="utf-8", errors="replace")
def symbol_set(image):
    return set(re.findall(r"^[0-9a-f]+\s+\w\s+(.+)$", command("arm-none-eabi-nm", image), re.M))
def function(image, name):
    return command("arm-none-eabi-objdump", "-d", "--disassemble=" + name, image)
old, off, on = (str(folder / (firmware + ".elf")) for folder in arms)
assert symbol_set(old) == symbol_set(off)
assert not any(re.match(r"^foc_board_(shadow_|adc_(route_config|candidate_begin|scan_at|current_window)|low_side_window)", name) for name in symbol_set(on))
extra = symbol_set(on) - symbol_set(off)
assert not any(re.match(r"^(__aeabi_|sinf|cosf|sqrtf|fmodf|floorf|atan2f|malloc|free)", name) for name in extra)
for image in (off, on):
    assert re.findall(r"\bbl\s+[0-9a-f]+ <adc_preempt_software_trigger_enable>", function(image, "TMR1_CH_IRQHandler"))
    assert len(re.findall(r"\bbl\s+[0-9a-f]+ <adc_preempt_software_trigger_enable>", function(image, "TMR1_CH_IRQHandler"))) == 1
    assert len(re.findall(r"\bbl\s+[0-9a-f]+ <foc_board_adc_complete>", function(image, "ADC1_IRQHandler"))) == 1
    assert len(re.findall(r"\bbl\s+[0-9a-f]+ <foc_runtime_h0_step>", function(image, "foc_board_adc_complete"))) == 1
print("ADC event, trigger, PCCE/H0 handoff call counts checked on both images")
print("No linked offline candidate, shadow or math/library additions; extra ARM symbols:", ", ".join(sorted(extra)))
main = (root / "firmware/at32f415/src/main.c").read_text(encoding="utf-8")
assert "adc_preempt_conversion_trigger_set(ADC1, ADC12_PREEMPT_TRIG_SOFTWARE, TRUE);" in main
assert main.count("adc_preempt_conversion_trigger_set(") == 1
assert "foc_at32_lock_output();" in main and "pins.gpio_mode = GPIO_MODE_ANALOG;" in main
locked_adapter = (root / "firmware/at32f415/src/foc_board.c").read_text(encoding="utf-8").split("bool foc_board_output_submit(", 1)[1]
old_adapter = command("git", "show", "HEAD:firmware/at32f415/src/foc_board.c").split("bool foc_board_output_submit(", 1)[1]
assert locked_adapter == old_adapter, "Output lock function diff"
directories = ("core", "runtime", "sensors", "calibration", "g3", "control_plane", "platform", "protocol",
               "tools", "scripts", "applications", "bsp", "work", "examples", "simulation")
assert not command("git", "status", "--porcelain", "--", *directories).strip()
assert command("git", "rev-parse", "HEAD").strip() == "d824933946a365b8081089c2e396d77b3f661bc8"
assert not command("git", "diff", "--cached", "--name-only").strip()
assert command("git", "branch", "--show-current").strip() == "codex/falconfoc-v2-vm01a"
for stage in ("arch-00", "rt-01"):
    prefix = root / f"docs/evidence/2026-11-19-next-{stage}"
    for artifact in (prefix.with_suffix(".md"), prefix / "raw-results.zip", prefix / "host-timing.txt"):
        assert artifact.is_file()
        print(artifact.relative_to(root), hashlib.sha256(artifact.read_bytes()).hexdigest())
print("Board output adapter matches HEAD, original stage artifacts present, delivery HEAD/index/scope verified")
