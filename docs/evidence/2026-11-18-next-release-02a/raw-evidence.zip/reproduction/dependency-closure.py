from pathlib import Path
from zipfile import ZipFile
from pathlib import PurePosixPath
import json,re,sys,collections,posixpath

out = Path(sys.argv[1])
dist = Path(sys.argv[2])
p = out/"assemble-matrix.py"
script = p.read_text(encoding="utf8").replace(chr(92)+chr(96),chr(96))
script = script.replace('with (root/"early-files.md").open("a",encoding="utf8",newline="\\n") as f:\n    f.write("\\n".join(investigations))',
'''early_path = root / "early-files.md"
header = early_path.read_text(encoding="utf8").split("\\n### ", 1)[0].rstrip()
early_path.write_text(header + "\\n\\n" + "\\n".join(investigations), encoding="utf8", newline="\\n")''')
p.write_text(script, encoding="utf8", newline="\n")
early_path=Path("docs/release/2026-11-18-sdk-0.1.0-rc.1/early-files.md")
early_path.write_text(early_path.read_text(encoding="utf8").replace(chr(92)+chr(96),chr(96)),
                      encoding="utf8",newline="\n")

history=json.loads((out/"history.json").read_bytes())
names={r["path"] for r in history}
archive=dist/"falconfoc-servo-sdk-0.1.0-rc.1.zip"
cmake_source={}
with ZipFile(archive) as z:
    for config in sorted(name for name in names if name.endswith("CMakeLists.txt")):
        body=z.read(archive.stem+"/"+config).decode()
        sources=re.findall(r'(?m)(?<![A-Za-z0-9_./])([.\w/]+\.c)(?=[\s)])',body)
        resolved={posixpath.normpath(posixpath.join(posixpath.dirname(config),p)) for p in sources}
        assert resolved<=names,(config,resolved-names)
        cmake_source[config]=sorted(resolved)
    for name in ("CMakeLists.txt","core/CMakeLists.txt","simulation/CMakeLists.txt",
                 "examples/servo/CMakeLists.txt"):
        (out / ("cmake-" + name.replace("/","_"))).write_bytes(z.read(archive.stem+"/"+name))
reverse=collections.defaultdict(list)
for row in history:
    for inc in row["includes"]:
        if inc["kind"]=="project":
            assert inc["resolved"] in names
            reverse[inc["resolved"]].append(row["path"])
records=[]
for row in history:
    if row["origin"]!="origin_unresolved":
        continue
    name=row["path"]
    reason={"cmake_sources":[cfg for cfg,src in cmake_source.items() if name in src],
            "direct_includers":sorted(reverse[name])}
    assert any(reason.values()),name
    records.append({"path":name,**reason})
(out/"sdk-dependency-closure.json").write_text(json.dumps(
    {"cmake_sources":cmake_source,"early_dependencies":records},indent=2)+"\n",encoding="utf8")
print("All 16 early files have a direct CMake or header dependency")
for row in records:
    print(row["path"]," | ",", ".join(row["cmake_sources"]+row["direct_includers"]))

