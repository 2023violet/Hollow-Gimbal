"""Freeze the historical Current request timeline with a fixed wire sequence."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "tools/falconfoc-cli"))
from falconfoc_cli import Frame, MESSAGES, encode, setpoint


request_names = ("hello", "capability", "setpoint", "arm", "setpoint", "start")
request_names += ("setpoint", "telemetry") * 10 + ("stop", "status", "telemetry")
payloads = {"setpoint": setpoint("current", 0.0, float(sys.argv[2]))}
wire = b"".join(
    encode(Frame(MESSAGES[name], 1, sequence, int(sequence != 0), payloads.get(name, b"")))
    for sequence, name in enumerate(request_names)
)
Path(sys.argv[1]).write_bytes(wire)
