import hashlib,json,math,pathlib,re,shutil,types,zipfile
from audit import OUT,ROOT,SRC,run
from analyze import analyze

NAME='2026-11-17-next-system-angle-01'
EVID=ROOT/'docs/evidence'/NAME
BASE=json.loads((OUT/'source-before.json').read_text(encoding='utf-8'))
def read(p): return p.read_text(encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def records(p):
    data=[json.loads(s) for s in read(p/'commands.jsonl').splitlines()]
    assert all(r['log_sha256']==sha(p/(r['name']+'.log')) for r in data)
    return data
def tests(p,n):
    data=records(p)
    assert all(r['exit']==0 for r in data)
    assert f'100% tests passed out of {n}' in read(p/'ctest.log')
    return {'count':n,'commands':data}

baseline={lane:tests(OUT/'tests'/lane,n) for lane,n in [('core',15),('runtime',11),('simulation',15)]}
regression={lane:tests(OUT/'final'/lane,n) for lane,n in [('core',15),('runtime',11),('core-asan',15)]}
regression.update({lane:tests(OUT/'verified'/lane,15) for lane in ['simulation','simulation-gcc','simulation-asan']})
gate=records(OUT/'verified/gates');assert all(r['exit']==0 for r in gate)
text=read(OUT/'verified/gates/strict-all.log')
assert '[Total]   PASS' in text and '45/45' in text and text.count('[cmake_quality] format-check:')==30
assert 'checked C/H files: 82' in read(OUT/'verified/gates/source.log')
measurements={lane:analyze(OUT/'verified'/lane/'data.csv') for lane in ['simulation','simulation-gcc','simulation-asan']}
metrics=measurements['simulation'];worst=metrics['worst_combined']
for label in ['missing-poles','publication-time']:
    assert all(r['exit']==0 for r in records(OUT/'mutations'/label/'old-tests'))
    rows=records(OUT/'mutations'/label/'new-tests')
    assert [r['exit'] for r in rows]==[0,0,1]
assert [r['exit'] for r in records(OUT/'review-mutation/before')]==[0,0,0]
assert [r['exit'] for r in records(OUT/'review-mutation/after')]==[0,0,1]
for row in ['future-candidate','duplicate-candidate','expired-candidate']:
    assert 'system_cache_expired case='+row in read(OUT/'verified/simulation/data.log')

attribution={label:json.loads(read(OUT/'attribution'/(label+'.json'))) for label in ['actual','ideal-phase']}
assert all(v['metrics']['control_quality']=='CONTROL_QUALITY_FAIL' and
           v['metrics']['update_accepted']==52 and v['metrics']['saturation_count']==0 and
           v['physical_applied']==False for v in attribution.values())
run(OUT/'review','ctest-entries',['ctest','--test-dir',OUT/'verified/simulation/build','-N'])
entries=read(OUT/'review/ctest-entries.log')
assert 'test-foc-periodic-chain' in entries and 'Total Tests: 15' in entries

result={'baseline_head':'f00e9a414d4de2e4d7a82cab47ebbeef6d54179b',
    'branch':'codex/falconfoc-v2-vm01a','verdict':'PASS_SCOPED_HOST_SYSTEM_ANGLE_ACCEPTANCE',
    'product_total_angle_limit':'NOT_SPECIFIED_NOT_CERTIFIED','git_delivery':'NOT_AUTHORIZED_THIS_STAGE',
    'acceptance_clarification':'User explicitly accepts continued control using the previous still-fresh valid source after candidate rejection; document boundary.',
    'G1':baseline,'G7':regression,'gates':gate,'cmake_format_files':30,'legacy_host_tests':45,
    'measurements':measurements,'attribution':attribution,
    'budgets':{'quantization_p7_rad':7.0*math.pi/65536.0,'mapping_rad':1e-5,
       'prediction_numeric_rad':2e-6,'reference_speed_arithmetic_mechanical_rad_s':.001,
       'dq_rotation_component_a':3e-7,'dq_vector_identity_a':5e-7,
       'source':'conditional analytic quantization/model bounds; existing phase/numeric contracts; declared reference arithmetic checks',
       'note':'Not a universal estimator or hardware accuracy guarantee; correlated signed components; no RSS assumption.'},
    'profiles':{'cpr':65536,'poles':[7,4],'offset_rad_stored_float':0.3700000047683716,
       'speed_lpf_hz':80,'prediction':[650,2000,.00065],'cadence_h0_h1_foreground_us':[200,500,200],
       'warmup_captures':40,'warmup_us':20000,'measurement_window_us':[600,40000],
       'samples_per_ordinary_case':198,'ordinary_cases':13,'rejection_cases':6,
       'seed':'0x51a72026','assumed_transport_availability_us':5,'stamp_jitter_us':20,
       'adc_sampling_jitter_us':5,'execution_jitter_us':10,
       'worst_combined_motion':[6.28,100,250],'worst_combined_capture_delay_us':150,
       'worst_combined_stamp_bias_us':10,'worst_combined_direction':-1,
       'worst_combined_clock_origin':4294965295},
    'independent_review':{'reviewer':'system_angle_review','read_only':True,
       'finding':'P2 test omission: retained feedback payload/dq/expiry not protected',
       'resolution':'logical payload comparisons, poisoned candidate phase/speed, actual Current dq and original-source expiry; compiled corruption mutant before0/after1',
       'production_defect_confirmed':False},
    'evidence_root':str(OUT)}

EVID.mkdir(exist_ok=False)
archive=EVID/'raw-logs.zip';files=set()
for folder in ['tests','initial','retry-foreground','retry-separated','retry-reviewed',
               'mutations','review-mutation','attribution','final','gates','verified','review']:
    for p in (OUT/folder).rglob('*'):
        if not p.is_file(): continue
        if p.name in ['commands.jsonl','LastTest.log','mutation.json','mutation.txt','ideal-phase-injection.c.txt']:
            files.add(p)
        if (p.parent/'commands.jsonl').is_file() and p.suffix in ['.log','.csv','.json']:
            files.add(p)
for p in ['audit.py','baseline.py','study.py','counterfactual.py','mutations.py','review_mutation.py',
          'final_checks.py','post_review.py','analyze.py','collect.py','progress.md','report.template.md',
          'source-before.json','artifacts-before.json','gate-isolation.json','head.txt','branch.txt','git-status-before.txt']:
    files.add(OUT/p)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files): z.write(p,p.relative_to(OUT).as_posix())
    for rel in ['simulation/tests/test_foc_periodic_chain.c','simulation/tests/foc_system_angle_oracle.h']:
        z.write(ROOT/rel,'source-current/'+rel)
    for label in ['missing-poles','publication-time']:
        for rel in ['runtime/src/foc_runtime.c','simulation/tests/test_foc_periodic_chain.c']:
            z.write(OUT/'mutations'/label/'source'/rel,'mutation-sources/'+label+'/'+rel)
    z.write(OUT/'attribution/ideal-source/simulation/src/foc_virtual_current.c','counterfactual-source/foc_virtual_current.c')
    z.write(OUT/'review-mutation/source/runtime/src/foc_runtime.c','review-mutation-source/foc_runtime.c')
result['raw_archive']={'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(files)+8}
save(EVID/'results.json',result)

names=['static','low-speed','constant','capture-delay','accelerate','reverse','stamp-bias',
       'stamp-jitter','adc-jitter','execution-jitter','clock-wrap','combined','virtual-poles']
table=['| 场景 | 最大相位误差 | RMS相位误差 |','|---|---:|---:|']
for name in names:
    v=metrics['cases'][name]['phase_error_rad']
    table.append(f'| {name} | {v["max_abs"]:.9g} | {v["rms"]:.9g} |')
regtable='''| 本轮正式执行 | 结果 |
|---|---|
| Core Clang / Core ASan+UBSan | 各15/15 |
| Runtime Clang | 11/11 |
| 复核后Simulation Clang / GCC / Clang ASan+UBSan | 各15/15 |
| Source / 修改C/H格式 | 82 C/H、9 CMake、9 README，exit0 / exit0 |
| 严格Scope all -RequireCMakeFormatter -Summary | exit0，30个CMake格式检查，Legacy Host45/45，Total PASS |'''
paths=['simulation/tests/test_foc_periodic_chain.c','simulation/tests/foc_system_angle_oracle.h',
       'simulation/README.md','docs/governance/Themis_工程维护日志.md',f'docs/evidence/{NAME}.md',
       f'docs/evidence/{NAME}/results.json',f'docs/evidence/{NAME}/change-verification.json',f'docs/evidence/{NAME}/raw-logs.zip']
mapping=math.remainder(float(worst['theta_h1_e'])-float(worst['theta_quantized_e']),2*math.pi)
report=read(OUT/'report.template.md').replace('@@CASE_TABLE@@','\n'.join(table)).replace(
    '@@REGRESSION_TABLE@@',regtable).replace('@@FILE_LIST@@','\n'.join('- `'+p+'`' for p in paths)).replace(
    '@@MAPPING@@',f'{mapping:+.12g}').replace('foc_motion.c:44','foc_motion.c:29').replace('foc_runtime.c:312','foc_runtime.c:315')
assert '@@' not in report
(ROOT/'docs/evidence'/f'{NAME}.md').write_text(report,encoding='utf-8')

log='docs/governance/Themis_工程维护日志.md';assert (ROOT/log).read_bytes()==(SRC/log).read_bytes()
append='''

## 2026-11-17 FalconFOC V2 NEXT-SYSTEM-ANGLE-01 系统角度误差与组合扰动

- [链路/Oracle] 扩展原periodic-chain CTest，真实Encoder→H1→H0→Pipeline/Current。Double强制运动、最近码值和独立速度/LPF参考；分离量化、源映射、raw/LPF、时间戳、模型与Float32计算项，不覆盖生产H1速度/H0角度。
- [实测] 13类预热场景及6类拒绝，2587接受测量行；最大总相位0.0290408770921rad、组合RMS0.0121325047757rad，最大Id/Iq误差0.0233581373120/0.0286009012699A（1A向量）。量化p7上界0.00033555829735rad，计算项最大3.98386820422e-7rad；条件三角界不当作产品总精度保证。
- [准入] 用户明确接受拒绝候选后保留旧新鲜源继续控制；正式检查拒绝payload不污染Current，原源过期后INHIBIT、UPDATE不增。传输失败/越界码发布invalid亦禁止新UPDATE。独立复核P2测试遗漏已通过污染旧槽的可编译变异0→1和正常GREEN关闭，无确认生产缺陷。
- [归因] 当前10ms Current基线与隔离理想ADC相位对照均保留CONTROL_QUALITY_FAIL；RUNNING RMSE仅0.089168893772→0.089167571490A。历史quality判据包含STOP后的full-window末项；不把该标签解释成相位主因，也不修改PI/电压/质量阈值。
- [回归/保护] Core15/15、Runtime11/11、复核后Simulation Clang/GCC/ASan+UBSan各15/15，Core ASan15/15，Source82/9/9、格式、strict Scope all含30项CMake和Host45/45通过。仅测试/helper/说明/本日志/新证据；生产、旧证据及2427既有产物保留，Gate使用历史ELF/MAP副本，非新ARM重建。
- [交付/边界] 报告docs/evidence/2026-11-17-next-system-angle-01.md，受控Host合同PASS；未授权本轮Git交付，不暂存/commit/push，不进入下一阶段。G3-SAFE HARDWARE NOT VERIFIED / G3-PWR LOCKED / AT32F415 WCET NOT VERIFIED / MOTOR PHYSICAL OPERATION UNVERIFIED。
'''
with (ROOT/log).open('ab') as f:f.write(append.encode('utf-8'))

module=types.ModuleType('baseline_helpers');module.__file__=str(OUT/'baseline.py')
exec(read(OUT/'baseline.py').split('\nif len(sys.argv) == 1:')[0],module.__dict__)
save(EVID/'change-verification.json',{})
now=module.manifest();artifacts=module.manifest(True)
changed=sorted(p for p in BASE if BASE[p]!=now.get(p));added=sorted(now.keys()-BASE.keys())
assert set(changed)=={'simulation/README.md','simulation/tests/test_foc_periodic_chain.c',log}
assert set(added)==set(paths)-set(changed)
assert artifacts==json.loads(read(OUT/'artifacts-before.json'))
assert all(sha(SRC/p)==v['sha256'] for p,v in BASE.items())
assert (ROOT/log).read_bytes().startswith((SRC/log).read_bytes())
assert module.git('status','--porcelain',root=module.MAIN)==(OUT/'main-status-before.txt').read_bytes()
assert module.git('rev-parse','HEAD')==(OUT/'head.txt').read_bytes()
assert module.git('branch','--show-current')==(OUT/'branch.txt').read_bytes()
remote=module.git('ls-remote','--heads','origin',result['branch']).decode().split()[0]
assert remote==result['baseline_head'] and not module.git('diff','--cached','--name-only')
for rel in ['simulation/README.md','simulation/tests/test_foc_periodic_chain.c','simulation/tests/foc_system_angle_oracle.h']:
    assert (ROOT/rel).read_bytes()==(OUT/'green-repo'/rel).read_bytes()
production=[p for p in BASE if p.startswith(('core/','sensors/','runtime/','firmware/','g3/','protocol/','simulation/src/','simulation/include/'))]
assert all(BASE[p]==now[p] for p in production)
protection={'source_files_before':len(BASE),'source_files_after':len(now),'changed_existing':changed,'added':added,
    'unchanged_control_and_api_files':len(production),'production_source_and_config_unchanged':True,
    'existing_ignored_artifacts_unchanged':len(artifacts),'existing_ignored_bytes':sum(v['size'] for v in artifacts.values()),
    'snapshot_unchanged':True,'maintenance_prefix_preserved':True,'main_worktree_unchanged':True,
    'head':result['baseline_head'],'remote_head':remote,'branch':result['branch'],
    'index_empty':True,'commit_push':'NOT_EXECUTED_NOT_AUTHORIZED_THIS_STAGE',
    'unchanged_production_sha256':{p:BASE[p]['sha256'] for p in production if p.endswith('.c')}}
save(EVID/'change-verification.json',protection);save(OUT/'change-verification.json',protection)
save(OUT/'results.json',result)
run(OUT/'review','diff-check',['git','diff','--check'],cwd=ROOT)
run(OUT/'review','status',['git','-c','core.quotepath=false','status','--short','--untracked-files=all'],cwd=ROOT)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
assert all(all(line.rstrip()==line for line in read(ROOT/p).splitlines())
           for p in paths if p not in BASE and not p.endswith('.zip'))
(OUT/'final.patch').write_bytes(module.git('diff','--binary'))
print(json.dumps({'verdict':result['verdict'],'files':paths,'source_before_after':[len(BASE),len(now)],
                  'archive':result['raw_archive'],'local_remote':remote,'sample_count':metrics['sample_count']},ensure_ascii=False))
