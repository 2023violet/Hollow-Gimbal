import pathlib, subprocess, sys
root, tmp = pathlib.Path.cwd(), pathlib.Path(sys.argv[1])
build = tmp/"board-clang-off"
source = (root/"firmware/at32f415/src/foc_board_timing.c").read_text(encoding="utf-8")
includes = ["firmware/at32f415/include","runtime/include","core/include","sensors/include",
            "calibration/include","g3/np/include","g3/safe/include","protocol/include",
            "platform/at/at32f415/generated/inc"]
flags = ["-D_DEBUG","-D_DLL","-D_MT","-Xclang","--dependent-lib=msvcrtd"]
predicate = " && observed_us - before_phase_us <= latest[index] - phase_us"
assert source.count(predicate) == 1
for name in ("control","stale-phase-only"):
    text = source if name == "control" else source.replace(predicate, "")
    src, obj, exe = (tmp/(name+ext) for ext in (".c",".obj",".exe"))
    src.write_text(text, encoding="utf-8")
    subprocess.run(["clang","-std=c11",*flags,*["-I"+str(root/inc) for inc in includes],"-c",str(src),"-o",str(obj)],check=True)
    subprocess.run(["clang","-fuse-ld=lld",*flags,str(build/"CMakeFiles/test-foc-timing.dir/tests/test_foc_timing.c.obj"),
                    str(obj),str(build/"falconfoc-board1.lib"),str(build/"protocol/falconfoc-wire.lib"),"-o",str(exe)],check=True)
    res = subprocess.run([str(exe)],capture_output=True,text=True)
    print(name,res.returncode,res.stderr.strip() or "passed all timing checks")
    assert res.returncode == (0 if name == "control" else 1)
    if name != "control":
        assert "FOC_BOARD_SPI_CS" in res.stderr
