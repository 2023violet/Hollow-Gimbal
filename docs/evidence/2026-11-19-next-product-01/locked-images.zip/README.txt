Locked Board1 ARM verification artifacts. These files were built offline, never flashed.
arm-base: DWT OFF Capture OFF; arm-dwt: DWT ON Capture OFF.
arm-capture: DWT OFF Capture ON; arm-both: DWT ON Capture ON.
Deployment requires explicit approvals and independent hardware isolation per the report.
