#include "foc_parameter.h"
char size_candidate[sizeof(struct foc_parameter_candidate)];
char size_receipt[sizeof(struct foc_parameter_receipt)];
char size_parameter_descriptor[sizeof(struct foc_parameter_descriptor)];
char size_parameter_edit[sizeof(struct foc_parameter_edit)];
