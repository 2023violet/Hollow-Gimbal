#define main formal_mailbox_main
#include "D:/study/Software/Hollow-Gimbal-vm01a/runtime/tests/test_foc_runtime_mailbox.c"
#undef main

static void stop_after_control(struct foc_runtime *runtime, enum foc_runtime_hook_point point, void *arg)
{
    bool *armed = arg;
    if (*armed && point == FOC_RUNTIME_HOOK_AFTER_CONTROL) {
        *armed = false;
        foc_runtime_request_inhibit(runtime, 0U);
    }
}

static int private_start(struct foc_runtime *runtime, bool *armed)
{
    struct foc_runtime_config cfg = runtime_config;
    cfg.hook = stop_after_control;
    cfg.hook_arg = armed;
    const struct foc_pipeline_command command = {{0.0f,1.0f},0U,0U};
    TEST_ASSERT(foc_runtime_init(runtime,&pipeline_config,&cfg,0U)==0);
    TEST_ASSERT(foc_runtime_publish_command(runtime,&command,0U)==0);
    TEST_ASSERT(publish_sample(runtime,0U,0U)==0);
    TEST_ASSERT(service(runtime,0U,0U)==FOC_RUNTIME_IDLE);
    struct foc_runtime_foreground_result fg;
    TEST_ASSERT(foc_runtime_foreground_poll(runtime,2U,0U,0U,&fg)>=0);
    for (uint32_t t=100U;t<=300U;t+=100U) {
        TEST_ASSERT(publish_sample(runtime,t,t/100U)==0);
        struct foc_runtime_fast_input input=input_at(t,t/100U);
        input.action=t==100U?FOC_RUNTIME_ACTION_ARM:t==200U?FOC_RUNTIME_ACTION_START:FOC_RUNTIME_ACTION_NONE;
        TEST_ASSERT(foc_runtime_h0_step(runtime,&input)==(t==300U?FOC_RUNTIME_OK:FOC_RUNTIME_IDLE));
        TEST_ASSERT(foc_runtime_foreground_poll(runtime,t+2U,0U,0U,&fg)>=0);
    }
    return 0;
}

int main(void)
{
    for(unsigned expired=0;expired<2;++expired) {
        struct foc_runtime rt={0}; bool armed=false;
        TEST_ASSERT(private_start(&rt,&armed)==0);
        struct foc_runtime_lifecycle_request request={.action=FOC_RUNTIME_ACTION_ARM,.request_sequence=91U,.source_session=rt.motion_session,.produced_us=expired?400U-1500U:302U};
        TEST_ASSERT(foc_runtime_publish_lifecycle_request(&rt,&request,302U)==0);
        TEST_ASSERT(publish_sample(&rt,400U,4U)==0);
        armed=true;
        struct foc_runtime_fast_input input=input_at(400U,4U);
        input.now_us=401U;
        const int status=foc_runtime_h0_step(&rt,&input);
        struct foc_runtime_lifecycle_result result;
        TEST_ASSERT(foc_runtime_read_lifecycle_result(&rt,&result)==0);
        printf("post_control_stop expired=%u h0=%d result=%d state=%d output=%d updates=%u session=%u\n",expired,status,result.result,rt.pipeline.safety.state,rt.pipeline.mock.last_request.action,rt.pipeline.mock.updates,rt.motion_session);
        TEST_ASSERT(rt.pipeline.mock.last_request.action==FOC_DEVICE_OUTPUT_INHIBIT);
        TEST_ASSERT(rt.pipeline.safety.state==FOC_SAFE_STATE_DISABLED);
    }
    for(unsigned invalid=0;invalid<2;++invalid) {
        struct foc_runtime rt={0}; TEST_ASSERT(start_running(&rt)==0);
        struct foc_runtime_lifecycle_request request={.action=FOC_RUNTIME_ACTION_ARM,.request_sequence=92U,.source_session=rt.motion_session,.produced_us=302U};
        TEST_ASSERT(foc_runtime_publish_lifecycle_request(&rt,&request,302U)==0);
        /* Model producer publishing after H0 invalidated its captured session.
         * Session invalidation is injected directly to isolate consumption predicate. */
        ++rt.motion_session;
        TEST_ASSERT(publish_sample(&rt,400U,4U)==0);
        struct foc_runtime_fast_input input=input_at(400U,4U);
        if(invalid)input.adc.valid_mask=0U;
        const uint32_t before=rt.pipeline.mock.updates;
        const int status=foc_runtime_h0_step(&rt,&input);
        struct foc_runtime_lifecycle_result result;
        TEST_ASSERT(foc_runtime_read_lifecycle_result(&rt,&result)==0);
        printf("consume_stale_session invalid=%u h0=%d result=%d state=%d output=%d updates=%u streak=%u\n",invalid,status,result.result,rt.pipeline.safety.state,rt.pipeline.mock.last_request.action,rt.pipeline.mock.updates,rt.pipeline.safety.invalid_sample_streak);
        TEST_ASSERT(result.result==FOC_RUNTIME_REQUEST_REJECTED && result.request_sequence==92U);
        TEST_ASSERT(rt.pipeline.mock.updates==before+(invalid?0U:1U));
        TEST_ASSERT(invalid?rt.pipeline.mock.last_request.action==FOC_DEVICE_OUTPUT_INHIBIT:rt.pipeline.safety.state==FOC_SAFE_STATE_RUNNING);
        TEST_ASSERT(rt.pipeline.safety.invalid_sample_streak==(invalid?1U:0U));
    }
    return 0;
}

