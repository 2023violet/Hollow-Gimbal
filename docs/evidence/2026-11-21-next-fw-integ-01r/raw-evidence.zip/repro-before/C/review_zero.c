/* Pre-fix reproduction: a supply with review_id 0 is accepted. */
#include "foc_board_boot.h"
#include <stdio.h>
static struct foc_runtime runtime; static struct foc_board_output output;
static struct foc_board_encoder encoder; static struct foc_board_boot boot;
int main(void) {
    struct foc_board_calibration_supply supply = *foc_board_calibration_supply();
    supply.review_id = 0U;
    const struct foc_board_calibration_expectation e = foc_board_calibration_expectation();
    enum foc_board_calibration_rejection r = foc_board_boot_qualify(&supply, &e, NULL, NULL);
    int s = foc_board_boot_select(&boot, &runtime, &output, &encoder, &supply, &e, 0U);
    printf("review_id=0: qualify rejection=%d select=%d configuration=%d calibration=%d\n",
           (int)r, s, (int)boot.configuration, (int)boot.calibration);
    return boot.configuration == FOC_BOARD_CALIBRATED_CONFIGURATION ? 1 : 0;
}
