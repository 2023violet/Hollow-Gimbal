import shutil
from audit import OUT,ROOT,CC,run,copy_source
dest=OUT/'mutant-expired-bypass';source=copy_source(dest/'source')
for rel in ['runtime/src/foc_runtime.c','runtime/tests/test_foc_runtime_mailbox.c']:
    shutil.copy2(ROOT/rel,source/rel)
p=source/'runtime/src/foc_runtime.c';s=p.read_text(encoding='utf-8')
needle='status = foc_runtime_control(runtime, &control_input);'
assert s.count(needle)==1
p.write_text(s.replace(needle,'status = lifecycle_result == FOC_RUNTIME_REQUEST_NONE\n                ? foc_runtime_control(runtime, &control_input)\n                : lifecycle_status;'),encoding='utf-8')
run(dest,'configure',['cmake','-S',source/'runtime','-B',dest/'build','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER='+CC])
run(dest,'build',['cmake','--build',dest/'build','--parallel','4'])
run(dest,'ctest',['ctest','--test-dir',dest/'build','--output-on-failure','-R','^test-foc-runtime-mailbox$'],expected=8)
