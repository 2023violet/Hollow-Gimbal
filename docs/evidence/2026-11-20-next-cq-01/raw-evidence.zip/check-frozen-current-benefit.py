import json
import pathlib
import sys
baseline = pathlib.Path(sys.argv[1])
for name in ('generic', 'salient'):
    rows = [json.loads(line) for line in (baseline / f'{name}-cal.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    def worst(configuration):
        return max(r['rms'] for r in rows if r.get('event') == 'CONTROL_TRIAL' and r['mode'] == 'current' and r['configuration'] == configuration)
    original, applied = worst('before'), worst('after')
    print(name, f'default={original:.9f} A', f'old_calibrated={applied:.9f} A', 'PASS' if applied < original else 'FAIL')
    if name == 'generic':
        assert applied < original, (original, applied)
