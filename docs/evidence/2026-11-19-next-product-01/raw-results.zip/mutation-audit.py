import hashlib, json, re, subprocess, sys
from pathlib import Path

root = Path.cwd()
scratch = Path(sys.argv[1])
board = root/'firmware/at32f415'
source = (board/'src/foc_board_pwm_model.c').read_text()
test = board/'tests/test_foc_pwm_port.c'
new = scratch/'board-gcc'
includes = [board/'include', *(root/p for p in (
    'core/include','calibration/include','g3/np/include','g3/safe/include',
    'runtime/include','sensors/include','platform/at/at32f415/generated/inc','protocol/include'))]
mutants = {
    'ignore-guard-at-load': ('!timer_witness_valid || !guard_allowed ||','!timer_witness_valid ||'),
    'partially-written-bank-applies': ('port->stage != FOC_BOARD_PWM_SHADOW_WRITTEN || !same_id',
        '(port->stage != FOC_BOARD_PWM_SHADOW_WRITTEN && port->stage != FOC_BOARD_PWM_UPDATE_ACCEPTED) || !same_id'),
    'ignore-compare-readback': ('compare != port->requested[channel - 1U] ||',''),
}
for name, (old, replacement) in mutants.items():
    assert old in source, (name, old)
    file = scratch/(name+'.c')
    file.write_text(source.replace(old,replacement,1))
    exe = scratch/(name+'.exe')
    subprocess.run(['gcc','-std=c11',*(f'-I{p}' for p in includes),str(file),str(test),
                    str(new/'libfalconfoc-board1.a'),str(new/'protocol/libfalconfoc-wire.a'),'-o',str(exe)],check=True)
    run = subprocess.run([str(exe)],capture_output=True,text=True,check=False)
    assert run.returncode == 1, name
    print(name, 'rejected by existing test:', run.stderr.strip())
