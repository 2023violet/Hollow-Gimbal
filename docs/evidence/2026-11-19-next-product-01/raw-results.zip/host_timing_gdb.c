#include "foc_board.h"
#include <stdint.h>
#include <stdio.h>
struct foc_runtime runtime;
struct foc_board_output output;
struct foc_board_adc adc;
struct foc_board_encoder encoder;
struct span { uint32_t start, end, identity, detail; };
struct { struct span trigger, adc, tmr5[3], spi, usart, supervision, serial; } rt_trace;
static uint32_t fake_clock(void) { return 0; }
__attribute__((noinline)) void witness(void) { puts("Host fixture only"); }
int main(void)
{
    adc.trace_cycles=fake_clock;
    adc.live.transaction.slot_id=40;
    adc.live.transaction.generation=77;
    adc.live.transaction.trace=(struct foc_board_adc_trace){.points=15,.compare_irq_cycles=8,
        .trigger_proxy_cycles=13,.trigger_write_return_cycles=14,.pcce_irq_cycles=56,
        .ranks_ready_cycles=66,.h0_start_cycles=70,.h0_finish_cycles=100,
        .adapter_start_cycles=83,.adapter_return_cycles=90};
    encoder.trace=(struct foc_board_encoder_trace){.seq=7,.decode_start_cycles=108,
        .decode_done_cycles=121,.h1_start_cycles=126,.h1_finish_cycles=153};
    rt_trace.adc=(struct span){56,103,40,0};
    rt_trace.spi=(struct span){109,112,7,0};
    rt_trace.serial=(struct span){154,190,10,0};
    runtime.h0.due_count=40;
    runtime.h1.due_count=7;
    runtime.supervision.due_count=40;
    runtime.pipeline.mock.output_confirmed=true;
    witness();
    return 0;
}
