#include "foc_impedance_feedforward.h"
#include "foc_runtime.h"
const char input_bytes[sizeof(struct foc_impedance_feedforward_input)] = {0};
const char result_bytes[sizeof(struct foc_impedance_feedforward_result)] = {0};
const char runtime_bytes[sizeof(struct foc_runtime)] = {0};
