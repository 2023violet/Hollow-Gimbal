#include "foc_virtual_calibration_package.h"

#include <inttypes.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

#define CHECK(expr)                                                                                \
    do {                                                                                           \
        if (!(expr)) {                                                                             \
            fprintf(stderr, "line %d failed: %s\n", __LINE__, #expr);                                \
            return -1;                                                                             \
        }                                                                                          \
    } while (0)

static const struct foc_cal_application_tuning_policy tuning = {
    .current = {
        .bandwidth_hz = 130.0f,
        .sample_period_s = 0.00036f,
        .update_delay_s = 0.00026f,
        .initial_error_a = 0.6f,
        .available_voltage_v = 1.25f,
    },
    .max_rs_relative_difference = 0.05f,
    .velocity_natural_frequency_rad_s = 19.0f,
    .velocity_damping_ratio = 0.8f,
    .position_bandwidth_rad_s = 3.6f,
    .outer_extra_delay_s = 0.0006f,
    .tune_outer = true,
};

struct scenario {
    const char *name;
    double speed_rad_s;
    float vbus_v;
    float id_a;
    float iq_a;
    bool mismatch;
    bool free_rotor;
    bool reverse;
};

static const struct scenario scenarios[] = {
    {"low_small",       0.5, 12.0f,  0.0f, 0.35f, false, false, false},
    {"low_large",       0.5, 12.0f,  0.0f, 2.20f, false, false, false},
    {"medium_large",    5.2, 12.0f,  0.0f, 2.20f, false, false, false},
    {"high_small",     18.0, 12.0f,  0.0f, 0.35f, false, false, false},
    {"high_large",     18.0, 12.0f,  0.0f, 2.20f, false, false, false},
    {"high_regen_d",   18.0, 12.0f, -0.35f,-2.2f, false, false, false},
    {"low_bus_large",   0.5,  6.1f,  0.0f, 2.20f, false, false, false},
    {"low_bus_high",   18.0,  6.1f,  0.0f, 2.20f, false, false, false},
    {"undervoltage",    0.5,  5.9f,  0.0f, 0.35f, false, false, false},
    {"plant_mismatch",  5.2, 12.0f,  0.0f, 2.20f, true,  false, false},
    {"current_clip",    0.5, 12.0f,  0.6f, 3.0f,  false, false, false},
    {"free_high_large",18.0, 12.0f,  0.0f, 2.20f, false, true,  false},
    {"high_reverse",   18.0, 12.0f,  0.0f, 2.20f, false, false, true },
    {"cold_large_free", 0.0, 12.0f,  0.0f, 2.20f, false, true,  false},
    {"cold_large_held", 0.0, 12.0f,  0.0f, 2.20f, false, false, false},
};

struct initialization {
    const struct foc_virtual_calibration_package *package;
    struct foc_cal_application_sensor sensor;
};

static int initialize(
    void *argument,
    struct foc_runtime *runtime,
    struct foc_encoder_context *encoder,
    const struct foc_pipeline_config *pipeline,
    const struct foc_virtual_current_profile *profile
)
{
    struct initialization *init = argument;
    const struct foc_virtual_calibration_package *package = init->package;
    const struct foc_cal_application_output output = {
        .submit = pipeline->output_submit,
        .argument = pipeline->output_arg,
    };


    (void)profile;
    CHECK(foc_cal_application_restore(
        &package->candidate, package->candidate.gains.identity.encoder_id,
        &package->lut, &output, runtime, &init->sensor, 0U) == FOC_CAL_APPLICATION_APPLIED);
    *encoder = init->sensor.encoder;
    return 0;
}

static int lifecycle(
    struct foc_virtual_current *driver, enum foc_runtime_action action, uint32_t tick_us
)
{
    struct foc_runtime_lifecycle_result result = {0};

    CHECK(foc_virtual_current_publish_lifecycle(driver, action, FOC_RUNTIME_MODE_CURRENT) ==
          FOC_RUNTIME_OK);
    CHECK(foc_virtual_current_run_until(driver, tick_us) == 0);
    CHECK(foc_virtual_current_read_lifecycle(driver, &result) == FOC_RUNTIME_OK);
    CHECK(result.result == FOC_RUNTIME_REQUEST_APPLIED);
    return 0;
}

static int log_sample(
    const struct scenario *sample, int direction, const struct foc_virtual_current *driver,
    uint32_t start_us, float id_a, float iq_a
)
{
    struct foc_runtime_snapshot view = {0};
    struct foc_virtual_motor_observation plant = {0};
    CHECK(foc_virtual_current_snapshot(driver, &view) == FOC_RUNTIME_OK);
    CHECK(foc_virtual_motor_observe(&driver->motor, &plant) == 0);

    /* Actual voltage applied over the interval ending here, not the new H0 receipt. */
    const double cs = cos(plant.electrical_position_rad);
    const double sn = sin(plant.electrical_position_rad);
    const double vd = cs * plant.v_alpha_v + sn * plant.v_beta_v;
    const double vq = -sn * plant.v_alpha_v + cs * plant.v_beta_v;
    CHECK(printf(
        "%s,%d,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ",%" PRIu32 ",%" PRIu32
        ",%" PRIu32 ",%" PRIu32 ",%d,%d,%d,%" PRIu32 ",%d"
        ",%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g"
        ",%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%u,%.9g"
        ",%.9g,%.9g,%.9g,%.9g,%.9g,%d\n",
        sample->name, direction, driver->virtual_time_us - start_us, driver->virtual_time_us,
        view.trigger_us, view.sample_us, view.command_us, view.sensor_us,
        driver->fault_events.last_accepted_update_us, view.state, view.action,
        view.output_confirmed, view.faults, view.pipeline_status,
        id_a, iq_a, plant.id_a, plant.iq_a, plant.mechanical_velocity_rad_s,
        view.mechanical_rad_s, vd, vq, hypot(plant.v_alpha_v, plant.v_beta_v),
        hypot(driver->output.v_alpha_v, driver->output.v_beta_v), plant.electromagnetic_torque_nm,
        sample->vbus_v, driver->runtime.pipeline.current.config.pwm.voltage_limit_v,
        driver->runtime.pipeline.current.config.pwm.vbus_min_v,
        driver->runtime.pipeline.current.config.current_limit_a,
        driver->motor.params.rs_ohm, driver->motor.params.ld_h, driver->motor.params.lq_h,
        driver->motor.params.psi_f_wb, driver->motor.params.pole_pairs,
        driver->profile.adc.current_a_per_count,
        driver->runtime.pipeline.current.config.kp_v_per_a.d,
        driver->runtime.pipeline.current.config.kp_v_per_a.q,
        driver->runtime.pipeline.current.config.ki_v_per_a_s.q,
        driver->runtime.pipeline.current.integral_v.d,
        driver->runtime.pipeline.current.integral_v.q, plant.fixture_active) > 0);
    return 0;
}

static int run(
    struct foc_virtual_current_profile profile, struct foc_virtual_calibration_package *package,
    const struct scenario *sample, int direction
)
{
    struct foc_virtual_current driver = {0};
    const uint32_t start_us = 1800U;
    const uint32_t duration_us = sample->reverse ? 200000U :
        sample->speed_rad_s == 0.0 ? 60000U : 120000U;
    const float sign = (float)direction;
    float id_a = sign * sample->id_a;
    float iq_a = sign * sample->iq_a;

    profile.vbus_v = sample->vbus_v;
    profile.initial_state.mechanical_velocity_rad_s = direction * sample->speed_rad_s;
    if (sample->mismatch) {
        profile.motor.rs_ohm *= 1.15;
        profile.motor.ld_h *= 0.85;
        profile.motor.lq_h *= 1.15;
        profile.motor.psi_f_wb *= 1.08;
    }
    struct initialization init = {.package = package};
    CHECK(foc_virtual_current_init_with(&driver, &profile, initialize, &init) == 0);
    const struct foc_current_config *live = &driver.runtime.pipeline.current.config;
    const struct foc_current_config *approved = &package->candidate.pipeline.current;
    CHECK(live->pwm.voltage_limit_v == approved->pwm.voltage_limit_v &&
          live->pwm.vbus_min_v == approved->pwm.vbus_min_v &&
          live->current_limit_a == approved->current_limit_a &&
          live->kp_v_per_a.d == approved->kp_v_per_a.d &&
          live->kp_v_per_a.q == approved->kp_v_per_a.q &&
          live->ki_v_per_a_s.q == approved->ki_v_per_a_s.q &&
          driver.runtime.config.h0.period_us == 200U &&
          driver.runtime.config.h1.period_us == 500U);
    if (!sample->free_rotor) {
        CHECK(foc_virtual_motor_set_fixture_speed(
            &driver.motor, profile.initial_state.mechanical_velocity_rad_s) == 0);
    }

    CHECK(foc_virtual_current_run_until(&driver, 700U) == 0);
    CHECK(foc_virtual_current_publish_iq(&driver, id_a, iq_a) == FOC_RUNTIME_OK);
    CHECK(foc_virtual_current_run_until(&driver, 1300U) == 0);
    CHECK(lifecycle(&driver, FOC_RUNTIME_ACTION_ARM, 1400U) == 0);
    CHECK(foc_virtual_current_publish_iq(&driver, id_a, iq_a) == FOC_RUNTIME_OK);
    CHECK(foc_virtual_current_run_until(&driver, 1600U) == 0);
    CHECK(lifecycle(&driver, FOC_RUNTIME_ACTION_START, start_us) == 0);
    CHECK(log_sample(sample, direction, &driver, start_us, id_a, iq_a) == 0);

    uint32_t expected_updates = driver.output.accepted_updates;
    const bool admitted = sample->vbus_v >= approved->pwm.vbus_min_v;
    for (uint32_t t = 200U; t <= duration_us; t += 200U) {
        if (sample->reverse && t == 100200U) {
            iq_a = -sign * 0.35f;
        }
        if ((t - 200U) % 1000U == 0U && (admitted || t == 200U)) {
            CHECK(foc_virtual_current_publish_iq(&driver, id_a, iq_a) == FOC_RUNTIME_OK);
        }
        CHECK(foc_virtual_current_run_until(&driver, start_us + t) == 0);
        CHECK(log_sample(sample, direction, &driver, start_us, id_a, iq_a) == 0);
        if (admitted) {
            expected_updates++;
            if (driver.output.mode != FOC_VIRTUAL_OUTPUT_UPDATE) {
                struct foc_runtime_snapshot view = {0};
                CHECK(foc_virtual_current_snapshot(&driver, &view) == FOC_RUNTIME_OK);
                const unsigned int slot = atomic_load(&driver.runtime.sensor_slot);
                uint16_t raw = 0;
                uint32_t corrected = 0;
                CHECK(foc_virtual_current_acquire_encoder(&driver.profile, &driver.motor, &raw) == 0);
                CHECK(foc_encoder_correct_code(&driver.encoder, raw, &corrected) == 0);
                fprintf(stderr,
                        "case=%s sign=%d H0=%u position=%.9g raw_now=%u corr_now=%u enc_raw=%u enc_corr=%u enc_us=%u continuity_lost=%d invalid=%u slot=%u slot_valid=%d phase=%.9g sample=%u pred=%u\n",
                        sample->name, direction, view.trigger_us, driver.motor.state.mechanical_position_rad,
                        raw, corrected, driver.encoder.previous_code, driver.encoder.previous_corrected_code,
                        driver.encoder.previous_us, driver.encoder.continuity_lost, driver.encoder.invalid_count,
                        slot, driver.runtime.sensor_slots[slot].sample.valid,
                        driver.runtime.sensor_slots[slot].sample.theta_elec_rad,
                        driver.runtime.sensor_slots[slot].sample.captured_us, view.angle_prediction_us);
            }
            CHECK(driver.output.mode == FOC_VIRTUAL_OUTPUT_UPDATE &&
                  driver.output.accepted_updates == expected_updates &&
                  driver.output.rejected_updates == 0U &&
                  driver.fault_events.last_accepted_update_us == start_us + t);
        } else {
            CHECK(driver.output.mode == FOC_VIRTUAL_OUTPUT_HIGH_Z &&
                  driver.output.accepted_updates == 0U);
            if (t == 2000U) {
                break;
            }
        }
    }

    CHECK(foc_virtual_current_request_stop(&driver) == 0);
    CHECK(foc_virtual_current_run_until(&driver, driver.virtual_time_us + 1000U) == 0);
    CHECK(driver.output.mode == FOC_VIRTUAL_OUTPUT_HIGH_Z &&
          driver.output.accepted_updates == expected_updates);
    CHECK(log_sample(sample, direction, &driver, start_us, 0.0f, 0.0f) == 0);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc != 3) {
        fputs("usage: reach-probe PROFILE APPROVED_FCAL\n", stderr);
        return 2;
    }
    struct foc_virtual_current_profile profile;
    struct foc_cal_workflow_request request;
    struct foc_virtual_calibration_package package;
    CHECK(foc_virtual_calibration_profile(argv[1], &profile, &request) == FOC_VIRTUAL_CAL_OK);
    profile.runtime.motion.impedance.damping_filter_hz = 48.0f;
    struct foc_cal_application_tuning_policy legacy = tuning;
    legacy.current.bandwidth_hz = 36.0f;
    legacy.current.available_voltage_v = 0.4f;
    CHECK(foc_virtual_calibration_package_load(
        argv[2], &profile, &request.identity, &tuning, &legacy, &package) == FOC_VIRTUAL_PACKAGE_OK);
    CHECK(!package.uses_legacy_policy);
    const struct foc_motor_rl_model *model = &package.candidate.gains.model;
    fprintf(stderr,
        "profile=%s review_id=%08" PRIx32 " rs=%.9g ld=%.9g lq=%.9g flux=%.9g kt=%.9g"
        " pp=%u current_limit=%.9g voltage_limit=%.9g vbus_min=%.9g\n",
        argv[1], package.review_id, model->rs_ohm, model->ld_h, model->lq_h, package.flux_wb,
        package.candidate.runtime.config.motion.impedance.torque_constant_nm_per_a,
        (unsigned int)package.candidate.runtime.config.motion.rotor.pole_pairs,
        package.candidate.pipeline.current.current_limit_a,
        package.candidate.pipeline.current.pwm.voltage_limit_v,
        package.candidate.pipeline.current.pwm.vbus_min_v);
    puts("case,direction,elapsed_us,time_us,h0_us,adc_us,cmd_us,enc_us,accepted_us,state,action,"
         "confirmed,faults,pipeline_status,id_ref,iq_ref,id,iq,omega,omega_enc,vd,vq,v_applied,"
         "v_accepted,torque,vbus,voltage_limit,bus_min,current_limit,rs,ld,lq,flux,pp,adc_quantum,"
         "kp_d,kp_q,ki_q,id_integral,iq_integral,fixture");
    for (unsigned int i = 0U; i < sizeof scenarios / sizeof scenarios[0]; i++) {
        for (int sign = -1; sign <= 1; sign += 2) {
            CHECK(run(profile, &package, &scenarios[i], sign) == 0);
        }
    }
    return 0;
}
