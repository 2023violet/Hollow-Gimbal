from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import os, shutil, subprocess as sp, sys

root = Path(__file__).resolve().parent
src = Path.cwd()
prev = root.parent / "falconfoc-soft05-2026-11-18"
logs = root / "logs"
logs.mkdir(exist_ok=True)
env = os.environ.copy()
llvm = Path(sp.check_output(["clang","-print-resource-dir"],text=True).strip())
env["PATH"] = os.pathsep.join([r"D:\Git\bin",r"C:\mingw64\bin",str(llvm/"lib/windows"),env["PATH"]])
env.update(PYTHONDONTWRITEBYTECODE="1",ASAN_OPTIONS="halt_on_error=1",
           UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
tool = Path("tools/falconfoc-calibration-replay")
golden = prev/"consumer/external-clang-output.txt"
baseline_bin = prev/"existing-regressions/build/locked-arm-current-worktree/falconfoc-v2-at32f415.bin"

def run(label, commands, cwd=src):
    status = 0
    with (logs/f"{label}.log").open("w",encoding="utf8") as f:
        for args in commands:
            print("$ "+sp.list2cmdline(list(map(str,args))),file=f,flush=True)
            status = sp.run(args,cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT).returncode
            print(f"exit={status}",file=f,flush=True)
            if status:
                break
    lines = (logs/f"{label}.log").read_text(encoding="utf8",errors="replace").splitlines()
    print(label,status,*((lines[-15:] if status else [
        l for l in lines if "tests passed out of" in l or l.startswith("[Total]") or "source_contract]" in l
    ])[-8:]),flush=True)
    return status

def flags(variant):
    compiler = "C:/mingw64/bin/gcc.exe" if variant=="gcc" else "clang"
    sanitize = ["-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
               "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined"] if variant=="asan" else []
    return [f"-DCMAKE_C_COMPILER={compiler}",*sanitize]

def host(job):
    name, project, variant, targets, regex = job
    label=f"{name}-{variant}"
    path=root/f"test-{label}"
    commands=[
        ["cmake","-S",project,"-B",path,"-G","Ninja","-DCMAKE_BUILD_TYPE=Debug",*flags(variant)],
        ["cmake","--build",path,"--parallel","4",*(["--target",*targets] if targets else [])],
        ["ctest","--test-dir",path,"--output-on-failure","--no-tests=error","-j","4",
         *(["-R",regex] if regex else [])],
    ]
    if name=="workflow-demo":
        commands+=[[path/"falconfoc-calibration-workflow-demo.exe"]]
    status=run(label,commands)
    if name=="workflow-demo" and status==0:
        output=sp.check_output([path/"falconfoc-calibration-workflow-demo.exe"],env=env)
        (logs/f"{label}-stdout.txt").write_bytes(output)
        assert output==golden.read_bytes()
    if name=="control":
        if status==0:
            for exe in ("test-foc-config-store","test-foc-config-codec"):
                output=sp.check_output([path/(exe+".exe")],env=env)
                (logs/(label+"-"+exe+".txt")).write_bytes(output)
                assert output==(prev/"existing-regressions/final-logs"/f"{variant}-{exe}.txt").read_bytes()
            with (logs/(label+".log")).open("a",encoding="utf8") as f:
                print("Config Store and Codec stdout byte-identical to SOFT-05",file=f)
    return status

def arm():
    label="locked-arm"
    path=root/"test-locked-arm"
    status=run(label,[
        ["cmake","-S","firmware/at32f415","-B",path,"-G","Ninja",
         f"-DCMAKE_TOOLCHAIN_FILE={(src/'tools/cmake/arm-gcc-toolchain.cmake').as_posix()}",
         "-DMCU_CPU=cortex-m4","-DMCU_FPU=none","-DMCU_FLOAT=soft"],
        ["cmake","--build",path,"--parallel","4"],
        ["arm-none-eabi-size",path/"falconfoc-v2-at32f415.elf"],
    ])
    if status==0:
        actual=(path/"falconfoc-v2-at32f415.bin").read_bytes()
        assert sha256(actual).hexdigest()=="6e63211ece4447818ee41536d632203059c837acc9e90c65e3098972b83a5403"
        assert actual==baseline_bin.read_bytes()
        with (logs/f"{label}.log").open("a",encoding="utf8") as output:
            print(f"BIN byte-identical to SOFT-05, {len(actual)} bytes, SHA-256 {sha256(actual).hexdigest()}",file=output)
    return status

suite=[
    ("core","core",[],None),("runtime","runtime",[],None),
    ("simulation","simulation",[],None),("protocol","protocol",[],None),
    ("board-host","firmware/at32f415",[],None),
    ("servo-demo","examples/servo",["falconfoc-servo-demo"],"^test-falconfoc-servo-(demo|faults)$"),
    ("motion-protection","examples/motion-protection",["falconfoc-motion-protection-demo"],
        "^test-falconfoc-motion-protection-example$"),
    ("inspector","tools/falconfoc-config-inspector",[],r"^test-falconfoc-config-inspector$"),
    ("control","control_plane",["test-foc-parameter","test-foc-config-codec","test-foc-config-store",
         "test-foc-config-diagnostics","test-foc-calibration-application"],
        r"^test-foc-(parameter|config-(codec|store|diagnostics)|calibration-application)$"),
]
affected=[
    ("calibration","calibration",[],None),
    ("workflow-demo","examples/calibration-workflow",["falconfoc-calibration-workflow-demo"],
        "^test-falconfoc-calibration-workflow-demo$"),
    ("trace-tool",tool,["falconfoc-calibration-replay-runner"],"^test-falconfoc-calibration-replay$"),
]
if sys.argv[1]=="baseline":
    jobs=suite
elif sys.argv[1]=="affected":
    jobs=affected
else:
    sys.exit(arm())
with ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(host,[(name,p,v,t,r) for name,p,t,r in jobs for v in ("clang","gcc","asan")]))
sys.exit(int(any(results)))
