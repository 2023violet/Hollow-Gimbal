This archive contains software, ARM static and HOST_VIRTUAL evidence only.
The GDB witness is a local Host process; no physical device was accessed.
See the neighboring INTEG-02 evidence report for how tests and measurements are scoped.
