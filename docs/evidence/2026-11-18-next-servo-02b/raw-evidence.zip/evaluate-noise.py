from pathlib import Path
import csv
root=Path(__file__).parent
data=root/"data"
with (data/"noise-holdout-result.csv").open(newline="") as f:
    rows={(r["candidate"],r["variant"]):r for r in csv.DictReader(f)}
assert len(rows)==21
results=[]
def add(case,group,name,observed,bound,op="<="):
    passed=observed<=bound if op=="<=" else observed==bound
    results.append((case,group,name,f"{observed:.12g}",op,f"{bound:.12g}",int(passed)))
for case,variant in rows:
    if variant!="C":
        continue
    a,b,c=({k:float(v) for k,v in rows[case,arm].items()
              if k not in ("NOISE_RESULT","candidate","variant")} for arm in "ABC")
    if case.startswith("hold-"):
        for k in ("request_hp_a","model_iq_hp_a"):
            add(case,"noise",k,c[k],min(.035,.8*a[k],.9*b[k]))
    if case.startswith("motion-"):
        for phase,key in (("crawl",.03),("accel",.25),("decel",.25),("reverse",.25)):
            k=phase+"_error_rad_s"
            add(case,"dynamic",k,c[k],min(key,1.1*a[k]+.005))
        add(case,"dynamic","reversal_delay_us",c["reversal_us"]-1120000,
            min(150000,a["reversal_us"]-1120000+10000))
        add(case,"dynamic","load_error_rad",abs(c["load_error_rad"]),abs(a["load_error_rad"])+.008)
    if not case.startswith("hold-"):
        group="saturation" if case.startswith("saturation") else "dynamic"
        for k in ("request_hp_a","model_iq_hp_a"):
            add(case,group,k,c[k],.035)
        add(case,group,"overshoot_rad",c["over_rad"],min(.075,a["over_rad"]+.005))
        add(case,group,"unload_recovery_us",c["recovery_us"],min(650000,a["recovery_us"]+25000))
        add(case,group,"tail_peak_error_rad",c["tail_peak_error_rad"],.008)
    if case.startswith("saturation"):
        add(case,"saturation","first_limit_us",c["first_limit_us"],0,"==")
        add(case,"saturation","longest_limit_us",c["longest_limit_us"],min(250000,a["longest_limit_us"]+25000))
        add(case,"saturation","tail_limit_count",c["tail_limit_count"],0,"==")
with (data/"noise-holdout-gates.csv").open("w",newline="") as f:
    out=csv.writer(f)
    out.writerow(["case","quality_scope","metric","C_observed","comparison","gate","pass"])
    out.writerows(results)
fails=[row for row in results if row[-1]==0]
assert [(r[0],r[2]) for r in fails]==[("motion-1p3x","reverse_error_rad_s")],fails
print("Frozen gate counts",len(results),"failed",len(fails),fails)
