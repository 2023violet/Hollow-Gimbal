"""Run the independently requested signed 2.20-A A/B/C holdout."""
import argparse
from pathlib import Path
import json
import sys

from analyze import parse_profile, rows_from
from reproduce import checked, PROFILES

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("frozen", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--work", type=Path)
    parser.add_argument("--reverse", action="store_true")
    args = parser.parse_args()
    args.out.mkdir()
    work = args.work if args.work else args.out
    project = work / "large-source"
    build = work / "large-build"
    checked([sys.executable, Path(__file__).with_name("project.py"), args.frozen, project,
             "--trace", "--transition"])
    fixture = project / "simulation/src/cq03_study.inc"
    fixture_text = fixture.read_text(encoding="utf-8-sig")
    start_anchor = "    } cases[] = {\n"
    end_anchor = "    };"
    start = fixture_text.index(start_anchor) + len(start_anchor)
    end = fixture_text.index(end_anchor, start)
    second = -2.20 if args.reverse else 2.20
    fixture.write_text(fixture_text[:start] + f'        {{"large_nominal", 2.20f, {second:.2f}f, CQ03_NONE}},\n'
                       + fixture_text[end:], encoding="utf-8")
    checked(["cmake", "-S", project / "simulation", "-B", build, "-G", "Ninja",
             "-DCMAKE_C_COMPILER=gcc", "-DCMAKE_BUILD_TYPE=Release",
             "-DCMAKE_C_FLAGS=-DCQ03_PROTO_C"], args.out / "large-configure.log")
    checked(["cmake", "--build", build, "--parallel", 6, "--target", "falconfoc-virtual-calibrate"],
            args.out / "large-build.log")
    metrics = {}
    for profile, (review, options) in PROFILES.items():
        exe = build / "falconfoc-virtual-calibrate.exe"
        stem = args.out / f"large-{profile}"
        csv = stem.with_suffix(".csv")
        log = stem.with_suffix(".jsonl")
        checked([exe, "--profile-id", profile, *options, "--approve-candidate", review,
                 "--cq-current-csv", csv], log, stem.with_suffix(".err"))
        parsed = parse_profile(csv, log)
        for name, variants in parsed["cases"].items():
            for group, info in variants.items():
                row = info["cold"]
                print(profile, name, group, row["dwell_entry_us"], row["saturated_duration_us"],
                      row["near_cap_h0"] * 200, row["running_rms_a"], row["overshoot_a"],
                      row["first_vq_v"])
        if not args.reverse:
            all_rows = rows_from(csv)
            for name, variants in parsed["cases"].items():
                for group, info in variants.items():
                    run = [row for row in all_rows if row["scenario"] == name and row["group"] == group
                           and row["update_applied"] == "1"]
                    band = 0.22
                    errors = [float(row["iq_plant_a"]) - float(row["iq_ref_a"]) for row in run]
                    out = [i for i, error in enumerate(errors) if abs(error) > band]
                    entry = out[-1] + 1 if out else 0
                    first_us = int(run[0]["h0_us"])
                    last_us = int(run[-1]["h0_us"])
                    enter_us = int(run[entry]["h0_us"]) if entry < len(run) else None
                    direction = 1 if name.endswith("_pos") else -1
                    overshoot = max(0.0, *(direction * error for error in errors))
                    near_cap_time = 200 * sum(int(row["near_voltage_cap"]) for row in run)
                    settled = enter_us - first_us if enter_us is not None else None
                    hold = last_us - enter_us if enter_us is not None else 0
                    tail_near = any(row["near_voltage_cap"] == "1" for row in run[len(run) * 3 // 4:])
                    passed = settled is not None and settled <= 4000 and hold >= 2000 and not tail_near and overshoot <= 0.18
                    info["v1_cold_large"] = {
                        "band_a": band, "settle_us": settled, "hold_us": hold,
                        "near_cap_total_us": near_cap_time, "tail_near_cap": bool(tail_near),
                        "overshoot_a": overshoot, "passed": passed,
                    }
                    print("v1_cold_large", profile, name, group, info["v1_cold_large"])
        metrics[profile] = parsed
    (args.out / "large-metrics.json").write_text(json.dumps(metrics, indent=2) + "\n",
                                                 encoding="utf-8")

if __name__ == "__main__":
    main()
