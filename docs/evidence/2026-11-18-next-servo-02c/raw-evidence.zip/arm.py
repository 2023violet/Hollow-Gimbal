from pathlib import Path
import hashlib,subprocess as sp
root=Path(__file__).parent
def run(tool,*args):
    return sp.check_output(["arm-none-eabi-"+tool,*args],text=True,stderr=sp.STDOUT)
flags=["-std=c11","-mcpu=cortex-m4","-mthumb","-mfloat-abi=soft","-Os","-ffunction-sections",
       "-fdata-sections","-fstack-usage","-Wall","-Wextra","-Wpedantic","-Werror"]
incs=["-Icore/include","-Iruntime/include","-Ig3/np/include","-Ig3/safe/include"]
print(run("gcc","--version").splitlines()[0])
print(" ".join(flags))
obj=root/"impedance-feedforward.o"
run("gcc",*flags,*incs,"-c","core/src/foc_impedance_feedforward.c","-o",obj)
print(run("size",obj),run("nm","-S",obj),obj.with_suffix(".su").read_text())
(root/"impedance-feedforward-disasm.txt").write_text(run("objdump","-dr",obj))
probe=root/"abi-probe.c"
probe.write_text('''#include "foc_impedance_feedforward.h"
#include "foc_runtime.h"
const char input_bytes[sizeof(struct foc_impedance_feedforward_input)] = {0};
const char result_bytes[sizeof(struct foc_impedance_feedforward_result)] = {0};
const char runtime_bytes[sizeof(struct foc_runtime)] = {0};
''')
run("gcc",*flags,*incs,"-c",probe,"-o",probe.with_suffix(".o"))
print(run("nm","-S","-t","d",probe.with_suffix(".o")))
for label,p in (("02B",Path("C:/Users/16429/AppData/Local/Temp/servo02b_1795013284519/final-complete/locked-arm")),("02C",root/"final-complete/locked-arm")):
    elf=next(p.glob("*.elf"))
    binary=next(p.glob("*.bin")).read_bytes()
    assert "foc_impedance_feedforward_" not in run("nm","-S",elf)
    print(label,run("size",elf),len(binary),hashlib.sha256(binary).hexdigest())
    if label=="02B":
        baseline=binary
    else:
        assert baseline==binary
print("Locked firmware byte-identical.")

