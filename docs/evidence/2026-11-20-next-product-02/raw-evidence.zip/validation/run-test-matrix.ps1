param([Parameter(Mandatory=$true)][string]$OutputRoot, [ValidateSet("clang","gcc","sanitizer")][string]$Toolchain)
$ErrorActionPreference='Stop'
$d=$OutputRoot
$compiler = if ($Toolchain -eq 'gcc') { 'gcc' } else { 'clang' }
$extra=@()
if ($Toolchain -eq 'sanitizer') {
    $env:Path="$(clang --print-resource-dir)\lib\windows;$env:Path"
    $env:ASAN_OPTIONS='halt_on_error=1'
    $env:UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'
    $extra+= '-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
    $extra+= '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined'
}
$dirs=@('core','runtime','calibration','control_plane','sensors','simulation','examples/servo','protocol','firmware/at32f415','examples/calibration-workflow','tools/falconfoc-calibration-replay')
foreach ($dir in $dirs) {
    $slug=$dir.Replace('/','-')
    $out="$d/$Toolchain-$slug"
    $log="$out.log"
    cmake -S $dir -B $out -G Ninja -DCMAKE_BUILD_TYPE=Debug "-DCMAKE_C_COMPILER=$compiler" @extra *> $log
    if ($LASTEXITCODE) { Get-Content $log -Tail 25; exit $LASTEXITCODE }
    cmake --build $out -j 4 *>> $log
    if ($LASTEXITCODE) { Get-Content $log -Tail 25; exit $LASTEXITCODE }
    $selected = switch ($dir) {
        'control_plane' { @('-R', '^test-foc-(parameter|config-codec|config-store|config-diagnostics|calibration-application)$') }
        'examples/servo' { @('-R', '^test-falconfoc-servo-') }
        'examples/calibration-workflow' { @('-R', '^test-falconfoc-calibration-workflow-demo$') }
        'tools/falconfoc-calibration-replay' { @('-R', '^test-falconfoc-calibration-replay$') }
    }
    ctest --test-dir $out --no-tests=error --output-on-failure -j 2 @selected *>> $log
    if ($LASTEXITCODE) { Get-Content $log -Tail 45; exit $LASTEXITCODE }
    $match=Select-String -LiteralPath $log -SimpleMatch '100% tests passed out of' | Select-Object -Last 1
    "$Toolchain $dir | $($match.Line)"
}


