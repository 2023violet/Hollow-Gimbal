from pathlib import Path
import subprocess as sp
t=Path(__file__).resolve().parent
src=Path.cwd()
out=t/"arm-sizes"
out.mkdir(exist_ok=True)
inc=["control_plane/include","runtime/include","core/include","g3/np/include","g3/safe/include","components/utils/crc"]
flags=["-std=c11","-Os","-mcpu=cortex-m4","-mthumb","-mfloat-abi=soft",
       "-ffunction-sections","-fdata-sections","-fstack-usage","-Wall","-Wextra","-Wpedantic"]
layout=out/"layout.c"
layout.write_text("""#include "foc_config_store_host.h"
char sizeof_policy[sizeof(struct foc_config_store_policy)];
char sizeof_identity[sizeof(struct foc_config_store_identity)];
char sizeof_candidate[sizeof(struct foc_parameter_candidate)];
char sizeof_workspace[sizeof(struct foc_config_store_workspace)];
char sizeof_report[sizeof(struct foc_config_store_report)];
char sizeof_host_device[sizeof(struct foc_config_store_host)];
char max_record[FOC_CONFIG_STORE_SLOT_BYTES];
""",encoding="utf8")
def command(*args):
    print("$ "+sp.list2cmdline(list(map(str,args))),flush=True)
    return sp.check_output(args,text=True)
def show(*args):
    output=command(*args)
    print(output.strip(),flush=True)
    return output
show("arm-none-eabi-gcc","--version")
for f in ["control_plane/src/foc_config_codec.c","control_plane/src/foc_config_store.c",
          "control_plane/src/foc_config_store_host.c","components/utils/crc/crc.c",layout]:
    obj=out/(Path(f).stem+".o")
    show("arm-none-eabi-gcc",*flags,*("-I"+p for p in inc),"-c",f,"-o",obj)
    if Path(f).stem=="crc":
        crc=out/"crc32-only.o"
        show("arm-none-eabi-ld","-r","--gc-sections","-u","crc32_ieee",obj,"-o",crc)
        obj=crc
    sizes=show("arm-none-eabi-size","-A",obj)
    sums={"text":0, "rodata":0, "data":0, "bss":0}
    for line in sizes.splitlines():
        if line.startswith("."):
            section,n,*_=line.split()
            stem=section.split(".")[1]
            if stem in sums:
                sums[stem]+=int(n)
    print(Path(f).stem,sums,flush=True)
    show("arm-none-eabi-nm","-u",obj)
    if Path(f).stem=="layout":
        print({name:int(size,16) for _,size,_,name in
            (line.split() for line in command("arm-none-eabi-nm","-S",obj).splitlines())},flush=True)
    else:
        print((out/(Path(f).stem+".su")).read_text().strip(),flush=True)
