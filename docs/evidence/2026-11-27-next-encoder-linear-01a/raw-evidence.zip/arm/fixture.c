#include "foc_encoder.h"
static struct foc_encoder_context encoder;
static struct foc_encoder_feedback feedback;
static volatile uint32_t raw;
#if NODES
static const int16_t table[NODES] = {0, 1};
#endif
int main(void)
{
    const struct foc_encoder_config config =
        {65536U, FOC_ENCODER_DIRECTION_NORMAL, 1000.0f, 100U, 2000U, 80.0f, 0.85f, 0.2f};
#if NODES
    const struct foc_encoder_lut lut = {table, NODES, 65536U, 17U};
    const int status = foc_encoder_init_with_lut(&encoder, &config, 17U, &lut);
#else
    const int status = foc_encoder_init(&encoder, &config);
#endif
    if (status != FOC_ENCODER_STATUS_OK) {
        return status;
    }
    return foc_encoder_update(&encoder, 0U, raw, FOC_ENCODER_TRANSPORT_OK, &feedback);
}
