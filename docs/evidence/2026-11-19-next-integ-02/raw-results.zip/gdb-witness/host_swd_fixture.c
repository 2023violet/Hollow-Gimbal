#include "foc_board_capture.h"
#include <stdio.h>

struct foc_board_capture falconfoc_capture_ram;
volatile uint32_t falconfoc_capture_request;
volatile uint32_t falconfoc_capture_cancel;

__attribute__((noinline)) void witness_stop(unsigned int phase)
{
    printf("Host witness phase %u\n", phase);
}
int main(void)
{
    FILE *input = fopen("host-virtual.bin", "rb");
    if (input == NULL || fread(&falconfoc_capture_ram.image, sizeof falconfoc_capture_ram.image, 1, input) != 1)
        return 2;
    if (fclose(input) != 0)
        return 3;
    witness_stop(0);
    if (falconfoc_capture_request != 17 || falconfoc_capture_cancel != 0)
        return 4;
    atomic_store(&falconfoc_capture_ram.state, FOC_CAPTURE_ACTIVE);
    witness_stop(1);
    if (falconfoc_capture_cancel != 17)
        return 5;
    atomic_store(&falconfoc_capture_ram.state, FOC_CAPTURE_READY);
    witness_stop(3);
    return 0;
}
