from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError(f"expected one source seam {old!r}; found {source.count(old)}")
    return source.replace(old, new, 1)


def command(argv, cwd, output=None, env=None):
    if output is None:
        return subprocess.check_output([str(value) for value in argv], cwd=cwd, env=env, text=True)
    with output.open("wb") as stream:
        subprocess.run(
            [str(value) for value in argv], cwd=cwd, stdout=stream,
            stderr=subprocess.STDOUT, env=env, check=True,
        )


def build_and_link(repo, build, output, target, source_name, source, runtime_variant=None):
    ninja = command(["ninja", "-C", build, "-t", "commands", target], repo)
    exe = f"{target}.exe"
    original_obj = f"CMakeFiles/{target}.dir/{source_name}.obj"
    local = output.with_suffix(".c")
    local.write_text(source, encoding="utf-8")
    obj = local.with_suffix(".obj")

    def words(line):
        return [word.strip('"') for word in re.findall(r'"[^"]*"|\S+', line)]

    def compile_substitute(old_obj, new_obj, new_source):
        line = next(line for line in ninja.splitlines() if " -c " in line and old_obj in line)
        flags = words(line.split(" -MD -MT ", 1)[0])
        command(flags + ["-I" + str(repo / "simulation/tests"), "-o", new_obj, "-c", new_source],
                build, new_obj.with_suffix(".compile.log"))

    compile_substitute(original_obj, obj, local)
    line = next(line for line in ninja.splitlines() if "-o " + exe in line)
    if "cd . && " in line:
        line = line.split("cd . && ", 1)[1].split(" && cd .", 1)[0]
    flags = [
        str(obj) if token == original_obj else
        str(output) if token == exe else
        token.replace(target + ".", output.stem + ".")
        if token.startswith(("/implib:", "/pdb:")) else token
        for token in words(line)
    ]
    if runtime_variant is not None:
        variant_obj = runtime_variant.with_suffix(".obj")
        compile_substitute("runtime/CMakeFiles/falconfoc-pipeline.dir/src/foc_runtime.c.obj",
                           variant_obj, runtime_variant)
        lib_index = next(i for i, flag in enumerate(flags) if "falconfoc-pipeline." in flag)
        flags.insert(lib_index, str(variant_obj))
    command(flags, build, output.with_suffix(".link.log"))


def dynamic_source(original, measured_only=False):
    original = replace_once(original,
        "static int take_sample(",
        "static int cq02_noise_peak_counts = 6;\n\nstatic int take_sample(")
    original = replace_once(
        original,
        "offset = (int)((*random >> 16U) % 13U) - 6;",
        """offset = (int)((*random >> 16U) % (unsigned)(2 * cq02_noise_peak_counts + 1)) -
            cq02_noise_peak_counts;""",
    )
    split, defn = original.split("struct motion_case {", 1)
    defn = defn.replace("    const char *name;", """    const char *name;
    float cq02_damping_scale;
    int cq02_noise_peak_counts;
    bool cq02_alternate_capture;""", 1)
    original = split + "struct motion_case {" + defn
    extra = Path(__file__).with_name("motion-d-noise-probe.c").read_text(encoding="utf-8-sig")
    original = replace_once(original, "int main(int argc, char **argv)\n{",
                            extra + "\nint main(int argc, char **argv)\n{\n"
                            '    if (argc == 2 && strcmp(argv[1], "--cq02-motion-variants") == 0) {\n'
                            "        return run_cq02_extra_motion(true);\n"
                            "    }")
    head, rest = original.split("static int run_motion_case(", 1)
    body, tail = rest.split("static void print_motion_headers", 1)
    body = replace_once(
        body,
        """    const struct foc_virtual_current_profile profile =
        noise_profile(test->inertia_scale, test->cap_a);""",
        """    struct foc_virtual_current_profile profile =
        noise_profile(test->inertia_scale, test->cap_a);
    const bool filtered = test->joint && (variant == 'B' || variant == 'D');
    profile.runtime.motion.impedance.damping_filter_hz = filtered ? 48.0f : 0.0f;""",
    )
    body = replace_once(
        body,
        """    const bool filtered = test->joint && (variant == 'B' || variant == 'D');
    const bool has_feedforward""",
        "    const bool has_feedforward",
    )
    body = replace_once(
        body, "    struct foc_virtual_current vm;",
        """    if (test->cq02_damping_scale > 0.0f) {
        gains.damping_nm_s_per_rad *= test->cq02_damping_scale;
    }
    cq02_noise_peak_counts =
        test->cq02_noise_peak_counts > 0 ? test->cq02_noise_peak_counts : 6;
    struct foc_virtual_current vm;""",
    )
    body = replace_once(body, "const uint32_t early = test->legacy_02b ?",
                        "const uint32_t early = test->legacy_02b || test->cq02_alternate_capture ?")
    witness_sign = "1.0f" if measured_only else "-1.0f"
    body = replace_once(
        body, "    struct noise_trial filter = {0};",
        f"""
    struct noise_trial filter = {{0}};
    if (filtered && vm.runtime.damping_filter_seen) {{
        const struct foc_runtime_sensor_slot *prelude =
            &vm.runtime.sensor_slots[atomic_load(&vm.runtime.sensor_slot)];
        filter.accepted = (struct damping_noise_filter){{
            {witness_sign} * vm.runtime.damping_speed_error_rad_s, true
        }};
        filter.accepted_us = prelude->sample.captured_us;
    }}""".lstrip("\n"),
    )
    old = """            CHECK(noise_trial_offer(&filter, &vm, &sample, session, 48.0f) == 0 && filter.pending);
            damping_speed = filter.proposed.velocity_rad_s;"""
    if not measured_only:
        body = replace_once(
            body, old,
            """            struct foc_runtime_sensor error_sample = sample;
            error_sample.mechanical_rad_s -= ref.velocity_rad_s;
            CHECK(noise_trial_offer(&filter, &vm, &error_sample, session, 48.0f) == 0 && filter.pending);
            damping_speed = ref.velocity_rad_s + filter.proposed.velocity_rad_s;""",
        )
    body = replace_once(
        body,
        """        /* Host-only algebraic seam: leave the real H1/H0 observation intact.
         * Published FF carries the motion term plus the equivalent change in D*v. */
        const float published_ff = filtered ? torque_ff + correction : torque_ff;""",
        """        /* The Host filter is only an independent witness. Publish physical FF alone. */
        const float published_ff = torque_ff;""",
    )
    body = replace_once(
        body,
        "            .measured_velocity_rad_s = sample.mechanical_rad_s,",
        "            .measured_velocity_rad_s = damping_speed,",
    )
    start = body.index("        CHECK(slot->target.target_a.d == 0.0f")
    end = body.index("        const uint32_t h0", start)
    body = body[:start] + """        CHECK(slot->target.target_a.d == 0.0f);
        CHECK(fabsf(slot->target.target_a.q - torque.iq_ref_a) <= 1.0e-6f);
        /* Report the actual production slot target, not the independent oracle. */
        torque.iq_ref_a = slot->target.target_a.q;
""" + body[end:]
    result = head + "static int run_motion_case(" + body + "static void print_motion_headers" + tail
    return replace_once(result, 'damping_velocity_rad_s,filter_source_dt_us,host_correction_nm,published_ff_nm',
                        'oracle_damping_speed_rad_s,oracle_filter_dt_us,host_correction_nm,published_ff_nm')


def axis_source(original):
    additional_cases = Path(__file__).with_name("axis-recovery-probe.c").read_text(encoding="utf-8-sig")
    original = replace_once(original, "int main(int argc, char **argv)",
                            additional_cases + "\nint main(int argc, char **argv)")
    return replace_once(
        original.replace("#include <stdio.h>", "#include <stdio.h>\n#include <stdlib.h>"),
        """    const struct foc_virtual_current_profile profile = foc_virtual_current_default_profile();
    struct motion_result result;""",
        """    struct foc_virtual_current_profile profile = foc_virtual_current_default_profile();
    profile.runtime.motion.impedance = (struct foc_runtime_impedance_config){
        .enabled = true,
        .mechanical_frame_id = 79U,
        .torque_constant_nm_per_a = 0.15f,
        .torque_limit_nm = 0.315f,
        .max_stiffness_nm_per_rad = 3.0f,
        .max_damping_nm_s_per_rad = 0.3f,
        .max_feedforward_nm = 0.315f,
        .damping_filter_hz = getenv("CQ02_DAMPING_48") == NULL ? 0.0f : 48.0f,
    };
    if (getenv("CQ02_RECOVERY_TRACE") != NULL) {
        puts("AXIS_TRACE,mode,phase,phase_us,at_us,ref,load_nm,position_rad,velocity_rad_s,"
             "request_a,actual_a,updates,state,faults,session,replay_hash");
        puts("AXIS_RESULT,mode,phase,error_rmse,tail_50ms_rmse,ending_error,capped_1ms_samples");
        puts("AXIS_FAULT,mode,injection_us,invalid_h1_us,inhibit_accept_us,fault_latched_us,"
             "updates_at_invalid_h1,updates_after,faults,new_session");
        return run_axis_recovery(&profile, FOC_RUNTIME_MODE_VELOCITY) != 0 ||
               run_axis_recovery(&profile, FOC_RUNTIME_MODE_POSITION) != 0;
    }
    struct motion_result result;""",
    )


def records(path, source):
    with path.open(encoding="ascii", newline="") as stream:
        yield from csv.DictReader(line for line in stream if line.startswith(source + ","))


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def joint(repo, build, destination, prior, repro=None, fixtures=None):
    destination.mkdir(exist_ok=True)
    source = (fixtures or repo) / "simulation/tests/test_foc_impedance_robustness.c"
    translated = dynamic_source(source.read_text(encoding="utf-8"), measured_only=repro is not None)
    target = destination / "cq02-joint.exe"
    build_and_link(repo, build, target, "test-foc-impedance-robustness",
                   "tests/test_foc_impedance_robustness.c", translated, repro)
    for name, flag in (("characterization", "--joint-control-characterization"),
                       ("holdout", "--joint-control-holdout")):
        command([target, flag, "--trace"], build, destination / f"{name}-replay.csv")
    evaluator = prior / "servo-02d-frozen-evaluator.py"
    command(["python", evaluator, destination], build, destination / "frozen-evaluation.json")
    holdout = destination / "holdout-replay.csv"
    labels = {"A": "0 Hz, no explicit FF", "B": "48 Hz, no explicit FF",
              "C": "0 Hz, explicit FF", "D": "48 Hz, explicit FF"}
    derived = {
        "arms": labels,
        "oracle_evidence": "Frozen Host backward Euler filter is diagnostic only. "
                           "Reported q-reference is read directly from production H1 slot and asserted in H0.",
        "context": "Original JOINT_BOUNDARY/TRIAL/MODE rows remain the historical helper checks "
                   "required by the unchanged evaluator. Full JOINT_RESULT/TRACE/GATE rows and "
                   "their noise/tracking/saturation gate metrics use actual Runtime opt-in.",
        "source_sha256": digest(source),
        "evaluator_sha256": digest(evaluator),
        "trace_sha256": {name: digest(destination / f"{name}-replay.csv")
                         for name in ("characterization", "holdout")},
        "dynamic": [{key: row[key] for key in (
            "case", "variant", "reversal_rms_rad_s", "tail_request_hp_a",
            "tail_model_hp_a", "settle_us", "recover_us", "peak_request_a", "peak_model_a",
            "over_budget_us", "limited_us", "peak_limit_run_us", "max_accepted_source_age_us"
        )} for row in records(holdout, "JOINT_RESULT")],
    }
    (destination / "summary.json").write_text(json.dumps(derived, indent=2) + "\n", encoding="utf-8")


def axes(repo, build, destination, prior, fixtures=None):
    source = (fixtures or repo) / "simulation/src/falconfoc_virtual_motion.c"
    target = destination / "cq02-axes.exe"
    build_and_link(repo, build, target, "falconfoc-virtual-motion",
                   "src/falconfoc_virtual_motion.c", axis_source(source.read_text(encoding="utf-8")))
    env = os.environ.copy()
    env.pop("CQ02_DAMPING_48", None)
    env.pop("CQ02_RECOVERY_TRACE", None)
    for label in ("off", "48hz"):
        command([target, "--csv", destination / f"axes-{label}.csv"],
                build, destination / f"axes-{label}.log", env=env)
        command([target], build, destination / f"axes-recovery-{label}.csv",
                env=dict(env, CQ02_RECOVERY_TRACE="1"))
        env["CQ02_DAMPING_48"] = "1"
    assert digest(destination / "axes-recovery-off.csv") == digest(destination / "axes-recovery-48hz.csv")
    for ext in ("csv", "log"):
        assert digest(destination / f"axes-off.{ext}") == digest(destination / f"axes-48hz.{ext}")
    with (destination / "axes-off.csv").open(newline="", encoding="ascii") as stream:
        rows = list(csv.DictReader(stream))
    report = {
        "classification": "BYTE_IDENTICAL",
        "unchanged_legacy_quality": [row["scenario"] for row in rows if row["expected_degraded"] == "1"],
        "rows": rows,
        "recovery_phases": ["positive step", "hold", "load", "unload", "negative step"],
        "recovery_data": list(records(destination / "axes-recovery-off.csv", "AXIS_RESULT")),
        "sensor_faults": list(records(destination / "axes-recovery-off.csv", "AXIS_FAULT")),
        "trace_sha256": digest(destination / "axes-recovery-off.csv"),
        "sha256": {ext: digest(destination / f"axes-off.{ext}") for ext in ("csv", "log")},
        "same_as_cq01": {
            ext: (destination / f"axes-off.{ext}").read_text(encoding="ascii") ==
                 (prior / f"servo-motion-modes-baseline.{ext}").read_text(encoding="utf-8-sig")
            for ext in ("csv", "log")
        },
    }
    (destination / "axes-summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


def extra_motion(build, destination):
    path = destination / "d-noise-motion.csv"
    command([destination / "cq02-joint.exe", "--cq02-motion-variants"], build, path)
    observed = list(records(path, "JOINT_RESULT"))
    arms = {(row["case"], row["variant"]): row for row in observed}
    cases = list(records(path, "CQ02_EXTRA"))
    intervals = {}
    for row in records(path, "JOINT_TRACE"):
        if int(row["oracle_filter_dt_us"]) != 0:
            intervals.setdefault(row["case"], set()).add(int(row["oracle_filter_dt_us"]))
    comparisons = []
    for row in cases:
        name = row["case"]
        off, on = (arms[name, arm] for arm in ("C", "D"))
        reverse_limit = min(0.25, 1.25 * float(off["reversal_rms_rad_s"]) + 0.005)
        noise_limit = min(0.035, 0.7 * float(off["tail_request_hp_a"]))
        comparisons.append({
            **row,
            "source_dt_us": sorted(intervals[name]),
            "reversal_limit_rad_s": reverse_limit,
            "reversal_within_limit": float(on["reversal_rms_rad_s"]) <= reverse_limit,
            "request_noise_limit_a": noise_limit,
            "request_noise_within_limit": float(on["tail_request_hp_a"]) <= noise_limit,
            "off": off,
            "on": on,
        })
    summary = {"trace_sha256": digest(path), "comparisons": comparisons}
    (destination / "d-noise-motion-summary.json").write_text(json.dumps(summary, indent=2) + "\n",
                                                               encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("build", type=Path, help="Configured Ninja Simulation build, incl. original targets")
    parser.add_argument("prior", type=Path, help="Extracted CQ01 evidence servo directory")
    parser.add_argument("destination", type=Path)
    parser.add_argument("--measured-only-runtime", type=Path)
    parser.add_argument("--fixtures", type=Path, help="Source root holding the frozen inputs")
    args = parser.parse_args()
    repo, build, prior, destination = (p.resolve() for p in (args.repo, args.build, args.prior,
                                                            args.destination))
    variant = args.measured_only_runtime
    joint(repo, build, destination, prior, None if variant is None else variant.resolve(),
          args.fixtures)
    if variant is None:
        axes(repo, build, destination, prior, args.fixtures)
        extra_motion(build, destination)


if __name__ == "__main__":
    main()


