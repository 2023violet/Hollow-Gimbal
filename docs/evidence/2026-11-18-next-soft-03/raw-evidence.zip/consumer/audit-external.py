from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess as sp

root = Path(__file__).resolve().parent
repo = Path.cwd()
source = root / "FalconFOC Source"
consumer = root / "External Config Store Consumer"
evidence = json.loads((root / "source-snapshot.json").read_text(encoding="utf-8"))
env = os.environ.copy()
clang_resource = Path(sp.check_output(["clang", "-print-resource-dir"], text=True).strip())
env["PATH"] = os.pathsep.join([r"C:\mingw64\bin", str(clang_resource / "lib/windows"), env["PATH"]])
env.update(ASAN_OPTIONS="halt_on_error=1", UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1",
           PYTHONDONTWRITEBYTECODE="1")
affected = set()
outputs = {}

with (root / "acceptance.log").open("w", encoding="utf-8") as report:
    print(f"Source HEAD {evidence['head']}", file=report)
    for variant in ("clang", "gcc", "clang-asan-ubsan"):
        build = root / f"Build {variant}"
        unit_log = (root / f"{variant}.log").read_text(encoding="utf-8")
        assert re.findall(r"^exit=(\d+)$", unit_log, re.MULTILINE) == ["0"] * 5
        assert "100% tests passed out of 1" in unit_log
        assert "Public header dependency paths resolve inside the isolated source tree." in unit_log
        assert not re.search(r"ERROR: AddressSanitizer|UndefinedBehaviorSanitizer|runtime error:", unit_log)
        configuration = (build / "CMakeCache.txt").read_text(encoding="utf-8")
        assert "FALCONFOC_SOURCE_DIR:" in configuration
        if variant == "clang-asan-ubsan":
            assert "-fsanitize=address,undefined" in configuration
        data = (root / f"{variant}-demo.txt").read_bytes()
        outputs[variant] = data
        for marker in (b"LOAD_ERASED status=2", b"DECODE_OTHER_ENCODER status=-9",
                       b"DECODE_CORRUPT_PAYLOAD status=-5", b"SAVE_B_TORN status=-15 step=80 offline=1",
                       b"STORAGE slot=A sequence=0 schema=2 fields=14 bytes=168 A=0 B=-4",
                       b"STORAGE slot=B sequence=1 schema=2 fields=14 bytes=168 A=0 B=0",
                       b"SECOND_DEVICE_LOAD_A status=0"):
            assert marker in data, marker
        assert data.count(b"EFFECTIVE values_checked=14 output=INHIBIT confirmed=1 updates=0") == 5

        units = json.loads((build / "compile_commands.json").read_text(encoding="utf-8"))
        resolved = {Path(unit["file"]).resolve() for unit in units}
        ninja_deps = sp.check_output(["ninja", "-C", build, "-t", "deps"], env=env, text=True)
        resolved.update((build / line.strip()).resolve()
                        for line in ninja_deps.splitlines() if line.startswith("    "))
        for filename in resolved:
            if filename.is_relative_to(source):
                relative = filename.relative_to(source).as_posix()
            elif filename.is_relative_to(consumer):
                relative = "examples/parameters/" + filename.relative_to(consumer).as_posix()
            else:
                continue
            affected.add(relative)
            checkout_bytes = (repo / relative).read_bytes()
            copied_bytes = filename.read_bytes()
            if relative in evidence["overlay_sha256"]:
                assert sha256(checkout_bytes).hexdigest() == evidence["overlay_sha256"][relative], filename
                assert checkout_bytes == copied_bytes, filename
            else:
                assert checkout_bytes.replace(b"\r\n", b"\n") == copied_bytes.replace(b"\r\n", b"\n"), filename
        print(f"{variant}: compile, CTest 1/1 and direct execution all exited 0", file=report)

    mismatches = {name for name, digest in evidence["overlay_sha256"].items()
                  if sha256((repo / name).read_bytes()).hexdigest() != digest}
    assert all(name not in affected and name != "CMakeLists.txt" and not name.endswith(".cmake")
               and not name.endswith("/CMakeLists.txt") for name in mismatches), mismatches
    for name in sorted(mismatches):
        print(f"Concurrent edit outside this target's source and dependency closure: {name}", file=report)
    assert len(set(outputs.values())) == 1
    digest = sha256(outputs["clang"]).hexdigest()
    print(f"Demo stdout is byte-identical across all three variants, SHA-256 {digest}", file=report)
    print(f"Compared {len(affected)} leaf source/header dependencies against the live checkout.", file=report)

print((root / "acceptance.log").read_text(encoding="utf-8"))
