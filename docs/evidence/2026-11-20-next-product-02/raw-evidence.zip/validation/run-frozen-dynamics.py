from pathlib import Path
import json,sys

repo, build, dest = (Path(arg).resolve() for arg in sys.argv[1:])
prior = Path(__file__).resolve().parent
sys.path.insert(0, str(prior / "dynamics"))
from reproduce_cq02_dynamics_import import axes, build_and_link, command, digest

dest.mkdir(parents=True, exist_ok=False)
src = prior.parent / "joint.c"
exe = dest / "joint.exe"
build_and_link(repo, build, exe, "test-foc-impedance-robustness",
               "tests/test_foc_impedance_robustness.c", src.read_text(encoding="utf-8"))
for tag, flag in (("characterization", "--joint-control-characterization"),
                  ("holdout", "--joint-control-holdout")):
    command([exe, flag, "--trace"], build, dest / f"{tag}-replay.csv")
    expected = prior.parent / f"{tag}-replay.csv"
    assert digest(dest / f"{tag}-replay.csv") == digest(expected), tag
servo = prior / "servo-frozen-evaluator"
command([sys.executable, servo / "servo-02d-frozen-evaluator.py", dest],
        build, dest / "frozen-evaluation.json")
verdict = json.loads((dest / "frozen-evaluation.json").read_text())
assert verdict["production_filter"] == "HOST QUALITY GATES PASSED", verdict["gates"]
assert all(not verdict[x] for x in ("noise_failures", "dynamic_failures", "saturation_failures"))
axes(repo, build, dest, servo)
print(verdict["gates"])

