#include "foc_encoder.h"
const unsigned char encoder_context_bytes[sizeof(struct foc_encoder_context)] = {0};
const unsigned char encoder_feedback_bytes[sizeof(struct foc_encoder_feedback)] = {0};
