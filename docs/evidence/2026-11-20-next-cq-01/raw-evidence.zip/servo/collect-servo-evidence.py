from __future__ import annotations

import csv
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from collections import defaultdict
from math import sqrt
from pathlib import Path


def digest(file):
    return hashlib.file_digest(file.open("rb"), "sha256").hexdigest()


def collect_probe(build, output):
    metrics, samples = {}, defaultdict(list)
    labels = {}
    probe_headers = [
        "case", "variant", "encoder_cutoff_hz", "damping_cutoff_hz", "kp_d", "kp_q",
        "ki_q", "load_nm", "input_slew_rad_s", "oracle_phase", "oracle_load", "mirror",
    ]
    trace_headers = [
        "case", "variant", "relative_us", "capture_us", "h1_delivery_us", "last_submit_us",
        "last_apply_us", "sample_seq", "session", "updates", "angle_source_age_us",
        "raw_count", "position_ref_rad", "position_plant_at_capture_rad",
        "velocity_plant_at_capture_rad_s", "position_sensor_rad", "velocity_sensor_rad_s",
        "damping_speed_rad_s", "phase_true_at_capture_rad", "phase_sensor_rad",
        "electrical_speed_rad_s", "k_torque_nm", "d_torque_nm", "physical_ff_nm",
        "torque_requested_nm", "iq_requested_a", "iq_plant_at_h1_a", "id_plant_at_h1_a",
        "load_nm", "limited",
    ]
    result_headers = [
        "case", "h1_samples", "position_rmse_rad", "peak_position_error_rad",
        "overshoot_rad", "settling_us", "reverse_settling_us", "load_recovery_us",
        "peak_speed_rad_s", "peak_requested_iq_a", "peak_plant_iq_a", "limited_us",
        "longest_limit_us", "load_tail_mean_error_rad", "tail_peak_error_rad",
        "tail_sensor_speed_rms_rad_s", "tail_q_request_rms_a", "tail_q_request_hp_a",
        "tail_plant_q_hp_a", "tail_request_torque_rms_nm", "tail_unfiltered_d_torque_rms_nm",
        "raw_count_repeats", "max_source_age_us", "accepted_updates", "fail_mask",
    ]
    with (
        (build / "historical-servo-probes.log").open() as original,
        (output / "servo-ablation-metrics.csv").open("w", newline="") as metrics_file,
        (output / "servo-ablation-log.txt").open("w") as event_file,
        (output / "servo-ablation-trace-windows.csv").open("w", newline="") as trace_file,
    ):
        writer = csv.writer(metrics_file)
        writer.writerow(probe_headers[1:] + result_headers)
        traces = csv.writer(trace_file)
        traces.writerow(trace_headers)
        for row in csv.reader(original):
            if row[0] == "PROBE":
                parameter = dict(zip(probe_headers, row[1:], strict=True))
            elif row[0] == "RESULT":
                event_file.write(",".join(row) + "\n")
                result = dict(zip(result_headers, row[1:], strict=True))
                assert result["case"] == parameter["case"]
                key = (parameter["variant"], result["case"])
                metrics[key] = result
                writer.writerow(list(parameter.values())[1:] + list(result.values()))
            elif row[0] == "CQ_TRACE":
                assert parameter["case"] == row[1]
                key = (parameter["variant"], row[1])
                t = int(row[2])
                samples[key].append(row)
                is_hold = "noise" in row[1] or "clean-code" in row[1]
                if (is_hold and t >= 1_300_000) or (not is_hold and (
                    t % 5000 == 0 or 860_000 <= t <= 885_000 or 1_625_000 <= t <= 1_640_000
                )):
                    traces.writerow([row[1], parameter["variant"], *row[2:]])
            else:
                event_file.write(",".join(row) + "\n")
                if row[0] in ("GATE", "QUALITY"):
                    labels[parameter["variant"], row[1]] = row[2:]
    historical = {}
    for row in csv.reader((build / "historical-servo-holdout.log").open()):
        if row[0] == "RESULT":
            historical[row[1]] = dict(zip(result_headers, row[1:], strict=True))
    assert all(
        metrics["fresh-baseline", case] == values for case, values in historical.items()
    ), "Derived fresh baseline must match all historical results"
    assert sum(int(values["fail_mask"]) == 0 for values in historical.values()) == 7
    assert sum(int(values["fail_mask"]) != 0 for values in historical.values()) == 3
    for variant in ("fresh-baseline", "D-only-48Hz", "common-sensor-30Hz"):
        assert labels[variant, "hold-delay-reject"][:4] == ["2400", "-5", "7", "7"]
    assert [
        int(metrics["D-only-48Hz", case]["fail_mask"])
        for case in historical
    ] == [0] * 9 + [16]

    derived_out = {}
    for (variant, case), rows in samples.items():
        if case == "hold-load-beyond-025":
            block = [row for row in rows if 1_400_000 <= int(row[2]) < 1_500_000]
            torque = [6.0 * (0.025 - 0.0003 * float(row[27])) * float(row[26]) for row in block]
            derived_out.setdefault(variant, {})[case] = {
                "loaded_tail_mean_electromagnetic_torque_nm": sum(torque) / len(torque),
                "loaded_tail_mean_signed_speed_rad_s": sum(float(row[14]) for row in block) / len(block),
            }
            continue
        lp = [0.0, 0.0, 0.0]
        square = [0.0, 0.0, 0.0]
        count = 0
        for row in rows:
            for channel, index in enumerate((21, 22, 25)):
                value = float(row[index])
                lp[channel] += 0.2 * (value - lp[channel])
                if int(row[2]) >= 1_300_000:
                    square[channel] += (value - lp[channel]) ** 2
            count += int(int(row[2]) >= 1_300_000)
        rms_k, rms_d, rms_q = (sqrt(value / count) for value in square)
        assert abs(rms_q - float(metrics[variant, case]["tail_q_request_hp_a"])) < 3e-9
        derived_out.setdefault(variant, {})[case] = {
            "tail_k_torque_hp_rms_nm": rms_k, "tail_d_torque_hp_rms_nm": rms_d,
            "tail_d_converted_current_hp_rms_a": rms_d / 0.15, "tail_requested_q_hp_rms_a": rms_q,
        }
    (output / "servo-ablation-derived.json").write_text(json.dumps(derived_out, indent=2) + "\n")


def collect_phase(repo, build, output):
    """Score the full new replay with the existing frozen 02D evaluator."""
    prior = repo / "docs/evidence/2026-11-18-next-servo-02d/raw-evidence.zip"
    evaluate_dir = build / "servo-02d-evaluation"
    evaluate_dir.mkdir(exist_ok=True)
    with zipfile.ZipFile(prior) as archive:
        scripts = {"evaluate-joint.py": output / "servo-02d-frozen-evaluator.py",
                   "freeze/holdout-freeze.txt": output / "servo-02d-original-freeze.txt"}
        for key, destination in scripts.items():
            destination.write_bytes(archive.read(key))
        for mode in ("holdout", "characterization"):
            source = build / f"servo02d-phase-consistency-{mode}.log"
            shutil.copyfile(source, evaluate_dir / f"{mode}-replay.csv")
            with (
                source.open() as log,
                (output / f"servo-02d-phase-consistency-{mode}-events.log").open("w") as events,
                (output / f"servo-02d-phase-consistency-{mode}-reversal.csv").open("w", newline="") as trace,
            ):
                writer = csv.writer(trace)
                for row in csv.reader(log):
                    if row[0] != "JOINT_TRACE":
                        events.write(",".join(row) + "\n")
                    elif row[1] == "case" or (row[2] in ("C", "D") and row[13] in ("4", "5")):
                        writer.writerow(row)
    with (output / "servo-02d-phase-consistency-frozen-evaluation.json").open("wb") as report:
        subprocess.run([sys.executable, str(output / "servo-02d-frozen-evaluator.py"),
                        str(evaluate_dir)], check=True, stdout=report)


def main():
    repo, build, output = map(Path, sys.argv[1:])
    output.mkdir(exist_ok=True)
    collect_probe(build, output)
    collect_phase(repo, build, output)
    for name in (
        "baseline.json", "build.log", "configure.log", "reproduce-servo-probes.py",
        "original-holdout-frozen.txt", "historical-servo-holdout.log",
        "historical-servo-holdout-trace.log", "servo-ctest.log", "started.txt", "ended.txt",
    ):
        shutil.copyfile(build / name, output / name)
    for prefix in ("servo-motion-modes-",):
        for original in build.glob(prefix + "*"):
            if original.suffix in (".log", ".csv"):
                shutil.copyfile(original, output / original.name)
    full_raw = {}
    for pattern in ("*probes.log", "servo02d-phase-consistency-*.log"):
        full_raw.update({path.name: digest(path) for path in build.glob(pattern)})
    (output / "servo-full-log-sha256.json").write_text(json.dumps(full_raw, indent=2) + "\n")


if __name__ == "__main__":
    main()

