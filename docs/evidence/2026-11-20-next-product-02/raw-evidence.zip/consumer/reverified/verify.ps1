param(
    [Parameter(Mandatory)][ValidateSet('clang','gcc','asan')][string]$Lane,
    [Parameter(Mandatory)][string]$EvidenceDir
)
$ErrorActionPreference = 'Stop'
$CCompiler = if ($Lane -eq 'gcc') { (Get-Command gcc).Source } else { (Get-Command clang).Source }
$BuildRoot = Join-Path $EvidenceDir $Lane
$Logs = Join-Path $EvidenceDir "raw/$Lane"
$Source = Join-Path $EvidenceDir 'src'
$Package = Join-Path $BuildRoot 'package'
$Relocated = Join-Path $BuildRoot 'relocated'
New-Item -ItemType Directory -Force $Logs | Out-Null
$CompilerArgs = @("-DCMAKE_C_COMPILER=$CCompiler", '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_C_FLAGS=-Wall -Wextra -Wpedantic -Werror')
if ($Lane -eq 'asan') {
    $CompilerArgs[-1] += ' -fsanitize=address,undefined -fno-omit-frame-pointer'
    $ResourceDir = (& $CCompiler --print-resource-dir).Trim()
    $env:PATH = "$(Join-Path $ResourceDir 'lib/windows');$env:PATH"
}
function Invoke-Logged {
    param([string]$Name, [string]$Program, [string[]]$Arguments)
    $LogFile = Join-Path $Logs "$Name.log"
    "$Program $($Arguments | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } } | Join-String -Separator ' ')" | Set-Content -Encoding UTF8 $LogFile
    & $Program @Arguments 2>&1 | Tee-Object -Append $LogFile
    $Code = $LASTEXITCODE
    if ($Code -ne 0) { throw "$Program exited $Code. See $LogFile" }
}
Invoke-Logged '01-core-configure' 'cmake' (@('-S', "$Source/isocore", '-B', "$BuildRoot/core", '-G', 'Ninja', '-DBUILD_TESTING=OFF') + $CompilerArgs)
Invoke-Logged '02-core-build' 'cmake' @('--build', "$BuildRoot/core", '--verbose')
Invoke-Logged '03-core-install' 'cmake' @('--install', "$BuildRoot/core", '--prefix', $Package)
Move-Item -LiteralPath $Package -Destination $Relocated
Get-ChildItem $Relocated -File -Recurse | Sort-Object FullName | ForEach-Object {
    '{0}  {1}' -f (Get-FileHash -Algorithm SHA256 $_.FullName).Hash, [IO.Path]::GetRelativePath($Relocated, $_.FullName)
} | Set-Content -Encoding UTF8 "$Logs/installed-sha256.txt"
Invoke-Logged '04-consumer-configure' 'cmake' (@('-S', "$Source/caller", '-B', "$BuildRoot/caller", '-G', 'Ninja', "-DCMAKE_PREFIX_PATH=$Relocated") + $CompilerArgs)
Invoke-Logged '05-consumer-build' 'cmake' @('--build', "$BuildRoot/caller", '--verbose')
Invoke-Logged '06-consumer-ctest' 'ctest' @('--test-dir', "$BuildRoot/caller", '-V', '--output-on-failure', '-R', '^external-')
Invoke-Logged '07-runtime-configure' 'cmake' (@('-S', "$Source/caller", '-B', "$BuildRoot/runtime", '-G', 'Ninja', "-DCMAKE_PREFIX_PATH=$Relocated", "-DFALCONFOC_RUNTIME_SOURCE_DIR=$Source/modules") + $CompilerArgs)
Invoke-Logged '08-runtime-build' 'cmake' @('--build', "$BuildRoot/runtime", '--verbose')
Invoke-Logged '09-runtime-ctest' 'ctest' @('--test-dir', "$BuildRoot/runtime", '-V', '--output-on-failure', '-R', '^external-')
Get-FileHash -Algorithm SHA256 "$BuildRoot/caller/core-consumer.exe", "$BuildRoot/runtime/runtime-consumer.exe" | ForEach-Object {
    '{0}  {1}' -f $_.Hash, (Split-Path -Leaf $_.Path)
} | Set-Content -Encoding UTF8 "$Logs/executables-sha256.txt"

$ConfigMatch = '^(BUILD_TESTING|CMAKE_(BUILD_TYPE|C_COMPILER|C_FLAGS|PREFIX_PATH)|FALCONFOC_RUNTIME_SOURCE_DIR|FalconFOCCore_DIR):[^=]*='
foreach ($Name in @('core','caller','runtime')) {
    Get-Content "$BuildRoot/$Name/CMakeCache.txt" | Where-Object { $_ -match $ConfigMatch } |
        Set-Content -Encoding UTF8 "$Logs/$Name-config.txt"
}
