
from collections import defaultdict
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile

db = Path("build/servo02b-noise")
exe = db / "test-foc-impedance-robustness.exe"
root = Path("docs/evidence")

def compare(archive, prefix, args):
    with ZipFile(root / archive / "raw-evidence.zip") as zipped:
        records = defaultdict(list)
        for line in check_output([exe, *args], text=True).splitlines():
            records[line.split(",", 1)[0]].append(line)
        for record, lines in records.items():
            filename = f"data/{prefix}-{record.lower()}.csv"
            expected = zipped.read(filename).decode().splitlines()[1:]
            diffs = sum(a != b for a, b in zip(lines, expected)) + abs(len(lines) - len(expected))
            print(archive, prefix, record, len(lines), diffs)

compare("2026-11-18-next-servo-01c", "training", ["--train", "--trace"])
compare("2026-11-18-next-servo-01c", "holdout", ["--trace"])
models = ["0.002001755405", "0.00599673437", "0.008009241894", "0.006023695227"]
compare("2026-11-18-next-servo-02a", "comparison", ["--mechanical-id-fit", *models, "--trace"])

