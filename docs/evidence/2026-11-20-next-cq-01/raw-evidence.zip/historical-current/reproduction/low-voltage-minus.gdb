set pagination off
break *foc_current_modulate+442
commands
silent
printf "core envelope rejection\n"
p voltage_magnitude
p voltage_limit_v
p rounding_slack
p *input
p requested_v
p result->svpwm
bt 8
f 1
p context->config
p context->integral_v
p proportional
p integral
p requested
f 6
p context->virtual_time_us
quit
end
run --voltage-limit-v 0.12 < build/next-cq-01-historical/holdout-current-reverse.wire > build/next-cq-01-historical/low-voltage-minus-gdb-wire.out
