#include "foc_measurement_trace.h"
char context_bytes[sizeof(struct foc_measurement_trace)];
char input_bytes[sizeof(struct foc_measurement_trace_record)];
char output_bytes[sizeof(union foc_measurement_trace_payload)];
char contract_bytes[sizeof(struct foc_measurement_trace_contract)];
char report_bytes[sizeof(struct foc_measurement_trace_report)];
