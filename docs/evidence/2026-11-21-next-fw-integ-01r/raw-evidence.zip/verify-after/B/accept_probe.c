/* Report what this build's expectation does with the synthetic verification supply. */
#include "foc_board_boot.h"
#include <stdio.h>
static struct foc_runtime runtime; static struct foc_board_output output;
static struct foc_board_encoder encoder; static struct foc_board_boot boot;
int main(void) {
    const struct foc_board_calibration_expectation e = foc_board_calibration_expectation();
    int s = foc_board_boot_select(&boot, &runtime, &output, &encoder, foc_board_calibration_supply(), &e, 0U);
    printf("expectation 0x%08lx supply 0x%08lx: select=%d configuration=%d calibration=%d rejection=%d\n",
           (unsigned long)e.supply_id, (unsigned long)foc_board_calibration_supply()->supply_id, s,
           (int)boot.configuration, (int)boot.calibration, (int)boot.rejection);
    return 0;
}
