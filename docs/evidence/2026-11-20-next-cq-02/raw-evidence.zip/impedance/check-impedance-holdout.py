from pathlib import Path
import csv
import sys

with Path(sys.argv[1]).open(encoding="utf-8-sig") as f:
    rows = list(csv.reader(f))
verdicts = {row[1]: int(row[3]) for row in rows if row and row[0] == "QUALITY"}
assert len(verdicts) == 10, verdicts
assert verdicts["hold-load-beyond-025"] == 16, verdicts
failed = {name: mask for name, mask in verdicts.items()
          if name != "hold-load-beyond-025" and mask}
assert not failed, failed
