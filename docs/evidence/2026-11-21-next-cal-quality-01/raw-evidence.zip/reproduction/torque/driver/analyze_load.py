"""Quantify current/voltage/shaft margins from the CQ-02 load evidence."""
import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
from statistics import mean

EPOCH_US = 2000
LAST_LOAD_WINDOW_US = 100_000

CONFIG = """
case load_magnitude_nm direction load_on_us load_off_us end_us cutoff_hz kp_nm_per_rad
kd_nm_s_per_rad configured_kt_nm_per_a core_i_limit_a motion_iq_limit_a policy_torque_limit_nm
voltage_cap_v min_runtime_bus_v pole_pairs flux_wb rs_ohm ld_h lq_h damping_nm_s
inertia_kg_m2 modeled_bus_v h0_us h1_us command_timeout_us adc_timeout_us fast_timeout_us
foreground_timeout_us invalid_latch_count max_kp max_kd
""".split()
QUALITY = """
case mask longest_limit_us recovery_us tail_peak_error_rad loaded_tail_error_rad
peak_error_rad peak_overshoot_rad tail_iq_request_hf_rms_a tail_plant_iq_hf_rms_a h1_samples
""".split()
TERMINATION = """
case observed_us safety_state faults updates_before updates_after old_session new_session
held_integral_d_v held_integral_q_v rejected
""".split()


def decode_log(path):
    data = path.read_bytes()
    encoding = "utf-16" if data.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
    return data.decode(encoding).splitlines()


def read_study(directory, name):
    path = directory / f"{name}-study.log"
    output = {}
    for line in decode_log(path):
        fields = next(csv.reader([line]))
        if not fields:
            continue
        record = fields[0]
        names = {"CONFIG": CONFIG, "QUALITY": QUALITY, "TERMINATION": TERMINATION}.get(record)
        if names is None:
            continue
        assert len(fields) == len(names) + 1, line
        output.setdefault(fields[1], {})[record.lower()] = {
            key: float(value) for key, value in zip(names[1:], fields[2:], strict=True)
        }
    return output


def row_groups(path):
    with path.open(newline="", encoding="ascii") as stream:
        table = csv.DictReader(stream)
        for scenario, rows in itertools.groupby(table, key=lambda row: row["case"]):
            yield scenario, [
                {key: float(value) for key, value in row.items() if key != "case"}
                for row in rows
            ]


def absolute_peak(rows, key):
    return max(abs(row[key]) for row in rows)


def study_sha256(directory, name):
    return {
        lane: hashlib.file_digest(
            (directory / f"{name}-{lane}.csv").open("rb"), "sha256"
        ).hexdigest()
        for lane in ("h0", "h1")
    }


def classify(directory, name):
    report = read_study(directory, name)
    for case, trace in row_groups(directory / f"{name}-h0.csv"):
        entry = report[case]
        config = entry["config"]
        termination = entry["termination"]
        direction = config["direction"]
        requested_load = config["load_magnitude_nm"]
        kt = config["configured_kt_nm_per_a"]
        pair_count = config["pole_pairs"]
        phase_flux = config["flux_wb"]
        rs = config["rs_ohm"]
        ld, lq = config["ld_h"], config["lq_h"]
        cap_a = min(config["core_i_limit_a"], config["motion_iq_limit_a"],
                    config["policy_torque_limit_nm"] / kt)
        kt_model = 1.5 * pair_count * phase_flux
        applied = [row for row in trace if row["enable_request"] == 1]
        inhibited = [row for row in trace if row["enable_request"] == 0]
        loaded = [row for row in applied if row["load_nm"] != 0]
        assert max(row["h0_us"] for row in loaded) >= min(
            EPOCH_US + config["load_off_us"] - 200, EPOCH_US + 1_399_400
        ), case
        tail_end = min(EPOCH_US + config["load_off_us"], loaded[-1]["h0_us"] + config["h0_us"])
        tail = [
            row for row in loaded if tail_end - LAST_LOAD_WINDOW_US <= row["h0_us"] < tail_end
        ]
        assert len(tail) == LAST_LOAD_WINDOW_US // config["h0_us"], case
        assert len(inhibited) == 4, case
        assert termination["updates_before"] == termination["updates_after"]
        assert inhibited[0]["session"] != applied[-1]["session"]
        assert len({row["session"] for row in applied}) == 1

        # At id=0, solve the steady PMSM voltage vector at the current ceiling across observed speed.
        # This includes both R*iq and the signed PM back-EMF. Reluctance is counted in measured torque.
        selected_iq = direction * cap_a
        vmax_required = max(
            math.hypot(pair_count * row["velocity_rad_s"] * lq * selected_iq,
                       rs * selected_iq + pair_count * row["velocity_rad_s"] * phase_flux)
            for row in loaded
        )
        min_voltage_cap = min(row["vlimit_v"] for row in applied)
        assert vmax_required < min_voltage_cap
        assert absolute_peak(applied, "iq_h0_a") <= cap_a + 1e-9
        assert absolute_peak(applied, "accepted_voltage_v") < min_voltage_cap
        assert trace[-1]["saturated_updates"] == 0

        theoretical_torque = kt_model * cap_a
        # Independent conservative bound if some d current were allowed within the existing vector cap.
        vector_torque_bound = theoretical_torque + 1.5 * pair_count * abs(ld - lq) * cap_a**2 / 2
        tail_iq = direction * mean(row["iq_plant_a"] for row in tail)
        tail_torque = direction * mean(row["electromagnetic_nm"] for row in tail)
        tail_speed = direction * mean(row["velocity_rad_s"] for row in tail)
        tail_drag = direction * mean(row["viscous_nm"] for row in tail)
        tail_residual = direction * mean(row["residual_nm"] for row in tail)
        assert math.isclose(tail_torque - tail_drag - requested_load, tail_residual, abs_tol=1e-10)
        over = requested_load > vector_torque_bound
        # Natural reverse slip can generate a helping drag torque. There is no steady zero-speed balance.
        if over:
            assert 0.248 < tail_iq < 0.252
            assert tail_torque < requested_load
            assert tail_speed < -0.05
            assert tail_drag < 0
            assert requested_load / kt_model > cap_a
        if case == "near-positive-extended":
            tail_error = entry["quality"]["loaded_tail_error_rad"]
            expected_error = requested_load / config["kp_nm_per_rad"]
            assert abs(tail_torque - requested_load) < 5e-5
            assert abs(tail_speed) < 0.005
            assert abs(tail_error - expected_error) < 0.0002
        entry["feasibility"] = {
            "classification": (
                "LOAD_INFEASIBLE_WITH_CURRENT_LIMITS" if over else "STATIC_TORQUE_FEASIBLE"
            ),
            "static_q_for_load_a": requested_load / kt_model,
            "stationary_voltage_for_load_v": rs * requested_load / kt_model,
            "id_zero_current_limited_shaft_torque_nm": theoretical_torque,
            "conservative_vector_limited_shaft_torque_bound_nm": vector_torque_bound,
            "zero_speed_reserve_nm": theoretical_torque - requested_load,
            "max_voltage_for_cap_under_observed_load_speed_v": vmax_required,
            "observed_min_bus_v": min(row["vbus_v"] for row in applied),
            "observed_effective_voltage_cap_v": min_voltage_cap,
            "peak_accepted_voltage_v": absolute_peak(applied, "accepted_voltage_v"),
            "peak_loaded_accepted_voltage_v": absolute_peak(loaded, "accepted_voltage_v"),
            "peak_abs_loaded_back_emf_v": absolute_peak(loaded, "back_emf_v"),
            "peak_abs_loaded_speed_rad_s": absolute_peak(loaded, "velocity_rad_s"),
            "peak_abs_pi_integral_v": max(math.hypot(row["integral_d_v"], row["integral_q_v"])
                                          for row in applied),
            "peak_abs_plant_iq_a": absolute_peak(applied, "iq_plant_a"),
            "peak_abs_loaded_plant_torque_nm": absolute_peak(loaded, "electromagnetic_nm"),
            "tail_mean_directional_plant_iq_a": tail_iq,
            "tail_mean_directional_plant_torque_nm": tail_torque,
            "tail_mean_directional_velocity_rad_s": tail_speed,
            "tail_mean_directional_viscous_drag_nm": tail_drag,
            "tail_mean_directional_residual_torque_nm": tail_residual,
            "tail_mean_directional_back_emf_v": direction * mean(row["back_emf_v"] for row in tail),
            "slip_equilibrium_velocity_at_current_cap_rad_s":
                (theoretical_torque - requested_load) / config["damping_nm_s"] if over else None,
            "tail_h0_samples": len(tail),
            "accepted_h0_rows": len(applied),
            "output_since_inhibit": inhibited[-1]["updates"] - applied[-1]["updates"],
        }

    for case, trace in row_groups(directory / f"{name}-h1.csv"):
        entry = report[case]
        config = entry["config"]
        timing = config["load_off_us"]
        direction = config["direction"]
        loaded = [row for row in trace if row["load_nm"] != 0]
        tail_end = min(timing, loaded[-1]["relative_us"] + config["h1_us"])
        tail = [
            row for row in loaded if tail_end - LAST_LOAD_WINDOW_US <= row["relative_us"] < tail_end
        ]
        assert len(tail) == LAST_LOAD_WINDOW_US // config["h1_us"], case
        assert absolute_peak(trace, "iq_request_a") <= config["motion_iq_limit_a"]
        for row in trace:
            assert row["capture_us"] + 1 == row["h1_us"]
        entry["feasibility"].update({
            "tail_mean_directional_uncapped_request_nm":
                direction * mean(row["requested_torque_nm"] for row in tail),
            "tail_mean_directional_capped_request_nm":
                direction * mean(row["capped_torque_nm"] for row in tail),
        })
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    directory = args.directory
    expected_fail = {"hold-load-beyond-025": 16, "mirror-load-beyond-025": 16,
                     "near-positive": 16, "near-negative": 16, "near-positive-extended": 16,
                     "feasible-positive": 0, "feasible-negative": 0}
    initial = classify(directory, "baseline")
    disabled = classify(directory, "disabled")
    candidate = classify(directory, "candidate")
    sha = study_sha256(directory, "baseline")
    assert sha == study_sha256(directory, "disabled") and initial == disabled
    for cases in (initial, candidate):
        for case, model in cases.items():
            if "quality" in model:
                assert model["quality"]["mask"] == expected_fail[case]
            if model["config"]["load_magnitude_nm"] == 0.039:
                assert model["feasibility"]["classification"] == "LOAD_INFEASIBLE_WITH_CURRENT_LIMITS"
    assert initial["hold-load-beyond-025"]["quality"]["longest_limit_us"] == 762500
    original = decode_log(directory / "original-holdouts.log")
    assert "QUALITY,hold-load-beyond-025,HOST_QUALITY_FAIL,16" in original
    summary = {"identical_frozen_candidate_disabled_trace_sha256": sha, "frozen_0hz": initial,
               "production_48hz": candidate}
    output = directory / "load-summary.json"
    output.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    for case in initial:
        for label, model in (("0 Hz", initial[case]), ("48 Hz", candidate[case])):
            p = model["feasibility"]
            q = model.get("quality", {})
            print(f"{label:>5} {case:24} mask={q.get('mask', '--')} "
                  f"saturation_ms={q.get('longest_limit_us', 0) / 1000:7.1f} "
                  f"recovery_ms={q.get('recovery_us', 0) / 1000:5.1f} "
                  f"tail_T={p['tail_mean_directional_plant_torque_nm']:.8f} "
                  f"tail_w={p['tail_mean_directional_velocity_rad_s']:.5f} "
                  f"tail_Vemf={p['tail_mean_directional_back_emf_v']:.6f} "
                  f"tail_Tdrag={p['tail_mean_directional_viscous_drag_nm']:.8f} "
                  f"max_V={p['peak_accepted_voltage_v']:.6f} "
                  f"peak_Iq={p['peak_abs_plant_iq_a']:.7f}")
    print(f"Verified identical disabled A/B traces and all D diagnostics. {output}")


if __name__ == "__main__":
    main()
