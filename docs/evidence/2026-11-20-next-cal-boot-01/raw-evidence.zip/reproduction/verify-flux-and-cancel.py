import csv
import json
import pathlib
import subprocess
import sys

sim, dest = map(pathlib.Path, sys.argv[1:])
dest.mkdir()
profiles = ("GENERIC_RESEARCH_MOTOR", "CALIBRATION_SALIENT_MOTOR")
for short, profile in zip(("generic", "salient"), profiles):
    path = dest / f"{short}-flux-intervals.csv"
    base = [str(sim), "--profile-id", profile, "--bootstrap", "unknown"]
    capture = subprocess.run([*base, "--flux-trace", str(path)], capture_output=True, text=True, check=True)
    (dest / f"{short}-flux-events.jsonl").write_text(capture.stdout, encoding="utf-8")
    with path.open(newline="", encoding="ascii") as stream:
        assert len(list(csv.DictReader(stream))) == 512
    captured_events = [json.loads(line) for line in capture.stdout.splitlines()]
    review = next(row["review_id"] for row in captured_events if row["event"] == "CANDIDATE_PREVIEW")
    for stage in ("ELECTRICAL_D", "FLUX"):
        target = dest / f"{short}-{stage}-must-not-exist.fcal"
        cancelled = subprocess.run([*base, "--cancel-after", stage, "--approve-candidate", review,
                                    "--save-config", str(target)], capture_output=True, text=True)
        (dest / f"{short}-cancel-after-{stage}.jsonl").write_text(cancelled.stdout, encoding="utf-8")
        rows = [json.loads(line) for line in cancelled.stdout.splitlines()]
        assert cancelled.returncode == 2 and rows[-1]["error"] == "CALIBRATION_CANCELLED", cancelled
        assert not target.exists()
        assert all(row.get("event") not in ("CANDIDATE_PREVIEW", "CONFIGURATION_APPLIED", "CONTROL_TRIAL") for row in rows)
    print(f"{short}: 512 paired flux intervals, cancellation after ELECTRICAL_D and FLUX refused application")


