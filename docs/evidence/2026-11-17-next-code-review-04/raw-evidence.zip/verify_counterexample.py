from audit import OUT,SRC,CC,run
run(OUT/'counterexample','build',[CC,'-std=c11',*[a for p in ['runtime/include','core/include','g3/np/include','g3/safe/include','runtime/tests'] for a in ['-I',SRC/p]],OUT/'counterexample.c',OUT/'runtime/build/falconfoc-pipeline.lib','-o',OUT/'counterexample/probe.exe'])
p=run(OUT/'counterexample','run',[OUT/'counterexample/probe.exe'])
assert 'scenario=0 H0=-5 state=1 action=0 confirmed=1 invalid_streak=1' in p.stdout
for i in [1,2]:
    assert f'scenario={i} H0=-5 state=3 action=1 confirmed=1 invalid_streak=0' in p.stdout
