
from pathlib import Path
from collections import Counter
import subprocess as sp
import re, hashlib

root=Path(__file__).parent
src=Path.cwd()
prior=Path(r"C:/Users/16429/AppData/Local/Temp/servo01a_1794995524571")/"final/locked-arm"
work=root/"arm-compare"
baseline=work/"baseline"
baseline.mkdir(parents=True,exist_ok=True)
for name in ["runtime/include/foc_runtime.h","runtime/src/foc_runtime.c"]:
    p=baseline/Path(name).name
    p.write_bytes(sp.check_output(["git","show","f9af51be:"+name]))
probe=work/"runtime-probe.c"
probe.write_text('#include "foc_runtime.h"\n'
                 'const char runtime_bytes[sizeof(struct foc_runtime)] = {0};\n'
                 'const char command_slot_bytes[sizeof(struct foc_runtime_command)] = {0};\n'
                 'const char sample_bytes[sizeof(struct foc_runtime_sensor)] = {0};\n'
                 'const char sensor_slot_bytes[sizeof(struct foc_runtime_sensor_slot)] = {0};\n'
                 'const char config_bytes[sizeof(struct foc_runtime_config)] = {0};\n')
flags=["-std=c11","-mcpu=cortex-m4","-mthumb","-mfloat-abi=soft","-Os",
       "-ffunction-sections","-fdata-sections","-fstack-usage","-Wall","-Wextra","-Wpedantic","-Werror"]
def tool(name,*args):
    return sp.check_output(["arm-none-eabi-"+name,*args],text=True,stderr=sp.STDOUT)
print(tool("gcc","--version").splitlines()[0])
print("flags"," ".join(flags))
for label, c, headers in [
    ("before",baseline/"foc_runtime.c",baseline),
    ("after",src/"runtime/src/foc_runtime.c",src/"runtime/include")
]:
    lane=work/label
    lane.mkdir(exist_ok=True)
    obj=lane/"runtime.o"
    incs=["-I"+str(headers),"-Icore/include","-Iruntime/include","-Ig3/np/include","-Ig3/safe/include"]
    tool("gcc",*flags,*incs,"-c",c,"-o",obj)
    sizes=lane/"probe.o"
    tool("gcc",*flags,*incs,"-c",probe,"-o",sizes)
    print(label,tool("size",obj),tool("nm","-S","--radix=d",sizes),sep="\n")
    disasm=tool("objdump","-dr",obj)
    (lane/"runtime-disasm.txt").write_text(disasm)
    print("stack allocations:")
    for line in obj.with_suffix(".su").read_text().splitlines():
        if re.search(r"foc_runtime_(h0|h1|control|init|impedance|prepare_outer|publish_reference)",line):
            print(line)
    calls_by_function={}
    for section in re.split(r"Disassembly of section ",disasm)[1:]:
        name=section.split(":\n",1)[0].removeprefix(".text.")
        r=re.findall(r"R_ARM_(?:THM_CALL|THM_JUMP24)\s+([\w.]+)",section)
        calls_by_function[name]=r
        if re.search(r"foc_runtime_(h0|h1|control|impedance|prepare_outer)",name):
            instructions=re.findall(r"^\s*[0-9a-f]+:\s+[0-9a-f]{4}(?: [0-9a-f]{4})?\s+([a-z]\w*)",section,re.M)
            helpers=Counter(x for x in r if x.startswith("__aeabi_") or "impedance" in x)
            print(name, "static instruction slots",len(instructions),"relevant calls",dict(helpers))
    callers={name:r.count("foc_impedance_step") for name,r in calls_by_function.items() if "foc_impedance_step" in r}
    expected=sum(callers.values())==(0 if label=="before" else 1)
    assert expected and all("h1" in name or "outer" in name or "impedance" in name for name in callers)
    print("impedance core call sites",callers)
    print("undefined:"," ".join(tool("nm","-u",obj).split()))
for label, location in [("before",prior),("after",root/"final-complete/locked-arm")]:
    elf=next(location.glob("*.elf"))
    binary=next(location.glob("*.bin"))
    symbols=tool("nm","-S",elf)
    impedance=[line for line in symbols.splitlines() if line.endswith(" T foc_impedance_step")]
    assert bool(impedance)==(label=="after")
    print(label,tool("size",elf))
    print(label,"linked impedance",impedance)
    print(label,"BIN",binary.stat().st_size,hashlib.sha256(binary.read_bytes()).hexdigest())


