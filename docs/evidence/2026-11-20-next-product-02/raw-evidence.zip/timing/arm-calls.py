"""Inventory direct and address-resolved tail calls from an Arm GNU objdump -d."""
from collections import Counter
from pathlib import Path
import re
import sys

LABEL = re.compile(r"^[0-9a-f]+ <([^>]+)>:")
OPCODE = re.compile(r"^\s*([0-9a-f]+):\s+(?:[0-9a-f]{4}\s+)+([a-z][a-z0-9.]+)\s*(.*)$")
TARGET = re.compile(r"^([0-9a-f]+) <([^>]+)>")
TAIL = {
    "b", "beq", "bne", "bhi", "bls", "bgt", "blt", "bge", "ble",
    "bcc", "bcs", "bpl", "bmi", "bvc", "bvs", "cbz", "cbnz",
}
ROOTS = [
    "TMR1_CH_IRQHandler", "ADC1_IRQHandler", "TMR5_GLOBAL_IRQHandler",
    "SPI1_IRQHandler", "USART1_IRQHandler",
    "foc_board_adc_complete", "foc_board_encoder_complete",
    "foc_runtime_h0_step", "foc_runtime_control", "foc_pipeline_step_guarded",
    "foc_current_step_internal", "foc_current_modulate", "foc_svpwm_trusted",
    "foc_runtime_h1_step", "foc_encoder_update", "foc_rotor_phase_from_counts",
    "foc_angle_normalize", "foc_angle_cache_prepare", "foc_impedance_step",
    "foc_runtime_foreground_poll", "foc_serial_poll",
]
WATCH = {
    "__ieee754_rem_pio2f", "__kernel_rem_pio2f", "__udivmoddi4",
    "sinf", "cosf", "fmodf", "hypotf", "sqrtf", "memcpy", "memset", "errno",
}


def inventory(path):
    bodies = {}
    instructions = None
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        label = LABEL.match(line)
        if label:
            instructions = []
            bodies[label[1]] = instructions
        elif (op := OPCODE.match(line)) and instructions is not None:
            instructions.append((int(op[1], 16), op[2].split(".")[0], op[3].split("@")[0].strip()))
    return bodies


def analyze(name, body):
    direct = Counter()
    indirect = []
    backwards_exclusive = []
    exclusive_seen = False
    for address, op, arg in body:
        if op in ("bl", "blx") or op in TAIL:
            target = TARGET.match(arg)
            if target and target[2] != name and "+" not in target[2]:
                direct[target[2]] += 1
            if target and exclusive_seen and op in TAIL and int(target[1], 16) < address:
                backwards_exclusive.append((hex(address), op, arg))
            if op == "blx" and target is None:
                indirect.append((hex(address), arg))
        if op == "bx" and arg not in ("lr", "r14"):
            indirect.append((hex(address), arg))
        if op == "ldrex":
            exclusive_seen = True
    return direct, indirect, backwards_exclusive


def reachable(name, calls):
    found = set()
    pending = [name]
    while pending:
        item = pending.pop()
        if item not in found:
            found.add(item)
            pending.extend(calls.get(item, ()))
    return found


for argument in sys.argv[1:]:
    print(f"## {argument}")
    bodies = inventory(Path(argument))
    calls = {name: analyze(name, body)[0] for name, body in bodies.items()}
    for name in ROOTS:
        assert name in bodies, f"missing {name}"
        targets, indirect, _ = analyze(name, bodies[name])
        print(f"{name}: {len(bodies[name])} displayed instructions/pool opcodes")
        print("  direct call sites:",
              ", ".join(f"{target} x{count}" for target, count in sorted(targets.items())))
        if indirect:
            print("  indirect sites:", indirect)
        nearby = reachable(name, calls) & WATCH
        print("  direct-transitive watched helpers:", ", ".join(sorted(nearby)))
    for name, body in bodies.items():
        _, _, exclusive_back_edges = analyze(name, body)
        if exclusive_back_edges:
            print(f"check exclusive retry/back edges in {name}:", exclusive_back_edges)
    heap = [name for name in bodies if re.search(r"(^|_)(malloc|realloc|calloc|free|sbrk)($|_)", name)]
    print("allocation/deallocation symbols:", heap)
    assert not heap
