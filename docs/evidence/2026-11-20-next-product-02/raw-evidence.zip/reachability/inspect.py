import csv, itertools, math, pathlib
root=pathlib.Path(__file__).resolve().parent
for profile in ('generic','salient'):
    print(profile)
    rows=csv.DictReader((root/(profile+'.csv')).open())
    for case, g in itertools.groupby(rows,lambda r: (r['case'],r['direction'])):
        g=[{k:float(v) for k,v in r.items() if k!='case'} for r in g]
        last=g[-2]
        tail=g[-102:-1]
        sign=int(case[1])
        if case[0]=='undervoltage':
            print(case,last['state'],last['pipeline_status'],last['accepted_us'])
            continue
        for e in ([g[500],last] if case[0]=='high_reverse' else [last]):
            vreq=math.hypot(e['rs']*e['id_ref']-e['omega']*e['pp']*e['lq']*e['iq_ref'],e['rs']*e['iq_ref']+e['omega']*e['pp']*(e['ld']*e['id_ref']+e['flux']))
            print(case,int(e['elapsed_us']), 'w=%.3f id=%+.3f iq=%+.3f V=%.3f need=%.3f sat=%d' % (e['omega'],e['id'],e['iq'],e['v_applied'],vreq, sum(t['v_applied']>=2.398 for t in tail)))
