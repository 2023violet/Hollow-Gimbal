import pathlib, subprocess, sys
root = pathlib.Path.cwd()
tmp = pathlib.Path(sys.argv[1])
build = tmp / "board-clang-off"
source = (root / "firmware/at32f415/src/foc_board_timing.c").read_text(encoding="utf-8")
includes = ["firmware/at32f415/include", "core/include", "g3/np/include", "g3/safe/include",
            "runtime/include", "calibration/include", "sensors/include",
            "platform/at/at32f415/generated/inc", "protocol/include"]
flags = ["-D_DEBUG", "-D_DLL", "-D_MT", "-Xclang", "--dependent-lib=msvcrtd"]
mutations = {
    "control": (None, None, None),
    "unwitnessed-event": ("event.coherent && unique_compare_witness &&", "event.coherent &&", "unknown"),
    "inclusive-deadline": ("write >= load - plan->setup_ns", "write > load - plan->setup_ns", "foc_board_shadow_stage(&candidate"),
    "ignore-stop-before-load": ("witness_valid && output_allowed &&", "witness_valid &&", "plan.load, true, false"),
}
for name, (old, new, marker) in mutations.items():
    c_file = tmp / (name + ".c")
    obj = tmp / (name + ".obj")
    exe = tmp / (name + ".exe")
    if old is not None:
        assert source.count(old) == 1, old
    c_file.write_text(source if old is None else source.replace(old, new), encoding="utf-8")
    subprocess.run(["clang", "-std=c11", *flags, *["-I"+str(root/inc) for inc in includes],
                    "-c", str(c_file), "-o", str(obj)], check=True)
    subprocess.run(["clang", "-fuse-ld=lld", *flags,
                    str(build/"CMakeFiles/test-foc-timing.dir/tests/test_foc_timing.c.obj"), str(obj),
                    str(build/"falconfoc-board1.lib"), str(build/"protocol/falconfoc-wire.lib"),
                    "-o", str(exe)], check=True)
    result = subprocess.run([str(exe)], capture_output=True, text=True)
    print(name, result.returncode, result.stderr.strip() or "timing suite passed", flush=True)
    assert result.returncode == (0 if marker is None else 1)
    if marker is not None:
        assert marker in result.stderr, result.stderr
