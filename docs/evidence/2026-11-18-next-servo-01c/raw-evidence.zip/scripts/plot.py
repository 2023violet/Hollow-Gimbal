
from pathlib import Path
from collections import defaultdict
import csv,sys
root=Path(__file__).parent
sys.path.insert(0,str(Path(r"C:/Users/16429/AppData/Local/Temp/servo01a_1794995524571")/"plot-deps"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
def read(name):
    with (root/"data"/name).open(newline="") as f:
        return list(csv.DictReader(f))
training={r["scenario"]:r for r in read("training-result.csv")}
holdout={r["scenario"]:r for r in read("holdout-result.csv")}
traces=defaultdict(list)
for r in read("holdout-trace.csv"):
    if r["scenario"]=="hold-load-beyond-025":
        traces[r["scenario"]].append(r)
fig,axs=plt.subplots(3,1,figsize=(9.6,8.8),layout="constrained")
fig.suptitle("FalconFOC | Impedance tuning and robustness",fontsize=17)
a,b,c=axs
colors=["#076779","#af4d20","#526572"]
for ax in axs:
    ax.grid(axis="y",alpha=.22); ax.spines[["top","right"]].set_visible(False)
for design,n,color in zip(["fixed","matched","biased"],["01B fixed","Exact J/B","Biased J/B"],colors):
    a.plot([.5,1,2,4],[1000*float(training[f"{j}-{design}"]["overshoot_rad"]) for j in ("j05","j10","j20","j40")],
           marker="o",linewidth=1.8,color=color,label=n)
a.axhline(75,color="#737373",linestyle="--",linewidth=1.3,label="75 mrad quality limit")
a.set(xlabel="Inertia relative to nominal", ylabel="Overshoot (mrad)",xticks=[.5,1,2,4],
      title="Training | Plant inertia sensitivity")
a.legend(ncols=2,frameon=False,fontsize=9)
names=["nominal","high","gentle"]
positions=list(range(3))
for offset,field,label,color in [(-.17,"tail_request_hf_rms_a","q request residual","#076779"),
                                 (.17,"tail_plant_hf_rms_a","Plant q current residual","#af4d20")]:
    b.bar([i+offset for i in positions],[1000*float(holdout[f"hold-noise-{n}"][field]) for n in names],
          width=.31,label=label,color=color)
b.axhline(35,color="#737373",linestyle="--",linewidth=1.3,label="35 mA quality limit")
b.set(xticks=positions,xticklabels=["18 rad/s, zeta 0.75","18 rad/s, zeta 1.20","12 rad/s, zeta 0.80"],
      ylabel="High-pass residual RMS (mA)",title="Holdout | Same +/-6-count noise, independent seed")
b.legend(ncols=2,frameon=False,fontsize=9)
d=traces["hold-load-beyond-025"]
time=[int(r["elapsed_us"])*1e-6 for r in d]
c.axvspan(.8,1.5,color="#e0c472",alpha=.30,label="0.039 N m opposing load")
c.plot(time,[float(r["ref_rad"]) for r in d],color="#737373",linestyle="--",label="Reference")
c.plot(time,[float(r["plant_rad"]) for r in d],color="#076779",linewidth=1.8,label="Plant position")
c.set(xlim=(0,2.6),xlabel="Time from reference step (s)",ylabel="Position (rad)",
      title="Holdout | 0.25 A cap cannot balance the applied load")
c.legend(ncols=2,frameon=False,fontsize=9)
fig.savefig(root/"robustness-curves.png",dpi=160)

