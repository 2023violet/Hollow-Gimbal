"""Analyze CQ cycle traces and verify frozen input/receipt invariants."""
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
import sys


def events(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines()]


def rms(values):
    return math.sqrt(sum(value * value for value in values) / len(values))


def analyze(rowset):
    assert rowset[0]["update_applied"] == rowset[-1]["update_applied"] == "0"
    assert rowset[-1]["action"] == "0"
    rows = [r for r in rowset if r["update_applied"] == "1"]
    assert len(rows) == 300 and rows[0]["elapsed_us"] == "200"
    assert all(int(b["h0_us"]) - int(a["h0_us"]) == 200 for a,b in zip(rows, rows[1:]))
    assert all(r["sample_us"] == r["h0_us"] and r["faults"] == "0" for r in rows)
    assert all(math.hypot(float(r["vd_v"]),float(r["vq_v"])) <=
               float(r["voltage_limit_v"]) * (1 + 16 * 2**-23) + 1e-7 for r in rows)
    errors = [float(r["iq_plant_a"]) - float(r["iq_ref_a"]) for r in rows]
    sat = [int(r["elapsed_us"]) for r in rows if r["near_voltage_cap"] == "1"]
    intervals = defaultdict(list)
    for r,e in zip(rows,errors):
        intervals[float(r["iq_ref_a"])].append((int(r["elapsed_us"]),e))
    return {
        "h0_active_updates":len(rows),
        "h0_active_rmse_a":rms(errors),
        "h0_tail_rmse_a":rms(errors[225:]),
        "peak_abs_error_a":max(map(abs,errors)),
        "mean_tail_signed_error_a":sum(errors[225:])/75,
        "peak_abs_phase_error_deg":max(abs(math.degrees(math.remainder(
            float(r["theta_h0_rad"]) - float(r["theta_plant_rad"]),2*math.pi))) for r in rows),
        "max_h1_to_sample_us":max(int(r["encoder_age_us"]) for r in rows),
        "peak_dq_voltage_v":max(math.hypot(float(r["vd_v"]),float(r["vq_v"])) for r in rows),
        "at_voltage_cap_samples":len(sat),
        "at_voltage_cap_us":len(sat)*200,
        "at_voltage_cap_last_us":sat[-1] if sat else None,
        "phases":[{"target_a": key, "last_outside_0p04_a_us":
                   max((t for t,e in group if abs(e)>0.04),default=None),
                   "rmse_a":rms([e for _,e in group])} for key,group in intervals.items()],
        "stop_confirmed":rowset[-1]["action"]=="0" and rowset[-1]["safety_state"]=="1",
    }


def main(directory):
    summary={}
    for profile in ("generic","salient"):
        applied = events(directory/f"{profile}-applied.jsonl")
        reloaded = events(directory/f"{profile}-reloaded.jsonl")
        for kind in ("CONFIGURATION_APPLIED","FAULT_RECOVERY_VERIFIED","CURRENT_BENEFIT_PASS"):
            assert [r for r in applied if r.get("event")==kind] == [r for r in reloaded if r.get("event")==kind]
        modes = {"before","after"}
        before = [r for r in applied if r.get("event")=="CONTROL_TRIAL" and r["configuration"] in modes]
        after = [r for r in reloaded if r.get("event")=="CONTROL_TRIAL"]
        assert len(before)==16 and before==after
        with (directory/f"{profile}-cycles.csv").open(newline="") as file:
            grouped=defaultdict(list)
            for row in csv.DictReader(file):
                assert None not in row and None not in row.values()
                grouped[(row["scenario"],row["group"])].append(row)
        for scenario in ("step_positive","step_negative","small_reversal","low_bus_reverse_exit","plant_mismatch_load"):
            cases = [group for (scene, _),group in grouped.items() if scene==scenario]
            keys = ("elapsed_us","h0_us","sample_us","h1_us","vbus_v","load_nm",
                    "voltage_limit_v","current_limit_a","iq_ref_a")
            stimuli=[tuple(tuple(r[key] for key in keys) for r in group) for group in cases]
            assert all(stimulus==stimuli[0] for stimulus in stimuli)
        summary[profile]={"cycles":{"/".join(key):analyze(group) for key,group in grouped.items()},
                          "trials":before,
                          "review_id":next(r["review_id"] for r in applied if r.get("event")=="CANDIDATE_REVIEWED"),
                          "fcal_sha256":hashlib.sha256((directory/f"{profile}-new.fcal").read_bytes()).hexdigest()}
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    main(Path(sys.argv[1]))

