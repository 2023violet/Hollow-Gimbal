"""Build, replay, archive, and analyze historical Current on a Windows Host."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile


def execute(command, root, log, stdin=None):
    result = subprocess.run(
        [str(arg) for arg in command],
        cwd=root, input=stdin, capture_output=True, check=False,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    log.with_suffix(".stderr").write_bytes(result.stderr)
    log.with_suffix(".out").write_bytes(result.stdout)
    if result.returncode:
        raise RuntimeError(f"Command failed. See {log.with_suffix('.stderr')}")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Frozen CQ-02 source at the start of this work")
    parser.add_argument("cq01", type=Path, help="Original CQ-01 raw-evidence.zip")
    parser.add_argument("scratch", type=Path, help="New directory outside source, for host builds and trace output")
    parser.add_argument("--compiler", default="clang")
    args = parser.parse_args()
    root, archive, scratch = (path.resolve() for path in (args.source, args.cq01, args.scratch))
    if root in scratch.parents or scratch in root.parents or root == scratch:
        raise SystemExit("Use a scratch directory separate from the source tree")
    scratch.mkdir()
    bundle = Path(__file__).resolve().parent
    out = scratch / "raw"
    out.mkdir()
    baseline = "historical-current/after/historical-current"
    with ZipFile(archive) as previous:
        wire = previous.read("historical-current/historical-current.wire")
        old_csv, old_json = (previous.read(f"{baseline}.{suffix}") for suffix in ("csv", "json"))
    (out / "historical-current.wire").write_bytes(wire)

    overlay = scratch / "overlay"
    commands = []

    def run(command, name, stdin=None):
        commands.append([str(arg) for arg in command])
        return execute(command, root, out / name, stdin)

    run([sys.executable, bundle / "instrument-current.py", root, overlay], "instrument")
    cli = root / "tools/falconfoc-cli/falconfoc_cli.py"
    metadata = {}
    for build, source, prefix in (("plain", root, "historical"), ("trace", overlay, "trace")):
        build_dir = scratch / build
        run(["cmake", "-S", source / "simulation", "-B", build_dir, "-G", "Ninja",
             "-DCMAKE_BUILD_TYPE=Debug", f"-DCMAKE_C_COMPILER={args.compiler}"],
            f"{build}-configure")
        run(["cmake", "--build", build_dir, "--target", "falconfoc-virtual-device",
             "--parallel", "4"], f"{build}-build")
        exe = build_dir / "falconfoc-virtual-device.exe"
        run([sys.executable, cli, "--simulator", exe, "virtual-demo", "--virtual-scenario", "current",
             "--advance-us", "500", "--duration-us", "10000", "--csv", out / f"{prefix}-current.csv",
             "--json", out / f"{prefix}-current.json"], f"{prefix}-current")
        result = run([exe, "--mode", "current", "--advance-us", "500"], f"{build}-wire", wire)
        metadata[build] = (result.stdout, [
            line for line in result.stderr.splitlines() if line.startswith(b"FALCONF0C_META ")
        ])
        assert (out / f"{prefix}-current.csv").read_bytes() == old_csv
        assert json.loads((out / f"{prefix}-current.json").read_bytes()) == json.loads(old_json)
    assert metadata["plain"] == metadata["trace"] and all(metadata["plain"])
    run([sys.executable, bundle / "analyze-current.py", out], "analysis")
    (out / "commands.json").write_text(json.dumps(commands, indent=2) + "\n", encoding="utf-8")
    (out / "source-sha256.json").write_text(json.dumps({
        path: hashlib.sha256((root / path).read_bytes()).hexdigest()
        for path in (
            "core/src/foc_current.c",
            "runtime/src/foc_pipeline.c",
            "runtime/src/foc_runtime.c",
            "simulation/src/foc_virtual_current.c",
            "simulation/src/foc_virtual_motor.c",
            "simulation/src/falconfoc_virtual_device.c",
            "tools/falconfoc-cli/falconfoc_cli.py",
        )
    }, indent=2) + "\n", encoding="utf-8")
    print((out / "analysis.out").read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()

