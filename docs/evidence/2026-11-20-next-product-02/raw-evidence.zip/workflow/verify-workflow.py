from pathlib import Path
import hashlib,json,subprocess,sys

root,runner,baseline,out=(Path(x).resolve() for x in sys.argv[1:])
out.mkdir(parents=True)
cli=root/"tools/falconfoc-cli/falconfoc_cli.py"
def call(name, args, status=0):
    command=[sys.executable, "-B", str(cli), "calibrate", "--simulator",str(runner),*map(str,args)]
    run=subprocess.run(command,text=True,capture_output=True,timeout=65)
    (out/f"{name}.jsonl").write_text(run.stdout,encoding="utf-8")
    if run.stderr:(out/f"{name}.stderr").write_text(run.stderr,encoding="utf-8")
    assert run.returncode==status,(name,run.returncode,run.stdout,run.stderr)
    return [json.loads(line) for line in run.stdout.splitlines()]
def pick(data,name):
    return next(x for x in data if x.get("event")==name)
def events(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines()]
def controls(data):
    return [x for x in data if x.get("event") in {"CONFIGURATION_APPLIED","FAULT_RECOVERY_VERIFIED","CONTROL_TRIAL","CURRENT_BENEFIT_PASS"}]
caps=pick(call("capabilities",["--capabilities"]),"HOST_CAPABILITIES")
assert caps["output_locked_on_board1"] and not caps["mcu_flash"] and not caps["physical_applied"]
report={}
for name,profile,cogging in (("generic","GENERIC_RESEARCH_MOTOR",["--cogging"]),
                             ("salient","CALIBRATION_SALIENT_MOTOR",[])):
    opts=["--profile-id",profile]
    preview=call(f"{name}-preview",opts+cogging)
    review=pick(preview,"CANDIDATE_PREVIEW")["review_id"]
    pack=out/f"{name}.fcal"
    trace=out/f"{name}-startup.csv"
    call(f"{name}-bad-review",opts+[ "--approve-candidate","BAD","--save-config",pack]+cogging,2)
    assert not pack.exists()
    applied=call(f"{name}-applied",opts+["--approve-candidate",review,"--save-config",pack,
                                      "--startup-trace",trace]+cogging)
    query=call(f"{name}-read-only",opts+["--load-config",pack,"--reachability","6.9",0,2.2,12])
    assert not controls(query)
    point=pick(query,"REACHABILITY")
    assert point["review_id"]==review and point["configuration_applied"] is False
    reloaded=call(f"{name}-reloaded",opts+["--load-config",pack,"--approve-candidate",review])
    assert controls(applied)==controls(reloaded)==controls(events(baseline/f"startup-{name}.jsonl"))
    assert pick(applied,"PARAMETERS_IDENTIFIED")==pick(events(baseline/f"startup-{name}.jsonl"),"PARAMETERS_IDENTIFIED")
    assert pack.read_bytes()==(baseline/f"active-{name}.fcal").read_bytes()
    assert trace.read_bytes()==(baseline/f"startup-{name}.csv").read_bytes()
    graded=subprocess.run([sys.executable,"-B",root/"simulation/tests/current_startup_quality.py",profile,trace],
                          text=True,capture_output=True,check=False)
    assert graded.returncode==(name=="salient"),graded.stderr
    (out/f"{name}-startup-v1.json").write_text(graded.stdout,encoding="utf-8")
    report[name]={"four_mode_and_reload_parity":True,"startup_csv_sha256":hashlib.sha256(trace.read_bytes()).hexdigest(),
                  "fcal_sha256":hashlib.sha256(pack.read_bytes()).hexdigest(),"reachability":point["verdict"],
                  "startup_v1_exit":graded.returncode}
mismatch=call("identity-mismatch",["--profile-id","CALIBRATION_SALIENT_MOTOR","--load-config",
                                  out/"generic.fcal","--reachability",0,0,0.5,12],2)
assert mismatch[-1]["error"]=="PACKAGE_IDENTITY" and not controls(mismatch)
bad_point=call("bad-point",["--load-config",out/"generic.fcal","--reachability",0,0,"nan",12],2)
assert bad_point[-1]["error"]=="INVALID_REACHABILITY_POINT"
(out/"summary.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report))

