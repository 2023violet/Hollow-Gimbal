import csv, hashlib, pathlib, re, subprocess, sys
root = pathlib.Path.cwd()
tmp = pathlib.Path(sys.argv[1])
def query(*cmd):
    return subprocess.check_output(cmd, text=True, encoding="utf-8")
for name in ("prior-hashes.csv", "platform-hashes.csv"):
    rows = list(csv.DictReader((tmp/name).open(encoding="utf-8-sig")))
    for entry in rows:
        p = pathlib.Path(entry["Path"])
        assert hashlib.sha256(p.read_bytes()).hexdigest() == entry["Hash"].lower(), p
    print(name, len(rows), "files match baseline")
assert query("git", "rev-parse", "HEAD").strip() == "d824933946a365b8081089c2e396d77b3f661bc8"
assert not query("git", "diff", "--cached", "--name-only").strip()
assert not query("git", "status", "--porcelain", "--", "core", "control_plane", "simulation", "sensors", "protocol", "tools/falconfoc-cli").strip()
for ext in ("elf", "bin", "hex"):
    name = "falconfoc-v2-at32f415."+ext
    before, after = ((tmp/sub/name).read_bytes() for sub in ("arm-before", "arm-after"))
    assert before == after
    print("ARM byte equality", ext, hashlib.sha256(after).hexdigest())
exe = tmp/"host-clang/falconfoc-servo-demo.exe"
def run(*args, rc=0):
    result = subprocess.run([str(exe), *args], capture_output=True, text=True, encoding="utf-8")
    assert result.returncode == rc, (args, result.returncode, result.stderr)
    assert "physical_applied=true" not in result.stdout
    return result.stdout, result.stderr
inspect, _ = run("--inspect","--iq-limit","1.8")
assert "config motion.iq_limit candidate=1.8 effective=1.8 unit=A" in inspect
assert "inspection state=DISABLED output=INHIBITED confirmed=true updates=0" in inspect
bad, reason = run("--inspect","--iq-limit","3",rc=1)
assert "ERR_RANGE" in reason and "runtime=INITIALIZED" not in bad
run("--unknown",rc=2)
run("--inspect","--iq-limit","bad",rc=2)
normal, _ = run()
replay, _ = run()
assert normal == replay, "repeat output comparison"
for phase,tick,state in (("SET_MODE",200,"DISABLED"),("ARM",600,"READY"),("START",800,"RUNNING")):
    assert re.search(rf"lifecycle {phase} APPLIED H0_us={tick} mode=3 state={state} session=1 request_seq=\d+", normal)
assert normal.count("STOP H0=OBSERVED H0_us=2400200 output=INHIBITED") == 2
assert normal.count("updates=11996->11996 old_session_publish=ERR_SESSION old_receipt=ERR_SESSION") == 2
assert normal.count("updates=11996 plant_update_steps=23992") == 2
for prefix in ("ZERO_FF","MODEL_FF"):
    for t in ("1000","1450000","1700200"):
        assert re.search(rf"^{prefix} t_us={t} .*state=RUNNING .*action=UPDATE .*command_receipt=APPLIED", normal, re.M)
faults, _ = run("--faults")
assert "tentative_PI_committed=false" in faults
assert "recovery BLOCKED reason=FATAL_RESET_REQUIRED" in faults
assert "recovery BLOCKED reason=SAMPLE_INVALID" in faults
recovery, _ = run("--recovery")
assert "CLEAR_COMMAND_TIMEOUT APPLIED H0_us=4400 state=DISABLED output=INHIBITED" in recovery
assert "sensor_us=5000 H0_us=5000 action=UPDATE updates=14" in recovery
assert "updates=14->14 old_session_publish=ERR_SESSION" in recovery
print("CLI syntax, CP validation/readback, replay determinism, receipts, Plant, STOP, FAULT, recovery and scope checked")
for name, data in (("inspect",inspect),("normal",normal),("faults",faults),("recovery",recovery)):
    (tmp/(name+"-stdout.log")).write_text(data, encoding="utf-8")
