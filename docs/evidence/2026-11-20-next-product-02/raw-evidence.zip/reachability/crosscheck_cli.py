"""Compare the normal FCAL CLI to an independent numerical steady-state oracle."""
from collections import Counter
import json
import math
from pathlib import Path
import subprocess
import sys

from analyze import ROOT, demand, iq_interval

SPECS = {
    "generic": ("GENERIC_RESEARCH_MOTOR", 201, "2ca90021"),
    "salient": ("CALIBRATION_SALIENT_MOTOR", 202, "66aded47"),
}


def query(exe, profile, kind, speed, id_a, target, vbus):
    profile_id, motor_id, review_id = SPECS[profile]
    fcal = ROOT / f"../cq03/startup/active-{profile}.fcal"
    arguments = [
        str(exe), "--profile-id", profile_id, "--load-config", str(fcal),
        "--reachability" if kind == "current" else "--reachability-torque",
        *(format(value, ".9g") for value in (speed, id_a, target, vbus)),
    ]
    run = subprocess.run(arguments, check=True, text=True, capture_output=True)
    events = list(map(json.loads, run.stdout.splitlines()))
    result = next(event for event in events if event.get("event") == "REACHABILITY")
    assert not result["configuration_applied"] and not result["physical_applied"]
    assert not any(event.get("event") == "CONFIGURATION_APPLIED" for event in events)
    assert result["control_mode"] == ("current" if kind == "current" else "impedance")
    assert result["motor_setup_id"] == motor_id and result["review_id"] == review_id
    return events, result


def oracle(model, actual, kind, speed, id_a, target, vbus):
    limits = actual["configured_limits"]
    assert (limits["current_a"], limits["min_vbus_v"], limits["duty_min"], limits["duty_max"]) == (
        2.5, 6, 0, 1
    )
    assert abs(limits["voltage_v"] - 2.4) < 2e-7
    assert abs(limits["torque_nm"] - (0.33 if kind == "torque" else 0)) < 2e-7
    cap_v = min(limits["voltage_v"], vbus / math.sqrt(3))
    kt = 1.5 * model["pp"] * (model["flux"] + (model["ld"] - model["lq"]) * id_a)
    iq_a = target / kt if kind == "torque" else target
    vd, vq = demand(model, speed, id_a, iq_a)
    tau = iq_a * kt
    required_v = math.hypot(vd, vq)
    margin_v = cap_v - required_v
    iq_range = None if vbus < limits["min_vbus_v"] else iq_interval(
        model, speed, id_a, cap_v, limits["current_a"]
    )
    if iq_range is not None and kind == "torque":
        cap_iq = limits["torque_nm"] / abs(kt)
        iq_range = [max(iq_range[0], -cap_iq), min(iq_range[1], cap_iq)]
        if iq_range[0] > iq_range[1]:
            iq_range = None
    reasons = []
    if vbus < limits["min_vbus_v"]:
        reasons.append("BUS_MINIMUM")
    if math.hypot(id_a, iq_a) > limits["current_a"]:
        reasons.append("CURRENT_LIMIT")
    if kind == "torque" and abs(tau) > limits["torque_nm"]:
        reasons.append("TORQUE_LIMIT")
    if margin_v < 0:
        reasons.append("VOLTAGE_LIMIT")
    verdict = "MODEL_INFEASIBLE" if reasons else "MODEL_FEASIBLE"
    expected = {
        "verdict": verdict,
        "reasons": reasons,
        "required_dq_v": [vd, vq],
        "required_v": required_v,
        "margin_v": margin_v,
        "near_voltage_limit": 0 <= margin_v <= 0.05 * cap_v,
        "range_valid": iq_range is not None,
        "iq_range_a": iq_range,
        "torque_range_nm": sorted(q * kt for q in iq_range) if iq_range is not None else None,
        "torque_nm": tau,
        "torque_per_q_amp": kt,
    }
    numeric_errors = []
    for key, wanted in expected.items():
        found = actual[key]
        if isinstance(wanted, float):
            numeric_errors.append(abs(wanted - found))
        elif wanted is None:
            assert found == [0, 0], (key, expected, actual)
        elif isinstance(wanted, list) and wanted and isinstance(wanted[0], float):
            numeric_errors.extend(abs(w - f) for w, f in zip(wanted, found, strict=True))
        else:
            assert wanted == found, (key, expected, actual)
    assert max(numeric_errors) < 3e-6, (expected, actual)
    return expected, max(numeric_errors)


def model_from_log(profile):
    line = (ROOT / f"{profile}.log").read_text(encoding="utf-8-sig").splitlines()[0]
    return {key: float(value) for token in line.split() for key, value in [token.split("=")]
            if key in {"rs", "ld", "lq", "flux", "pp"}}


def main():
    exe = Path(sys.argv[1]).resolve()
    summary = json.loads((ROOT / "summary.json").read_text(encoding="utf-8-sig"))
    models = {profile: model_from_log(profile) for profile in SPECS}
    counts = Counter()
    output = []

    def compare(profile, case, phase, kind, speed, id_a, target, vbus):
        events, result = query(exe, profile, kind, speed, id_a, target, vbus)
        expected, error = oracle(models[profile], result, kind, speed, id_a, target, vbus)
        counts[result["verdict"]] += 1
        output.append({
            "profile": profile, "case": case, "phase": phase, "max_numeric_error": error,
            "independent_oracle": expected, "cli_events": events,
        })
        return result

    for segment in summary["segments"]:
        profile, case, phase = (segment[key] for key in ("profile", "case", "phase"))
        id_a, iq_a = segment["request"]
        vbus = segment["vbus_v"]
        speed = segment.get("observed", {}).get("omega", segment["initial_speed_rad_s"])
        result = compare(profile, case, phase, "current", speed, id_a, iq_a, vbus)
        if case == "plant_mismatch" and profile == "salient":
            assert result["verdict"] == "MODEL_FEASIBLE" and result["near_voltage_limit"]
            assert segment["verdict"] == "VOLTAGE_LIMITED"
        if case == "cold_large_free" and profile == "salient":
            for endpoint, label in zip(segment["speed_endpoints_rad_s"], ("startup", "tail")):
                compare(profile, case, label, "current", endpoint, id_a, iq_a, vbus)

    for profile in SPECS:
        for sign in (-1, 1):
            for speed, torque in ((0, .20), (0, .34), (18, .32), (18, -.20)):
                compare(profile, "impedance_cap", "steady", "torque", sign * speed, 0, sign * torque, 12)
    assert len(output) == 84, len(output)
    result = {
        "query_count": len(output),
        "verdict_counts": dict(counts),
        "max_numeric_error": max(row["max_numeric_error"] for row in output),
        "queries": output,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
