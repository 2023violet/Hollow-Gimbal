from concurrent.futures import ThreadPoolExecutor, as_completed
from hashlib import sha256
import os
from pathlib import Path
import shutil
import subprocess as sp
import sys
from zipfile import ZipFile

root = Path(__file__).resolve().parent
origin = Path.cwd().resolve()
repo = root / "source"
logs = root / "logs"
logs.mkdir()
head = sp.check_output(["git", "rev-parse", "HEAD"], cwd=origin, text=True).strip()
assert head == "a07d7db6b3f2d439255724df05e77e343ae6a731", head
sp.run(["git", "clone", "--shared", "--quiet", "--no-checkout", origin, repo], check=True)
sp.run(["git", "-C", repo, "checkout", "--quiet", "--detach", head], check=True)
changed = sp.check_output(["git", "status", "--porcelain=v1", "-z", "-uall"], cwd=origin).decode()
prefixes = ("core/", "runtime/", "simulation/", "sensors/", "firmware/", "calibration/",
            "protocol/", "examples/servo/", "docs/servo/", "scripts/sdk/consumers/",
            "docs/evidence/2026-11-18-next-servo-02d/")
overlay = []
for status in filter(None, changed.split("\0")):
    path = status[3:]
    if not path.startswith(prefixes) and path not in ("README.md", "docs/README.md", "scripts/README.md"):
        continue
    assert (origin / path).is_file(), path
    (repo / path).parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(origin / path, repo / path)
    overlay.append(path)
(logs / "snapshot.txt").write_text(
    f"Source: {origin}\nIsolated snapshot: {repo}\nBase commit: {head}\nOverlay paths:\n" +
    "\n".join(sorted(overlay)) + "\n", encoding="utf-8"
)

env = os.environ.copy()
env["PATH"] = os.pathsep.join([
    r"D:\Git\bin", r"C:\mingw64\bin",
    str(Path(sp.check_output(["clang", "-print-resource-dir"], text=True).strip()) / "lib/windows"),
    env["PATH"],
])
env.update(PYTHONDONTWRITEBYTECODE="1", ASAN_OPTIONS="halt_on_error=1",
           UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
clang = shutil.which("clang", path=env["PATH"])
gcc = shutil.which("gcc", path=env["PATH"])
tools = [clang, gcc, "arm-none-eabi-gcc", "cmake", "ninja", sys.executable]
with (logs / "toolchains.txt").open("w", encoding="utf-8") as f:
    for tool in tools:
        version = sp.check_output([tool, "--version"], cwd=repo, env=env, text=True).splitlines()[0]
        print(f"{tool}: {version}", file=f)

def run(label, commands, local_env=None):
    logfile = logs / f"{label}.log"
    status = 0
    with logfile.open("w", encoding="utf-8") as f:
        for cmd in commands:
            print("$ " + sp.list2cmdline(list(map(str, cmd))), file=f, flush=True)
            status = sp.run(cmd, cwd=repo, env=local_env or env, stdout=f, stderr=sp.STDOUT).returncode
            if status:
                break
    lines = logfile.read_text(encoding="utf-8", errors="replace").splitlines()
    markers = ("tests passed out of", "all requested checks passed", "[Total]", "FLASH:", "RAM:",
               "checked C/H files", "checked CMake files", "checked README files", "Ran 8 tests",
               "TRACE SHA", "ARM flash image")
    shown = lines[-24:] if status else [line for line in lines if any(k in line for k in markers)][-8:]
    print(f"{label}: {status}", *shown, sep="\n", flush=True)
    return status

def host(project, variant, *, options=(), name=None, targets=(), selection=None):
    label = name or f"{project}-{variant}"
    out = root / "builds" / label
    compiler = gcc if variant == "gcc" else clang
    flags = []
    if variant == "asan":
        flags = [
            "-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
            "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined",
        ]
    return run(label, [
        ["cmake", "-S", project, "-B", out, "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Debug",
         "-DCMAKE_C_COMPILER=" + compiler, *flags, *options],
        ["cmake", "--build", out, "--parallel", "4", *(["--target", *targets] if targets else [])],
        ["ctest", "--test-dir", out, "--no-tests=error", "--output-on-failure", "-j", "4",
         *(["-R", selection] if selection else [])],
    ])

def locked_arm():
    out = root / "builds" / "locked-arm"
    rc = run("arm", [
        ["cmake", "-S", "firmware/at32f415", "-B", out, "-G", "Ninja",
         f"-DCMAKE_TOOLCHAIN_FILE={(repo/'tools/cmake/arm-gcc-toolchain.cmake').as_posix()}",
         "-DMCU_CPU=cortex-m4", "-DMCU_FPU=none", "-DMCU_FLOAT=soft"],
        ["cmake", "--build", out, "--parallel", "4"],
        ["arm-none-eabi-size", "-A", out / "falconfoc-v2-at32f415.elf"],
    ])
    if rc:
        return rc
    base = Path(sys.argv[1]) / "final-complete" / "locked-arm" / "falconfoc-v2-at32f415.bin"
    current = out / base.name
    first = base.read_bytes()
    second = current.read_bytes()
    digest = sha256(second).hexdigest()
    with (logs / "arm.log").open("a", encoding="utf-8") as f:
        print(f"03B baseline: {base}\nSOFT-01: {current}", file=f)
        print(f"03B bytes={len(first)} SHA-256={sha256(first).hexdigest()}", file=f)
        print(f"SOFT-01 bytes={len(second)} SHA-256={digest}", file=f)
        print(f"Byte-for-byte equality: {first == second}", file=f)
    print(f"arm comparison: {len(second)} bytes, SHA-256 {digest}, equality={first == second}", flush=True)
    return int(first != second)

def strict_gate():
    cmds = []
    for preset in ("fw-full-diag-carrier-debug","fw-standard-carrier-minsizerel","fw-tiny-carrier-minsizerel"):
        cmds += [["cmake", "--preset", preset], ["cmake", "--build", "--preset", "build-" + preset,
                                                  "--parallel", "4"]]
    return run("strict-gate", [
        *cmds,
        [r"D:\Git\bin\bash.exe", "-lc", "./run.sh build"],
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
         "scripts/gates/check_themis_quality_gate.ps1", "-RepoRoot", repo,
         "-Scope", "all", "-RequireCMakeFormatter"],
    ])

def source_contract():
    return run("source-contract", [
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
         "scripts/gates/check_falconfoc_source_contract.ps1", "-RepoRoot", repo],
        ["clang-format", "--dry-run", "--Werror", "examples/servo/main.c"],
    ])

def cli():
    (repo / 'build/vm01a-simulation').mkdir(parents=True, exist_ok=True)
    cli_env = {**env, "FOC_SERIAL_SIM": str(root / "builds" / "board-host-clang" / "foc-serial-sim.exe"),
               "FOC_VIRTUAL_DEVICE": str(root / "builds" / "simulation-clang" / "falconfoc-virtual-device.exe")}
    return run("cli-virtual-uart-v1", [
        [sys.executable, "-m", "unittest", "discover", "-s", "tools/falconfoc-cli", "-p",
         "test_falconfoc_cli.py", "-v"]
    ], cli_env)

def replay():
    script = root / "replay-02d.py"
    return run("frozen-02d", [[sys.executable, script, root / "builds" / "simulation-clang"]])

archive_name = "falconfoc-servo-sdk-0.1.0-rc.1"
original_sdk = origin / "build" / "sdk-candidates" / "servo-03b-2026-11-18"
archive = original_sdk / (archive_name + ".zip")
manifest = original_sdk / "SDK-SOURCE-MANIFEST.json"
archive_hash = sha256(archive.read_bytes()).hexdigest()
manifest_hash = sha256(manifest.read_bytes()).hexdigest()
assert archive_hash == "4293dcd599859226ea52248d23262c134cffbf7d74fd09bd2a258aad8b8c5694"
assert manifest_hash == "34f3cfe5e54bf6daab9d182fac01b2a1fae594bba33d77a3ab852bfc5ca5f0c4"
(logs / "sdk-identity.txt").write_text(f"Archive SHA-256={archive_hash}\nManifest SHA-256={manifest_hash}\n",
                                       encoding="utf-8")
with ZipFile(archive) as z:
    z.extractall(root / "sdk")
sdk = root / "sdk" / archive_name
shutil.copytree(repo / "scripts/sdk/consumers", root / "standalone-sdk-consumers")

jobs = {}
with ThreadPoolExecutor(max_workers=5) as pool:
    def submit(label, fn, *args, **kwargs):
        jobs[pool.submit(fn, *args, **kwargs)] = label
    submit("strict-gate", strict_gate)
    submit("arm", locked_arm)
    submit("source", source_contract)
    for project in ("core", "runtime", "simulation", "sensors", "calibration", "protocol"):
        for variant in ("clang", "gcc", "asan"):
            submit(f"{project}-{variant}", host, project, variant)
    for variant in ("clang", "gcc", "asan"):
        submit(f"board-host-{variant}", host, "firmware/at32f415", variant, name=f"board-host-{variant}")
        submit(f"servo-demo-{variant}", host, "examples/servo", variant, name=f"servo-demo-{variant}",
               targets=["falconfoc-servo-demo"], selection=r"^test-falconfoc-servo-(demo|faults)$")
        for use in ("core", "servo"):
            submit(f"original-sdk-{use}-{variant}", host, root / "standalone-sdk-consumers" / use, variant,
                   name=f"original-sdk-{use}-{variant}", options=[f"-DFALCONFOC_SOURCE_DIR={sdk}"])
    status = {}
    for task in as_completed(jobs):
        status[jobs[task]] = task.result()

if status["simulation-clang"] == 0:
    status["frozen-02d"] = replay()
if status["simulation-clang"] == 0 and status["board-host-clang"] == 0:
    status["cli-virtual-uart-v1"] = cli()
(logs / "summary.txt").write_text(
    "\n".join(f"{name}={status[name]}" for name in sorted(status)) + "\n", encoding="utf-8"
)
sys.exit(int(any(status.values())))

