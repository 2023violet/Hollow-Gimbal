#include <stdio.h>
#include "foc_bootstrap.h"
#include "foc_virtual_bootstrap_capture.h"
int main(void)
{
    printf("sample_bytes=%zu\ncapture_bytes=%zu\nfit_result_bytes=%zu\nreused_rotor_context_bytes=%zu\n",
           sizeof(struct foc_bootstrap_sample), sizeof(struct foc_virtual_bootstrap_capture_result),
           sizeof(struct foc_bootstrap_result), sizeof(struct foc_calibration_rotor_context));
    return 0;
}