import csv
import json
import subprocess as sp
import sys
from pathlib import Path
if len(sys.argv) != 3:
    raise SystemExit("usage: metrics-adapter.py EVIDENCE_DIRECTORY VIRTUAL_TEST_EXECUTABLE")
root = Path(sys.argv[1]).resolve()
exe = Path(sys.argv[2]).resolve()
sys.path.insert(0,str(Path.cwd()/"tools/falconfoc-cli"))
from falconfoc_cli import _virtual_metrics

result=sp.check_output([exe,"--trace"])
(root/"motor-id-trace.csv").write_bytes(result)
assert sp.check_output([exe,"--trace"])==result
labels=("startup","positive","negative","saturation","recovery","stop")
profiles={}
fits=[]
gains=[]
for row in csv.reader(result.decode().splitlines()):
    if row[0]=="FIT" or row[0]=="REJECT":
        fits.append(row)
        print(",".join(row))
        continue
    if row[0]=="GAINS":
        gains.append(row)
        print(",".join(row))
        continue
    kind,profile,segment,t,dr,qr,d,q,state,action,faults,accepted,rejected,sat,int_d,int_q=row
    point={"kind":"virtual","control_mode":0,"virtual_time_us":int(t),
           "iq_actual_a":float(q),"iq_target_a":float(qr),"id_actual_a":float(d),"id_target_a":float(dr),
           "state":int(state),"output_action":int(action),"faults":int(faults),
           "virtual_update_accepted":int(accepted),"virtual_update_rejected":int(rejected),
           "saturation_count":int(sat),"integral_d_v":float(int_d),"integral_q_v":float(int_q)}
    profiles.setdefault(profile,{}).setdefault(segment,[]).append(point)
assert list(profiles)==["fixed","truth","fitted"]
summary={}
for profile,groups in profiles.items():
    all_records=[p for seg in labels for p in groups[seg]]
    assert len(all_records)==222
    full=_virtual_metrics(all_records,"current",44400)
    prev=groups["startup"][-1]
    rows={}
    for seg in labels[1:-1]:
        valid=groups[seg]
        assert all(p["state"]==3 and p["output_action"]==1 for p in valid)
        args=[dict(p,saturation_count=p["saturation_count"]-prev["saturation_count"],
                   virtual_update_accepted=p["virtual_update_accepted"]-prev["virtual_update_accepted"])
              for p in valid]
        origin=prev["virtual_time_us"]
        m=_virtual_metrics(args,"current",args[-1]["virtual_time_us"]-origin)
        t=m["settling_time_us"]
        m["settling_elapsed_us"]=None if t is None else t-origin
        rows[seg]=m
        print(f"{profile:6} {seg:10} {m['running_window_rmse']:.6f} {m['running_tail_rmse']:.6f} "
              f"{m['peak_error']:.6f} {m['overshoot']:.6f} {str(m['settling_elapsed_us']):>5} "
              f"{m['saturation_duration_us']:5} {m['update_accepted']:3} {m['control_quality']}")
        prev=valid[-1]
    final=groups["stop"][-1]
    assert final["state"]==1 and final["output_action"]==0 and final["faults"]==0
    assert final["virtual_update_accepted"]==220 and final["virtual_update_rejected"]==0
    print(f"{profile:6} complete   full_rmse={full['full_window_rmse']:.9f} "
          f"running_rmse={full['running_window_rmse']:.9f} satur_us={full['saturation_duration_us']}")
    sat_end=groups["saturation"][-1]
    recovery_end=groups["recovery"][-1]
    print(f"{profile} integral_q_v saturation_end={sat_end['integral_q_v']:.9f} "
          f"recovery_end={recovery_end['integral_q_v']:.9f}")
    summary[profile]={"segments":rows,"full":full,"stop":final,"integral_at_saturation_end":sat_end,"integral_at_recovery_end":recovery_end}
history=json.loads((root/"historical-current.json").read_text())["metrics"]
(root/"motor-id-metrics.json").write_text(json.dumps(
    {"fits":fits,"gains":gains,"historical_current":history,"comparison":summary},indent=2)+"\n")
print({k:history[k] for k in ("full_window_rmse","running_window_rmse","running_tail_rmse","control_quality")})

