
"""Require byte-identical historical CLI modes across the SERVO-02C fixture edit."""
import csv
import hashlib
from pathlib import Path
from subprocess import check_output
from sys import argv

directory = Path(argv[1])
before = directory / "pre02c-robustness.exe"
after = directory / "test-foc-impedance-robustness.exe"
models = ("0.002001755405", "0.00599673437", "0.008009241894", "0.006023695227")
modes = (
    (),
    ("--trace",),
    ("--train",),
    ("--train", "--trace"),
    ("--mechanical-id-fit", *models),
    ("--mechanical-id-fit", *models, "--trace"),
    ("--damping-noise-train",),
    ("--damping-noise-train", "--trace"),
    ("--damping-noise-holdout",),
    ("--damping-noise-holdout", "--trace"),
)
with (directory / "legacy-mode-comparison.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["command", "bytes", "records", "before_sha256", "after_sha256"])
    for mode in modes:
        prior = check_output([before, *mode])
        current = check_output([after, *mode])
        assert prior == current, mode
        kind = " ".join(mode) or "<default>"
        row = (kind, len(prior), prior.count(b"\n"), hashlib.sha256(prior).hexdigest(), hashlib.sha256(current).hexdigest())
        writer.writerow(row)
        print(*row)

