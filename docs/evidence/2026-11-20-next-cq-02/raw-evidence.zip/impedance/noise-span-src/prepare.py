from pathlib import Path
import sys
repo,dest=map(Path,sys.argv[1:])
s=(repo/'simulation/tests/test_foc_impedance_robustness.c').read_text()
old='offset = (int)((*random >> 16U) % 13U) - 6;'
assert s.count(old)==1
s=s.replace(old,'offset = (int)((*random >> 16U) % (2U * CQ02_COUNTS + 1U)) - CQ02_COUNTS;')
(dest/'robustness-counts.c').write_text(s)
