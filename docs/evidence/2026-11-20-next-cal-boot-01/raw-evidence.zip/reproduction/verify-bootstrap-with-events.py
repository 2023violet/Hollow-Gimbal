import importlib.util
import json
import pathlib
import sys

repo, simulator, output = map(pathlib.Path, sys.argv[1:])
output.mkdir()
sys.argv[1] = str(simulator)

def load_test(name):
    spec = importlib.util.spec_from_file_location(name, repo / "simulation" / "tests" / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

boot = load_test("test_virtual_bootstrap_cli")
reuse = load_test("test_virtual_calibration_reuse_cli")
with (output / "bootstrap-events.jsonl").open("w", encoding="utf-8") as log:
    run = boot.run

    def recorded(profile, *arguments, **options):
        rows = run(profile, *arguments, **options)
        log.write(json.dumps({"profile": profile, "arguments": list(map(str, arguments)),
                              "options": options, "rows": rows}) + "\n")
        log.flush()
        return rows

    boot.run = recorded
    boot.verify_source_boundary()
    for motor in boot.MOTORS:
        boot.verify_modes(motor, output)
        boot.verify_rejections(motor[0], output)
        boot.verify_history(motor[0])
    print("Both profiles: bootstrap modes, FCAL review, four-mode control, 14 rejections and measured reuse passed.")

cli = reuse.calibration_cli
reuse.calibration_cli = lambda *args: cli(*args, "--bootstrap", "unknown")
with (output / "reuse-encoder-change.jsonl").open("w", encoding="utf-8") as log:
    for motor in boot.MOTORS:
        with reuse.ReuseSession(motor[0], product_cli=True) as session:
            def command(line, *, ok=True):
                rows = session.command(line, ok=ok)
                log.write(json.dumps({"profile": motor[0], "command": line, "rows": rows}) + "\n")
                log.flush()
                return rows

            initial = command("capture")
            assert reuse.event(initial, "FLUX_CANDIDATE")["dq_frame"] == 402
            initial_review = reuse.review(initial)
            reuse.assert_closed_loop(command(f"approve {initial_review}"))
            plan = reuse.planned_parameters(command("plan encoder"))
            for parameter in ("ENCODER_LUT", "ROTOR_OFFSET", "LD_LQ", "FLUX_KT"):
                assert plan[parameter] == "REMEASURE", plan
            refreshed = command("measure")
            reuse.event(refreshed, "BOOTSTRAP_CAPTURE")
            assert reuse.event(refreshed, "FLUX_CANDIDATE")["dq_frame"] == 402
            new_review = reuse.review(refreshed)
            assert new_review != initial_review
            reuse.assert_closed_loop(command(f"approve {new_review}"))
            command("quit")
print("Both profiles: encoder change invalidates mapped quantities, recaptures and applies a new reviewed configuration.")

