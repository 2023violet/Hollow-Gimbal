"""Bounded contiguous-line screen for historical and selected upstream source."""

from difflib import SequenceMatcher
from pathlib import Path
import re, json, subprocess, sys

out = Path(sys.argv[1])
git = lambda *args: subprocess.check_output(["git", *args])
parent = "1f542521189d5e0ef25e64e6530608ece8d6e137"
parent_paths = git("ls-tree", "-r", "--name-only", "-z", parent, "--", "applications/algo",
                   "applications/motor", "applications/driver", "bsp", "subsys").decode().split("\0")
parent_files = [(path, git("show", f"{parent}:{path}")) for path in parent_paths if path.endswith((".c",".h"))]
groups = {
    "legacy_parent": parent_files,
    **{folder.name: [(path.relative_to(folder).as_posix(),path.read_bytes())
                     for path in sorted(folder.rglob("*")) if path.suffix in (".c",".cpp",".h")]
       for folder in sorted((out/"upstream-source").iterdir()) if folder.is_dir()},
}
parent_blob_names = {}
for item in git("ls-tree", "-r", "-z", parent).split(b"\0"):
    if item:
        identity, name = item.split(b"\t", 1)
        parent_blob_names.setdefault(identity.split()[-1].decode(), []).append(name.decode())

def normalized(data):
    body = data.decode("utf8", "replace")
    body = re.sub(r"/\*.*?\*/|//[^\n]*",lambda m: "\n"*m[0].count("\n"),body, flags=re.S)
    return [(i, re.sub(r"\s+","",s)) for i,s in enumerate(body.splitlines(),1)
            if s.strip() not in {"","{","}","};"}]

records = []
for path in sorted((out/"first-introduction").rglob("*")):
    if not path.is_file():
        continue
    local = path.relative_to(out/"first-introduction").as_posix()
    a = normalized(path.read_bytes())
    blob = git("hash-object",str(path)).decode().strip()
    comparisons = []
    for group, candidates in groups.items():
        longest = 0
        hits = []
        for remote, data in candidates:
            b = normalized(data)
            matcher = SequenceMatcher(None,[line for i,line in a],[line for i,line in b],autojunk=False)
            for match in matcher.get_matching_blocks():
                longest=max(longest,match.size)
                if match.size >= 3:
                    hits.append({"path":remote,"sdk_start":a[match.a][0],"sdk_end":a[match.a+match.size-1][0],
                                 "match_start":b[match.b][0],"match_end":b[match.b+match.size-1][0],
                                 "lines":match.size})
        comparisons.append({"group":group,"files":len(candidates),"max_contiguous_lines":longest,"hits":hits})
    records.append({"path":local,"first_blob_in_parent":parent_blob_names.get(blob,[]),
                    "comparisons":comparisons})
summary = {label:len(files) for label,files in groups.items()}
(out/"comparison.json").write_text(json.dumps({"groups":summary,"records":records},indent=2)+"\n",encoding="utf8")
print("Scanned",len(records),"SDK originals against",summary)
for result in records:
    print(result["path"],"exact-parent matches=",len(result["first_blob_in_parent"]),
          "max contiguous lines:",[f"{item['group']}={item['max_contiguous_lines']}"
                                   for item in result["comparisons"]])
    for group in result["comparisons"]:
        if group["hits"]:
            print("  ",group["group"],group["hits"])

