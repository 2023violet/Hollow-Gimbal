
from pathlib import Path
import subprocess as sp
import csv
from collections import defaultdict

root=Path(__file__).parent
prior=Path(r"C:/Users/16429/AppData/Local/Temp/sensorest02_de5847f09abe4fa284364f62cb5f055f")
build=root/"final/simulation-clang"
data=root/"data"
data.mkdir(exist_ok=True)
def run(name,*args):
    cmd=[build/(name+".exe"),*args]
    result=sp.run(cmd,check=True,capture_output=True)
    print(sp.list2cmdline(cmd))
    return result.stdout.decode("ascii").splitlines()

raw=run("test-foc-impedance-virtual","--trace")
(root/"holdout-full.log").write_text("\n".join(raw)+"\n",encoding="ascii")
keys={
    "TRACE":("trace.csv","record scenario elapsed_us capture_us sensor_seq ref_rad plant_rad plant_rad_s target_iq_a live_cap_a plant_iq_a plant_id_a load_nm limited torque_nm command_seq imported_command_us h0_us updates"),
    "SUMMARY":("summary.csv","record scenario samples error_rms_rad max_error_rad overshoot_rad settling_candidate_us max_speed_rad_s min_target_iq_a max_target_iq_a max_abs_plant_iq_a max_abs_plant_id_a limited_us longest_limited_us pre_max_error_rad loaded_signed_mean_error_rad final_max_error_rad final_span_rad final_plant_rad commands updates"),
    "BOUNDARY":("boundary.csv","record transition updates_before updates_after safety_state fault_bits session_before session_after"),
    "QUALITY":("quality.csv","record scenario status"),
}
records=defaultdict(list)
for row in csv.reader(raw):
    assert row[0] in keys
    records[row[0]].append(row)
for kind, (name, header) in keys.items():
    with (data/name).open("w",newline="") as file:
        writer=csv.writer(file)
        columns=header.split()
        writer.writerow(columns)
        for row in records[kind]:
            assert len(columns)==len(row),(kind,row)
            writer.writerow(row)
first=(root/"first-holdout.log").read_text(encoding="utf-8-sig").splitlines()
assert [r for r in raw if not r.startswith("TRACE,")]==first
assert len(records["TRACE"])==22000
assert [r[-1] for r in records["QUALITY"]]==["PASS"]*6
cap_detail=defaultdict(lambda:[0,0.0,0.0,0,0])
command_age=defaultdict(set)
for r in records["TRACE"]:
    _,scenario,t,capture,seq,ref,pos,speed,iq,cap,actual,id,load,limited,torque,cmd,published,h0,updates=r
    t,capture,seq,cmd,published,h0,updates=map(int,(t,capture,seq,cmd,published,h0,updates))
    assert t%500==0 and capture==1000+t and cmd==2+t//500 and seq==capture//500+1
    assert abs(float(iq))<=float(cap)
    assert h0-capture in (100,200)
    if scenario!="cascade-load":
        assert published==capture
        command_age[scenario].add(h0-published)
    if scenario=="limited":
        counter=cap_detail[cap]
        counter[0]+=1
        counter[1]=max(counter[1],abs(float(iq)))
        counter[2]=max(counter[2],abs(float(actual)))
        counter[3]+=int(limited)
        counter[4]+=abs(float(actual))>float(cap)
print("trace validated",len(records["TRACE"]),"rows and 6 frozen PASS")
for name,ages in sorted(command_age.items()):
    print("consumption age_us",name,",".join(map(str,sorted(ages))))
print("limited cap, samples, peak requested, peak plant, clipped samples, plant above cap samples")
for row in cap_detail.items():
    print(row)
old_trace=prior/"new-speed-trace.log"
after=run("test-foc-sensor-est","--trace")
assert after==old_trace.read_text(encoding="ascii").splitlines()
print("EST02 speed and control replay byte-equivalent rows",len(after))
assert run("test-foc-motor-id-virtual","--trace")== (prior/"motor-id.log").read_text(encoding="ascii").splitlines()
assert run("test-foc-motor-id-virtual","--quality")== (prior/"motor-id-quality.log").read_text(encoding="ascii").splitlines()
assert run("test-foc-periodic-chain","--encoder-linearization")== (prior/"encoder-linear.log").read_text(encoding="ascii").splitlines()
assert run("test-foc-periodic-chain","--encoder-calibration-study")== (prior/"encoder-calibration.log").read_text(encoding="ascii").splitlines()
assert run("test-foc-periodic-chain","--encoder-calibration-dataset")== (prior/"encoder-calibration-dataset.log").read_text(encoding="ascii").splitlines()
angle=data/"system-angle.csv"
run("test-foc-periodic-chain","--system-angle-csv",angle)
assert angle.read_bytes()==(prior/"system-angle-after.csv").read_bytes()
ref=sp.check_output([root/"final/sensors-clang/test-foc-sensor-reference.exe","--trace"])
assert ref==(prior/"green-test-trace.log").read_bytes()
print("SENSOR-EST-02 reference, Motor-ID 01A/01B, LUT 01A/01B and System Angle replays match preserved baseline")


