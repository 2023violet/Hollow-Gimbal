/**
 * @file    test_foc_runtime_impedance.c
 * @brief   Runtime impedance mailbox, identity, and output transaction tests.
 * @version v0.1.0
 * @date    2026.11.18
 *
 * Test role
 * ---------
 * Exercise the public Foreground, H1, H0 and lifecycle paths with fixed
 * source identities and a deterministic mock output.
 */

/* Includes --------------------------------------------------------------------- */

#include "foc_runtime.h"

#include <math.h>
#include <stdio.h>

/* Private Macros --------------------------------------------------------------- */

#define CHECK(condition)                                                    \
    do {                                                                    \
        if (!(condition)) {                                                 \
            fprintf(stderr, "%s:%d: %s\n", __FILE__, __LINE__, #condition); \
            return 1;                                                       \
        }                                                                   \
    } while (0)

/* Private Constants ------------------------------------------------------------ */

static const struct foc_pipeline_config pipeline_config = {
    .current = {{1.0f, 2.4f, 0.0f, 1.0f, 0.0003f}, {1.08f, 1.35f}, {540.0f, 540.0f}, 2.5f},
    .adc = {0.01f, 0.002f, 1.0f, 2048.0f, 2048.0f, 2048.0f, FOC_DEVICE_PHASE_ORDER_ABC},
    .pwm = {6000U, FOC_DEVICE_PHASE_ORDER_ABC},
    .safety = {1500U, 500U, 350U, 350U, 3U},
};

static const struct foc_runtime_config config = {
    .h0 = {100U, 20U, 10U},
    .h1 = {100U, 20U, 10U},
    .supervision = {100U, 20U, 10U},
    .telemetry = {10000U, 20U, 10U},
    .foreground_budget_us = 15U,
    .angle_timeout_us = 200U,
    .motion = {
        .enabled = true,
        .rotor = {4U, 0.37f},
        .prediction = {150U, 2000.0f, 0.001f},
        .velocity = {0.18f, 1.4f, 0.002f},
        .position = {4.0f, 12.0f},
        .iq_limit_a = 1.25f,
        .impedance = {
            .enabled = true,
            .mechanical_frame_id = 7U,
            .torque_constant_nm_per_a = 0.25f,
            .torque_limit_nm = 0.5f,
            .max_stiffness_nm_per_rad = 2.0f,
            .max_damping_nm_s_per_rad = 0.5f,
            .max_feedforward_nm = 0.4f,
        },
    },
};

/* Private Helpers -------------------------------------------------------------- */

static struct foc_runtime_fast_input adc(uint32_t t)
{
    return (struct foc_runtime_fast_input){
        .adc = {1200U, 2048U, 2048U, 2048U, FOC_DEVICE_SAMPLE_ALL_VALID, t / 100U, t},
        .now_us = t,
    };
}

static int sense(struct foc_runtime *runtime, uint32_t t, float p, float v, uint32_t frame)
{
    const struct foc_runtime_sensor sample = {
        .theta_elec_rad = 0.37f,
        .captured_us = t,
        .seq = t / 100U,
        .valid = true,
        .mechanical_rad = p,
        .mechanical_rad_s = v,
        .electrical_phase_valid = true,
        .mechanical_frame_id = frame,
    };
    return foc_runtime_h1_step(runtime, &sample, t, 0U);
}

static int cycle(struct foc_runtime *runtime, uint32_t t, int expected)
{
    struct foc_runtime_fast_input input = adc(t);
    struct foc_runtime_foreground_result result;
    CHECK(foc_runtime_h0_step(runtime, &input) == expected);
    CHECK(foc_runtime_foreground_poll(runtime, t, 0U, 0U, &result) >= 0);
    return 0;
}

static int request(struct foc_runtime *runtime, uint32_t t, enum foc_runtime_action action,
                   enum foc_runtime_mode mode)
{
    struct foc_runtime_snapshot snapshot;
    CHECK(foc_runtime_read_snapshot(runtime, &snapshot) == FOC_RUNTIME_OK);
    const struct foc_runtime_lifecycle_request request = {
        .action = action,
        .requested_mode = mode,
        .request_sequence = t / 100U,
        .source_session = snapshot.motion_session,
        .produced_us = t - 1U,
    };
    return foc_runtime_publish_lifecycle_request(runtime, &request, t - 1U);
}

static int test_selection(void)
{
    struct foc_runtime runtime;
    CHECK(foc_runtime_init(&runtime, &pipeline_config, &config, 0U) == FOC_RUNTIME_OK);
    CHECK(sense(&runtime, 0U, 0.0f, 0.0f, 0U) == FOC_RUNTIME_OK);
    CHECK(cycle(&runtime, 0U, FOC_RUNTIME_IDLE) == 0);
    CHECK(runtime.mode == FOC_RUNTIME_MODE_CURRENT && runtime.pipeline.mock.output_confirmed);
    CHECK(request(&runtime, 100U, FOC_RUNTIME_ACTION_SET_MODE, FOC_RUNTIME_MODE_IMPEDANCE) ==
          FOC_RUNTIME_OK);
    CHECK(sense(&runtime, 100U, 0.0f, 0.0f, 7U) == FOC_RUNTIME_OK);
    CHECK(cycle(&runtime, 100U, FOC_RUNTIME_IDLE) == 0);
    struct foc_runtime_lifecycle_result result;
    CHECK(foc_runtime_read_lifecycle_result(&runtime, &result) == FOC_RUNTIME_OK);
    CHECK(result.result == FOC_RUNTIME_REQUEST_APPLIED && result.h0_us == 100U &&
          result.request_sequence == 1U && result.applied_session == 1U &&
          result.requested_mode == FOC_RUNTIME_MODE_IMPEDANCE);
    CHECK(runtime.mode == FOC_RUNTIME_MODE_IMPEDANCE && runtime.pipeline.mock.updates == 0U);
    return 0;
}

/* Test Entry ------------------------------------------------------------------- */

int main(void)
{
    return test_selection();
}

/* ---------------------------------------- end of file ----------------------------------------- */
