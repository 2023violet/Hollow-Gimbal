# CQ-02D Host load diagnostics

The standalone driver links production Runtime, Pipeline, Core, Encoder, Device
and Safety through the standard Virtual Motor target. It reuses the frozen
legacy workload's profile, tuning, sampling, and quality oracle. The source
trees are supplied through CMake and remain untouched. The historical test
executable is also rebuilt independently.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 -FrozenRepo <frozen-source-tree> -CandidateRepo <CQ-02-source-tree> -OutputDirectory <new-output-directory>
```

Windows host dependencies are CMake 3.25 or later, Ninja, Clang, and Python 3.11
or later. The script compiles the frozen and candidate libraries separately
and runs the candidate with cutoff 0 Hz and 48 Hz via the formal Runtime
configuration. It checks that both 0 Hz traces match byte-for-byte before
calculating the summaries. The duplicate disabled CSVs can be reproduced using
the command above and are represented by their verified hashes in the summary.

H0 timestamps are absolute. H1 relative timestamps are measured from 2,000 µs.
The loaded tail in each completed case is the last 100 ms before unloading. The
early STOP and fault cases instead use the last 100 ms before the injected
action. H0 mechanical values are the integrated Plant observations at the cycle
boundary. Voltage and PI values are the accepted outputs at that boundary for
the subsequent Plant step. Positive and negative comparisons sign-normalize
reported loaded-tail values, while the traces preserve signs.

The default load dwell is 700 ms with onset at 800 ms and release at 1,500 ms
relative to the original epoch. The static near-limit witness extends the dwell
to 4.2 s. The original historical 0.039 N·m workload and 250 ms saturation
threshold retain their failed verdict. The 98%-capacity workload also exceeds
the saturation threshold during the transient in both controller versions.
The extended run shows that the near-limit load reaches the passive spring
equilibrium under the current ceiling. The direct shunt/electrical/shaft data
here are synthetic Virtual Motor observations. Physical calibration and bridge
behavior require bench evidence.
