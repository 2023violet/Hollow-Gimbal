from pathlib import Path
import csv,subprocess as sp,sys
from collections import defaultdict
from zipfile import ZipFile

root=Path(__file__).parent
build=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/"final-complete/simulation-clang"
data=root/"data"
data.mkdir(exist_ok=True)
def run(label,target,*args):
    cmd=[build/(target+".exe"),*args]
    print(sp.list2cmdline(cmd),flush=True)
    raw=sp.check_output(cmd)
    (root/f"{label}.log").write_bytes(raw)
    groups=defaultdict(list)
    for row in csv.reader(raw.decode("ascii").splitlines()):
        groups[row[0]].append(row)
    return groups
def compare(z, records, mapping):
    for record, name in mapping.items():
        entries=list(csv.reader(z.read("data/"+name+".csv").decode().splitlines()))
        assert entries[1:]==records[record],(name,len(entries)-1,len(records[record]))
        print("Exact",name,len(records[record]),flush=True)
def emit(heading,records,headers):
    for label,rows in records.items():
        assert label in headers,label
        fields=headers[label].split()
        with (data/f"{heading}-{label.lower()}.csv").open("w",newline="") as f:
            out=csv.writer(f)
            out.writerow(fields)
            for row in rows:
                assert len(row)==len(fields),(label,len(row),len(fields))
                out.writerow(row)
def archive(suffix):
    return ZipFile(f"docs/evidence/2026-11-18-next-servo-{suffix}/raw-evidence.zip")
rt="test-foc-runtime-impedance-virtual"
study="test-foc-impedance-robustness"
id_test="test-foc-mechanical-id-virtual"
static=run("static-hold",rt,"--static-hold","--trace")
emit("static-hold",static,{
 "STATIC":"record scenario verdict cap_a model_host_load_nm feedforward_nm tolerance_rad capacity_nm signed_margin_nm has_equilibrium at_torque_limit position_constrained nearest_equilibrium_error_rad loaded_mean_error_rad loaded_mean_plant_speed_rad_s loaded_mean_plant_iq_a total_at_cap_us longest_at_cap_us unload_recover_us unloaded_tail_max_abs_error_rad updates_before_stop updates_after_stop old_session new_session",
 "STATIC_TRACE":"record scenario elapsed_us captured_us h0_consumed_us command_seq reference_rad plant_position_rad position_error_rad plant_speed_rad_s plant_iq_a iq_request_a feedforward_torque_nm at_iq_cap updates session",
})
assert len(static["STATIC"])==8 and len(static["STATIC_TRACE"])==48000
with archive("01a") as z:
    replay=run("01a-replay","test-foc-impedance-virtual","--trace")
    compare(z,replay,{kind:kind.lower() for kind in ("TRACE","SUMMARY","QUALITY","BOUNDARY")})
with archive("01b") as z:
    replay=run("01b-replay",rt,"--trace")
    compare(z,replay,{kind:kind.lower() for kind in ("TRACE","SUMMARY","QUALITY","BOUNDARY","RECOVERY")})
with archive("01c") as z:
    for mode, args in [("training",["--train","--trace"]),("holdout",["--trace"])]:
        replay=run("01c-"+mode,study,*args)
        compare(z,replay,{kind:f"{mode}-{kind.lower()}" for kind in replay})
        if mode=="holdout":
            for kind in ("QUALITY","GATE","RESULT"):
                (data/f"01c-{kind.lower()}.csv").write_bytes(z.read(f"data/holdout-{kind.lower()}.csv"))
with archive("02a") as z:
    models=list(csv.DictReader(z.read("frozen-models.csv").decode().splitlines()))
    def coefficients(*rows):
        return [row[name] for row in rows for name in ("J_kg_m2","B_nm_s_per_rad")]
    compare(z,run("02a-id-replay",id_test,"--trace"),{
        "OBS":"identification-obs","FIT":"identification-fit","REFUSAL":"identification-refusal",
        "COUNTERFACTUAL":"identification-counterfactual","ACQUISITION":"identification-acquisition"})
    compare(z,run("02a-prediction-replay",id_test,"--predict",*coefficients(*models),"--trace"),{
        "PREDICT":"prediction-predict","OBS":"prediction-obs"})
    compare(z,run("02a-loop-replay",study,"--mechanical-id-fit",*coefficients(models[0],models[3]),"--trace"),{
        kind:f"comparison-{kind.lower()}" for kind in ("TRACE","DESIGN","RESULT","QUALITY","STOP","GATE")})
with archive("02b") as z:
    for name in ("static-hold-static","static-hold-static_trace"):
        assert (data/(name+".csv")).read_bytes()==z.read("data/"+name+".csv"),name
        print("Exact 02B",name,flush=True)
print("Historical replay complete.")
