/* Independent Host diagnostic. Reuse the frozen workload helpers and Oracle. */
#define _CRT_SECURE_NO_WARNINGS
#define main cq01_original_main
#include "test_foc_impedance_robustness.c"
#undef main

struct load_case {
    const char *name;
    double torque_nm;
    int direction;
    bool expect_legacy_pass;
    bool fault;
    bool stop_loaded;
    uint32_t alternate_load_duration_us;
};

static FILE *h0_csv;
static FILE *h1_csv;

static int advance_h0(struct foc_virtual_current *vm, const char *name, uint32_t to,
                      uint32_t session, bool running)
{
    while (vm->next_h0_us <= to) {
        const uint32_t h0_us = vm->next_h0_us;
        const uint32_t prior_updates = vm->output.accepted_updates;
        const struct foc_vector_dq prior_integral = vm->runtime.pipeline.current.integral_v;
        CHECK(foc_virtual_current_run_until(vm, h0_us) == 0);
        const struct foc_pipeline *pipe = &vm->runtime.pipeline;
        const struct foc_device_pwm_request *pwm = &vm->output.request;
        const struct foc_vector_dq integral = pipe->current.integral_v;
        const double v = hypot(vm->output.v_alpha_v, vm->output.v_beta_v);
        struct foc_virtual_motor_observation plant;
        CHECK(foc_virtual_motor_observe(&vm->motor, &plant) == 0);
        struct foc_device_adc_raw adc;
        CHECK(foc_virtual_current_acquire_adc(&vm->profile, &vm->motor, vm->sample_seq, h0_us, &adc)
              == 0);
        const double vbus = (float)adc.vbus_raw * pipe->adc_config.vbus_v_per_count;
        const double vlimit = fmin(pipe->current.config.pwm.voltage_limit_v, vbus / sqrt(3.0));
        CHECK(pipe->mock.output_confirmed && pipe->mock.updates == vm->output.accepted_updates &&
              vm->output.rejected_updates == 0U && vm->output.registers.bridge_gate_closed == 1U &&
              vm->output.registers.bridge_enabled == 0U && isfinite(integral.d) &&
              isfinite(integral.q));
        if (running) {
            CHECK(pipe->safety.state == FOC_SAFE_STATE_RUNNING && vm->runtime.motion_session == session &&
                  pipe->safety.latched_faults == 0U && vm->output.accepted_updates == prior_updates + 1U);
            CHECK(pipe->last_reason == FOC_PIPELINE_OK && pwm->action == FOC_DEVICE_OUTPUT_UPDATE &&
                  pwm->output_enable_request != 0U && pipe->sample.produced_us == h0_us &&
                  pwm->duty_a >= 0.0f && pwm->duty_a <= 1.0f &&
                  pwm->duty_b >= 0.0f && pwm->duty_b <= 1.0f &&
                  pwm->duty_c >= 0.0f && pwm->duty_c <= 1.0f &&
                  vm->output.registers.channel1_compare <= pipe->pwm_config.period_counts &&
                  vm->output.registers.channel2_compare <= pipe->pwm_config.period_counts &&
                  vm->output.registers.channel3_compare <= pipe->pwm_config.period_counts &&
                  fabsf(pipe->target_a.q) <= vm->runtime.config.motion.iq_limit_a &&
                  pipe->target_a.d == 0.0f &&
                  v <= vlimit + 1e-5 && hypot(integral.d, integral.q) <= vlimit + 1e-5);
        } else {
            CHECK(vm->output.accepted_updates == prior_updates &&
                  pwm->action == FOC_DEVICE_OUTPUT_INHIBIT && pwm->output_enable_request == 0U &&
                  vm->output.mode == FOC_VIRTUAL_OUTPUT_HIGH_Z &&
                  integral.d == prior_integral.d && integral.q == prior_integral.q);
        }
        const struct foc_virtual_motor_params *motor = &vm->motor.params;
        const double omega_e = motor->pole_pairs * plant.mechanical_velocity_rad_s;
        const double back_emf = omega_e * (motor->psi_f_wb + motor->ld_h * plant.id_a);
        const double drag = motor->damping_nm_s * plant.mechanical_velocity_rad_s;
        const double net = plant.electromagnetic_torque_nm - drag - plant.applied_load_torque_nm;
        fprintf(h0_csv, "%s,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,", name, h0_us,
                vm->runtime.motion_session, (unsigned)pipe->safety.state, pipe->safety.latched_faults,
                (unsigned)pwm->action, (unsigned)pwm->output_enable_request, vm->output.accepted_updates,
                vm->output.rejected_updates, vm->output.saturated_updates,
                pipe->sample.produced_us, vm->runtime.angle_prediction_us);
        fprintf(h0_csv, "%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.12g,%.12g,%.12g,%.12g,",
                pwm->duty_a, pwm->duty_b, pwm->duty_c, integral.d, integral.q, pipe->target_a.q,
                pipe->measured_dq_a.d, pipe->measured_dq_a.q, plant.id_a, plant.iq_a,
                plant.mechanical_position_rad, plant.mechanical_velocity_rad_s);
        fprintf(h0_csv, "%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%d\n",
                plant.applied_load_torque_nm, plant.electromagnetic_torque_nm, drag, net, back_emf,
                vbus, vlimit, v, vm->output.v_alpha_v, vm->output.v_beta_v, pipe->last_reason);
    }
    CHECK(foc_virtual_current_run_until(vm, to) == 0);
    return 0;
}

static int run_probe(const struct load_case *scenario, float damping_hz)
{
    const uint32_t load_on_us = 800000U;
    const uint32_t load_off_us = load_on_us + (scenario->alternate_load_duration_us != 0U
                                                  ? scenario->alternate_load_duration_us
                                                  : 700000U);
    const uint32_t end_us = load_off_us + 1100000U;
    const uint32_t interrupted_us = 1400000U;
    const bool interrupt = scenario->stop_loaded || scenario->fault;
    const struct study_case legacy = {
        scenario->name, 1.30, NOMINAL, QUANTIZED, LOAD, scenario->direction * 0.30f,
        0.25f, 0U, 0U, 0U, 0U, false,
    };
    struct foc_virtual_current_profile profile = foc_virtual_current_default_profile();
    profile.motor.inertia_kg_m2 *= legacy.inertia_scale;
    profile.current.current_limit_a = legacy.cap_a;
    profile.runtime.motion.iq_limit_a = legacy.cap_a;
    profile.runtime.motion.prediction.max_prediction_us = 600U;
    profile.runtime.motion.impedance = (struct foc_runtime_impedance_config){
        .enabled = true,
        .mechanical_frame_id = frame_id,
        .torque_constant_nm_per_a = (float)(1.5 * profile.motor.pole_pairs * profile.motor.psi_f_wb),
        .torque_limit_nm = 0.315f,
        .max_stiffness_nm_per_rad = 3.0f,
        .max_damping_nm_s_per_rad = 0.3f,
#ifdef CQ02_FILTER_CONFIG
        .damping_filter_hz = damping_hz,
#endif
    };
    struct foc_impedance_config gains;
    struct foc_impedance_tuning_candidate design;
    double j_est, b_est;
    CHECK(design_candidate(&legacy, NULL, &profile, &gains, &design, &j_est, &b_est) == 0);
    struct foc_virtual_current vm;
    CHECK(start_case(&vm, &profile, &gains, legacy.sensor) == 0);
    const struct foc_runtime_motion_config *live = &vm.runtime.config.motion;
    const struct foc_current_config *current = &vm.runtime.pipeline.current.config;
    CHECK(current->current_limit_a == legacy.cap_a && live->iq_limit_a == legacy.cap_a &&
          live->impedance.torque_constant_nm_per_a == gains.torque_constant_nm_per_a &&
          live->impedance.torque_limit_nm == gains.torque_limit_nm &&
          !live->limits.enabled && !live->cogging.enabled && vm.motor.cogging_amplitude_nm == 0.0);
    printf("CONFIG,%s,%.9g,%d,%u,%u,%u,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%u,"
           "%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%u,%u,%u,%u,%u,%u,%u,%.9g,%.9g\n",
           scenario->name, scenario->torque_nm, scenario->direction, load_on_us, load_off_us, end_us,
           damping_hz,
           gains.stiffness_nm_per_rad, gains.damping_nm_s_per_rad,
           live->impedance.torque_constant_nm_per_a, current->current_limit_a, live->iq_limit_a,
           live->impedance.torque_limit_nm, current->pwm.voltage_limit_v, current->pwm.vbus_min_v,
           profile.motor.pole_pairs, profile.motor.psi_f_wb, profile.motor.rs_ohm, profile.motor.ld_h,
           profile.motor.lq_h, profile.motor.damping_nm_s, profile.motor.inertia_kg_m2, profile.vbus_v,
           vm.runtime.config.h0.period_us, vm.runtime.config.h1.period_us,
           vm.runtime.pipeline.safety.config.command_timeout_us,
           vm.runtime.pipeline.safety.config.sample_timeout_us,
           vm.runtime.pipeline.safety.config.fast_heartbeat_timeout_us,
           vm.runtime.pipeline.safety.config.foreground_heartbeat_timeout_us,
           vm.runtime.pipeline.safety.config.invalid_sample_latch_after,
           live->impedance.max_stiffness_nm_per_rad, live->impedance.max_damping_nm_s_per_rad);
    const uint32_t session = vm.runtime.motion_session;
    const uint32_t base_updates = vm.output.accepted_updates;
    struct metrics m = {.tail_min_error = INFINITY, .tail_max_error = -INFINITY};
    uint32_t random = 0U, limit_run = 0U;
    double q_lp = 0.0, actual_lp = 0.0;
    for (uint32_t t = 0U; t < (interrupt ? interrupted_us : end_us); t += period_us) {
        const uint32_t deadline = epoch_us + t;
        CHECK(advance_h0(&vm, scenario->name, deadline - 1U, session, true) == 0);
        struct foc_runtime_sensor sample;
        uint16_t raw = 0U;
        CHECK(take_sample(&vm, legacy.sensor, &random, &sample, &raw, NULL) == 0);
        CHECK(publish(&vm, &gains, legacy.target_rad, 0.0f, 0.0f) == FOC_RUNTIME_OK);
        CHECK(foc_runtime_h1_step(&vm.runtime, &sample, deadline, 0U) == FOC_RUNTIME_OK);
        const struct foc_runtime_sensor_slot *slot =
            &vm.runtime.sensor_slots[atomic_load(&vm.runtime.sensor_slot)];
        CHECK(slot->target_valid && slot->mode == FOC_RUNTIME_MODE_IMPEDANCE &&
              slot->session == session && slot->sample.seq == sample.seq &&
              slot->sample.captured_us == deadline - 1U && slot->target.seq == vm.command_seq &&
              slot->target.produced_us == deadline - 1U && slot->target.target_a.d == 0.0f &&
              fabsf(slot->target.target_a.q) <= legacy.cap_a);
        CHECK(advance_h0(&vm, scenario->name, deadline, session, true) == 0);
        CHECK(vm.output.accepted_updates == base_updates + (deadline - 1600U) / 200U + 1U);
        if (t == load_on_us || t == load_off_us) {
            const double load = t == load_on_us ? scenario->direction * scenario->torque_nm : 0.0;
            CHECK(foc_virtual_motor_set_load(&vm.motor, load) == 0);
        }

        float damping_feedback = sample.mechanical_rad_s;
#ifdef CQ02_FILTER_CONFIG
        if (damping_hz > 0.0f) {
            CHECK(vm.runtime.damping_filter_seen);
            damping_feedback = -vm.runtime.damping_speed_error_rad_s;
        }
#endif
        const struct foc_impedance_input input = {
            .position_error_rad = legacy.target_rad - sample.mechanical_rad,
            .measured_velocity_rad_s = damping_feedback,
            .live_iq_limit_a = legacy.cap_a,
        };
        struct foc_impedance_output torque;
        CHECK(foc_impedance_step(&gains, &input, &torque) == FOC_STATUS_OK && torque.valid);
        CHECK(torque.iq_ref_a == slot->target.target_a.q);
        /* Canonicalize the sign for the historical positive-direction overshoot Oracle. */
        struct foc_virtual_motor_state normalized = vm.motor.state;
        normalized.mechanical_position_rad *= scenario->direction;
        normalized.mechanical_velocity_rad_s *= scenario->direction;
        normalized.iq_a *= scenario->direction;
        record(&m, &legacy, &normalized, &sample, &torque, legacy.target_rad * scenario->direction,
               0.0f, gains.damping_nm_s_per_rad, t, end_us, load_on_us, load_off_us, UINT32_MAX,
               &limit_run, &q_lp, &actual_lp);
        struct foc_virtual_motor_observation obs;
        CHECK(foc_virtual_motor_observe(&vm.motor, &obs) == 0);
        fprintf(h1_csv, "%s,%u,%u,%u,%u,%u,%u,%.9g,%.9g,%.9g,%.9g,%.12g,%.12g,%.12g,%.12g,"
                "%.12g,%.12g,%.9g,%.9g,%.9g\n",
                scenario->name, t, sample.captured_us, deadline, vm.command_seq, slot->sample.seq,
                (unsigned)torque.limited, legacy.target_rad, sample.mechanical_rad,
                sample.mechanical_rad_s, damping_feedback, obs.mechanical_position_rad,
                obs.mechanical_velocity_rad_s, obs.id_a, obs.iq_a, obs.applied_load_torque_nm,
                obs.electromagnetic_torque_nm, torque.requested_torque_nm,
                torque.limited_torque_nm, slot->target.target_a.q);
    }
    if (!interrupt) {
        const unsigned fail = quality_mask(&m, LOAD);
        printf("QUALITY,%s,%u,%u,%u,%.10g,%.10g,%.10g,%.10g,%.10g,%.10g,%u\n",
               scenario->name, fail, m.longest_limit_us, m.recover_us, m.tail_peak_error,
               m.loaded_error_sum / m.load_samples, m.peak_error, m.peak_over,
               sqrt(m.tail_qhp2 / m.noise_samples), sqrt(m.tail_actual_qhp2 / m.noise_samples),
               m.samples);
        CHECK(m.samples == end_us / period_us && m.recover_us <= 650000U &&
              m.tail_peak_error <= 0.008);
        if (scenario->expect_legacy_pass) {
            CHECK(fail == 0U);
        } else if (scenario->torque_nm == 0.039) {
            CHECK(fail == 16U && (damping_hz != 0.0f || scenario->direction != 1 ||
                                m.longest_limit_us == 762500U));
        }
    } else {
        CHECK(fabsf(vm.runtime.pipeline.target_a.q) == legacy.cap_a);
    }
    const uint32_t accepted = vm.output.accepted_updates;
    if (scenario->fault) {
        foc_runtime_request_inhibit(&vm.runtime, FOC_SAFE_FAULT_INVALID_STATE);
    } else {
        CHECK(foc_virtual_current_request_stop(&vm) == FOC_RUNTIME_OK);
    }
    CHECK(advance_h0(&vm, scenario->name, vm.virtual_time_us + 800U, session, false) == 0 &&
          vm.runtime.motion_session != session && !vm.runtime.accepted_outer_seen);
    const enum foc_safe_state state = vm.runtime.pipeline.safety.state;
    const uint32_t faults = vm.runtime.pipeline.safety.latched_faults;
    CHECK(state == (scenario->fault ? FOC_SAFE_STATE_FAULT_LATCHED : FOC_SAFE_STATE_DISABLED) &&
          faults == (scenario->fault ? FOC_SAFE_FAULT_INVALID_STATE : 0U));
    printf("TERMINATION,%s,%u,%u,%u,%u,%u,%u,%u,%.9g,%.9g,%u\n",
           scenario->name, vm.virtual_time_us, (unsigned)state, faults, accepted, vm.output.accepted_updates,
           session, vm.runtime.motion_session, vm.runtime.pipeline.current.integral_v.d,
           vm.runtime.pipeline.current.integral_v.q, vm.output.rejected_updates);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 4 || (strcmp(argv[1], "0") != 0 && strcmp(argv[1], "48") != 0)) {
        return 2;
    }
    const float damping_hz = strtof(argv[1], NULL);
#ifndef CQ02_FILTER_CONFIG
    if (damping_hz != 0.0f) {
        return 2;
    }
#endif
    h0_csv = fopen(argv[2], "w");
    h1_csv = fopen(argv[3], "w");
    CHECK(h0_csv != NULL && h1_csv != NULL);
    fputs("case,h0_us,session,state,faults,action,enable_request,updates,rejected,saturated_updates,"
          "adc_us,angle_age_us,duty_a,duty_b,duty_c,integral_d_v,integral_q_v,iq_h0_a,"
          "id_measured_a,iq_measured_a,id_plant_a,iq_plant_a,position_rad,velocity_rad_s,"
          "load_nm,electromagnetic_nm,viscous_nm,residual_nm,back_emf_v,vbus_v,vlimit_v,"
          "accepted_voltage_v,accepted_alpha_v,accepted_beta_v,reason\n", h0_csv);
    fputs("case,relative_us,capture_us,h1_us,command_seq,encoder_seq,limited,reference_rad,"
          "position_measured_rad,velocity_measured_rad_s,damping_feedback_rad_s,position_plant_rad,"
          "velocity_plant_rad_s,id_plant_a,iq_plant_a,load_nm,actual_torque_nm,requested_torque_nm,"
          "capped_torque_nm,iq_request_a\n", h1_csv);
    const struct load_case scenarios[] = {
        {"feasible-positive", 0.030, 1, true, false, false, 0U},
        {"feasible-negative", 0.030, -1, true, false, false, 0U},
        {"near-positive", 0.03675, 1, false, false, false, 0U},
        {"near-negative", 0.03675, -1, false, false, false, 0U},
        {"near-positive-extended", 0.03675, 1, false, false, false, 4200000U},
        {"hold-load-beyond-025", 0.039, 1, false, false, false, 0U},
        {"mirror-load-beyond-025", 0.039, -1, false, false, false, 0U},
        {"overload-stop", 0.039, 1, false, false, true, 0U},
        {"overload-fault", 0.039, -1, false, true, false, 0U},
    };
    for (size_t i = 0; i < sizeof scenarios / sizeof *scenarios; ++i) {
        CHECK(run_probe(&scenarios[i], damping_hz) == 0);
    }
    CHECK(fclose(h0_csv) == 0 && fclose(h1_csv) == 0);
    return 0;
}
