/**
 * @file    foc_board_capture_boot_fixture.c
 * @brief   Host fixture: a formally selected Board1 boot written by the production SRAM recorder.
 * @version v0.1.0
 * @date    2026.11.21
 *
 * Test role
 * ---------
 * Select the startup configuration with the production foc_board_boot_select()
 * (no supply for "nominal", the synthetic verification supply for
 * "calibrated"), derive the Capture Profile from the effective Runtime/Encoder
 * through foc_board_boot_capture_profile(), and seal a complete image with the
 * production writer. Observation rows are synthetic Host data, producer HOST.
 *
 * Usage: foc-board-capture-boot-fixture <nominal|calibrated> <image.bin> [capture-id]
 */

/* Includes --------------------------------------------------------------------- */

#include "foc_board_boot.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Private Variables ------------------------------------------------------------ */

static struct foc_runtime runtime;
static struct foc_board_output output;
static struct foc_board_encoder encoder;
static struct foc_board_boot boot;
static struct foc_board_capture recorder;

/* Private Helpers -------------------------------------------------------------- */

static int fail(const char *message)
{
    fprintf(stderr, "fixture: %s\n", message);
    return 1;
}

static void fill_rows(uint32_t start)
{
    for (uint32_t i = 0U; i < 40U; ++i) {
        const uint32_t completion = start + 55U + 200U * i;
        struct foc_capture_adc *row = foc_board_capture_adc(&recorder, completion);
        row->slot = i + 100U;
        row->token_slot = row->slot;
        row->slot_start_us = completion - 55U;
        row->generation = i + 80U;
        row->requested_us = completion - 8U;
        row->ranks12 = 1241U | (2032U << 16);
        row->ranks34 = 2063U | (2018U << 16);
        row->flags = FOC_CAPTURE_ADC_SLOT | FOC_CAPTURE_ADC_TOKEN | FOC_CAPTURE_ADC_VALID |
            FOC_CAPTURE_ADC_H0 | FOC_CAPTURE_ADC_CLEAR | FOC_CAPTURE_ADC_CONSUMED;
        row->h0_us = completion;
        row->h0_return_us = completion + 3U;
        row->safety = FOC_CAPTURE_OUTPUT_LOCKED | FOC_CAPTURE_OUTPUT_CONFIRMED;
    }
    for (uint32_t i = 0U; i < 16U; ++i) {
        const uint32_t completion = start + 70U + 500U * i;
        struct foc_capture_encoder *row = foc_board_capture_encoder(&recorder, completion);
        row->encoder_sequence = 200U + i;
        row->cs_us = completion - 70U;
        row->rx_us = completion - 45U;
        row->h1_return_us = completion + 3U;
        row->raw_word = i + 16384U;
        row->flags = FOC_CAPTURE_ENCODER_CS | FOC_CAPTURE_ENCODER_RAW |
            FOC_CAPTURE_ENCODER_POSITION | FOC_CAPTURE_ENCODER_SPEED | FOC_CAPTURE_ENCODER_H1;
    }
}

/* Test Entry ------------------------------------------------------------------- */

int main(int argc, char *argv[])
{
    if (argc < 3 || argc > 4) {
        return fail("usage: <nominal|calibrated> <image.bin> [capture-id]");
    }
    const bool calibrated = strcmp(argv[1], "calibrated") == 0;
    if (!calibrated && strcmp(argv[1], "nominal") != 0) {
        return fail("mode must be nominal or calibrated");
    }
    const struct foc_board_calibration_expectation expected = foc_board_calibration_expectation();
    if (foc_board_boot_select(
            &boot,
            &runtime,
            &output,
            &encoder,
            calibrated ? foc_board_calibration_supply() : NULL,
            calibrated ? &expected : NULL,
            0U
        ) != FOC_RUNTIME_OK) {
        return fail("boot selection failed");
    }
    if (boot.configuration !=
        (calibrated ? FOC_BOARD_CALIBRATED_CONFIGURATION : FOC_BOARD_NOMINAL_CONFIGURATION)) {
        return fail("unexpected effective configuration");
    }
    struct foc_capture_profile profile;
    if (!foc_board_boot_capture_profile(&boot, 0U, &profile)) {
        return fail("no capture profile");
    }
    const uint32_t id = argc == 4 ? (uint32_t)strtoul(argv[3], NULL, 0) : (calibrated ? 34U : 33U);
    const uint32_t start = UINT32_MAX - 4000U;
    if (!foc_board_capture_start(&recorder, id, FOC_CAPTURE_HOST, start, &profile)) {
        return fail("recorder did not start");
    }
    fill_rows(start);
    for (unsigned int n = 0U; n < 100U; ++n) {
        foc_board_capture_poll(&recorder, start + FOC_CAPTURE_WINDOW_US, 0U);
    }
    if (atomic_load(&recorder.state) != FOC_CAPTURE_READY) {
        return fail("recorder not sealed");
    }
    FILE *file = fopen(argv[2], "wb");
    if (file == NULL || fwrite(&recorder.image, sizeof recorder.image, 1U, file) != 1U ||
        fclose(file) != 0) {
        return fail("cannot write image");
    }
    printf(
        "%s capture %lu: cpr %lu direction %ld pole pairs %lu phase order %lu crc 0x%08lx\n",
        argv[1],
        (unsigned long)id,
        (unsigned long)recorder.image.header.encoder_cpr,
        (long)recorder.image.header.encoder_direction,
        (unsigned long)recorder.image.header.pole_pairs,
        (unsigned long)recorder.image.header.phase_order,
        (unsigned long)recorder.image.header.crc32
    );
    return 0;
}

/* ---------------------------------------- end of file ----------------------------------------- */
