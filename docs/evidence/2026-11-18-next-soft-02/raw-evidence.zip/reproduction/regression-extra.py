from pathlib import Path
import hashlib, os, subprocess as sp, shutil
from concurrent.futures import ThreadPoolExecutor
t=Path(__file__).resolve().parent
src=Path.cwd()
logs=t/"verify-complete"
env=os.environ.copy()
env["PATH"]=os.pathsep.join([r"C:\mingw64\bin",
    str(Path(sp.check_output(["clang","-print-resource-dir"],text=True).strip())/"lib/windows"),env["PATH"]])
env.update(PYTHONDONTWRITEBYTECODE="1",ASAN_OPTIONS="halt_on_error=1",
           UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
def log(label, cmds, cwd=src, extra=None):
    with (logs/(label+".log")).open("w",encoding="utf8") as f:
        for cmd in cmds:
            print("$ "+sp.list2cmdline(list(map(str,cmd))),file=f,flush=True)
            status=sp.run(cmd,cwd=cwd,env=env| (extra or {}),stdout=f,stderr=sp.STDOUT).returncode
            if status:
                break
    print(label,status,flush=True)
    return status
def extra_task(project, label, variant, target=None, selection=None):
    label+=f"-{variant}"
    out=t/"final-complete"/label
    compiler="C:/mingw64/bin/gcc.exe" if variant=="gcc" else "clang"
    flags=["-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
           "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined"] if variant=="asan" else []
    return log(label,[["cmake","-S",project,"-B",out,"-G","Ninja","-DCMAKE_BUILD_TYPE=Debug",
                       "-DCMAKE_C_COMPILER="+compiler,*flags],
                      ["cmake","--build",out,"--parallel","4",*(["--target",target] if target else [])],
                      ["ctest","--test-dir",out,"--no-tests=error","--output-on-failure",
                       *(["-R",selection] if selection else [])]])
def cli():
    cwd=t/"legacy-source"
    (cwd/"build/vm01a-simulation").mkdir(parents=True,exist_ok=True)
    old=t.parent/"soft01-regression-bclpxd47"/"probe-v1.py"
    probe=t/"probe-v1.py"
    p=old.read_text().replace('root / "source"', 'root / "legacy-source"')
    p=p.replace('root / "builds" / "board-host-clang"', 'root / "board-host"')
    p=p.replace('("param-read", foc.parameter_read(0x1001), "INVALID_ARGUMENT"),',
                '''("param-read", foc.parameter_read(0x1001), "INVALID_ARGUMENT"),
        ("param-read", foc.parameter_read(0x100B), "INVALID_ARGUMENT"),
        ("param-read", foc.parameter_read(0x3011), "INVALID_ARGUMENT"),''')
    probe.write_text(p,encoding="utf8")
    return log("uart-v1-and-cli",[["python",probe],["python","-m","unittest","discover","-s",
        "tools/falconfoc-cli","-p","test_falconfoc_cli.py","-v"]],cwd,{"FOC_SERIAL_SIM":str(t/"board-host/foc-serial-sim.exe"),
        "FOC_VIRTUAL_DEVICE":str(t/"final-complete/simulation-clang/falconfoc-virtual-device.exe")})
def formatting():
    cfg=t/"cmake-format.py"
    shutil.copyfile(src/".cmake-format",cfg)
    cmakepaths=["core/CMakeLists.txt","runtime/CMakeLists.txt","firmware/at32f415/CMakeLists.txt",
                "control_plane/CMakeLists.txt","examples/motion-protection/CMakeLists.txt"]
    paths=["core/include/foc_following_error.h","core/include/foc_motion_limits.h","core/src/foc_following_error.c",
           "core/src/foc_motion_limits.c","core/tests/test_foc_motion_protection.c","runtime/include/foc_runtime.h",
           "runtime/src/foc_runtime.c","runtime/tests/test_foc_runtime_protection.c","control_plane/include/foc_parameter.h",
           "control_plane/src/foc_parameter.c","control_plane/tests/test_foc_parameter.c","simulation/include/foc_virtual_current.h",
           "simulation/src/foc_virtual_current.c","examples/motion-protection/main.c"]
    return log("formatting",[["clang-format","--dry-run","--Werror",*paths],
        ["python","-m","cmakelang.format","--check","-c",cfg,"--",*cmakepaths]])
with ThreadPoolExecutor(max_workers=4) as pool:
    futures=[]
    for v in ("gcc","asan"):
        futures += [pool.submit(extra_task,"firmware/at32f415","board-host",v),
                    pool.submit(extra_task,"examples/servo","servo-demo",v,"falconfoc-servo-demo","^test-falconfoc-servo-(demo|faults)$")]
    futures += [pool.submit(cli),pool.submit(formatting)]
    results=[f.result() for f in futures]
raise SystemExit(int(any(results)))
