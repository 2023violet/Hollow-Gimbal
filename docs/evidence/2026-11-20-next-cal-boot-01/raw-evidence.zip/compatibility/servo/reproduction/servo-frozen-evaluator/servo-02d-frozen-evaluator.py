
"""Apply the frozen SERVO-02D Holdout gates."""
import csv
import json
from math import isfinite, sqrt
from pathlib import Path
from sys import argv

root = Path(argv[1])


def records(filename, name):
    with filename.open(encoding="ascii", newline="") as stream:
        yield from csv.DictReader(line for line in stream if line.startswith(name + ","))


held = root / "holdout-replay.csv"
early = root / "characterization-replay.csv"
pairs = {(row["case"], row["variant"]): row for row in records(held, "JOINT_RESULT")}
assert len(pairs) == 24
gates = list(records(held, "JOINT_GATE"))
assert len(gates) == 4
boundaries = list(records(held, "JOINT_BOUNDARY"))
assert len(boundaries) == 3
trials = list(records(held, "JOINT_TRIAL"))
modes = list(records(held, "JOINT_MODE"))
assert len(trials) == len(modes) == 1 and trials[0]["source_dt_us"] == "625"
assert modes[0]["prior_session"] != modes[0]["new_session"] and modes[0]["mode"] == "0"

report = {
    "cases": {},
    "gates": gates,
    "boundaries": boundaries,
    "unacknowledged_trial_replacement": trials,
    "disabled_mode_change": modes,
    "noise_failures": [],
    "dynamic_failures": [],
    "saturation_failures": [],
}

for (case, arm), row in pairs.items():
    if arm != "D":
        continue
    baseline = pairs[case, "C"]
    f = lambda key: float(row[key])
    c = lambda key: float(baseline[key])
    case_report = report["cases"][case] = {
        "numbers_and_identity": {arm: pairs[case, arm] for arm in "ABCD"},
        "noise_failures": [],
        "dynamic_failures": [],
        "saturation_failures": [],
    }

    def check(metric, group, bound):
        actual = f(metric)
        if actual > bound:
            failure = dict(case=case, metric=metric, observed=actual, limit=bound)
            report[group].append(failure)
            case_report[group].append(failure)

    noise_cap = 0.035
    if int(row["seed"]) != 0:
        noise_cap = min(noise_cap, 0.70 * c("tail_request_hp_a"))
    check("tail_request_hp_a", "noise_failures", noise_cap)
    check("tail_model_hp_a", "noise_failures", 0.035)
    case_report["physical"] = "ACTUATOR_LIMITED" if f("limited_us") > 0 else "ACTUATOR_UNLIMITED"
    if case == "hold-joint-lowcap":
        assert f("over_budget_us") > 0 and f("limited_us") > 0
        case_report["reference"] = "REFERENCE_INFEASIBLE"
        case_report["reverse_above_ordinary_absolute_cap"] = f("reversal_rms_rad_s") > 0.25
        check("peak_request_a", "saturation_failures", f("iq_limit_a"))
        check("tail_limited_frames", "saturation_failures", 0)
        check("peak_limit_run_us", "saturation_failures", min(250_000, c("peak_limit_run_us") + 25_000))
        check("settle_us", "saturation_failures", min(650_000, c("settle_us") + 25_000))
        continue
    assert f("over_budget_us") == 0 and f("limited_us") == 0
    for phase in ("forward_accel", "forward_decel", "reverse_accel", "reverse_decel", "reversal", "crawl"):
        metric = f"{phase}_rms_rad_s"
        absolute_cap = 0.030 if phase == "crawl" else 0.25
        check(metric, "dynamic_failures", min(absolute_cap, 1.25 * c(metric) + 0.005))
    check("crossed_us", "dynamic_failures", min(150_000, c("crossed_us") + 25_000))
    check("settle_us", "dynamic_failures", min(650_000, c("settle_us") + 25_000))
    check("recover_us", "dynamic_failures", min(650_000, c("recover_us") + 25_000))
    check("tail_peak_position_error_rad", "dynamic_failures", 0.008)
    check("peak_model_a", "dynamic_failures", 1.25 * c("peak_model_a") + 0.02)

for row in gates:
    assert int(row["reason"]) == -5
    assert row["updates_before"] == row["updates_after"]
    assert row["old_session"] != row["new_session"]
    assert (float(row["peak_ff_nm"]) > 0.01) == (row["variant"] in ("C", "D"))

for row in boundaries:
    kind = int(row["kind"])
    assert row["updates_before"] == row["updates_after"]
    assert row["old_session"] != row["new_session"]
    assert float(row["motion_ff_nm"]) < -0.01 and float(row["correction_nm"]) != 0.0
    assert abs(float(row["motion_ff_nm"]) + float(row["correction_nm"]) - float(row["published_ff_nm"])) < 5e-9
    assert int(row["rejected"]) == int(kind == 1)
    assert int(row["faults"]) == (4 if kind == 2 else 0)

for name, data in (("holdout", held), ("original", early)):
    stage_stats = report[f"{name}_near_reference_zero"] = {}
    for row in records(data, "JOINT_TRACE"):
        variant = row["variant"]
        ref_v = float(row["ref_velocity_rad_s"])
        if row["stage"] not in ("4", "5") or abs(ref_v) > 0.08:
            continue
        assert isfinite(ref_v)
        r = stage_stats.setdefault(row["case"], {}).setdefault(
            variant, dict(samples=0, signs_against_model_speed_error=0, peak_requested_iq_a=0.0, peak_model_iq_a=0.0, peak_correction_nm=0.0)
        )
        r["samples"] += 1
        actual_v = float(row["model_velocity_rad_s"])
        true_error = ref_v - actual_v
        r["signs_against_model_speed_error"] += int(abs(true_error) > 0.005 and float(row["d_nm"]) * true_error < 0)
        r["peak_requested_iq_a"] = max(r["peak_requested_iq_a"], abs(float(row["iq_request_a"])))
        r["peak_model_iq_a"] = max(r["peak_model_iq_a"], abs(float(row["model_iq_a"])))
        r["peak_correction_nm"] = max(r["peak_correction_nm"], abs(float(row["host_correction_nm"])))

report["classification"] = {
    "DAMPING_NOISE_QUALITY": "FAIL" if report["noise_failures"] else "PASS",
    "DYNAMIC_RESPONSE_QUALITY": "FAIL" if report["dynamic_failures"] else "PASS",
    "SATURATION_RECOVERY": "FAIL" if report["saturation_failures"] else "PASS",
    "SAFETY_CONTRACT": "PASS",
    "JOINT_CONTROL_QUALITY": "FAIL" if any(report[group] for group in (
        "noise_failures", "dynamic_failures", "saturation_failures"
    )) else "PASS",
}
report["production_filter"] = (
    "KEEP EXISTING IMPEDANCE"
    if report["classification"]["JOINT_CONTROL_QUALITY"] == "FAIL"
    else "HOST QUALITY GATES PASSED"
)
report["original_characterization"] = list(records(early, "JOINT_RESULT"))
print(json.dumps(report, indent=2))

