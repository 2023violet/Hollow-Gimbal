#include "foc_impedance_tuning.h"
int foc_impedance_tuning_design(const struct foc_impedance_tuning_input *input,
                                struct foc_impedance_tuning_candidate *candidate)
{
    (void)input;
    *candidate = (struct foc_impedance_tuning_candidate){0};
    return FOC_IMPEDANCE_TUNING_OK;
}

