from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import json, os, shutil, subprocess as sp, sys, tempfile

root=Path(__file__).resolve().parent
repo=Path.cwd()
workspace=Path(tempfile.mkdtemp(prefix="external-",dir=root))
libs=workspace/"falconfoc-source"
consumer=workspace/"consumer"
logs=root/"external-logs"
logs.mkdir(exist_ok=True)
for path in ("calibration","sensors","core","g3","runtime","control_plane","components/utils/crc"):
    shutil.copytree(repo/path,libs/path,ignore=shutil.ignore_patterns("__pycache__","build",".git"))
shutil.copytree(repo/"tools/falconfoc-calibration-replay", consumer,
                ignore=shutil.ignore_patterns("__pycache__","build",".git"))
assert not (libs/".git").exists() and not (consumer/".git").exists()
with (logs/"source-hashes.log").open("w",encoding="utf8") as f:
    for tree in (libs,consumer):
        for path in sorted(tree.rglob("*")):
            if path.is_file():
                print(sha256(path.read_bytes()).hexdigest(),path.relative_to(workspace),file=f)
env=os.environ.copy()
llvm=Path(sp.check_output(["clang","-print-resource-dir"],text=True).strip())
env["PATH"]=os.pathsep.join([str(llvm/"lib/windows"),r"C:\mingw64\bin",env["PATH"]])
env.update(ASAN_OPTIONS="halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1",
           PYTHONDONTWRITEBYTECODE="1")
def check(variant):
    compiler="gcc" if variant=="gcc" else "clang"
    flags=["-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer",
           "-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined"] if variant=="asan" else []
    out=workspace/("build-"+variant)
    exe=out/"falconfoc-calibration-replay-runner.exe"
    cmd=[
        [compiler,"--version"],
        ["cmake","-S",consumer,"-B",out,"-G","Ninja","-DCMAKE_BUILD_TYPE=Debug",
         f"-DFALCONFOC_SOURCE_DIR={libs.as_posix()}",f"-DCMAKE_C_COMPILER={compiler}",*flags],
        ["cmake","--build",out,"--parallel","4","--target","falconfoc-calibration-replay-runner"],
        ["ctest","--test-dir",out,"--output-on-failure","--no-tests=error",
         "-R","^test-falconfoc-calibration-replay$","-V"],
    ]
    with (logs/(variant+".log")).open("w",encoding="utf8") as f:
        for args in cmd:
            print("$ "+sp.list2cmdline(list(map(str,args))),file=f,flush=True)
            sp.run(args,cwd=workspace,env=env,stdout=f,stderr=sp.STDOUT,check=True)
    report=sp.check_output([sys.executable,"-B",consumer/"replay.py","replay",consumer/"fixtures/host-valid",
                            "--runner",exe,"--json"],env=env)
    (logs/(variant+"-replay.json")).write_bytes(report)
    assert json.loads(report)["can_generate_candidate"]
    print(variant,"Git-free consumer 1/1; JSON SHA-256",sha256(report).hexdigest(),flush=True)
with ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(check,("clang","gcc","asan")))
