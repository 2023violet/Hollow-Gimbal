# PRODUCT-02D3 | Virtual Motor evidence

The native C11 observer drives the existing calibrated Virtual Current integration. Inputs are the two reviewed CQ-03 FCAL v1 packages (Generic `2ca90021`, Salient `66aded47`). The separate activity log records loaded model identity, approved 130 Hz PI gains through the restored driver readback, 200 µs H0, 500 µs H1, 2.5 A current vector cap, 2.4 V command cap and 6.0 V minimum operating bus. The calibrated encoder retains its caller-owned LUT storage through the run.

Each run starts with an independent Plant shaft pre-spin at 0, ±0.5, ±5.2 or ±18 mechanical rad/s. Fixed-speed rows hold the Plant shaft at that value with the existing Virtual Motor fixture, providing a controlled back-EMF boundary regardless of mechanical load. Free rows release mechanical dynamics and evaluate voltage demand against observed speed at every sample. The exposed encoder sees the ordinary Plant position through virtual distortion, quantization and the reviewed LUT. Neither Runtime speed nor angle is injected. The (0.35) A endpoint and (2.20) A large commands are exercised in both directions. The nonzero-Id regeneration case exercises signed d-axis math as well. An actual high-speed command reversal changes from signed 2.20 A to opposite 0.35 A after 100 ms. The 6.1 V bus remains above the Core minimum and its modulation circle exceeds the 2.4 V command cap. The 5.9 V bus is refused on the first Current attempt and yields zero accepted UPDATE. The mismatch changes Plant Rs, Ld, Lq and flux by multipliers 1.15, 0.85, 1.15 and 1.08 only. The Current vector clamp uses the actual requested `(±0.6, ±3.0) A`, and the Plant converges to the projection `(±0.4903, ±2.4515) A`.

After START at 1800 µs, the first accepted UPDATE is at 2000 µs. Accepted voltage can affect the Plant over the following interval. The CSV distinguishes `v_accepted` (new H0 receipt) from `v_applied` and `vd/vq` (the actual terminal voltage held over the interval ending at that sample). The Plant state in a row is the state before the current H0 receipt takes effect. The observer checks transaction roles, zero rejected updates under valid buses, zero accepted updates below minimum bus, and confirmed INHIBIT with unchanged UPDATE count after STOP.

The terminal comparison uses the last 100 H0 intervals (20 ms) of each segment. It rotates the applied terminal voltage to the Plant's midpoint electrical frame and compares it with independently computed voltage from the observed average Id/Iq/speed and the Plant parameters. The dynamic lane also accounts for finite-window (L,Delta i/Delta t). Iq ranges come from numerical convex minimization and bisection in Python. For a voltage-limited segment, comparison to a range boundary uses **observed Id** because saturation can take actual Id off its command. The CLI cross-check separately uses the approved FCAL model and the requested Id. Its query speed is the observed 20 ms mean; additional Salient cold-step queries check the start and end operating points. Values near the steady boundary use the CLI's 5% availability-margin threshold. Actual cap dwell uses the V1 proximity rule of 2 mV. The 5.9 V cases remain classified by bus admission.

## Results

- 60 signed runs, 64 segments after splitting reversals. Observations comprise 32 fixed-speed tracking segments, 2 free-speed tracking segments, 4 vector-clipped segments, 16 fixed-speed voltage-limited segments, 4 free-speed voltage-limited segments, 2 Salient changing-speed crossings and 4 rejects for 5.9 V bus.
- Maximum fixed-speed steady d/q residual 0.322 mV, maximum derivative-adjusted residual across running segments 1.405 mV. Terminal Iq was within 4.405 mA of the independent voltage-boundary result over saturated steady/changing-speed windows evaluated using observed Id and speed.
- At ±18 rad/s, Generic tracks ±0.35 A and settles near ±0.991 A for a ±2.20 A same-direction command. Demand is 2.010 V and 3.129 V respectively. Salient needs 2.578 V for ±0.35 A and 4.035 V for ±2.20 A, and reaches approximately ±0.123 A and ±0.120 A. Opposite-sign Iq is reachable under the same fixed speed and bus. Full 2.4 V cap dwell is recorded in the corresponding saturated tails.
- At ±5.2 rad/s, nominal Salient ±2.20 A needs 2.384 V and tracks. Perturbed Salient needs 2.695 V and reaches ±1.872 A at the 2.4 V cap. The CLI sees the unchanged approved model and therefore correctly returns `MODEL_FEASIBLE` with near-cap margin for the supplied parameters. The Plant mismatch is independent evidence that a nominal verdict cannot establish behavior under unknown actual R/L/flux.
- 84 production CLI queries matched independently computed voltage, reasons, intervals and verdicts. They cover 64 trajectory segment means, 4 Salient start/tail points and 16 signed torque cases at Id=0. The CLI returned 46 feasible and 38 infeasible with no application. The maximum absolute numeric difference of the compared scalars was (9.86	imes10^{-8}) in their reported units.
- The original Salient V1 CSV reproduced byte-for-byte at SHA-256 `4c25fbec05b9745dfc512112fe48c7ca17bd6aa37cc4af2a7588cd92db698b22`; its original scorer exits 1. Both directions took 4.8 ms after first output application. At 4 ms, measured |Iq| was 1.905–1.907 A against the 1.98 A entering edge; target steady demand 1.756 V, applied output 1.769–1.776 V with the initial clipping already exited. A same-gains fixed-zero-speed counterfactual also took 4.8 ms and settled to ±2.20 A without sustained clipping. The 200 µs publication-to-application wait is separately recorded and outside the V1 timer. Early transient voltage clipping and closed-loop current dynamics both appear in the trajectory, while rising speed produces a separate tail voltage limit. At 61.8 ms the rotor was at approximately ±6.904 rad/s, demand 2.603 V, output at 2.4 V, |Iq|≈1.9875 A.

These are synthetic average-value Plant observations. The held-speed fixture supplies mechanical reaction torque. Terminal voltage uses the Simulator's declared average-duty behavior in the active portion, and its disabled Plant model uses zero terminal voltage. Hardware behavior, inverter dead-time, target execution time and power-stage safety are outside this evidence.

## Reproduce

From the extracted archive root in PowerShell, set `$baseline` to the frozen PRODUCT-02 input source and `$final` to the source containing the PRODUCT-02 reachability CLI. The same commands used GCC 16.2.0, Ninja, CMake, and Python 3.13. Use a distinct build directory. Output names below use the same directory as the scripts. The reproduction CSV uses a temporary directory before replacing the archived copy, respecting the native command's exclusive file-save semantics.

```powershell
$reach = (Resolve-Path ./reachability).Path
$env:FALCON_REACH_PROBE_SOURCE = "$reach/reach_probe.c"
cmake -S "$baseline/simulation" -B "$reach/probe-build" -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=gcc "-DCMAKE_PROJECT_INCLUDE=$reach/reach_inject.cmake"
cmake --build "$reach/probe-build" --target reach-probe falconfoc-virtual-calibrate --parallel 4
& "$reach/probe-build/reach-probe.exe" GENERIC_RESEARCH_MOTOR "$reach/../cq03/startup/active-generic.fcal" 1> "$reach/generic.csv" 2> "$reach/generic.log"
& "$reach/probe-build/reach-probe.exe" CALIBRATION_SALIENT_MOTOR "$reach/../cq03/startup/active-salient.fcal" 1> "$reach/salient.csv" 2> "$reach/salient.log"
$replay = New-Item -ItemType Directory (Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString()))
& "$reach/probe-build/falconfoc-virtual-calibrate.exe" --profile-id CALIBRATION_SALIENT_MOTOR --approve-candidate 66aded47 --cq-startup-csv "$replay/salient-v1-reproduced.csv" > "$reach/salient-v1-reproduced.jsonl"
Copy-Item "$replay/salient-v1-reproduced.csv" "$reach/salient-v1-reproduced.csv" -Force
python "$reach/../cq03/startup/current_startup_quality.py" CALIBRATION_SALIENT_MOTOR "$reach/salient-v1-reproduced.csv" > "$reach/salient-v1-quality.json"
# Scorer exits 1 for the reproduced V1 quality failure.
python -B "$reach/analyze.py" > "$reach/summary.json"
cmake -S "$final/simulation" -B "$reach/final-build" -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=gcc
cmake --build "$reach/final-build" --target falconfoc-virtual-calibrate --parallel 4
python -B "$reach/crosscheck_cli.py" "$reach/final-build/falconfoc-virtual-calibrate.exe" > "$reach/cli-crosscheck.json"
```

The failed development attempt in which the probe's caller-owned LUT storage expired has no bearing on product behavior and is omitted from the evidence bundle. The published probe holds the buffer for the full driver lifetime and all reported results use that version.
