The candidate ZIP is a separate internal local artifact.
servo-03b.patch contains all new/changed project text files from this stage.
The generated binary evidence bundle is delivered separately.
