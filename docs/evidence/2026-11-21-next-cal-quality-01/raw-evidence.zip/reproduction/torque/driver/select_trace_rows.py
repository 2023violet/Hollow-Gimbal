"""Export exact trace rows for browsing while keeping the full hashes."""
import csv
from pathlib import Path
from sys import argv

replay, output = map(Path, argv[1:])
for name in ("baseline", "candidate"):
    for lane, time_field in (("h0", "h0_us"), ("h1", "relative_us")):
        with (replay / f"{name}-{lane}.csv").open(newline="", encoding="ascii") as f:
            rs = csv.DictReader(f)
            with (output / f"{name}-{lane}-selected.csv").open("w", newline="", encoding="ascii") as out:
                ws = csv.DictWriter(out, rs.fieldnames)
                ws.writeheader()
                for row in rs:
                    stamp = int(row[time_field]) - (2000 if lane == "h0" else 0)
                    stop_event = lane == "h0" and 1_401_000 <= stamp + 2000 <= 1_402_300
                    load_edge = stamp in range(799_000, 802_000) or stamp in range(1_499_000, 1_502_000)
                    if stamp % 10_000 == 0 or stop_event or load_edge:
                        ws.writerow(row)

