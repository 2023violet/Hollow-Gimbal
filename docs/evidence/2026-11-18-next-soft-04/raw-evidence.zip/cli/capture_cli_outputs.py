from hashlib import sha256
import json
from pathlib import Path
import struct
from subprocess import run
import zlib

root = Path(__file__).resolve().parent
build = root / 'build-clang'
fixture = build / 'falconfoc-config-fixtures.exe'
inspector = build / 'falconfoc-config-inspector.exe'
profile = ['--profile', 'host-fixture-v1']
images = {}
for mode in ('normal', 'other-encoder', 'interrupted', 'ack-lost'):
    target = root / (mode + '.bin')
    result = run([fixture, mode], capture_output=True, check=True, timeout=15)
    assert len(result.stdout) == 512 and not result.stderr
    target.write_bytes(result.stdout)
    images[mode] = target

bad_crc = bytearray(images['normal'].read_bytes())
bad_crc[256 + 56] ^= 1
path = root / 'bad-crc.bin'
path.write_bytes(bad_crc)
images['bad-crc'] = path

future_schema = bytearray(images['normal'].read_bytes())
struct.pack_into('<H', future_schema, 256 + 10, 3)
payload = struct.unpack_from('<H', future_schema, 256 + 16)[0]
crc = zlib.crc32(future_schema[256 + 4 : 256 + 52] + future_schema[256 + 56 : 256 + 56 + payload])
struct.pack_into('<I', future_schema, 256 + 52, crc)
path = root / 'future-schema.bin'
path.write_bytes(future_schema)
images['future-schema'] = path

before = {name: sha256(path.read_bytes()).hexdigest() for name, path in images.items()}

def capture(name, args, returns=0):
    result = run([inspector, *args], capture_output=True, check=False, timeout=15)
    assert result.returncode == returns, result.stderr
    if returns == 0:
        assert not result.stderr
        suffix = '.json' if '--json' in args else '.txt'
        if suffix == '.json':
            assert json.loads(result.stdout)['schema_version'] == 1
        (root / (name + suffix)).write_bytes(result.stdout)
    else:
        assert not result.stdout
        (root / (name + '.stderr.txt')).write_bytes(result.stderr)

for name, path in images.items():
    capture('inspect-' + name, ['inspect', *profile, path])
    capture('inspect-' + name, ['inspect', '--json', *profile, path])
capture('inspect-integrity-only', ['inspect', '--json', images['normal']])
capture('diff-a-b', ['diff', *profile, images['normal']])
capture('diff-a-b', ['diff', '--json', *profile, images['normal']])
capture('diff-selected-default', ['diff', '--json', *profile, '--against-default', images['normal']])
capture('diff-selected-default', ['diff', *profile, '--against-default', images['normal']])
capture('diff-identity-rejected', ['diff', '--json', *profile, images['normal'], images['other-encoder']])
capture('explain-reinit', ['explain', '--json', 'REINITIALIZATION_REQUIRED'])
capture('explain-migration', ['explain', 'MIGRATION_REQUIRED'])

for size in (511, 513):
    path = root / ('input-' + str(size) + '.bin')
    path.write_bytes(images['normal'].read_bytes()[:size] + bytes(max(0, size - 512)))
    capture('reject-' + str(size), ['inspect', '--json', path], returns=2)
    assert path.stat().st_size == size

after = {name: sha256(path.read_bytes()).hexdigest() for name, path in images.items()}
assert before == after
(root / 'image-hashes.json').write_text(
    json.dumps({'before': before, 'after': after, 'all_equal': before == after}, indent=2) + '\n',
    encoding='utf-8',
)
